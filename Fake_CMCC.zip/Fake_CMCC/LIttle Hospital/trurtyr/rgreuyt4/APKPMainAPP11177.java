package tyuyu.trurtyr.rgreuyt4;

import android.app.Application;

public class APKPMainAPP11177 extends Application {
  public APKPMainAPP11177() {
    System.loadLibrary("APKProtect");
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeCMCC-dex2jar.jar!/tyuyu/trurtyr/rgreuyt4/APKPMainAPP11177.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */