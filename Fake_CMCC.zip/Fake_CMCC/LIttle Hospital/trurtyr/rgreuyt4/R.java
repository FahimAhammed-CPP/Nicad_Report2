package tyuyu.trurtyr.rgreuyt4;

public final class R {
  public static final class attr {}
  
  public static final class dimen {
    public static final int activity_horizontal_margin = 2131034112;
    
    public static final int activity_vertical_margin = 2131034113;
  }
  
  public static final class drawable {
    public static final int qq = 2130837504;
  }
  
  public static final class layout {
    public static final int activity_main = 2130903040;
  }
  
  public static final class string {
    public static final int action_settings = 2131099649;
    
    public static final int app_name = 2131099648;
    
    public static final int hello_world = 2131099650;
  }
  
  public static final class style {
    public static final int AppBaseTheme = 2131165184;
    
    public static final int AppTheme = 2131165185;
  }
  
  public static final class xml {
    public static final int device_admin_sample = 2130968576;
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeCMCC-dex2jar.jar!/tyuyu/trurtyr/rgreuyt4/R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */