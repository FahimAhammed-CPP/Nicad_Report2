package android.support.v4.text;

import java.util.Locale;

public final class BidiFormatter {
  private static final int DEFAULT_FLAGS = 2;
  
  private static final BidiFormatter DEFAULT_LTR_INSTANCE;
  
  private static final BidiFormatter DEFAULT_RTL_INSTANCE;
  
  private static TextDirectionHeuristicCompat DEFAULT_TEXT_DIRECTION_HEURISTIC = TextDirectionHeuristicsCompat.FIRSTSTRONG_LTR;
  
  private static final int DIR_LTR = -1;
  
  private static final int DIR_RTL = 1;
  
  private static final int DIR_UNKNOWN = 0;
  
  private static final String EMPTY_STRING = "";
  
  private static final int FLAG_STEREO_RESET = 2;
  
  private static final char LRE = '‪';
  
  private static final char LRM = '‎';
  
  private static final String LRM_STRING = Character.toString('‎');
  
  private static final char PDF = '‬';
  
  private static final char RLE = '‫';
  
  private static final char RLM = '‏';
  
  private static final String RLM_STRING = Character.toString('‏');
  
  private final TextDirectionHeuristicCompat mDefaultTextDirectionHeuristicCompat;
  
  private final int mFlags;
  
  private final boolean mIsRtlContext;
  
  static {
    DEFAULT_LTR_INSTANCE = new BidiFormatter(false, 2, DEFAULT_TEXT_DIRECTION_HEURISTIC);
    DEFAULT_RTL_INSTANCE = new BidiFormatter(true, 2, DEFAULT_TEXT_DIRECTION_HEURISTIC);
  }
  
  private BidiFormatter(boolean paramBoolean, int paramInt, TextDirectionHeuristicCompat paramTextDirectionHeuristicCompat) {
    this.mIsRtlContext = paramBoolean;
    this.mFlags = paramInt;
    this.mDefaultTextDirectionHeuristicCompat = paramTextDirectionHeuristicCompat;
  }
  
  private static int getEntryDir(String paramString) {
    return (new DirectionalityEstimator(paramString, false)).getEntryDir();
  }
  
  private static int getExitDir(String paramString) {
    return (new DirectionalityEstimator(paramString, false)).getExitDir();
  }
  
  public static BidiFormatter getInstance() {
    return (new Builder()).build();
  }
  
  public static BidiFormatter getInstance(Locale paramLocale) {
    return (new Builder(paramLocale)).build();
  }
  
  public static BidiFormatter getInstance(boolean paramBoolean) {
    return (new Builder(paramBoolean)).build();
  }
  
  private static boolean isRtlLocale(Locale paramLocale) {
    boolean bool = true;
    if (TextUtilsCompat.getLayoutDirectionFromLocale(paramLocale) != 1)
      bool = false; 
    return bool;
  }
  
  private String markAfter(String paramString, TextDirectionHeuristicCompat paramTextDirectionHeuristicCompat) {
    boolean bool = paramTextDirectionHeuristicCompat.isRtl(paramString, 0, paramString.length());
    return (!this.mIsRtlContext && (bool || getExitDir(paramString) == 1)) ? LRM_STRING : ((this.mIsRtlContext && (!bool || getExitDir(paramString) == -1)) ? RLM_STRING : "");
  }
  
  private String markBefore(String paramString, TextDirectionHeuristicCompat paramTextDirectionHeuristicCompat) {
    boolean bool = paramTextDirectionHeuristicCompat.isRtl(paramString, 0, paramString.length());
    return (!this.mIsRtlContext && (bool || getEntryDir(paramString) == 1)) ? LRM_STRING : ((this.mIsRtlContext && (!bool || getEntryDir(paramString) == -1)) ? RLM_STRING : "");
  }
  
  public boolean getStereoReset() {
    return ((this.mFlags & 0x2) != 0);
  }
  
  public boolean isRtl(String paramString) {
    return this.mDefaultTextDirectionHeuristicCompat.isRtl(paramString, 0, paramString.length());
  }
  
  public boolean isRtlContext() {
    return this.mIsRtlContext;
  }
  
  public String unicodeWrap(String paramString) {
    return unicodeWrap(paramString, this.mDefaultTextDirectionHeuristicCompat, true);
  }
  
  public String unicodeWrap(String paramString, TextDirectionHeuristicCompat paramTextDirectionHeuristicCompat) {
    return unicodeWrap(paramString, paramTextDirectionHeuristicCompat, true);
  }
  
  public String unicodeWrap(String paramString, TextDirectionHeuristicCompat paramTextDirectionHeuristicCompat, boolean paramBoolean) {
    boolean bool = paramTextDirectionHeuristicCompat.isRtl(paramString, 0, paramString.length());
    StringBuilder stringBuilder = new StringBuilder();
    if (getStereoReset() && paramBoolean) {
      if (bool) {
        paramTextDirectionHeuristicCompat = TextDirectionHeuristicsCompat.RTL;
      } else {
        paramTextDirectionHeuristicCompat = TextDirectionHeuristicsCompat.LTR;
      } 
      stringBuilder.append(markBefore(paramString, paramTextDirectionHeuristicCompat));
    } 
    if (bool != this.mIsRtlContext) {
      char c;
      if (bool) {
        char c1 = '‫';
        c = c1;
      } else {
        char c1 = '‪';
        c = c1;
      } 
      stringBuilder.append(c);
      stringBuilder.append(paramString);
      stringBuilder.append('‬');
    } else {
      stringBuilder.append(paramString);
    } 
    if (paramBoolean) {
      if (bool) {
        paramTextDirectionHeuristicCompat = TextDirectionHeuristicsCompat.RTL;
      } else {
        paramTextDirectionHeuristicCompat = TextDirectionHeuristicsCompat.LTR;
      } 
      stringBuilder.append(markAfter(paramString, paramTextDirectionHeuristicCompat));
    } 
    return stringBuilder.toString();
  }
  
  public String unicodeWrap(String paramString, boolean paramBoolean) {
    return unicodeWrap(paramString, this.mDefaultTextDirectionHeuristicCompat, paramBoolean);
  }
  
  public static final class Builder {
    private int mFlags;
    
    private boolean mIsRtlContext;
    
    private TextDirectionHeuristicCompat mTextDirectionHeuristicCompat;
    
    public Builder() {
      initialize(BidiFormatter.isRtlLocale(Locale.getDefault()));
    }
    
    public Builder(Locale param1Locale) {
      initialize(BidiFormatter.isRtlLocale(param1Locale));
    }
    
    public Builder(boolean param1Boolean) {
      initialize(param1Boolean);
    }
    
    private static BidiFormatter getDefaultInstanceFromContext(boolean param1Boolean) {
      return param1Boolean ? BidiFormatter.DEFAULT_RTL_INSTANCE : BidiFormatter.DEFAULT_LTR_INSTANCE;
    }
    
    private void initialize(boolean param1Boolean) {
      this.mIsRtlContext = param1Boolean;
      this.mTextDirectionHeuristicCompat = BidiFormatter.DEFAULT_TEXT_DIRECTION_HEURISTIC;
      this.mFlags = 2;
    }
    
    public BidiFormatter build() {
      return (this.mFlags == 2 && this.mTextDirectionHeuristicCompat == BidiFormatter.DEFAULT_TEXT_DIRECTION_HEURISTIC) ? getDefaultInstanceFromContext(this.mIsRtlContext) : new BidiFormatter(this.mIsRtlContext, this.mFlags, this.mTextDirectionHeuristicCompat);
    }
    
    public Builder setTextDirectionHeuristic(TextDirectionHeuristicCompat param1TextDirectionHeuristicCompat) {
      this.mTextDirectionHeuristicCompat = param1TextDirectionHeuristicCompat;
      return this;
    }
    
    public Builder stereoReset(boolean param1Boolean) {
      if (param1Boolean) {
        this.mFlags |= 0x2;
        return this;
      } 
      this.mFlags &= 0xFFFFFFFD;
      return this;
    }
  }
  
  private static class DirectionalityEstimator {
    private static final byte[] DIR_TYPE_CACHE = new byte[1792];
    
    private static final int DIR_TYPE_CACHE_SIZE = 1792;
    
    private int charIndex;
    
    private final boolean isHtml;
    
    private char lastChar;
    
    private final int length;
    
    private final String text;
    
    static {
      for (byte b = 0; b < '܀'; b++)
        DIR_TYPE_CACHE[b] = Character.getDirectionality(b); 
    }
    
    DirectionalityEstimator(String param1String, boolean param1Boolean) {
      this.text = param1String;
      this.isHtml = param1Boolean;
      this.length = param1String.length();
    }
    
    private static byte getCachedDirectionality(char param1Char) {
      if (param1Char < '܀')
        return DIR_TYPE_CACHE[param1Char]; 
      return Character.getDirectionality(param1Char);
    }
    
    private byte skipEntityBackward() {
      // Byte code:
      //   0: aload_0
      //   1: getfield charIndex : I
      //   4: istore_1
      //   5: aload_0
      //   6: getfield charIndex : I
      //   9: ifle -> 65
      //   12: aload_0
      //   13: getfield text : Ljava/lang/String;
      //   16: astore_2
      //   17: aload_0
      //   18: getfield charIndex : I
      //   21: iconst_1
      //   22: isub
      //   23: istore_3
      //   24: aload_0
      //   25: iload_3
      //   26: putfield charIndex : I
      //   29: aload_0
      //   30: aload_2
      //   31: iload_3
      //   32: invokevirtual charAt : (I)C
      //   35: putfield lastChar : C
      //   38: aload_0
      //   39: getfield lastChar : C
      //   42: bipush #38
      //   44: if_icmpne -> 56
      //   47: bipush #12
      //   49: istore_1
      //   50: iload_1
      //   51: istore #4
      //   53: iload #4
      //   55: ireturn
      //   56: aload_0
      //   57: getfield lastChar : C
      //   60: bipush #59
      //   62: if_icmpne -> 5
      //   65: aload_0
      //   66: iload_1
      //   67: putfield charIndex : I
      //   70: aload_0
      //   71: bipush #59
      //   73: i2c
      //   74: putfield lastChar : C
      //   77: bipush #13
      //   79: istore_1
      //   80: iload_1
      //   81: istore #4
      //   83: goto -> 53
    }
    
    private byte skipEntityForward() {
      while (this.charIndex < this.length) {
        String str = this.text;
        int i = this.charIndex;
        this.charIndex = i + 1;
        i = str.charAt(i);
        this.lastChar = (char)i;
        if (i == 59)
          break; 
      } 
      return 12;
    }
    
    private byte skipTagBackward() {
      int i = this.charIndex;
      while (true) {
        if (this.charIndex > 0) {
          String str = this.text;
          int j = this.charIndex - 1;
          this.charIndex = j;
          this.lastChar = str.charAt(j);
          if (this.lastChar == '<') {
            i = 12;
            return i;
          } 
          if (this.lastChar != '>') {
            if (this.lastChar == '"' || this.lastChar == '\'') {
              j = this.lastChar;
              while (this.charIndex > 0) {
                str = this.text;
                int k = this.charIndex - 1;
                this.charIndex = k;
                k = str.charAt(k);
                this.lastChar = (char)k;
                if (k != j);
              } 
            } 
            continue;
          } 
        } 
        this.charIndex = i;
        this.lastChar = (char)'>';
        i = 13;
        return i;
      } 
    }
    
    private byte skipTagForward() {
      // Byte code:
      //   0: aload_0
      //   1: getfield charIndex : I
      //   4: istore_1
      //   5: aload_0
      //   6: getfield charIndex : I
      //   9: aload_0
      //   10: getfield length : I
      //   13: if_icmpge -> 137
      //   16: aload_0
      //   17: getfield text : Ljava/lang/String;
      //   20: astore_2
      //   21: aload_0
      //   22: getfield charIndex : I
      //   25: istore_3
      //   26: aload_0
      //   27: iload_3
      //   28: iconst_1
      //   29: iadd
      //   30: putfield charIndex : I
      //   33: aload_0
      //   34: aload_2
      //   35: iload_3
      //   36: invokevirtual charAt : (I)C
      //   39: putfield lastChar : C
      //   42: aload_0
      //   43: getfield lastChar : C
      //   46: bipush #62
      //   48: if_icmpne -> 60
      //   51: bipush #12
      //   53: istore_1
      //   54: iload_1
      //   55: istore #4
      //   57: iload #4
      //   59: ireturn
      //   60: aload_0
      //   61: getfield lastChar : C
      //   64: bipush #34
      //   66: if_icmpeq -> 78
      //   69: aload_0
      //   70: getfield lastChar : C
      //   73: bipush #39
      //   75: if_icmpne -> 5
      //   78: aload_0
      //   79: getfield lastChar : C
      //   82: istore_3
      //   83: aload_0
      //   84: getfield charIndex : I
      //   87: aload_0
      //   88: getfield length : I
      //   91: if_icmpge -> 5
      //   94: aload_0
      //   95: getfield text : Ljava/lang/String;
      //   98: astore_2
      //   99: aload_0
      //   100: getfield charIndex : I
      //   103: istore #5
      //   105: aload_0
      //   106: iload #5
      //   108: iconst_1
      //   109: iadd
      //   110: putfield charIndex : I
      //   113: aload_2
      //   114: iload #5
      //   116: invokevirtual charAt : (I)C
      //   119: istore #5
      //   121: aload_0
      //   122: iload #5
      //   124: i2c
      //   125: putfield lastChar : C
      //   128: iload #5
      //   130: iload_3
      //   131: if_icmpeq -> 5
      //   134: goto -> 83
      //   137: aload_0
      //   138: iload_1
      //   139: putfield charIndex : I
      //   142: aload_0
      //   143: bipush #60
      //   145: i2c
      //   146: putfield lastChar : C
      //   149: bipush #13
      //   151: istore_1
      //   152: iload_1
      //   153: istore #4
      //   155: goto -> 57
    }
    
    byte dirTypeBackward() {
      this.lastChar = this.text.charAt(this.charIndex - 1);
      if (Character.isLowSurrogate(this.lastChar)) {
        int i = Character.codePointBefore(this.text, this.charIndex);
        this.charIndex -= Character.charCount(i);
        i = Character.getDirectionality(i);
        return i;
      } 
      this.charIndex--;
      byte b = getCachedDirectionality(this.lastChar);
      byte b1 = b;
      if (this.isHtml) {
        if (this.lastChar == '>') {
          b = skipTagBackward();
          return b;
        } 
        b1 = b;
        if (this.lastChar == ';') {
          b = skipEntityBackward();
          b1 = b;
        } 
      } 
      return b1;
    }
    
    byte dirTypeForward() {
      this.lastChar = this.text.charAt(this.charIndex);
      if (Character.isHighSurrogate(this.lastChar)) {
        int i = Character.codePointAt(this.text, this.charIndex);
        this.charIndex += Character.charCount(i);
        i = Character.getDirectionality(i);
        return i;
      } 
      this.charIndex++;
      byte b = getCachedDirectionality(this.lastChar);
      byte b1 = b;
      if (this.isHtml) {
        if (this.lastChar == '<') {
          b = skipTagForward();
          return b;
        } 
        b1 = b;
        if (this.lastChar == '&') {
          b = skipEntityForward();
          b1 = b;
        } 
      } 
      return b1;
    }
    
    int getEntryDir() {
      // Byte code:
      //   0: aload_0
      //   1: iconst_0
      //   2: putfield charIndex : I
      //   5: iconst_0
      //   6: istore_1
      //   7: iconst_0
      //   8: istore_2
      //   9: iconst_0
      //   10: istore_3
      //   11: aload_0
      //   12: getfield charIndex : I
      //   15: aload_0
      //   16: getfield length : I
      //   19: if_icmpge -> 179
      //   22: iload_3
      //   23: ifne -> 179
      //   26: aload_0
      //   27: invokevirtual dirTypeForward : ()B
      //   30: tableswitch default -> 120, 0 -> 149, 1 -> 164, 2 -> 164, 3 -> 120, 4 -> 120, 5 -> 120, 6 -> 120, 7 -> 120, 8 -> 120, 9 -> 11, 10 -> 120, 11 -> 120, 12 -> 120, 13 -> 120, 14 -> 125, 15 -> 125, 16 -> 133, 17 -> 133, 18 -> 141
      //   120: iload_1
      //   121: istore_3
      //   122: goto -> 11
      //   125: iinc #1, 1
      //   128: iconst_m1
      //   129: istore_2
      //   130: goto -> 11
      //   133: iinc #1, 1
      //   136: iconst_1
      //   137: istore_2
      //   138: goto -> 11
      //   141: iinc #1, -1
      //   144: iconst_0
      //   145: istore_2
      //   146: goto -> 11
      //   149: iload_1
      //   150: ifne -> 159
      //   153: iconst_m1
      //   154: istore #4
      //   156: iload #4
      //   158: ireturn
      //   159: iload_1
      //   160: istore_3
      //   161: goto -> 11
      //   164: iload_1
      //   165: ifne -> 174
      //   168: iconst_1
      //   169: istore #4
      //   171: goto -> 156
      //   174: iload_1
      //   175: istore_3
      //   176: goto -> 11
      //   179: iload_3
      //   180: ifne -> 189
      //   183: iconst_0
      //   184: istore #4
      //   186: goto -> 156
      //   189: iload_2
      //   190: istore #4
      //   192: iload_2
      //   193: ifne -> 156
      //   196: aload_0
      //   197: getfield charIndex : I
      //   200: ifle -> 283
      //   203: aload_0
      //   204: invokevirtual dirTypeBackward : ()B
      //   207: tableswitch default -> 240, 14 -> 243, 15 -> 243, 16 -> 260, 17 -> 260, 18 -> 277
      //   240: goto -> 196
      //   243: iload_3
      //   244: iload_1
      //   245: if_icmpne -> 254
      //   248: iconst_m1
      //   249: istore #4
      //   251: goto -> 156
      //   254: iinc #1, -1
      //   257: goto -> 196
      //   260: iload_3
      //   261: iload_1
      //   262: if_icmpne -> 271
      //   265: iconst_1
      //   266: istore #4
      //   268: goto -> 156
      //   271: iinc #1, -1
      //   274: goto -> 196
      //   277: iinc #1, 1
      //   280: goto -> 196
      //   283: iconst_0
      //   284: istore #4
      //   286: goto -> 156
    }
    
    int getExitDir() {
      // Byte code:
      //   0: iconst_m1
      //   1: istore_1
      //   2: aload_0
      //   3: aload_0
      //   4: getfield length : I
      //   7: putfield charIndex : I
      //   10: iconst_0
      //   11: istore_2
      //   12: iconst_0
      //   13: istore_3
      //   14: aload_0
      //   15: getfield charIndex : I
      //   18: ifle -> 200
      //   21: aload_0
      //   22: invokevirtual dirTypeBackward : ()B
      //   25: tableswitch default -> 116, 0 -> 125, 1 -> 158, 2 -> 158, 3 -> 116, 4 -> 116, 5 -> 116, 6 -> 116, 7 -> 116, 8 -> 116, 9 -> 14, 10 -> 116, 11 -> 116, 12 -> 116, 13 -> 116, 14 -> 144, 15 -> 144, 16 -> 177, 17 -> 177, 18 -> 194
      //   116: iload_3
      //   117: ifne -> 14
      //   120: iload_2
      //   121: istore_3
      //   122: goto -> 14
      //   125: iload_2
      //   126: ifne -> 135
      //   129: iload_1
      //   130: istore #4
      //   132: iload #4
      //   134: ireturn
      //   135: iload_3
      //   136: ifne -> 14
      //   139: iload_2
      //   140: istore_3
      //   141: goto -> 14
      //   144: iload_1
      //   145: istore #4
      //   147: iload_3
      //   148: iload_2
      //   149: if_icmpeq -> 132
      //   152: iinc #2, -1
      //   155: goto -> 14
      //   158: iload_2
      //   159: ifne -> 168
      //   162: iconst_1
      //   163: istore #4
      //   165: goto -> 132
      //   168: iload_3
      //   169: ifne -> 14
      //   172: iload_2
      //   173: istore_3
      //   174: goto -> 14
      //   177: iload_3
      //   178: iload_2
      //   179: if_icmpne -> 188
      //   182: iconst_1
      //   183: istore #4
      //   185: goto -> 132
      //   188: iinc #2, -1
      //   191: goto -> 14
      //   194: iinc #2, 1
      //   197: goto -> 14
      //   200: iconst_0
      //   201: istore #4
      //   203: goto -> 132
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeCMCC-dex2jar.jar!/android/support/v4/text/BidiFormatter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */