package android.support.v4.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.view.AccessibilityDelegateCompat;
import android.support.v4.view.MotionEventCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;

public class SlidingPaneLayout extends ViewGroup {
  private static final int DEFAULT_FADE_COLOR = -858993460;
  
  private static final int DEFAULT_OVERHANG_SIZE = 32;
  
  static final SlidingPanelLayoutImpl IMPL = new SlidingPanelLayoutImplBase();
  
  private static final int MIN_FLING_VELOCITY = 400;
  
  private static final String TAG = "SlidingPaneLayout";
  
  private boolean mCanSlide;
  
  private int mCoveredFadeColor;
  
  private final ViewDragHelper mDragHelper;
  
  private boolean mFirstLayout = true;
  
  private float mInitialMotionX;
  
  private float mInitialMotionY;
  
  private boolean mIsUnableToDrag;
  
  private final int mOverhangSize;
  
  private PanelSlideListener mPanelSlideListener;
  
  private int mParallaxBy;
  
  private float mParallaxOffset;
  
  private final ArrayList<DisableLayerRunnable> mPostedRunnables = new ArrayList<DisableLayerRunnable>();
  
  private boolean mPreservedOpenState;
  
  private Drawable mShadowDrawable;
  
  private float mSlideOffset;
  
  private int mSlideRange;
  
  private View mSlideableView;
  
  private int mSliderFadeColor = -858993460;
  
  private final Rect mTmpRect = new Rect();
  
  public SlidingPaneLayout(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public SlidingPaneLayout(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public SlidingPaneLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    float f = (paramContext.getResources().getDisplayMetrics()).density;
    this.mOverhangSize = (int)(32.0F * f + 0.5F);
    ViewConfiguration.get(paramContext);
    setWillNotDraw(false);
    ViewCompat.setAccessibilityDelegate((View)this, new AccessibilityDelegate());
    ViewCompat.setImportantForAccessibility((View)this, 1);
    this.mDragHelper = ViewDragHelper.create(this, 0.5F, new DragHelperCallback());
    this.mDragHelper.setEdgeTrackingEnabled(1);
    this.mDragHelper.setMinVelocity(400.0F * f);
  }
  
  private boolean closePane(View paramView, int paramInt) {
    boolean bool = false;
    if (this.mFirstLayout || smoothSlideTo(0.0F, paramInt)) {
      this.mPreservedOpenState = false;
      bool = true;
    } 
    return bool;
  }
  
  private void dimChildView(View paramView, float paramFloat, int paramInt) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    if (paramFloat > 0.0F && paramInt != 0) {
      int i = (int)(((0xFF000000 & paramInt) >>> 24) * paramFloat);
      if (layoutParams.dimPaint == null)
        layoutParams.dimPaint = new Paint(); 
      layoutParams.dimPaint.setColorFilter((ColorFilter)new PorterDuffColorFilter(i << 24 | 0xFFFFFF & paramInt, PorterDuff.Mode.SRC_OVER));
      if (ViewCompat.getLayerType(paramView) != 2)
        ViewCompat.setLayerType(paramView, 2, layoutParams.dimPaint); 
      invalidateChildRegion(paramView);
      return;
    } 
    if (ViewCompat.getLayerType(paramView) != 0) {
      if (layoutParams.dimPaint != null)
        layoutParams.dimPaint.setColorFilter(null); 
      DisableLayerRunnable disableLayerRunnable = new DisableLayerRunnable(paramView);
      this.mPostedRunnables.add(disableLayerRunnable);
      ViewCompat.postOnAnimation((View)this, disableLayerRunnable);
    } 
  }
  
  private void invalidateChildRegion(View paramView) {
    IMPL.invalidateChildRegion(this, paramView);
  }
  
  private void onPanelDragged(int paramInt) {
    LayoutParams layoutParams = (LayoutParams)this.mSlideableView.getLayoutParams();
    this.mSlideOffset = (paramInt - getPaddingLeft() + layoutParams.leftMargin) / this.mSlideRange;
    if (this.mParallaxBy != 0)
      parallaxOtherViews(this.mSlideOffset); 
    if (layoutParams.dimWhenOffset)
      dimChildView(this.mSlideableView, this.mSlideOffset, this.mSliderFadeColor); 
    dispatchOnPanelSlide(this.mSlideableView);
  }
  
  private boolean openPane(View paramView, int paramInt) {
    null = true;
    if (this.mFirstLayout || smoothSlideTo(1.0F, paramInt)) {
      this.mPreservedOpenState = true;
      return null;
    } 
    return false;
  }
  
  private void parallaxOtherViews(float paramFloat) {
    boolean bool;
    LayoutParams layoutParams = (LayoutParams)this.mSlideableView.getLayoutParams();
    if (layoutParams.dimWhenOffset && layoutParams.leftMargin <= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      if (view != this.mSlideableView) {
        int j = (int)((1.0F - this.mParallaxOffset) * this.mParallaxBy);
        this.mParallaxOffset = paramFloat;
        view.offsetLeftAndRight(j - (int)((1.0F - paramFloat) * this.mParallaxBy));
        if (bool)
          dimChildView(view, 1.0F - this.mParallaxOffset, this.mCoveredFadeColor); 
      } 
    } 
  }
  
  private static boolean viewIsOpaque(View paramView) {
    boolean bool = true;
    if (!ViewCompat.isOpaque(paramView)) {
      if (Build.VERSION.SDK_INT >= 18)
        return false; 
      Drawable drawable = paramView.getBackground();
      if (drawable != null) {
        if (drawable.getOpacity() != -1)
          bool = false; 
        return bool;
      } 
      bool = false;
    } 
    return bool;
  }
  
  protected boolean canScroll(View paramView, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3) {
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      int i = paramView.getScrollX();
      int j = paramView.getScrollY();
      for (int k = viewGroup.getChildCount() - 1; k >= 0; k--) {
        View view = viewGroup.getChildAt(k);
        if (paramInt2 + i >= view.getLeft() && paramInt2 + i < view.getRight() && paramInt3 + j >= view.getTop() && paramInt3 + j < view.getBottom() && canScroll(view, true, paramInt1, paramInt2 + i - view.getLeft(), paramInt3 + j - view.getTop()))
          return true; 
      } 
    } 
    return (paramBoolean && ViewCompat.canScrollHorizontally(paramView, -paramInt1));
  }
  
  @Deprecated
  public boolean canSlide() {
    return this.mCanSlide;
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof LayoutParams && super.checkLayoutParams(paramLayoutParams));
  }
  
  public boolean closePane() {
    return closePane(this.mSlideableView, 0);
  }
  
  public void computeScroll() {
    if (this.mDragHelper.continueSettling(true)) {
      if (!this.mCanSlide) {
        this.mDragHelper.abort();
        return;
      } 
    } else {
      return;
    } 
    ViewCompat.postInvalidateOnAnimation((View)this);
  }
  
  void dispatchOnPanelClosed(View paramView) {
    if (this.mPanelSlideListener != null)
      this.mPanelSlideListener.onPanelClosed(paramView); 
    sendAccessibilityEvent(32);
  }
  
  void dispatchOnPanelOpened(View paramView) {
    if (this.mPanelSlideListener != null)
      this.mPanelSlideListener.onPanelOpened(paramView); 
    sendAccessibilityEvent(32);
  }
  
  void dispatchOnPanelSlide(View paramView) {
    if (this.mPanelSlideListener != null)
      this.mPanelSlideListener.onPanelSlide(paramView, this.mSlideOffset); 
  }
  
  public void draw(Canvas paramCanvas) {
    View view;
    super.draw(paramCanvas);
    if (getChildCount() > 1) {
      view = getChildAt(1);
    } else {
      view = null;
    } 
    if (view != null && this.mShadowDrawable != null) {
      int i = this.mShadowDrawable.getIntrinsicWidth();
      int j = view.getLeft();
      int k = view.getTop();
      int m = view.getBottom();
      this.mShadowDrawable.setBounds(j - i, k, j, m);
      this.mShadowDrawable.draw(paramCanvas);
    } 
  }
  
  protected boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    int i = paramCanvas.save(2);
    if (this.mCanSlide && !layoutParams.slideable && this.mSlideableView != null) {
      paramCanvas.getClipBounds(this.mTmpRect);
      this.mTmpRect.right = Math.min(this.mTmpRect.right, this.mSlideableView.getLeft());
      paramCanvas.clipRect(this.mTmpRect);
    } 
    if (Build.VERSION.SDK_INT >= 11) {
      boolean bool1 = super.drawChild(paramCanvas, paramView, paramLong);
      paramCanvas.restoreToCount(i);
      return bool1;
    } 
    if (layoutParams.dimWhenOffset && this.mSlideOffset > 0.0F) {
      if (!paramView.isDrawingCacheEnabled())
        paramView.setDrawingCacheEnabled(true); 
      Bitmap bitmap = paramView.getDrawingCache();
      if (bitmap != null) {
        paramCanvas.drawBitmap(bitmap, paramView.getLeft(), paramView.getTop(), layoutParams.dimPaint);
        boolean bool2 = false;
        paramCanvas.restoreToCount(i);
        return bool2;
      } 
      Log.e("SlidingPaneLayout", "drawChild: child view " + paramView + " returned null drawing cache");
      boolean bool1 = super.drawChild(paramCanvas, paramView, paramLong);
      paramCanvas.restoreToCount(i);
      return bool1;
    } 
    if (paramView.isDrawingCacheEnabled())
      paramView.setDrawingCacheEnabled(false); 
    boolean bool = super.drawChild(paramCanvas, paramView, paramLong);
    paramCanvas.restoreToCount(i);
    return bool;
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new LayoutParams();
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new LayoutParams((ViewGroup.MarginLayoutParams)paramLayoutParams) : new LayoutParams(paramLayoutParams));
  }
  
  public int getCoveredFadeColor() {
    return this.mCoveredFadeColor;
  }
  
  public int getParallaxDistance() {
    return this.mParallaxBy;
  }
  
  public int getSliderFadeColor() {
    return this.mSliderFadeColor;
  }
  
  boolean isDimmed(View paramView) {
    boolean bool1 = false;
    if (paramView == null)
      return bool1; 
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    boolean bool2 = bool1;
    if (this.mCanSlide) {
      bool2 = bool1;
      if (layoutParams.dimWhenOffset) {
        bool2 = bool1;
        if (this.mSlideOffset > 0.0F)
          bool2 = true; 
      } 
    } 
    return bool2;
  }
  
  public boolean isOpen() {
    return (!this.mCanSlide || this.mSlideOffset == 1.0F);
  }
  
  public boolean isSlideable() {
    return this.mCanSlide;
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.mFirstLayout = true;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    this.mFirstLayout = true;
    byte b = 0;
    int i = this.mPostedRunnables.size();
    while (b < i) {
      ((DisableLayerRunnable)this.mPostedRunnables.get(b)).run();
      b++;
    } 
    this.mPostedRunnables.clear();
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    float f1;
    float f2;
    int i = MotionEventCompat.getActionMasked(paramMotionEvent);
    if (!this.mCanSlide && i == 0 && getChildCount() > 1) {
      View view = getChildAt(1);
      if (view != null) {
        boolean bool;
        if (!this.mDragHelper.isViewUnder(view, (int)paramMotionEvent.getX(), (int)paramMotionEvent.getY())) {
          bool = true;
        } else {
          bool = false;
        } 
        this.mPreservedOpenState = bool;
      } 
    } 
    if (!this.mCanSlide || (this.mIsUnableToDrag && i != 0)) {
      this.mDragHelper.cancel();
      return super.onInterceptTouchEvent(paramMotionEvent);
    } 
    if (i == 3 || i == 1) {
      this.mDragHelper.cancel();
      return false;
    } 
    boolean bool1 = false;
    boolean bool2 = bool1;
    switch (i) {
      default:
        bool2 = bool1;
      case 1:
        if (this.mDragHelper.shouldInterceptTouchEvent(paramMotionEvent) || bool2)
          return true; 
        break;
      case 0:
        this.mIsUnableToDrag = false;
        f1 = paramMotionEvent.getX();
        f2 = paramMotionEvent.getY();
        this.mInitialMotionX = f1;
        this.mInitialMotionY = f2;
        bool2 = bool1;
        if (this.mDragHelper.isViewUnder(this.mSlideableView, (int)f1, (int)f2)) {
          bool2 = bool1;
          if (isDimmed(this.mSlideableView))
            bool2 = true; 
        } 
      case 2:
        f2 = paramMotionEvent.getX();
        f1 = paramMotionEvent.getY();
        f2 = Math.abs(f2 - this.mInitialMotionX);
        f1 = Math.abs(f1 - this.mInitialMotionY);
        bool2 = bool1;
        if (f2 > this.mDragHelper.getTouchSlop()) {
          bool2 = bool1;
          if (f1 > f2) {
            this.mDragHelper.cancel();
            this.mIsUnableToDrag = true;
            return false;
          } 
        } 
    } 
    return false;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: iload #4
    //   2: iload_2
    //   3: isub
    //   4: istore #6
    //   6: aload_0
    //   7: invokevirtual getPaddingLeft : ()I
    //   10: istore_2
    //   11: aload_0
    //   12: invokevirtual getPaddingRight : ()I
    //   15: istore #7
    //   17: aload_0
    //   18: invokevirtual getPaddingTop : ()I
    //   21: istore #8
    //   23: aload_0
    //   24: invokevirtual getChildCount : ()I
    //   27: istore #9
    //   29: iload_2
    //   30: istore #4
    //   32: aload_0
    //   33: getfield mFirstLayout : Z
    //   36: ifeq -> 62
    //   39: aload_0
    //   40: getfield mCanSlide : Z
    //   43: ifeq -> 105
    //   46: aload_0
    //   47: getfield mPreservedOpenState : Z
    //   50: ifeq -> 105
    //   53: fconst_1
    //   54: fstore #10
    //   56: aload_0
    //   57: fload #10
    //   59: putfield mSlideOffset : F
    //   62: iconst_0
    //   63: istore #5
    //   65: iload_2
    //   66: istore_3
    //   67: iload #4
    //   69: istore_2
    //   70: iload #5
    //   72: istore #4
    //   74: iload #4
    //   76: iload #9
    //   78: if_icmpge -> 315
    //   81: aload_0
    //   82: iload #4
    //   84: invokevirtual getChildAt : (I)Landroid/view/View;
    //   87: astore #11
    //   89: aload #11
    //   91: invokevirtual getVisibility : ()I
    //   94: bipush #8
    //   96: if_icmpne -> 111
    //   99: iinc #4, 1
    //   102: goto -> 74
    //   105: fconst_0
    //   106: fstore #10
    //   108: goto -> 56
    //   111: aload #11
    //   113: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   116: checkcast android/support/v4/widget/SlidingPaneLayout$LayoutParams
    //   119: astore #12
    //   121: aload #11
    //   123: invokevirtual getMeasuredWidth : ()I
    //   126: istore #13
    //   128: iconst_0
    //   129: istore #5
    //   131: aload #12
    //   133: getfield slideable : Z
    //   136: ifeq -> 276
    //   139: aload #12
    //   141: getfield leftMargin : I
    //   144: istore #14
    //   146: aload #12
    //   148: getfield rightMargin : I
    //   151: istore #15
    //   153: iload_2
    //   154: iload #6
    //   156: iload #7
    //   158: isub
    //   159: aload_0
    //   160: getfield mOverhangSize : I
    //   163: isub
    //   164: invokestatic min : (II)I
    //   167: iload_3
    //   168: isub
    //   169: iload #14
    //   171: iload #15
    //   173: iadd
    //   174: isub
    //   175: istore #15
    //   177: aload_0
    //   178: iload #15
    //   180: putfield mSlideRange : I
    //   183: aload #12
    //   185: getfield leftMargin : I
    //   188: iload_3
    //   189: iadd
    //   190: iload #15
    //   192: iadd
    //   193: iload #13
    //   195: iconst_2
    //   196: idiv
    //   197: iadd
    //   198: iload #6
    //   200: iload #7
    //   202: isub
    //   203: if_icmple -> 271
    //   206: iconst_1
    //   207: istore_1
    //   208: aload #12
    //   210: iload_1
    //   211: putfield dimWhenOffset : Z
    //   214: iload_3
    //   215: iload #15
    //   217: i2f
    //   218: aload_0
    //   219: getfield mSlideOffset : F
    //   222: fmul
    //   223: f2i
    //   224: aload #12
    //   226: getfield leftMargin : I
    //   229: iadd
    //   230: iadd
    //   231: istore_3
    //   232: iload_3
    //   233: iload #5
    //   235: isub
    //   236: istore #5
    //   238: aload #11
    //   240: iload #5
    //   242: iload #8
    //   244: iload #5
    //   246: iload #13
    //   248: iadd
    //   249: iload #8
    //   251: aload #11
    //   253: invokevirtual getMeasuredHeight : ()I
    //   256: iadd
    //   257: invokevirtual layout : (IIII)V
    //   260: iload_2
    //   261: aload #11
    //   263: invokevirtual getWidth : ()I
    //   266: iadd
    //   267: istore_2
    //   268: goto -> 99
    //   271: iconst_0
    //   272: istore_1
    //   273: goto -> 208
    //   276: aload_0
    //   277: getfield mCanSlide : Z
    //   280: ifeq -> 310
    //   283: aload_0
    //   284: getfield mParallaxBy : I
    //   287: ifeq -> 310
    //   290: fconst_1
    //   291: aload_0
    //   292: getfield mSlideOffset : F
    //   295: fsub
    //   296: aload_0
    //   297: getfield mParallaxBy : I
    //   300: i2f
    //   301: fmul
    //   302: f2i
    //   303: istore #5
    //   305: iload_2
    //   306: istore_3
    //   307: goto -> 232
    //   310: iload_2
    //   311: istore_3
    //   312: goto -> 232
    //   315: aload_0
    //   316: getfield mFirstLayout : Z
    //   319: ifeq -> 384
    //   322: aload_0
    //   323: getfield mCanSlide : Z
    //   326: ifeq -> 390
    //   329: aload_0
    //   330: getfield mParallaxBy : I
    //   333: ifeq -> 344
    //   336: aload_0
    //   337: aload_0
    //   338: getfield mSlideOffset : F
    //   341: invokespecial parallaxOtherViews : (F)V
    //   344: aload_0
    //   345: getfield mSlideableView : Landroid/view/View;
    //   348: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   351: checkcast android/support/v4/widget/SlidingPaneLayout$LayoutParams
    //   354: getfield dimWhenOffset : Z
    //   357: ifeq -> 376
    //   360: aload_0
    //   361: aload_0
    //   362: getfield mSlideableView : Landroid/view/View;
    //   365: aload_0
    //   366: getfield mSlideOffset : F
    //   369: aload_0
    //   370: getfield mSliderFadeColor : I
    //   373: invokespecial dimChildView : (Landroid/view/View;FI)V
    //   376: aload_0
    //   377: aload_0
    //   378: getfield mSlideableView : Landroid/view/View;
    //   381: invokevirtual updateObscuredViewsVisibility : (Landroid/view/View;)V
    //   384: aload_0
    //   385: iconst_0
    //   386: putfield mFirstLayout : Z
    //   389: return
    //   390: iconst_0
    //   391: istore_2
    //   392: iload_2
    //   393: iload #9
    //   395: if_icmpge -> 376
    //   398: aload_0
    //   399: aload_0
    //   400: iload_2
    //   401: invokevirtual getChildAt : (I)Landroid/view/View;
    //   404: fconst_0
    //   405: aload_0
    //   406: getfield mSliderFadeColor : I
    //   409: invokespecial dimChildView : (Landroid/view/View;FI)V
    //   412: iinc #2, 1
    //   415: goto -> 392
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_1
    //   1: invokestatic getMode : (I)I
    //   4: istore_3
    //   5: iload_1
    //   6: invokestatic getSize : (I)I
    //   9: istore #4
    //   11: iload_2
    //   12: invokestatic getMode : (I)I
    //   15: istore #5
    //   17: iload_2
    //   18: invokestatic getSize : (I)I
    //   21: istore_2
    //   22: iload_3
    //   23: ldc_w 1073741824
    //   26: if_icmpeq -> 244
    //   29: aload_0
    //   30: invokevirtual isInEditMode : ()Z
    //   33: ifeq -> 233
    //   36: iload_3
    //   37: ldc_w -2147483648
    //   40: if_icmpne -> 205
    //   43: iload #4
    //   45: istore #6
    //   47: iload_2
    //   48: istore_1
    //   49: iload #5
    //   51: istore #7
    //   53: iconst_0
    //   54: istore #4
    //   56: iconst_m1
    //   57: istore_2
    //   58: iload #7
    //   60: lookupswitch default -> 88, -2147483648 -> 326, 1073741824 -> 308
    //   88: fconst_0
    //   89: fstore #8
    //   91: iconst_0
    //   92: istore #9
    //   94: iload #6
    //   96: aload_0
    //   97: invokevirtual getPaddingLeft : ()I
    //   100: isub
    //   101: aload_0
    //   102: invokevirtual getPaddingRight : ()I
    //   105: isub
    //   106: istore_3
    //   107: aload_0
    //   108: invokevirtual getChildCount : ()I
    //   111: istore #10
    //   113: iload #10
    //   115: iconst_2
    //   116: if_icmple -> 128
    //   119: ldc 'SlidingPaneLayout'
    //   121: ldc_w 'onMeasure: More than two child views are not supported.'
    //   124: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   127: pop
    //   128: aload_0
    //   129: aconst_null
    //   130: putfield mSlideableView : Landroid/view/View;
    //   133: iconst_0
    //   134: istore #11
    //   136: iload #11
    //   138: iload #10
    //   140: if_icmpge -> 646
    //   143: aload_0
    //   144: iload #11
    //   146: invokevirtual getChildAt : (I)Landroid/view/View;
    //   149: astore #12
    //   151: aload #12
    //   153: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   156: checkcast android/support/v4/widget/SlidingPaneLayout$LayoutParams
    //   159: astore #13
    //   161: aload #12
    //   163: invokevirtual getVisibility : ()I
    //   166: bipush #8
    //   168: if_icmpne -> 341
    //   171: aload #13
    //   173: iconst_0
    //   174: putfield dimWhenOffset : Z
    //   177: iload_3
    //   178: istore #5
    //   180: iload #4
    //   182: istore #14
    //   184: iload #9
    //   186: istore #15
    //   188: iinc #11, 1
    //   191: iload #15
    //   193: istore #9
    //   195: iload #14
    //   197: istore #4
    //   199: iload #5
    //   201: istore_3
    //   202: goto -> 136
    //   205: iload #5
    //   207: istore #7
    //   209: iload_2
    //   210: istore_1
    //   211: iload #4
    //   213: istore #6
    //   215: iload_3
    //   216: ifne -> 53
    //   219: sipush #300
    //   222: istore #6
    //   224: iload #5
    //   226: istore #7
    //   228: iload_2
    //   229: istore_1
    //   230: goto -> 53
    //   233: new java/lang/IllegalStateException
    //   236: dup
    //   237: ldc_w 'Width must have an exact value or MATCH_PARENT'
    //   240: invokespecial <init> : (Ljava/lang/String;)V
    //   243: athrow
    //   244: iload #5
    //   246: istore #7
    //   248: iload_2
    //   249: istore_1
    //   250: iload #4
    //   252: istore #6
    //   254: iload #5
    //   256: ifne -> 53
    //   259: aload_0
    //   260: invokevirtual isInEditMode : ()Z
    //   263: ifeq -> 297
    //   266: iload #5
    //   268: istore #7
    //   270: iload_2
    //   271: istore_1
    //   272: iload #4
    //   274: istore #6
    //   276: iload #5
    //   278: ifne -> 53
    //   281: ldc_w -2147483648
    //   284: istore #7
    //   286: sipush #300
    //   289: istore_1
    //   290: iload #4
    //   292: istore #6
    //   294: goto -> 53
    //   297: new java/lang/IllegalStateException
    //   300: dup
    //   301: ldc_w 'Height must not be UNSPECIFIED'
    //   304: invokespecial <init> : (Ljava/lang/String;)V
    //   307: athrow
    //   308: iload_1
    //   309: aload_0
    //   310: invokevirtual getPaddingTop : ()I
    //   313: isub
    //   314: aload_0
    //   315: invokevirtual getPaddingBottom : ()I
    //   318: isub
    //   319: istore_2
    //   320: iload_2
    //   321: istore #4
    //   323: goto -> 88
    //   326: iload_1
    //   327: aload_0
    //   328: invokevirtual getPaddingTop : ()I
    //   331: isub
    //   332: aload_0
    //   333: invokevirtual getPaddingBottom : ()I
    //   336: isub
    //   337: istore_2
    //   338: goto -> 88
    //   341: fload #8
    //   343: fstore #16
    //   345: aload #13
    //   347: getfield weight : F
    //   350: fconst_0
    //   351: fcmpl
    //   352: ifle -> 388
    //   355: fload #8
    //   357: aload #13
    //   359: getfield weight : F
    //   362: fadd
    //   363: fstore #16
    //   365: iload #9
    //   367: istore #15
    //   369: iload #4
    //   371: istore #14
    //   373: fload #16
    //   375: fstore #8
    //   377: iload_3
    //   378: istore #5
    //   380: aload #13
    //   382: getfield width : I
    //   385: ifeq -> 188
    //   388: aload #13
    //   390: getfield leftMargin : I
    //   393: aload #13
    //   395: getfield rightMargin : I
    //   398: iadd
    //   399: istore_1
    //   400: aload #13
    //   402: getfield width : I
    //   405: bipush #-2
    //   407: if_icmpne -> 565
    //   410: iload #6
    //   412: iload_1
    //   413: isub
    //   414: ldc_w -2147483648
    //   417: invokestatic makeMeasureSpec : (II)I
    //   420: istore_1
    //   421: aload #13
    //   423: getfield height : I
    //   426: bipush #-2
    //   428: if_icmpne -> 603
    //   431: iload_2
    //   432: ldc_w -2147483648
    //   435: invokestatic makeMeasureSpec : (II)I
    //   438: istore #5
    //   440: aload #12
    //   442: iload_1
    //   443: iload #5
    //   445: invokevirtual measure : (II)V
    //   448: aload #12
    //   450: invokevirtual getMeasuredWidth : ()I
    //   453: istore #5
    //   455: aload #12
    //   457: invokevirtual getMeasuredHeight : ()I
    //   460: istore #14
    //   462: iload #4
    //   464: istore_1
    //   465: iload #7
    //   467: ldc_w -2147483648
    //   470: if_icmpne -> 490
    //   473: iload #4
    //   475: istore_1
    //   476: iload #14
    //   478: iload #4
    //   480: if_icmple -> 490
    //   483: iload #14
    //   485: iload_2
    //   486: invokestatic min : (II)I
    //   489: istore_1
    //   490: iload_3
    //   491: iload #5
    //   493: isub
    //   494: istore #4
    //   496: iload #4
    //   498: ifge -> 640
    //   501: iconst_1
    //   502: istore #15
    //   504: aload #13
    //   506: iload #15
    //   508: putfield slideable : Z
    //   511: iload #9
    //   513: iload #15
    //   515: ior
    //   516: istore #9
    //   518: iload #9
    //   520: istore #15
    //   522: iload_1
    //   523: istore #14
    //   525: fload #16
    //   527: fstore #8
    //   529: iload #4
    //   531: istore #5
    //   533: aload #13
    //   535: getfield slideable : Z
    //   538: ifeq -> 188
    //   541: aload_0
    //   542: aload #12
    //   544: putfield mSlideableView : Landroid/view/View;
    //   547: iload #9
    //   549: istore #15
    //   551: iload_1
    //   552: istore #14
    //   554: fload #16
    //   556: fstore #8
    //   558: iload #4
    //   560: istore #5
    //   562: goto -> 188
    //   565: aload #13
    //   567: getfield width : I
    //   570: iconst_m1
    //   571: if_icmpne -> 588
    //   574: iload #6
    //   576: iload_1
    //   577: isub
    //   578: ldc_w 1073741824
    //   581: invokestatic makeMeasureSpec : (II)I
    //   584: istore_1
    //   585: goto -> 421
    //   588: aload #13
    //   590: getfield width : I
    //   593: ldc_w 1073741824
    //   596: invokestatic makeMeasureSpec : (II)I
    //   599: istore_1
    //   600: goto -> 421
    //   603: aload #13
    //   605: getfield height : I
    //   608: iconst_m1
    //   609: if_icmpne -> 624
    //   612: iload_2
    //   613: ldc_w 1073741824
    //   616: invokestatic makeMeasureSpec : (II)I
    //   619: istore #5
    //   621: goto -> 440
    //   624: aload #13
    //   626: getfield height : I
    //   629: ldc_w 1073741824
    //   632: invokestatic makeMeasureSpec : (II)I
    //   635: istore #5
    //   637: goto -> 440
    //   640: iconst_0
    //   641: istore #15
    //   643: goto -> 504
    //   646: iload #9
    //   648: ifne -> 658
    //   651: fload #8
    //   653: fconst_0
    //   654: fcmpl
    //   655: ifle -> 1064
    //   658: iload #6
    //   660: aload_0
    //   661: getfield mOverhangSize : I
    //   664: isub
    //   665: istore #11
    //   667: iconst_0
    //   668: istore #5
    //   670: iload #5
    //   672: iload #10
    //   674: if_icmpge -> 1064
    //   677: aload_0
    //   678: iload #5
    //   680: invokevirtual getChildAt : (I)Landroid/view/View;
    //   683: astore #13
    //   685: aload #13
    //   687: invokevirtual getVisibility : ()I
    //   690: bipush #8
    //   692: if_icmpne -> 701
    //   695: iinc #5, 1
    //   698: goto -> 670
    //   701: aload #13
    //   703: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   706: checkcast android/support/v4/widget/SlidingPaneLayout$LayoutParams
    //   709: astore #12
    //   711: aload #13
    //   713: invokevirtual getVisibility : ()I
    //   716: bipush #8
    //   718: if_icmpeq -> 695
    //   721: aload #12
    //   723: getfield width : I
    //   726: ifne -> 826
    //   729: aload #12
    //   731: getfield weight : F
    //   734: fconst_0
    //   735: fcmpl
    //   736: ifle -> 826
    //   739: iconst_1
    //   740: istore_1
    //   741: iload_1
    //   742: ifeq -> 831
    //   745: iconst_0
    //   746: istore #7
    //   748: iload #9
    //   750: ifeq -> 891
    //   753: aload #13
    //   755: aload_0
    //   756: getfield mSlideableView : Landroid/view/View;
    //   759: if_acmpeq -> 891
    //   762: aload #12
    //   764: getfield width : I
    //   767: ifge -> 695
    //   770: iload #7
    //   772: iload #11
    //   774: if_icmpgt -> 787
    //   777: aload #12
    //   779: getfield weight : F
    //   782: fconst_0
    //   783: fcmpl
    //   784: ifle -> 695
    //   787: iload_1
    //   788: ifeq -> 876
    //   791: aload #12
    //   793: getfield height : I
    //   796: bipush #-2
    //   798: if_icmpne -> 841
    //   801: iload_2
    //   802: ldc_w -2147483648
    //   805: invokestatic makeMeasureSpec : (II)I
    //   808: istore_1
    //   809: aload #13
    //   811: iload #11
    //   813: ldc_w 1073741824
    //   816: invokestatic makeMeasureSpec : (II)I
    //   819: iload_1
    //   820: invokevirtual measure : (II)V
    //   823: goto -> 695
    //   826: iconst_0
    //   827: istore_1
    //   828: goto -> 741
    //   831: aload #13
    //   833: invokevirtual getMeasuredWidth : ()I
    //   836: istore #7
    //   838: goto -> 748
    //   841: aload #12
    //   843: getfield height : I
    //   846: iconst_m1
    //   847: if_icmpne -> 861
    //   850: iload_2
    //   851: ldc_w 1073741824
    //   854: invokestatic makeMeasureSpec : (II)I
    //   857: istore_1
    //   858: goto -> 809
    //   861: aload #12
    //   863: getfield height : I
    //   866: ldc_w 1073741824
    //   869: invokestatic makeMeasureSpec : (II)I
    //   872: istore_1
    //   873: goto -> 809
    //   876: aload #13
    //   878: invokevirtual getMeasuredHeight : ()I
    //   881: ldc_w 1073741824
    //   884: invokestatic makeMeasureSpec : (II)I
    //   887: istore_1
    //   888: goto -> 809
    //   891: aload #12
    //   893: getfield weight : F
    //   896: fconst_0
    //   897: fcmpl
    //   898: ifle -> 695
    //   901: aload #12
    //   903: getfield width : I
    //   906: ifne -> 1011
    //   909: aload #12
    //   911: getfield height : I
    //   914: bipush #-2
    //   916: if_icmpne -> 976
    //   919: iload_2
    //   920: ldc_w -2147483648
    //   923: invokestatic makeMeasureSpec : (II)I
    //   926: istore_1
    //   927: iload #9
    //   929: ifeq -> 1026
    //   932: iload #6
    //   934: aload #12
    //   936: getfield leftMargin : I
    //   939: aload #12
    //   941: getfield rightMargin : I
    //   944: iadd
    //   945: isub
    //   946: istore #17
    //   948: iload #17
    //   950: ldc_w 1073741824
    //   953: invokestatic makeMeasureSpec : (II)I
    //   956: istore #14
    //   958: iload #7
    //   960: iload #17
    //   962: if_icmpeq -> 695
    //   965: aload #13
    //   967: iload #14
    //   969: iload_1
    //   970: invokevirtual measure : (II)V
    //   973: goto -> 695
    //   976: aload #12
    //   978: getfield height : I
    //   981: iconst_m1
    //   982: if_icmpne -> 996
    //   985: iload_2
    //   986: ldc_w 1073741824
    //   989: invokestatic makeMeasureSpec : (II)I
    //   992: istore_1
    //   993: goto -> 927
    //   996: aload #12
    //   998: getfield height : I
    //   1001: ldc_w 1073741824
    //   1004: invokestatic makeMeasureSpec : (II)I
    //   1007: istore_1
    //   1008: goto -> 927
    //   1011: aload #13
    //   1013: invokevirtual getMeasuredHeight : ()I
    //   1016: ldc_w 1073741824
    //   1019: invokestatic makeMeasureSpec : (II)I
    //   1022: istore_1
    //   1023: goto -> 927
    //   1026: iconst_0
    //   1027: iload_3
    //   1028: invokestatic max : (II)I
    //   1031: istore #14
    //   1033: aload #13
    //   1035: iload #7
    //   1037: aload #12
    //   1039: getfield weight : F
    //   1042: iload #14
    //   1044: i2f
    //   1045: fmul
    //   1046: fload #8
    //   1048: fdiv
    //   1049: f2i
    //   1050: iadd
    //   1051: ldc_w 1073741824
    //   1054: invokestatic makeMeasureSpec : (II)I
    //   1057: iload_1
    //   1058: invokevirtual measure : (II)V
    //   1061: goto -> 695
    //   1064: aload_0
    //   1065: iload #6
    //   1067: iload #4
    //   1069: invokevirtual setMeasuredDimension : (II)V
    //   1072: aload_0
    //   1073: iload #9
    //   1075: putfield mCanSlide : Z
    //   1078: aload_0
    //   1079: getfield mDragHelper : Landroid/support/v4/widget/ViewDragHelper;
    //   1082: invokevirtual getViewDragState : ()I
    //   1085: ifeq -> 1100
    //   1088: iload #9
    //   1090: ifne -> 1100
    //   1093: aload_0
    //   1094: getfield mDragHelper : Landroid/support/v4/widget/ViewDragHelper;
    //   1097: invokevirtual abort : ()V
    //   1100: return
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.getSuperState());
    if (savedState.isOpen) {
      openPane();
    } else {
      closePane();
    } 
    this.mPreservedOpenState = savedState.isOpen;
  }
  
  protected Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    if (isSlideable()) {
      boolean bool1 = isOpen();
      savedState.isOpen = bool1;
      return (Parcelable)savedState;
    } 
    boolean bool = this.mPreservedOpenState;
    savedState.isOpen = bool;
    return (Parcelable)savedState;
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramInt1 != paramInt3)
      this.mFirstLayout = true; 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    float f1;
    float f2;
    if (!this.mCanSlide)
      return super.onTouchEvent(paramMotionEvent); 
    this.mDragHelper.processTouchEvent(paramMotionEvent);
    int i = paramMotionEvent.getAction();
    boolean bool2 = true;
    switch (i & 0xFF) {
      default:
        return bool2;
      case 0:
        f1 = paramMotionEvent.getX();
        f2 = paramMotionEvent.getY();
        this.mInitialMotionX = f1;
        this.mInitialMotionY = f2;
        return bool2;
      case 1:
        break;
    } 
    boolean bool1 = bool2;
    if (isDimmed(this.mSlideableView)) {
      float f3 = paramMotionEvent.getX();
      f1 = paramMotionEvent.getY();
      float f4 = f3 - this.mInitialMotionX;
      f2 = f1 - this.mInitialMotionY;
      i = this.mDragHelper.getTouchSlop();
      bool1 = bool2;
      if (f4 * f4 + f2 * f2 < (i * i)) {
        bool1 = bool2;
        if (this.mDragHelper.isViewUnder(this.mSlideableView, (int)f3, (int)f1)) {
          closePane(this.mSlideableView, 0);
          bool1 = bool2;
        } 
      } 
    } 
    return bool1;
  }
  
  public boolean openPane() {
    return openPane(this.mSlideableView, 0);
  }
  
  public void requestChildFocus(View paramView1, View paramView2) {
    super.requestChildFocus(paramView1, paramView2);
    if (!isInTouchMode() && !this.mCanSlide) {
      boolean bool;
      if (paramView1 == this.mSlideableView) {
        bool = true;
      } else {
        bool = false;
      } 
      this.mPreservedOpenState = bool;
    } 
  }
  
  void setAllChildrenVisible() {
    byte b = 0;
    int i = getChildCount();
    while (b < i) {
      View view = getChildAt(b);
      if (view.getVisibility() == 4)
        view.setVisibility(0); 
      b++;
    } 
  }
  
  public void setCoveredFadeColor(int paramInt) {
    this.mCoveredFadeColor = paramInt;
  }
  
  public void setPanelSlideListener(PanelSlideListener paramPanelSlideListener) {
    this.mPanelSlideListener = paramPanelSlideListener;
  }
  
  public void setParallaxDistance(int paramInt) {
    this.mParallaxBy = paramInt;
    requestLayout();
  }
  
  public void setShadowDrawable(Drawable paramDrawable) {
    this.mShadowDrawable = paramDrawable;
  }
  
  public void setShadowResource(int paramInt) {
    setShadowDrawable(getResources().getDrawable(paramInt));
  }
  
  public void setSliderFadeColor(int paramInt) {
    this.mSliderFadeColor = paramInt;
  }
  
  @Deprecated
  public void smoothSlideClosed() {
    closePane();
  }
  
  @Deprecated
  public void smoothSlideOpen() {
    openPane();
  }
  
  boolean smoothSlideTo(float paramFloat, int paramInt) {
    boolean bool = false;
    if (this.mCanSlide) {
      LayoutParams layoutParams = (LayoutParams)this.mSlideableView.getLayoutParams();
      paramInt = (int)((getPaddingLeft() + layoutParams.leftMargin) + this.mSlideRange * paramFloat);
      if (this.mDragHelper.smoothSlideViewTo(this.mSlideableView, paramInt, this.mSlideableView.getTop())) {
        setAllChildrenVisible();
        ViewCompat.postInvalidateOnAnimation((View)this);
        bool = true;
      } 
    } 
    return bool;
  }
  
  void updateObscuredViewsVisibility(View paramView) {
    byte b1;
    byte b2;
    byte b3;
    byte b4;
    int i = getPaddingLeft();
    int j = getWidth();
    int k = getPaddingRight();
    int m = getPaddingTop();
    int n = getHeight();
    int i1 = getPaddingBottom();
    if (paramView != null && viewIsOpaque(paramView)) {
      b1 = paramView.getLeft();
      b2 = paramView.getRight();
      b3 = paramView.getTop();
      b4 = paramView.getBottom();
    } else {
      b4 = 0;
      b3 = 0;
      b2 = 0;
      b1 = 0;
    } 
    byte b5 = 0;
    int i2 = getChildCount();
    while (true) {
      if (b5 < i2) {
        View view = getChildAt(b5);
        if (view != paramView) {
          int i3 = Math.max(i, view.getLeft());
          int i4 = Math.max(m, view.getTop());
          int i5 = Math.min(j - k, view.getRight());
          int i6 = Math.min(n - i1, view.getBottom());
          if (i3 >= b1 && i4 >= b3 && i5 <= b2 && i6 <= b4) {
            i5 = 4;
          } else {
            i5 = 0;
          } 
          view.setVisibility(i5);
          b5++;
          continue;
        } 
      } 
      return;
    } 
  }
  
  static {
    int i = Build.VERSION.SDK_INT;
    if (i >= 17) {
      IMPL = new SlidingPanelLayoutImplJBMR1();
      return;
    } 
    if (i >= 16) {
      IMPL = new SlidingPanelLayoutImplJB();
      return;
    } 
  }
  
  class AccessibilityDelegate extends AccessibilityDelegateCompat {
    private final Rect mTmpRect = new Rect();
    
    private void copyNodeInfoNoChildren(AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat1, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat2) {
      Rect rect = this.mTmpRect;
      param1AccessibilityNodeInfoCompat2.getBoundsInParent(rect);
      param1AccessibilityNodeInfoCompat1.setBoundsInParent(rect);
      param1AccessibilityNodeInfoCompat2.getBoundsInScreen(rect);
      param1AccessibilityNodeInfoCompat1.setBoundsInScreen(rect);
      param1AccessibilityNodeInfoCompat1.setVisibleToUser(param1AccessibilityNodeInfoCompat2.isVisibleToUser());
      param1AccessibilityNodeInfoCompat1.setPackageName(param1AccessibilityNodeInfoCompat2.getPackageName());
      param1AccessibilityNodeInfoCompat1.setClassName(param1AccessibilityNodeInfoCompat2.getClassName());
      param1AccessibilityNodeInfoCompat1.setContentDescription(param1AccessibilityNodeInfoCompat2.getContentDescription());
      param1AccessibilityNodeInfoCompat1.setEnabled(param1AccessibilityNodeInfoCompat2.isEnabled());
      param1AccessibilityNodeInfoCompat1.setClickable(param1AccessibilityNodeInfoCompat2.isClickable());
      param1AccessibilityNodeInfoCompat1.setFocusable(param1AccessibilityNodeInfoCompat2.isFocusable());
      param1AccessibilityNodeInfoCompat1.setFocused(param1AccessibilityNodeInfoCompat2.isFocused());
      param1AccessibilityNodeInfoCompat1.setAccessibilityFocused(param1AccessibilityNodeInfoCompat2.isAccessibilityFocused());
      param1AccessibilityNodeInfoCompat1.setSelected(param1AccessibilityNodeInfoCompat2.isSelected());
      param1AccessibilityNodeInfoCompat1.setLongClickable(param1AccessibilityNodeInfoCompat2.isLongClickable());
      param1AccessibilityNodeInfoCompat1.addAction(param1AccessibilityNodeInfoCompat2.getActions());
      param1AccessibilityNodeInfoCompat1.setMovementGranularities(param1AccessibilityNodeInfoCompat2.getMovementGranularities());
    }
    
    public boolean filter(View param1View) {
      return SlidingPaneLayout.this.isDimmed(param1View);
    }
    
    public void onInitializeAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1View, param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName(SlidingPaneLayout.class.getName());
    }
    
    public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat) {
      AccessibilityNodeInfoCompat accessibilityNodeInfoCompat = AccessibilityNodeInfoCompat.obtain(param1AccessibilityNodeInfoCompat);
      super.onInitializeAccessibilityNodeInfo(param1View, accessibilityNodeInfoCompat);
      copyNodeInfoNoChildren(param1AccessibilityNodeInfoCompat, accessibilityNodeInfoCompat);
      accessibilityNodeInfoCompat.recycle();
      param1AccessibilityNodeInfoCompat.setClassName(SlidingPaneLayout.class.getName());
      param1AccessibilityNodeInfoCompat.setSource(param1View);
      ViewParent viewParent = ViewCompat.getParentForAccessibility(param1View);
      if (viewParent instanceof View)
        param1AccessibilityNodeInfoCompat.setParent((View)viewParent); 
      int i = SlidingPaneLayout.this.getChildCount();
      for (byte b = 0; b < i; b++) {
        View view = SlidingPaneLayout.this.getChildAt(b);
        if (!filter(view) && view.getVisibility() == 0) {
          ViewCompat.setImportantForAccessibility(view, 1);
          param1AccessibilityNodeInfoCompat.addChild(view);
        } 
      } 
    }
    
    public boolean onRequestSendAccessibilityEvent(ViewGroup param1ViewGroup, View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return !filter(param1View) ? super.onRequestSendAccessibilityEvent(param1ViewGroup, param1View, param1AccessibilityEvent) : false;
    }
  }
  
  private class DisableLayerRunnable implements Runnable {
    final View mChildView;
    
    DisableLayerRunnable(View param1View) {
      this.mChildView = param1View;
    }
    
    public void run() {
      if (this.mChildView.getParent() == SlidingPaneLayout.this) {
        ViewCompat.setLayerType(this.mChildView, 0, null);
        SlidingPaneLayout.this.invalidateChildRegion(this.mChildView);
      } 
      SlidingPaneLayout.this.mPostedRunnables.remove(this);
    }
  }
  
  private class DragHelperCallback extends ViewDragHelper.Callback {
    private DragHelperCallback() {}
    
    public int clampViewPositionHorizontal(View param1View, int param1Int1, int param1Int2) {
      SlidingPaneLayout.LayoutParams layoutParams = (SlidingPaneLayout.LayoutParams)SlidingPaneLayout.this.mSlideableView.getLayoutParams();
      param1Int2 = SlidingPaneLayout.this.getPaddingLeft() + layoutParams.leftMargin;
      int i = SlidingPaneLayout.this.mSlideRange;
      return Math.min(Math.max(param1Int1, param1Int2), param1Int2 + i);
    }
    
    public int getViewHorizontalDragRange(View param1View) {
      return SlidingPaneLayout.this.mSlideRange;
    }
    
    public void onEdgeDragStarted(int param1Int1, int param1Int2) {
      SlidingPaneLayout.this.mDragHelper.captureChildView(SlidingPaneLayout.this.mSlideableView, param1Int2);
    }
    
    public void onViewCaptured(View param1View, int param1Int) {
      SlidingPaneLayout.this.setAllChildrenVisible();
    }
    
    public void onViewDragStateChanged(int param1Int) {
      if (SlidingPaneLayout.this.mDragHelper.getViewDragState() == 0) {
        if (SlidingPaneLayout.this.mSlideOffset == 0.0F) {
          SlidingPaneLayout.this.updateObscuredViewsVisibility(SlidingPaneLayout.this.mSlideableView);
          SlidingPaneLayout.this.dispatchOnPanelClosed(SlidingPaneLayout.this.mSlideableView);
          SlidingPaneLayout.access$502(SlidingPaneLayout.this, false);
          return;
        } 
      } else {
        return;
      } 
      SlidingPaneLayout.this.dispatchOnPanelOpened(SlidingPaneLayout.this.mSlideableView);
      SlidingPaneLayout.access$502(SlidingPaneLayout.this, true);
    }
    
    public void onViewPositionChanged(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      SlidingPaneLayout.this.onPanelDragged(param1Int1);
      SlidingPaneLayout.this.invalidate();
    }
    
    public void onViewReleased(View param1View, float param1Float1, float param1Float2) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
      //   4: checkcast android/support/v4/widget/SlidingPaneLayout$LayoutParams
      //   7: astore #4
      //   9: aload_0
      //   10: getfield this$0 : Landroid/support/v4/widget/SlidingPaneLayout;
      //   13: invokevirtual getPaddingLeft : ()I
      //   16: aload #4
      //   18: getfield leftMargin : I
      //   21: iadd
      //   22: istore #5
      //   24: fload_2
      //   25: fconst_0
      //   26: fcmpl
      //   27: ifgt -> 57
      //   30: iload #5
      //   32: istore #6
      //   34: fload_2
      //   35: fconst_0
      //   36: fcmpl
      //   37: ifne -> 69
      //   40: iload #5
      //   42: istore #6
      //   44: aload_0
      //   45: getfield this$0 : Landroid/support/v4/widget/SlidingPaneLayout;
      //   48: invokestatic access$300 : (Landroid/support/v4/widget/SlidingPaneLayout;)F
      //   51: ldc 0.5
      //   53: fcmpl
      //   54: ifle -> 69
      //   57: iload #5
      //   59: aload_0
      //   60: getfield this$0 : Landroid/support/v4/widget/SlidingPaneLayout;
      //   63: invokestatic access$700 : (Landroid/support/v4/widget/SlidingPaneLayout;)I
      //   66: iadd
      //   67: istore #6
      //   69: aload_0
      //   70: getfield this$0 : Landroid/support/v4/widget/SlidingPaneLayout;
      //   73: invokestatic access$200 : (Landroid/support/v4/widget/SlidingPaneLayout;)Landroid/support/v4/widget/ViewDragHelper;
      //   76: iload #6
      //   78: aload_1
      //   79: invokevirtual getTop : ()I
      //   82: invokevirtual settleCapturedViewAt : (II)Z
      //   85: pop
      //   86: aload_0
      //   87: getfield this$0 : Landroid/support/v4/widget/SlidingPaneLayout;
      //   90: invokevirtual invalidate : ()V
      //   93: return
    }
    
    public boolean tryCaptureView(View param1View, int param1Int) {
      return SlidingPaneLayout.this.mIsUnableToDrag ? false : ((SlidingPaneLayout.LayoutParams)param1View.getLayoutParams()).slideable;
    }
  }
  
  public static class LayoutParams extends ViewGroup.MarginLayoutParams {
    private static final int[] ATTRS = new int[] { 16843137 };
    
    Paint dimPaint;
    
    boolean dimWhenOffset;
    
    boolean slideable;
    
    public float weight = 0.0F;
    
    public LayoutParams() {
      super(-1, -1);
    }
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, ATTRS);
      this.weight = typedArray.getFloat(0, 0.0F);
      typedArray.recycle();
    }
    
    public LayoutParams(LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
      this.weight = param1LayoutParams.weight;
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
  }
  
  public static interface PanelSlideListener {
    void onPanelClosed(View param1View);
    
    void onPanelOpened(View param1View);
    
    void onPanelSlide(View param1View, float param1Float);
  }
  
  static class SavedState extends View.BaseSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>() {
        public SlidingPaneLayout.SavedState createFromParcel(Parcel param2Parcel) {
          return new SlidingPaneLayout.SavedState(param2Parcel);
        }
        
        public SlidingPaneLayout.SavedState[] newArray(int param2Int) {
          return new SlidingPaneLayout.SavedState[param2Int];
        }
      };
    
    boolean isOpen;
    
    private SavedState(Parcel param1Parcel) {
      super(param1Parcel);
      boolean bool;
      if (param1Parcel.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.isOpen = bool;
    }
    
    SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      if (this.isOpen) {
        param1Int = 1;
      } else {
        param1Int = 0;
      } 
      param1Parcel.writeInt(param1Int);
    }
  }
  
  static final class null implements Parcelable.Creator<SavedState> {
    public SlidingPaneLayout.SavedState createFromParcel(Parcel param1Parcel) {
      return new SlidingPaneLayout.SavedState(param1Parcel);
    }
    
    public SlidingPaneLayout.SavedState[] newArray(int param1Int) {
      return new SlidingPaneLayout.SavedState[param1Int];
    }
  }
  
  public static class SimplePanelSlideListener implements PanelSlideListener {
    public void onPanelClosed(View param1View) {}
    
    public void onPanelOpened(View param1View) {}
    
    public void onPanelSlide(View param1View, float param1Float) {}
  }
  
  static interface SlidingPanelLayoutImpl {
    void invalidateChildRegion(SlidingPaneLayout param1SlidingPaneLayout, View param1View);
  }
  
  static class SlidingPanelLayoutImplBase implements SlidingPanelLayoutImpl {
    public void invalidateChildRegion(SlidingPaneLayout param1SlidingPaneLayout, View param1View) {
      ViewCompat.postInvalidateOnAnimation((View)param1SlidingPaneLayout, param1View.getLeft(), param1View.getTop(), param1View.getRight(), param1View.getBottom());
    }
  }
  
  static class SlidingPanelLayoutImplJB extends SlidingPanelLayoutImplBase {
    private Method mGetDisplayList;
    
    private Field mRecreateDisplayList;
    
    SlidingPanelLayoutImplJB() {
      try {
        this.mGetDisplayList = View.class.getDeclaredMethod("getDisplayList", (Class[])null);
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("SlidingPaneLayout", "Couldn't fetch getDisplayList method; dimming won't work right.", noSuchMethodException);
      } 
      try {
        this.mRecreateDisplayList = View.class.getDeclaredField("mRecreateDisplayList");
        this.mRecreateDisplayList.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {
        Log.e("SlidingPaneLayout", "Couldn't fetch mRecreateDisplayList field; dimming will be slow.", noSuchFieldException);
      } 
    }
    
    public void invalidateChildRegion(SlidingPaneLayout param1SlidingPaneLayout, View param1View) {
      if (this.mGetDisplayList != null && this.mRecreateDisplayList != null) {
        try {
          this.mRecreateDisplayList.setBoolean(param1View, true);
          this.mGetDisplayList.invoke(param1View, (Object[])null);
        } catch (Exception exception) {
          Log.e("SlidingPaneLayout", "Error refreshing display list state", exception);
        } 
        super.invalidateChildRegion(param1SlidingPaneLayout, param1View);
        return;
      } 
      param1View.invalidate();
    }
  }
  
  static class SlidingPanelLayoutImplJBMR1 extends SlidingPanelLayoutImplBase {
    public void invalidateChildRegion(SlidingPaneLayout param1SlidingPaneLayout, View param1View) {
      ViewCompat.setLayerPaint(param1View, ((SlidingPaneLayout.LayoutParams)param1View.getLayoutParams()).dimPaint);
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeCMCC-dex2jar.jar!/android/support/v4/widget/SlidingPaneLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */