package android.support.v4.print;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.print.pdf.PrintedPdfDocument;
import android.util.Log;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class PrintHelperKitkat {
  public static final int COLOR_MODE_COLOR = 2;
  
  public static final int COLOR_MODE_MONOCHROME = 1;
  
  private static final String LOG_TAG = "PrintHelperKitkat";
  
  private static final int MAX_PRINT_SIZE = 3500;
  
  public static final int SCALE_MODE_FILL = 2;
  
  public static final int SCALE_MODE_FIT = 1;
  
  int mColorMode = 2;
  
  final Context mContext;
  
  int mScaleMode = 2;
  
  PrintHelperKitkat(Context paramContext) {
    this.mContext = paramContext;
  }
  
  private Bitmap loadBitmap(Uri paramUri, BitmapFactory.Options paramOptions) throws FileNotFoundException {
    if (paramUri == null || this.mContext == null)
      throw new IllegalArgumentException("bad argument to loadBitmap"); 
    InputStream inputStream = null;
    try {
      InputStream inputStream1 = this.mContext.getContentResolver().openInputStream(paramUri);
      inputStream = inputStream1;
      return BitmapFactory.decodeStream(inputStream1, null, paramOptions);
    } finally {
      if (inputStream != null)
        try {
          inputStream.close();
        } catch (IOException iOException) {
          Log.w("PrintHelperKitkat", "close fail ", iOException);
        }  
    } 
  }
  
  private Bitmap loadConstrainedBitmap(Uri paramUri, int paramInt) throws FileNotFoundException {
    Bitmap bitmap;
    BitmapFactory.Options options1 = null;
    if (paramInt <= 0 || paramUri == null || this.mContext == null)
      throw new IllegalArgumentException("bad argument to getScaledBitmap"); 
    BitmapFactory.Options options2 = new BitmapFactory.Options();
    options2.inJustDecodeBounds = true;
    loadBitmap(paramUri, options2);
    int i = options2.outWidth;
    int j = options2.outHeight;
    options2 = options1;
    if (i > 0) {
      if (j <= 0)
        return (Bitmap)options1; 
    } else {
      return (Bitmap)options2;
    } 
    int k = Math.max(i, j);
    int m;
    for (m = 1; k > paramInt; m <<= 1)
      k >>>= 1; 
    options2 = options1;
    if (m > 0) {
      options2 = options1;
      if (Math.min(i, j) / m > 0) {
        options2 = new BitmapFactory.Options();
        options2.inMutable = true;
        options2.inSampleSize = m;
        bitmap = loadBitmap(paramUri, options2);
      } 
    } 
    return bitmap;
  }
  
  public int getColorMode() {
    return this.mColorMode;
  }
  
  public int getScaleMode() {
    return this.mScaleMode;
  }
  
  public void printBitmap(final String jobName, final Bitmap bitmap) {
    if (bitmap != null) {
      final int fittingMode = this.mScaleMode;
      PrintManager printManager = (PrintManager)this.mContext.getSystemService("print");
      PrintAttributes.MediaSize mediaSize = PrintAttributes.MediaSize.UNKNOWN_PORTRAIT;
      if (bitmap.getWidth() > bitmap.getHeight())
        mediaSize = PrintAttributes.MediaSize.UNKNOWN_LANDSCAPE; 
      PrintAttributes printAttributes = (new PrintAttributes.Builder()).setMediaSize(mediaSize).setColorMode(this.mColorMode).build();
      printManager.print(jobName, new PrintDocumentAdapter() {
            private PrintAttributes mAttributes;
            
            public void onLayout(PrintAttributes param1PrintAttributes1, PrintAttributes param1PrintAttributes2, CancellationSignal param1CancellationSignal, PrintDocumentAdapter.LayoutResultCallback param1LayoutResultCallback, Bundle param1Bundle) {
              boolean bool = true;
              this.mAttributes = param1PrintAttributes2;
              PrintDocumentInfo printDocumentInfo = (new PrintDocumentInfo.Builder(jobName)).setContentType(1).setPageCount(1).build();
              if (param1PrintAttributes2.equals(param1PrintAttributes1))
                bool = false; 
              param1LayoutResultCallback.onLayoutFinished(printDocumentInfo, bool);
            }
            
            public void onWrite(PageRange[] param1ArrayOfPageRange, ParcelFileDescriptor param1ParcelFileDescriptor, CancellationSignal param1CancellationSignal, PrintDocumentAdapter.WriteResultCallback param1WriteResultCallback) {
              PrintedPdfDocument printedPdfDocument = new PrintedPdfDocument(PrintHelperKitkat.this.mContext, this.mAttributes);
              try {
                PdfDocument.Page page = printedPdfDocument.startPage(1);
                RectF rectF = new RectF();
                this(page.getInfo().getContentRect());
                Matrix matrix = new Matrix();
                this();
                float f = rectF.width() / bitmap.getWidth();
                if (fittingMode == 2) {
                  f = Math.max(f, rectF.height() / bitmap.getHeight());
                } else {
                  f = Math.min(f, rectF.height() / bitmap.getHeight());
                } 
                matrix.postScale(f, f);
                matrix.postTranslate((rectF.width() - bitmap.getWidth() * f) / 2.0F, (rectF.height() - bitmap.getHeight() * f) / 2.0F);
                page.getCanvas().drawBitmap(bitmap, matrix, null);
                printedPdfDocument.finishPage(page);
                try {
                  FileOutputStream fileOutputStream = new FileOutputStream();
                  this(param1ParcelFileDescriptor.getFileDescriptor());
                  printedPdfDocument.writeTo(fileOutputStream);
                  param1WriteResultCallback.onWriteFinished(new PageRange[] { PageRange.ALL_PAGES });
                } catch (IOException iOException1) {}
                return;
              } finally {
                if (iOException != null)
                  iOException.close(); 
                if (param1ParcelFileDescriptor != null)
                  try {
                    param1ParcelFileDescriptor.close();
                  } catch (IOException iOException1) {} 
              } 
            }
          }printAttributes);
    } 
  }
  
  public void printBitmap(String paramString, Uri paramUri) throws FileNotFoundException {
    printBitmap(paramString, loadConstrainedBitmap(paramUri, 3500));
  }
  
  public void setColorMode(int paramInt) {
    this.mColorMode = paramInt;
  }
  
  public void setScaleMode(int paramInt) {
    this.mScaleMode = paramInt;
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeCMCC-dex2jar.jar!/android/support/v4/print/PrintHelperKitkat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */