package android.support.v4.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.support.v4.util.SimpleArrayMap;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;

public class FragmentActivity extends Activity {
  static final String FRAGMENTS_TAG = "android:support:fragments";
  
  private static final int HONEYCOMB = 11;
  
  static final int MSG_REALLY_STOPPED = 1;
  
  static final int MSG_RESUME_PENDING = 2;
  
  private static final String TAG = "FragmentActivity";
  
  SimpleArrayMap<String, LoaderManagerImpl> mAllLoaderManagers;
  
  boolean mCheckedForLoaderManager;
  
  final FragmentContainer mContainer = new FragmentContainer() {
      public View findViewById(int param1Int) {
        return FragmentActivity.this.findViewById(param1Int);
      }
    };
  
  boolean mCreated;
  
  final FragmentManagerImpl mFragments = new FragmentManagerImpl();
  
  final Handler mHandler = new Handler() {
      public void handleMessage(Message param1Message) {
        switch (param1Message.what) {
          default:
            super.handleMessage(param1Message);
            return;
          case 1:
            if (FragmentActivity.this.mStopped)
              FragmentActivity.this.doReallyStop(false); 
            return;
          case 2:
            break;
        } 
        FragmentActivity.this.onResumeFragments();
        FragmentActivity.this.mFragments.execPendingActions();
      }
    };
  
  LoaderManagerImpl mLoaderManager;
  
  boolean mLoadersStarted;
  
  boolean mOptionsMenuInvalidated;
  
  boolean mReallyStopped;
  
  boolean mResumed;
  
  boolean mRetaining;
  
  boolean mStopped;
  
  private void dumpViewHierarchy(String paramString, PrintWriter paramPrintWriter, View paramView) {
    paramPrintWriter.print(paramString);
    if (paramView == null) {
      paramPrintWriter.println("null");
      return;
    } 
    paramPrintWriter.println(viewToString(paramView));
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      int i = viewGroup.getChildCount();
      if (i > 0) {
        paramString = paramString + "  ";
        byte b = 0;
        while (true) {
          if (b < i) {
            dumpViewHierarchy(paramString, paramPrintWriter, viewGroup.getChildAt(b));
            b++;
            continue;
          } 
          return;
        } 
      } 
    } 
  }
  
  private static String viewToString(View paramView) {
    // Byte code:
    //   0: bipush #70
    //   2: istore_1
    //   3: bipush #46
    //   5: istore_2
    //   6: new java/lang/StringBuilder
    //   9: dup
    //   10: sipush #128
    //   13: invokespecial <init> : (I)V
    //   16: astore_3
    //   17: aload_3
    //   18: aload_0
    //   19: invokevirtual getClass : ()Ljava/lang/Class;
    //   22: invokevirtual getName : ()Ljava/lang/String;
    //   25: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   28: pop
    //   29: aload_3
    //   30: bipush #123
    //   32: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   35: pop
    //   36: aload_3
    //   37: aload_0
    //   38: invokestatic identityHashCode : (Ljava/lang/Object;)I
    //   41: invokestatic toHexString : (I)Ljava/lang/String;
    //   44: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   47: pop
    //   48: aload_3
    //   49: bipush #32
    //   51: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   54: pop
    //   55: aload_0
    //   56: invokevirtual getVisibility : ()I
    //   59: lookupswitch default -> 92, 0 -> 532, 4 -> 542, 8 -> 552
    //   92: aload_3
    //   93: bipush #46
    //   95: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   98: pop
    //   99: aload_0
    //   100: invokevirtual isFocusable : ()Z
    //   103: ifeq -> 562
    //   106: bipush #70
    //   108: istore #4
    //   110: iload #4
    //   112: istore #5
    //   114: aload_3
    //   115: iload #5
    //   117: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   120: pop
    //   121: aload_0
    //   122: invokevirtual isEnabled : ()Z
    //   125: ifeq -> 573
    //   128: bipush #69
    //   130: istore #4
    //   132: iload #4
    //   134: istore #5
    //   136: aload_3
    //   137: iload #5
    //   139: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   142: pop
    //   143: aload_0
    //   144: invokevirtual willNotDraw : ()Z
    //   147: ifeq -> 584
    //   150: bipush #46
    //   152: istore #4
    //   154: iload #4
    //   156: istore #5
    //   158: aload_3
    //   159: iload #5
    //   161: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   164: pop
    //   165: aload_0
    //   166: invokevirtual isHorizontalScrollBarEnabled : ()Z
    //   169: ifeq -> 595
    //   172: bipush #72
    //   174: istore #4
    //   176: iload #4
    //   178: istore #5
    //   180: aload_3
    //   181: iload #5
    //   183: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   186: pop
    //   187: aload_0
    //   188: invokevirtual isVerticalScrollBarEnabled : ()Z
    //   191: ifeq -> 606
    //   194: bipush #86
    //   196: istore #4
    //   198: iload #4
    //   200: istore #5
    //   202: aload_3
    //   203: iload #5
    //   205: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   208: pop
    //   209: aload_0
    //   210: invokevirtual isClickable : ()Z
    //   213: ifeq -> 617
    //   216: bipush #67
    //   218: istore #4
    //   220: iload #4
    //   222: istore #5
    //   224: aload_3
    //   225: iload #5
    //   227: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   230: pop
    //   231: aload_0
    //   232: invokevirtual isLongClickable : ()Z
    //   235: ifeq -> 628
    //   238: bipush #76
    //   240: istore #4
    //   242: iload #4
    //   244: istore #5
    //   246: aload_3
    //   247: iload #5
    //   249: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   252: pop
    //   253: aload_3
    //   254: bipush #32
    //   256: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   259: pop
    //   260: aload_0
    //   261: invokevirtual isFocused : ()Z
    //   264: ifeq -> 639
    //   267: iload_1
    //   268: istore #5
    //   270: aload_3
    //   271: iload #5
    //   273: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   276: pop
    //   277: aload_0
    //   278: invokevirtual isSelected : ()Z
    //   281: ifeq -> 648
    //   284: bipush #83
    //   286: istore_1
    //   287: iload_1
    //   288: istore #5
    //   290: aload_3
    //   291: iload #5
    //   293: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   296: pop
    //   297: iload_2
    //   298: istore #5
    //   300: aload_0
    //   301: invokevirtual isPressed : ()Z
    //   304: ifeq -> 313
    //   307: bipush #80
    //   309: istore_2
    //   310: iload_2
    //   311: istore #5
    //   313: aload_3
    //   314: iload #5
    //   316: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   319: pop
    //   320: aload_3
    //   321: bipush #32
    //   323: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   326: pop
    //   327: aload_3
    //   328: aload_0
    //   329: invokevirtual getLeft : ()I
    //   332: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   335: pop
    //   336: aload_3
    //   337: bipush #44
    //   339: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   342: pop
    //   343: aload_3
    //   344: aload_0
    //   345: invokevirtual getTop : ()I
    //   348: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   351: pop
    //   352: aload_3
    //   353: bipush #45
    //   355: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   358: pop
    //   359: aload_3
    //   360: aload_0
    //   361: invokevirtual getRight : ()I
    //   364: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   367: pop
    //   368: aload_3
    //   369: bipush #44
    //   371: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   374: pop
    //   375: aload_3
    //   376: aload_0
    //   377: invokevirtual getBottom : ()I
    //   380: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   383: pop
    //   384: aload_0
    //   385: invokevirtual getId : ()I
    //   388: istore_2
    //   389: iload_2
    //   390: iconst_m1
    //   391: if_icmpeq -> 520
    //   394: aload_3
    //   395: ldc ' #'
    //   397: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   400: pop
    //   401: aload_3
    //   402: iload_2
    //   403: invokestatic toHexString : (I)Ljava/lang/String;
    //   406: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   409: pop
    //   410: aload_0
    //   411: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   414: astore #6
    //   416: iload_2
    //   417: ifeq -> 520
    //   420: aload #6
    //   422: ifnull -> 520
    //   425: ldc -16777216
    //   427: iload_2
    //   428: iand
    //   429: lookupswitch default -> 456, 16777216 -> 663, 2130706432 -> 657
    //   456: aload #6
    //   458: iload_2
    //   459: invokevirtual getResourcePackageName : (I)Ljava/lang/String;
    //   462: astore_0
    //   463: aload #6
    //   465: iload_2
    //   466: invokevirtual getResourceTypeName : (I)Ljava/lang/String;
    //   469: astore #7
    //   471: aload #6
    //   473: iload_2
    //   474: invokevirtual getResourceEntryName : (I)Ljava/lang/String;
    //   477: astore #6
    //   479: aload_3
    //   480: ldc ' '
    //   482: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   485: pop
    //   486: aload_3
    //   487: aload_0
    //   488: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   491: pop
    //   492: aload_3
    //   493: ldc ':'
    //   495: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   498: pop
    //   499: aload_3
    //   500: aload #7
    //   502: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   505: pop
    //   506: aload_3
    //   507: ldc '/'
    //   509: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   512: pop
    //   513: aload_3
    //   514: aload #6
    //   516: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   519: pop
    //   520: aload_3
    //   521: ldc '}'
    //   523: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   526: pop
    //   527: aload_3
    //   528: invokevirtual toString : ()Ljava/lang/String;
    //   531: areturn
    //   532: aload_3
    //   533: bipush #86
    //   535: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   538: pop
    //   539: goto -> 99
    //   542: aload_3
    //   543: bipush #73
    //   545: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   548: pop
    //   549: goto -> 99
    //   552: aload_3
    //   553: bipush #71
    //   555: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   558: pop
    //   559: goto -> 99
    //   562: bipush #46
    //   564: istore #4
    //   566: iload #4
    //   568: istore #5
    //   570: goto -> 114
    //   573: bipush #46
    //   575: istore #4
    //   577: iload #4
    //   579: istore #5
    //   581: goto -> 136
    //   584: bipush #68
    //   586: istore #4
    //   588: iload #4
    //   590: istore #5
    //   592: goto -> 158
    //   595: bipush #46
    //   597: istore #4
    //   599: iload #4
    //   601: istore #5
    //   603: goto -> 180
    //   606: bipush #46
    //   608: istore #4
    //   610: iload #4
    //   612: istore #5
    //   614: goto -> 202
    //   617: bipush #46
    //   619: istore #4
    //   621: iload #4
    //   623: istore #5
    //   625: goto -> 224
    //   628: bipush #46
    //   630: istore #4
    //   632: iload #4
    //   634: istore #5
    //   636: goto -> 246
    //   639: bipush #46
    //   641: istore_1
    //   642: iload_1
    //   643: istore #5
    //   645: goto -> 270
    //   648: bipush #46
    //   650: istore_1
    //   651: iload_1
    //   652: istore #5
    //   654: goto -> 290
    //   657: ldc 'app'
    //   659: astore_0
    //   660: goto -> 463
    //   663: ldc 'android'
    //   665: astore_0
    //   666: goto -> 463
    //   669: astore_0
    //   670: goto -> 520
    // Exception table:
    //   from	to	target	type
    //   456	463	669	android/content/res/Resources$NotFoundException
    //   463	520	669	android/content/res/Resources$NotFoundException
  }
  
  void doReallyStop(boolean paramBoolean) {
    if (!this.mReallyStopped) {
      this.mReallyStopped = true;
      this.mRetaining = paramBoolean;
      this.mHandler.removeMessages(1);
      onReallyStop();
    } 
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    if (Build.VERSION.SDK_INT >= 11);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("Local FragmentActivity ");
    paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this)));
    paramPrintWriter.println(" State:");
    String str = paramString + "  ";
    paramPrintWriter.print(str);
    paramPrintWriter.print("mCreated=");
    paramPrintWriter.print(this.mCreated);
    paramPrintWriter.print("mResumed=");
    paramPrintWriter.print(this.mResumed);
    paramPrintWriter.print(" mStopped=");
    paramPrintWriter.print(this.mStopped);
    paramPrintWriter.print(" mReallyStopped=");
    paramPrintWriter.println(this.mReallyStopped);
    paramPrintWriter.print(str);
    paramPrintWriter.print("mLoadersStarted=");
    paramPrintWriter.println(this.mLoadersStarted);
    if (this.mLoaderManager != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("Loader Manager ");
      paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this.mLoaderManager)));
      paramPrintWriter.println(":");
      this.mLoaderManager.dump(paramString + "  ", paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    } 
    this.mFragments.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.println("View Hierarchy:");
    dumpViewHierarchy(paramString + "  ", paramPrintWriter, getWindow().getDecorView());
  }
  
  public Object getLastCustomNonConfigurationInstance() {
    null = (NonConfigurationInstances)getLastNonConfigurationInstance();
    return (null != null) ? null.custom : null;
  }
  
  LoaderManagerImpl getLoaderManager(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
    if (this.mAllLoaderManagers == null)
      this.mAllLoaderManagers = new SimpleArrayMap(); 
    LoaderManagerImpl loaderManagerImpl = (LoaderManagerImpl)this.mAllLoaderManagers.get(paramString);
    if (loaderManagerImpl == null) {
      if (paramBoolean2) {
        loaderManagerImpl = new LoaderManagerImpl(paramString, this, paramBoolean1);
        this.mAllLoaderManagers.put(paramString, loaderManagerImpl);
      } 
      return loaderManagerImpl;
    } 
    loaderManagerImpl.updateActivity(this);
    return loaderManagerImpl;
  }
  
  public FragmentManager getSupportFragmentManager() {
    return this.mFragments;
  }
  
  public LoaderManager getSupportLoaderManager() {
    if (this.mLoaderManager != null)
      return this.mLoaderManager; 
    this.mCheckedForLoaderManager = true;
    this.mLoaderManager = getLoaderManager("(root)", this.mLoadersStarted, true);
    return this.mLoaderManager;
  }
  
  void invalidateSupportFragment(String paramString) {
    if (this.mAllLoaderManagers != null) {
      LoaderManagerImpl loaderManagerImpl = (LoaderManagerImpl)this.mAllLoaderManagers.get(paramString);
      if (loaderManagerImpl != null && !loaderManagerImpl.mRetaining) {
        loaderManagerImpl.doDestroy();
        this.mAllLoaderManagers.remove(paramString);
      } 
    } 
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    this.mFragments.noteStateNotSaved();
    int i = paramInt1 >> 16;
    if (i != 0) {
      if (this.mFragments.mActive == null || --i < 0 || i >= this.mFragments.mActive.size()) {
        Log.w("FragmentActivity", "Activity result fragment index out of range: 0x" + Integer.toHexString(paramInt1));
        return;
      } 
      Fragment fragment = this.mFragments.mActive.get(i);
      if (fragment == null) {
        Log.w("FragmentActivity", "Activity result no fragment exists for index: 0x" + Integer.toHexString(paramInt1));
        return;
      } 
      fragment.onActivityResult(0xFFFF & paramInt1, paramInt2, paramIntent);
      return;
    } 
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  public void onAttachFragment(Fragment paramFragment) {}
  
  public void onBackPressed() {
    if (!this.mFragments.popBackStackImmediate())
      finish(); 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.mFragments.dispatchConfigurationChanged(paramConfiguration);
  }
  
  protected void onCreate(Bundle paramBundle) {
    Bundle bundle = null;
    this.mFragments.attachActivity(this, this.mContainer, null);
    if (getLayoutInflater().getFactory() == null)
      getLayoutInflater().setFactory((LayoutInflater.Factory)this); 
    super.onCreate(paramBundle);
    NonConfigurationInstances nonConfigurationInstances = (NonConfigurationInstances)getLastNonConfigurationInstance();
    if (nonConfigurationInstances != null)
      this.mAllLoaderManagers = nonConfigurationInstances.loaders; 
    if (paramBundle != null) {
      ArrayList<Fragment> arrayList;
      Parcelable parcelable = paramBundle.getParcelable("android:support:fragments");
      FragmentManagerImpl fragmentManagerImpl = this.mFragments;
      paramBundle = bundle;
      if (nonConfigurationInstances != null)
        arrayList = nonConfigurationInstances.fragments; 
      fragmentManagerImpl.restoreAllState(parcelable, arrayList);
    } 
    this.mFragments.dispatchCreate();
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    if (paramInt == 0) {
      int i = super.onCreatePanelMenu(paramInt, paramMenu) | this.mFragments.dispatchCreateOptionsMenu(paramMenu, getMenuInflater());
      if (Build.VERSION.SDK_INT < 11)
        i = 1; 
      return i;
    } 
    return super.onCreatePanelMenu(paramInt, paramMenu);
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    Context context = null;
    if (!"fragment".equals(paramString))
      return super.onCreateView(paramString, paramContext, paramAttributeSet); 
    String str1 = paramAttributeSet.getAttributeValue(null, "class");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, FragmentTag.Fragment);
    String str2 = str1;
    if (str1 == null)
      str2 = typedArray.getString(0); 
    int i = typedArray.getResourceId(1, -1);
    str1 = typedArray.getString(2);
    typedArray.recycle();
    if (!Fragment.isSupportFragmentClass((Context)this, str2))
      return super.onCreateView(paramString, paramContext, paramAttributeSet); 
    if (false)
      throw new NullPointerException(); 
    if (-1 == 0 && i == -1 && str1 == null)
      throw new IllegalArgumentException(paramAttributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + str2); 
    paramContext = context;
    if (i != -1)
      fragment2 = this.mFragments.findFragmentById(i); 
    Fragment fragment1 = fragment2;
    if (fragment2 == null) {
      fragment1 = fragment2;
      if (str1 != null)
        fragment1 = this.mFragments.findFragmentByTag(str1); 
    } 
    Fragment fragment2 = fragment1;
    if (fragment1 == null) {
      fragment2 = fragment1;
      if (-1 != 0)
        fragment2 = this.mFragments.findFragmentById(0); 
    } 
    if (FragmentManagerImpl.DEBUG)
      Log.v("FragmentActivity", "onCreateView: id=0x" + Integer.toHexString(i) + " fname=" + str2 + " existing=" + fragment2); 
    if (fragment2 == null) {
      boolean bool;
      fragment2 = Fragment.instantiate((Context)this, str2);
      fragment2.mFromLayout = true;
      if (i != 0) {
        bool = i;
      } else {
        bool = false;
      } 
      fragment2.mFragmentId = bool;
      fragment2.mContainerId = 0;
      fragment2.mTag = str1;
      fragment2.mInLayout = true;
      fragment2.mFragmentManager = this.mFragments;
      fragment2.onInflate(this, paramAttributeSet, fragment2.mSavedFragmentState);
      this.mFragments.addFragment(fragment2, true);
    } else {
      if (fragment2.mInLayout)
        throw new IllegalArgumentException(paramAttributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(i) + ", tag " + str1 + ", or parent id 0x" + Integer.toHexString(0) + " with another fragment for " + str2); 
      fragment2.mInLayout = true;
      if (!fragment2.mRetaining)
        fragment2.onInflate(this, paramAttributeSet, fragment2.mSavedFragmentState); 
      this.mFragments.moveToState(fragment2);
    } 
    if (fragment2.mView == null)
      throw new IllegalStateException("Fragment " + str2 + " did not create a view."); 
    if (i != 0)
      fragment2.mView.setId(i); 
    if (fragment2.mView.getTag() == null)
      fragment2.mView.setTag(str1); 
    return fragment2.mView;
  }
  
  protected void onDestroy() {
    super.onDestroy();
    doReallyStop(false);
    this.mFragments.dispatchDestroy();
    if (this.mLoaderManager != null)
      this.mLoaderManager.doDestroy(); 
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (Build.VERSION.SDK_INT < 5 && paramInt == 4 && paramKeyEvent.getRepeatCount() == 0) {
      onBackPressed();
      return true;
    } 
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public void onLowMemory() {
    super.onLowMemory();
    this.mFragments.dispatchLowMemory();
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    if (super.onMenuItemSelected(paramInt, paramMenuItem))
      return true; 
    switch (paramInt) {
      default:
        return false;
      case 0:
        return this.mFragments.dispatchOptionsItemSelected(paramMenuItem);
      case 6:
        break;
    } 
    return this.mFragments.dispatchContextItemSelected(paramMenuItem);
  }
  
  protected void onNewIntent(Intent paramIntent) {
    super.onNewIntent(paramIntent);
    this.mFragments.noteStateNotSaved();
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    switch (paramInt) {
      default:
        super.onPanelClosed(paramInt, paramMenu);
        return;
      case 0:
        break;
    } 
    this.mFragments.dispatchOptionsMenuClosed(paramMenu);
  }
  
  protected void onPause() {
    super.onPause();
    this.mResumed = false;
    if (this.mHandler.hasMessages(2)) {
      this.mHandler.removeMessages(2);
      onResumeFragments();
    } 
    this.mFragments.dispatchPause();
  }
  
  protected void onPostResume() {
    super.onPostResume();
    this.mHandler.removeMessages(2);
    onResumeFragments();
    this.mFragments.execPendingActions();
  }
  
  protected boolean onPrepareOptionsPanel(View paramView, Menu paramMenu) {
    return super.onPreparePanel(0, paramView, paramMenu);
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    if (paramInt == 0 && paramMenu != null) {
      if (this.mOptionsMenuInvalidated) {
        this.mOptionsMenuInvalidated = false;
        paramMenu.clear();
        onCreatePanelMenu(paramInt, paramMenu);
      } 
      return onPrepareOptionsPanel(paramView, paramMenu) | this.mFragments.dispatchPrepareOptionsMenu(paramMenu);
    } 
    return super.onPreparePanel(paramInt, paramView, paramMenu);
  }
  
  void onReallyStop() {
    if (this.mLoadersStarted) {
      this.mLoadersStarted = false;
      if (this.mLoaderManager != null)
        if (!this.mRetaining) {
          this.mLoaderManager.doStop();
        } else {
          this.mLoaderManager.doRetain();
        }  
    } 
    this.mFragments.dispatchReallyStop();
  }
  
  protected void onResume() {
    super.onResume();
    this.mHandler.sendEmptyMessage(2);
    this.mResumed = true;
    this.mFragments.execPendingActions();
  }
  
  protected void onResumeFragments() {
    this.mFragments.dispatchResume();
  }
  
  public Object onRetainCustomNonConfigurationInstance() {
    return null;
  }
  
  public final Object onRetainNonConfigurationInstance() {
    if (this.mStopped)
      doReallyStop(true); 
    Object object = onRetainCustomNonConfigurationInstance();
    ArrayList<Fragment> arrayList = this.mFragments.retainNonConfig();
    int i = 0;
    int j = 0;
    if (this.mAllLoaderManagers != null) {
      int k = this.mAllLoaderManagers.size();
      LoaderManagerImpl[] arrayOfLoaderManagerImpl = new LoaderManagerImpl[k];
      int m;
      for (m = k - 1; m >= 0; m--)
        arrayOfLoaderManagerImpl[m] = (LoaderManagerImpl)this.mAllLoaderManagers.valueAt(m); 
      i = 0;
      m = j;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          LoaderManagerImpl loaderManagerImpl = arrayOfLoaderManagerImpl[j];
          if (loaderManagerImpl.mRetaining) {
            m = 1;
          } else {
            loaderManagerImpl.doDestroy();
            this.mAllLoaderManagers.remove(loaderManagerImpl.mWho);
          } 
          j++;
          continue;
        } 
        break;
      } 
    } 
    if (arrayList == null && i == 0 && object == null)
      return null; 
    NonConfigurationInstances nonConfigurationInstances = new NonConfigurationInstances();
    nonConfigurationInstances.activity = null;
    nonConfigurationInstances.custom = object;
    nonConfigurationInstances.children = null;
    nonConfigurationInstances.fragments = arrayList;
    nonConfigurationInstances.loaders = this.mAllLoaderManagers;
    return nonConfigurationInstances;
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    Parcelable parcelable = this.mFragments.saveAllState();
    if (parcelable != null)
      paramBundle.putParcelable("android:support:fragments", parcelable); 
  }
  
  protected void onStart() {
    super.onStart();
    this.mStopped = false;
    this.mReallyStopped = false;
    this.mHandler.removeMessages(1);
    if (!this.mCreated) {
      this.mCreated = true;
      this.mFragments.dispatchActivityCreated();
    } 
    this.mFragments.noteStateNotSaved();
    this.mFragments.execPendingActions();
    if (!this.mLoadersStarted) {
      this.mLoadersStarted = true;
      if (this.mLoaderManager != null) {
        this.mLoaderManager.doStart();
      } else if (!this.mCheckedForLoaderManager) {
        this.mLoaderManager = getLoaderManager("(root)", this.mLoadersStarted, false);
        if (this.mLoaderManager != null && !this.mLoaderManager.mStarted)
          this.mLoaderManager.doStart(); 
      } 
      this.mCheckedForLoaderManager = true;
    } 
    this.mFragments.dispatchStart();
    if (this.mAllLoaderManagers != null) {
      int i = this.mAllLoaderManagers.size();
      LoaderManagerImpl[] arrayOfLoaderManagerImpl = new LoaderManagerImpl[i];
      int j;
      for (j = i - 1; j >= 0; j--)
        arrayOfLoaderManagerImpl[j] = (LoaderManagerImpl)this.mAllLoaderManagers.valueAt(j); 
      for (j = 0; j < i; j++) {
        LoaderManagerImpl loaderManagerImpl = arrayOfLoaderManagerImpl[j];
        loaderManagerImpl.finishRetain();
        loaderManagerImpl.doReportStart();
      } 
    } 
  }
  
  protected void onStop() {
    super.onStop();
    this.mStopped = true;
    this.mHandler.sendEmptyMessage(1);
    this.mFragments.dispatchStop();
  }
  
  public void startActivityForResult(Intent paramIntent, int paramInt) {
    if (paramInt != -1 && (0xFFFF0000 & paramInt) != 0)
      throw new IllegalArgumentException("Can only use lower 16 bits for requestCode"); 
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  public void startActivityFromFragment(Fragment paramFragment, Intent paramIntent, int paramInt) {
    if (paramInt == -1) {
      super.startActivityForResult(paramIntent, -1);
      return;
    } 
    if ((0xFFFF0000 & paramInt) != 0)
      throw new IllegalArgumentException("Can only use lower 16 bits for requestCode"); 
    super.startActivityForResult(paramIntent, (paramFragment.mIndex + 1 << 16) + (0xFFFF & paramInt));
  }
  
  public void supportInvalidateOptionsMenu() {
    if (Build.VERSION.SDK_INT >= 11) {
      ActivityCompatHoneycomb.invalidateOptionsMenu(this);
      return;
    } 
    this.mOptionsMenuInvalidated = true;
  }
  
  static class FragmentTag {
    public static final int[] Fragment = new int[] { 16842755, 16842960, 16842961 };
    
    public static final int Fragment_id = 1;
    
    public static final int Fragment_name = 0;
    
    public static final int Fragment_tag = 2;
  }
  
  static final class NonConfigurationInstances {
    Object activity;
    
    SimpleArrayMap<String, Object> children;
    
    Object custom;
    
    ArrayList<Fragment> fragments;
    
    SimpleArrayMap<String, LoaderManagerImpl> loaders;
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeCMCC-dex2jar.jar!/android/support/v4/app/FragmentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */