package android.support.v4.app;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.v4.util.DebugUtils;
import android.support.v4.util.LogWriter;
import android.util.Log;
import android.util.SparseArray;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

final class FragmentManagerImpl extends FragmentManager {
  static final Interpolator ACCELERATE_CUBIC;
  
  static final Interpolator ACCELERATE_QUINT;
  
  static final int ANIM_DUR = 220;
  
  public static final int ANIM_STYLE_CLOSE_ENTER = 3;
  
  public static final int ANIM_STYLE_CLOSE_EXIT = 4;
  
  public static final int ANIM_STYLE_FADE_ENTER = 5;
  
  public static final int ANIM_STYLE_FADE_EXIT = 6;
  
  public static final int ANIM_STYLE_OPEN_ENTER = 1;
  
  public static final int ANIM_STYLE_OPEN_EXIT = 2;
  
  static boolean DEBUG = false;
  
  static final Interpolator DECELERATE_CUBIC;
  
  static final Interpolator DECELERATE_QUINT;
  
  static final boolean HONEYCOMB;
  
  static final String TAG = "FragmentManager";
  
  static final String TARGET_REQUEST_CODE_STATE_TAG = "android:target_req_state";
  
  static final String TARGET_STATE_TAG = "android:target_state";
  
  static final String USER_VISIBLE_HINT_TAG = "android:user_visible_hint";
  
  static final String VIEW_STATE_TAG = "android:view_state";
  
  ArrayList<Fragment> mActive;
  
  FragmentActivity mActivity;
  
  ArrayList<Fragment> mAdded;
  
  ArrayList<Integer> mAvailBackStackIndices;
  
  ArrayList<Integer> mAvailIndices;
  
  ArrayList<BackStackRecord> mBackStack;
  
  ArrayList<FragmentManager.OnBackStackChangedListener> mBackStackChangeListeners;
  
  ArrayList<BackStackRecord> mBackStackIndices;
  
  FragmentContainer mContainer;
  
  ArrayList<Fragment> mCreatedMenus;
  
  int mCurState = 0;
  
  boolean mDestroyed;
  
  Runnable mExecCommit = new Runnable() {
      public void run() {
        FragmentManagerImpl.this.execPendingActions();
      }
    };
  
  boolean mExecutingActions;
  
  boolean mHavePendingDeferredStart;
  
  boolean mNeedMenuInvalidate;
  
  String mNoTransactionsBecause;
  
  Fragment mParent;
  
  ArrayList<Runnable> mPendingActions;
  
  SparseArray<Parcelable> mStateArray = null;
  
  Bundle mStateBundle = null;
  
  boolean mStateSaved;
  
  Runnable[] mTmpActions;
  
  static {
    if (Build.VERSION.SDK_INT >= 11)
      bool = true; 
    HONEYCOMB = bool;
    DECELERATE_QUINT = (Interpolator)new DecelerateInterpolator(2.5F);
    DECELERATE_CUBIC = (Interpolator)new DecelerateInterpolator(1.5F);
    ACCELERATE_QUINT = (Interpolator)new AccelerateInterpolator(2.5F);
    ACCELERATE_CUBIC = (Interpolator)new AccelerateInterpolator(1.5F);
  }
  
  private void checkStateLoss() {
    if (this.mStateSaved)
      throw new IllegalStateException("Can not perform this action after onSaveInstanceState"); 
    if (this.mNoTransactionsBecause != null)
      throw new IllegalStateException("Can not perform this action inside of " + this.mNoTransactionsBecause); 
  }
  
  static Animation makeFadeAnimation(Context paramContext, float paramFloat1, float paramFloat2) {
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat1, paramFloat2);
    alphaAnimation.setInterpolator(DECELERATE_CUBIC);
    alphaAnimation.setDuration(220L);
    return (Animation)alphaAnimation;
  }
  
  static Animation makeOpenCloseAnimation(Context paramContext, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    AnimationSet animationSet = new AnimationSet(false);
    ScaleAnimation scaleAnimation = new ScaleAnimation(paramFloat1, paramFloat2, paramFloat1, paramFloat2, 1, 0.5F, 1, 0.5F);
    scaleAnimation.setInterpolator(DECELERATE_QUINT);
    scaleAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)scaleAnimation);
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat3, paramFloat4);
    alphaAnimation.setInterpolator(DECELERATE_CUBIC);
    alphaAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)alphaAnimation);
    return (Animation)animationSet;
  }
  
  public static int reverseTransit(int paramInt) {
    boolean bool = false;
    switch (paramInt) {
      default:
        return bool;
      case 4097:
        return 8194;
      case 8194:
        return 4097;
      case 4099:
        break;
    } 
    return 4099;
  }
  
  private void throwException(RuntimeException paramRuntimeException) {
    Log.e("FragmentManager", paramRuntimeException.getMessage());
    Log.e("FragmentManager", "Activity state:");
    PrintWriter printWriter = new PrintWriter((Writer)new LogWriter("FragmentManager"));
    if (this.mActivity != null) {
      try {
        this.mActivity.dump("  ", (FileDescriptor)null, printWriter, new String[0]);
      } catch (Exception exception) {
        Log.e("FragmentManager", "Failed dumping state", exception);
      } 
      throw paramRuntimeException;
    } 
    try {
      dump("  ", null, (PrintWriter)exception, new String[0]);
    } catch (Exception exception1) {
      Log.e("FragmentManager", "Failed dumping state", exception1);
    } 
    throw paramRuntimeException;
  }
  
  public static int transitToStyleIndex(int paramInt, boolean paramBoolean) {
    byte b = -1;
    switch (paramInt) {
      default:
        return b;
      case 4097:
        return paramBoolean ? 1 : 2;
      case 8194:
        return paramBoolean ? 3 : 4;
      case 4099:
        break;
    } 
    return paramBoolean ? 5 : 6;
  }
  
  void addBackStackState(BackStackRecord paramBackStackRecord) {
    if (this.mBackStack == null)
      this.mBackStack = new ArrayList<BackStackRecord>(); 
    this.mBackStack.add(paramBackStackRecord);
    reportBackStackChanged();
  }
  
  public void addFragment(Fragment paramFragment, boolean paramBoolean) {
    if (this.mAdded == null)
      this.mAdded = new ArrayList<Fragment>(); 
    if (DEBUG)
      Log.v("FragmentManager", "add: " + paramFragment); 
    makeActive(paramFragment);
    if (!paramFragment.mDetached) {
      if (this.mAdded.contains(paramFragment))
        throw new IllegalStateException("Fragment already added: " + paramFragment); 
      this.mAdded.add(paramFragment);
      paramFragment.mAdded = true;
      paramFragment.mRemoving = false;
      if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
        this.mNeedMenuInvalidate = true; 
      if (paramBoolean)
        moveToState(paramFragment); 
    } 
  }
  
  public void addOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener) {
    if (this.mBackStackChangeListeners == null)
      this.mBackStackChangeListeners = new ArrayList<FragmentManager.OnBackStackChangedListener>(); 
    this.mBackStackChangeListeners.add(paramOnBackStackChangedListener);
  }
  
  public int allocBackStackIndex(BackStackRecord paramBackStackRecord) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   6: ifnull -> 19
    //   9: aload_0
    //   10: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   13: invokevirtual size : ()I
    //   16: ifgt -> 104
    //   19: aload_0
    //   20: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   23: ifnonnull -> 39
    //   26: new java/util/ArrayList
    //   29: astore_2
    //   30: aload_2
    //   31: invokespecial <init> : ()V
    //   34: aload_0
    //   35: aload_2
    //   36: putfield mBackStackIndices : Ljava/util/ArrayList;
    //   39: aload_0
    //   40: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   43: invokevirtual size : ()I
    //   46: istore_3
    //   47: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   50: ifeq -> 91
    //   53: new java/lang/StringBuilder
    //   56: astore_2
    //   57: aload_2
    //   58: invokespecial <init> : ()V
    //   61: ldc 'FragmentManager'
    //   63: aload_2
    //   64: ldc_w 'Setting back stack index '
    //   67: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   70: iload_3
    //   71: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   74: ldc_w ' to '
    //   77: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: aload_1
    //   81: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   84: invokevirtual toString : ()Ljava/lang/String;
    //   87: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   90: pop
    //   91: aload_0
    //   92: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   95: aload_1
    //   96: invokevirtual add : (Ljava/lang/Object;)Z
    //   99: pop
    //   100: aload_0
    //   101: monitorexit
    //   102: iload_3
    //   103: ireturn
    //   104: aload_0
    //   105: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   108: aload_0
    //   109: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   112: invokevirtual size : ()I
    //   115: iconst_1
    //   116: isub
    //   117: invokevirtual remove : (I)Ljava/lang/Object;
    //   120: checkcast java/lang/Integer
    //   123: invokevirtual intValue : ()I
    //   126: istore_3
    //   127: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   130: ifeq -> 171
    //   133: new java/lang/StringBuilder
    //   136: astore_2
    //   137: aload_2
    //   138: invokespecial <init> : ()V
    //   141: ldc 'FragmentManager'
    //   143: aload_2
    //   144: ldc_w 'Adding back stack index '
    //   147: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   150: iload_3
    //   151: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   154: ldc_w ' with '
    //   157: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   160: aload_1
    //   161: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   164: invokevirtual toString : ()Ljava/lang/String;
    //   167: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   170: pop
    //   171: aload_0
    //   172: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   175: iload_3
    //   176: aload_1
    //   177: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   180: pop
    //   181: aload_0
    //   182: monitorexit
    //   183: goto -> 102
    //   186: astore_1
    //   187: aload_0
    //   188: monitorexit
    //   189: aload_1
    //   190: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	186	finally
    //   19	39	186	finally
    //   39	91	186	finally
    //   91	102	186	finally
    //   104	171	186	finally
    //   171	183	186	finally
    //   187	189	186	finally
  }
  
  public void attachActivity(FragmentActivity paramFragmentActivity, FragmentContainer paramFragmentContainer, Fragment paramFragment) {
    if (this.mActivity != null)
      throw new IllegalStateException("Already attached"); 
    this.mActivity = paramFragmentActivity;
    this.mContainer = paramFragmentContainer;
    this.mParent = paramFragment;
  }
  
  public void attachFragment(Fragment paramFragment, int paramInt1, int paramInt2) {
    if (DEBUG)
      Log.v("FragmentManager", "attach: " + paramFragment); 
    if (paramFragment.mDetached) {
      paramFragment.mDetached = false;
      if (!paramFragment.mAdded) {
        if (this.mAdded == null)
          this.mAdded = new ArrayList<Fragment>(); 
        if (this.mAdded.contains(paramFragment))
          throw new IllegalStateException("Fragment already added: " + paramFragment); 
        if (DEBUG)
          Log.v("FragmentManager", "add from attach: " + paramFragment); 
        this.mAdded.add(paramFragment);
        paramFragment.mAdded = true;
        if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
          this.mNeedMenuInvalidate = true; 
        moveToState(paramFragment, this.mCurState, paramInt1, paramInt2, false);
      } 
    } 
  }
  
  public FragmentTransaction beginTransaction() {
    return new BackStackRecord(this);
  }
  
  public void detachFragment(Fragment paramFragment, int paramInt1, int paramInt2) {
    if (DEBUG)
      Log.v("FragmentManager", "detach: " + paramFragment); 
    if (!paramFragment.mDetached) {
      paramFragment.mDetached = true;
      if (paramFragment.mAdded) {
        if (this.mAdded != null) {
          if (DEBUG)
            Log.v("FragmentManager", "remove from detach: " + paramFragment); 
          this.mAdded.remove(paramFragment);
        } 
        if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
          this.mNeedMenuInvalidate = true; 
        paramFragment.mAdded = false;
        moveToState(paramFragment, 1, paramInt1, paramInt2, false);
      } 
    } 
  }
  
  public void dispatchActivityCreated() {
    this.mStateSaved = false;
    moveToState(2, false);
  }
  
  public void dispatchConfigurationChanged(Configuration paramConfiguration) {
    if (this.mAdded != null)
      for (byte b = 0; b < this.mAdded.size(); b++) {
        Fragment fragment = this.mAdded.get(b);
        if (fragment != null)
          fragment.performConfigurationChanged(paramConfiguration); 
      }  
  }
  
  public boolean dispatchContextItemSelected(MenuItem paramMenuItem) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mAdded : Ljava/util/ArrayList;
    //   4: ifnull -> 56
    //   7: iconst_0
    //   8: istore_2
    //   9: iload_2
    //   10: aload_0
    //   11: getfield mAdded : Ljava/util/ArrayList;
    //   14: invokevirtual size : ()I
    //   17: if_icmpge -> 56
    //   20: aload_0
    //   21: getfield mAdded : Ljava/util/ArrayList;
    //   24: iload_2
    //   25: invokevirtual get : (I)Ljava/lang/Object;
    //   28: checkcast android/support/v4/app/Fragment
    //   31: astore_3
    //   32: aload_3
    //   33: ifnull -> 50
    //   36: aload_3
    //   37: aload_1
    //   38: invokevirtual performContextItemSelected : (Landroid/view/MenuItem;)Z
    //   41: ifeq -> 50
    //   44: iconst_1
    //   45: istore #4
    //   47: iload #4
    //   49: ireturn
    //   50: iinc #2, 1
    //   53: goto -> 9
    //   56: iconst_0
    //   57: istore #4
    //   59: goto -> 47
  }
  
  public void dispatchCreate() {
    this.mStateSaved = false;
    moveToState(1, false);
  }
  
  public boolean dispatchCreateOptionsMenu(Menu paramMenu, MenuInflater paramMenuInflater) {
    boolean bool1 = false;
    boolean bool2 = false;
    ArrayList<Fragment> arrayList1 = null;
    ArrayList<Fragment> arrayList2 = null;
    if (this.mAdded != null) {
      byte b = 0;
      while (true) {
        arrayList1 = arrayList2;
        bool1 = bool2;
        if (b < this.mAdded.size()) {
          Fragment fragment = this.mAdded.get(b);
          arrayList1 = arrayList2;
          bool1 = bool2;
          if (fragment != null) {
            arrayList1 = arrayList2;
            bool1 = bool2;
            if (fragment.performCreateOptionsMenu(paramMenu, paramMenuInflater)) {
              bool1 = true;
              arrayList1 = arrayList2;
              if (arrayList2 == null)
                arrayList1 = new ArrayList(); 
              arrayList1.add(fragment);
            } 
          } 
          b++;
          arrayList2 = arrayList1;
          bool2 = bool1;
          continue;
        } 
        break;
      } 
    } 
    if (this.mCreatedMenus != null)
      for (byte b = 0; b < this.mCreatedMenus.size(); b++) {
        Fragment fragment = this.mCreatedMenus.get(b);
        if (arrayList1 == null || !arrayList1.contains(fragment))
          fragment.onDestroyOptionsMenu(); 
      }  
    this.mCreatedMenus = arrayList1;
    return bool1;
  }
  
  public void dispatchDestroy() {
    this.mDestroyed = true;
    execPendingActions();
    moveToState(0, false);
    this.mActivity = null;
    this.mContainer = null;
    this.mParent = null;
  }
  
  public void dispatchDestroyView() {
    moveToState(1, false);
  }
  
  public void dispatchLowMemory() {
    if (this.mAdded != null)
      for (byte b = 0; b < this.mAdded.size(); b++) {
        Fragment fragment = this.mAdded.get(b);
        if (fragment != null)
          fragment.performLowMemory(); 
      }  
  }
  
  public boolean dispatchOptionsItemSelected(MenuItem paramMenuItem) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mAdded : Ljava/util/ArrayList;
    //   4: ifnull -> 56
    //   7: iconst_0
    //   8: istore_2
    //   9: iload_2
    //   10: aload_0
    //   11: getfield mAdded : Ljava/util/ArrayList;
    //   14: invokevirtual size : ()I
    //   17: if_icmpge -> 56
    //   20: aload_0
    //   21: getfield mAdded : Ljava/util/ArrayList;
    //   24: iload_2
    //   25: invokevirtual get : (I)Ljava/lang/Object;
    //   28: checkcast android/support/v4/app/Fragment
    //   31: astore_3
    //   32: aload_3
    //   33: ifnull -> 50
    //   36: aload_3
    //   37: aload_1
    //   38: invokevirtual performOptionsItemSelected : (Landroid/view/MenuItem;)Z
    //   41: ifeq -> 50
    //   44: iconst_1
    //   45: istore #4
    //   47: iload #4
    //   49: ireturn
    //   50: iinc #2, 1
    //   53: goto -> 9
    //   56: iconst_0
    //   57: istore #4
    //   59: goto -> 47
  }
  
  public void dispatchOptionsMenuClosed(Menu paramMenu) {
    if (this.mAdded != null)
      for (byte b = 0; b < this.mAdded.size(); b++) {
        Fragment fragment = this.mAdded.get(b);
        if (fragment != null)
          fragment.performOptionsMenuClosed(paramMenu); 
      }  
  }
  
  public void dispatchPause() {
    moveToState(4, false);
  }
  
  public boolean dispatchPrepareOptionsMenu(Menu paramMenu) {
    boolean bool1 = false;
    boolean bool2 = false;
    if (this.mAdded != null) {
      byte b = 0;
      while (true) {
        bool1 = bool2;
        if (b < this.mAdded.size()) {
          Fragment fragment = this.mAdded.get(b);
          bool1 = bool2;
          if (fragment != null) {
            bool1 = bool2;
            if (fragment.performPrepareOptionsMenu(paramMenu))
              bool1 = true; 
          } 
          b++;
          bool2 = bool1;
          continue;
        } 
        break;
      } 
    } 
    return bool1;
  }
  
  public void dispatchReallyStop() {
    moveToState(2, false);
  }
  
  public void dispatchResume() {
    this.mStateSaved = false;
    moveToState(5, false);
  }
  
  public void dispatchStart() {
    this.mStateSaved = false;
    moveToState(4, false);
  }
  
  public void dispatchStop() {
    this.mStateSaved = true;
    moveToState(3, false);
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: aload_1
    //   8: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   11: ldc_w '    '
    //   14: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   17: invokevirtual toString : ()Ljava/lang/String;
    //   20: astore #5
    //   22: aload_0
    //   23: getfield mActive : Ljava/util/ArrayList;
    //   26: ifnull -> 150
    //   29: aload_0
    //   30: getfield mActive : Ljava/util/ArrayList;
    //   33: invokevirtual size : ()I
    //   36: istore #6
    //   38: iload #6
    //   40: ifle -> 150
    //   43: aload_3
    //   44: aload_1
    //   45: invokevirtual print : (Ljava/lang/String;)V
    //   48: aload_3
    //   49: ldc_w 'Active Fragments in '
    //   52: invokevirtual print : (Ljava/lang/String;)V
    //   55: aload_3
    //   56: aload_0
    //   57: invokestatic identityHashCode : (Ljava/lang/Object;)I
    //   60: invokestatic toHexString : (I)Ljava/lang/String;
    //   63: invokevirtual print : (Ljava/lang/String;)V
    //   66: aload_3
    //   67: ldc_w ':'
    //   70: invokevirtual println : (Ljava/lang/String;)V
    //   73: iconst_0
    //   74: istore #7
    //   76: iload #7
    //   78: iload #6
    //   80: if_icmpge -> 150
    //   83: aload_0
    //   84: getfield mActive : Ljava/util/ArrayList;
    //   87: iload #7
    //   89: invokevirtual get : (I)Ljava/lang/Object;
    //   92: checkcast android/support/v4/app/Fragment
    //   95: astore #8
    //   97: aload_3
    //   98: aload_1
    //   99: invokevirtual print : (Ljava/lang/String;)V
    //   102: aload_3
    //   103: ldc_w '  #'
    //   106: invokevirtual print : (Ljava/lang/String;)V
    //   109: aload_3
    //   110: iload #7
    //   112: invokevirtual print : (I)V
    //   115: aload_3
    //   116: ldc_w ': '
    //   119: invokevirtual print : (Ljava/lang/String;)V
    //   122: aload_3
    //   123: aload #8
    //   125: invokevirtual println : (Ljava/lang/Object;)V
    //   128: aload #8
    //   130: ifnull -> 144
    //   133: aload #8
    //   135: aload #5
    //   137: aload_2
    //   138: aload_3
    //   139: aload #4
    //   141: invokevirtual dump : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   144: iinc #7, 1
    //   147: goto -> 76
    //   150: aload_0
    //   151: getfield mAdded : Ljava/util/ArrayList;
    //   154: ifnull -> 247
    //   157: aload_0
    //   158: getfield mAdded : Ljava/util/ArrayList;
    //   161: invokevirtual size : ()I
    //   164: istore #6
    //   166: iload #6
    //   168: ifle -> 247
    //   171: aload_3
    //   172: aload_1
    //   173: invokevirtual print : (Ljava/lang/String;)V
    //   176: aload_3
    //   177: ldc_w 'Added Fragments:'
    //   180: invokevirtual println : (Ljava/lang/String;)V
    //   183: iconst_0
    //   184: istore #7
    //   186: iload #7
    //   188: iload #6
    //   190: if_icmpge -> 247
    //   193: aload_0
    //   194: getfield mAdded : Ljava/util/ArrayList;
    //   197: iload #7
    //   199: invokevirtual get : (I)Ljava/lang/Object;
    //   202: checkcast android/support/v4/app/Fragment
    //   205: astore #8
    //   207: aload_3
    //   208: aload_1
    //   209: invokevirtual print : (Ljava/lang/String;)V
    //   212: aload_3
    //   213: ldc_w '  #'
    //   216: invokevirtual print : (Ljava/lang/String;)V
    //   219: aload_3
    //   220: iload #7
    //   222: invokevirtual print : (I)V
    //   225: aload_3
    //   226: ldc_w ': '
    //   229: invokevirtual print : (Ljava/lang/String;)V
    //   232: aload_3
    //   233: aload #8
    //   235: invokevirtual toString : ()Ljava/lang/String;
    //   238: invokevirtual println : (Ljava/lang/String;)V
    //   241: iinc #7, 1
    //   244: goto -> 186
    //   247: aload_0
    //   248: getfield mCreatedMenus : Ljava/util/ArrayList;
    //   251: ifnull -> 344
    //   254: aload_0
    //   255: getfield mCreatedMenus : Ljava/util/ArrayList;
    //   258: invokevirtual size : ()I
    //   261: istore #6
    //   263: iload #6
    //   265: ifle -> 344
    //   268: aload_3
    //   269: aload_1
    //   270: invokevirtual print : (Ljava/lang/String;)V
    //   273: aload_3
    //   274: ldc_w 'Fragments Created Menus:'
    //   277: invokevirtual println : (Ljava/lang/String;)V
    //   280: iconst_0
    //   281: istore #7
    //   283: iload #7
    //   285: iload #6
    //   287: if_icmpge -> 344
    //   290: aload_0
    //   291: getfield mCreatedMenus : Ljava/util/ArrayList;
    //   294: iload #7
    //   296: invokevirtual get : (I)Ljava/lang/Object;
    //   299: checkcast android/support/v4/app/Fragment
    //   302: astore #8
    //   304: aload_3
    //   305: aload_1
    //   306: invokevirtual print : (Ljava/lang/String;)V
    //   309: aload_3
    //   310: ldc_w '  #'
    //   313: invokevirtual print : (Ljava/lang/String;)V
    //   316: aload_3
    //   317: iload #7
    //   319: invokevirtual print : (I)V
    //   322: aload_3
    //   323: ldc_w ': '
    //   326: invokevirtual print : (Ljava/lang/String;)V
    //   329: aload_3
    //   330: aload #8
    //   332: invokevirtual toString : ()Ljava/lang/String;
    //   335: invokevirtual println : (Ljava/lang/String;)V
    //   338: iinc #7, 1
    //   341: goto -> 283
    //   344: aload_0
    //   345: getfield mBackStack : Ljava/util/ArrayList;
    //   348: ifnull -> 452
    //   351: aload_0
    //   352: getfield mBackStack : Ljava/util/ArrayList;
    //   355: invokevirtual size : ()I
    //   358: istore #6
    //   360: iload #6
    //   362: ifle -> 452
    //   365: aload_3
    //   366: aload_1
    //   367: invokevirtual print : (Ljava/lang/String;)V
    //   370: aload_3
    //   371: ldc_w 'Back Stack:'
    //   374: invokevirtual println : (Ljava/lang/String;)V
    //   377: iconst_0
    //   378: istore #7
    //   380: iload #7
    //   382: iload #6
    //   384: if_icmpge -> 452
    //   387: aload_0
    //   388: getfield mBackStack : Ljava/util/ArrayList;
    //   391: iload #7
    //   393: invokevirtual get : (I)Ljava/lang/Object;
    //   396: checkcast android/support/v4/app/BackStackRecord
    //   399: astore #8
    //   401: aload_3
    //   402: aload_1
    //   403: invokevirtual print : (Ljava/lang/String;)V
    //   406: aload_3
    //   407: ldc_w '  #'
    //   410: invokevirtual print : (Ljava/lang/String;)V
    //   413: aload_3
    //   414: iload #7
    //   416: invokevirtual print : (I)V
    //   419: aload_3
    //   420: ldc_w ': '
    //   423: invokevirtual print : (Ljava/lang/String;)V
    //   426: aload_3
    //   427: aload #8
    //   429: invokevirtual toString : ()Ljava/lang/String;
    //   432: invokevirtual println : (Ljava/lang/String;)V
    //   435: aload #8
    //   437: aload #5
    //   439: aload_2
    //   440: aload_3
    //   441: aload #4
    //   443: invokevirtual dump : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   446: iinc #7, 1
    //   449: goto -> 380
    //   452: aload_0
    //   453: monitorenter
    //   454: aload_0
    //   455: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   458: ifnull -> 546
    //   461: aload_0
    //   462: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   465: invokevirtual size : ()I
    //   468: istore #6
    //   470: iload #6
    //   472: ifle -> 546
    //   475: aload_3
    //   476: aload_1
    //   477: invokevirtual print : (Ljava/lang/String;)V
    //   480: aload_3
    //   481: ldc_w 'Back Stack Indices:'
    //   484: invokevirtual println : (Ljava/lang/String;)V
    //   487: iconst_0
    //   488: istore #7
    //   490: iload #7
    //   492: iload #6
    //   494: if_icmpge -> 546
    //   497: aload_0
    //   498: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   501: iload #7
    //   503: invokevirtual get : (I)Ljava/lang/Object;
    //   506: checkcast android/support/v4/app/BackStackRecord
    //   509: astore_2
    //   510: aload_3
    //   511: aload_1
    //   512: invokevirtual print : (Ljava/lang/String;)V
    //   515: aload_3
    //   516: ldc_w '  #'
    //   519: invokevirtual print : (Ljava/lang/String;)V
    //   522: aload_3
    //   523: iload #7
    //   525: invokevirtual print : (I)V
    //   528: aload_3
    //   529: ldc_w ': '
    //   532: invokevirtual print : (Ljava/lang/String;)V
    //   535: aload_3
    //   536: aload_2
    //   537: invokevirtual println : (Ljava/lang/Object;)V
    //   540: iinc #7, 1
    //   543: goto -> 490
    //   546: aload_0
    //   547: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   550: ifnull -> 589
    //   553: aload_0
    //   554: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   557: invokevirtual size : ()I
    //   560: ifle -> 589
    //   563: aload_3
    //   564: aload_1
    //   565: invokevirtual print : (Ljava/lang/String;)V
    //   568: aload_3
    //   569: ldc_w 'mAvailBackStackIndices: '
    //   572: invokevirtual print : (Ljava/lang/String;)V
    //   575: aload_3
    //   576: aload_0
    //   577: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   580: invokevirtual toArray : ()[Ljava/lang/Object;
    //   583: invokestatic toString : ([Ljava/lang/Object;)Ljava/lang/String;
    //   586: invokevirtual println : (Ljava/lang/String;)V
    //   589: aload_0
    //   590: monitorexit
    //   591: aload_0
    //   592: getfield mPendingActions : Ljava/util/ArrayList;
    //   595: ifnull -> 688
    //   598: aload_0
    //   599: getfield mPendingActions : Ljava/util/ArrayList;
    //   602: invokevirtual size : ()I
    //   605: istore #6
    //   607: iload #6
    //   609: ifle -> 688
    //   612: aload_3
    //   613: aload_1
    //   614: invokevirtual print : (Ljava/lang/String;)V
    //   617: aload_3
    //   618: ldc_w 'Pending Actions:'
    //   621: invokevirtual println : (Ljava/lang/String;)V
    //   624: iconst_0
    //   625: istore #7
    //   627: iload #7
    //   629: iload #6
    //   631: if_icmpge -> 688
    //   634: aload_0
    //   635: getfield mPendingActions : Ljava/util/ArrayList;
    //   638: iload #7
    //   640: invokevirtual get : (I)Ljava/lang/Object;
    //   643: checkcast java/lang/Runnable
    //   646: astore_2
    //   647: aload_3
    //   648: aload_1
    //   649: invokevirtual print : (Ljava/lang/String;)V
    //   652: aload_3
    //   653: ldc_w '  #'
    //   656: invokevirtual print : (Ljava/lang/String;)V
    //   659: aload_3
    //   660: iload #7
    //   662: invokevirtual print : (I)V
    //   665: aload_3
    //   666: ldc_w ': '
    //   669: invokevirtual print : (Ljava/lang/String;)V
    //   672: aload_3
    //   673: aload_2
    //   674: invokevirtual println : (Ljava/lang/Object;)V
    //   677: iinc #7, 1
    //   680: goto -> 627
    //   683: astore_1
    //   684: aload_0
    //   685: monitorexit
    //   686: aload_1
    //   687: athrow
    //   688: aload_3
    //   689: aload_1
    //   690: invokevirtual print : (Ljava/lang/String;)V
    //   693: aload_3
    //   694: ldc_w 'FragmentManager misc state:'
    //   697: invokevirtual println : (Ljava/lang/String;)V
    //   700: aload_3
    //   701: aload_1
    //   702: invokevirtual print : (Ljava/lang/String;)V
    //   705: aload_3
    //   706: ldc_w '  mActivity='
    //   709: invokevirtual print : (Ljava/lang/String;)V
    //   712: aload_3
    //   713: aload_0
    //   714: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   717: invokevirtual println : (Ljava/lang/Object;)V
    //   720: aload_3
    //   721: aload_1
    //   722: invokevirtual print : (Ljava/lang/String;)V
    //   725: aload_3
    //   726: ldc_w '  mContainer='
    //   729: invokevirtual print : (Ljava/lang/String;)V
    //   732: aload_3
    //   733: aload_0
    //   734: getfield mContainer : Landroid/support/v4/app/FragmentContainer;
    //   737: invokevirtual println : (Ljava/lang/Object;)V
    //   740: aload_0
    //   741: getfield mParent : Landroid/support/v4/app/Fragment;
    //   744: ifnull -> 767
    //   747: aload_3
    //   748: aload_1
    //   749: invokevirtual print : (Ljava/lang/String;)V
    //   752: aload_3
    //   753: ldc_w '  mParent='
    //   756: invokevirtual print : (Ljava/lang/String;)V
    //   759: aload_3
    //   760: aload_0
    //   761: getfield mParent : Landroid/support/v4/app/Fragment;
    //   764: invokevirtual println : (Ljava/lang/Object;)V
    //   767: aload_3
    //   768: aload_1
    //   769: invokevirtual print : (Ljava/lang/String;)V
    //   772: aload_3
    //   773: ldc_w '  mCurState='
    //   776: invokevirtual print : (Ljava/lang/String;)V
    //   779: aload_3
    //   780: aload_0
    //   781: getfield mCurState : I
    //   784: invokevirtual print : (I)V
    //   787: aload_3
    //   788: ldc_w ' mStateSaved='
    //   791: invokevirtual print : (Ljava/lang/String;)V
    //   794: aload_3
    //   795: aload_0
    //   796: getfield mStateSaved : Z
    //   799: invokevirtual print : (Z)V
    //   802: aload_3
    //   803: ldc_w ' mDestroyed='
    //   806: invokevirtual print : (Ljava/lang/String;)V
    //   809: aload_3
    //   810: aload_0
    //   811: getfield mDestroyed : Z
    //   814: invokevirtual println : (Z)V
    //   817: aload_0
    //   818: getfield mNeedMenuInvalidate : Z
    //   821: ifeq -> 844
    //   824: aload_3
    //   825: aload_1
    //   826: invokevirtual print : (Ljava/lang/String;)V
    //   829: aload_3
    //   830: ldc_w '  mNeedMenuInvalidate='
    //   833: invokevirtual print : (Ljava/lang/String;)V
    //   836: aload_3
    //   837: aload_0
    //   838: getfield mNeedMenuInvalidate : Z
    //   841: invokevirtual println : (Z)V
    //   844: aload_0
    //   845: getfield mNoTransactionsBecause : Ljava/lang/String;
    //   848: ifnull -> 871
    //   851: aload_3
    //   852: aload_1
    //   853: invokevirtual print : (Ljava/lang/String;)V
    //   856: aload_3
    //   857: ldc_w '  mNoTransactionsBecause='
    //   860: invokevirtual print : (Ljava/lang/String;)V
    //   863: aload_3
    //   864: aload_0
    //   865: getfield mNoTransactionsBecause : Ljava/lang/String;
    //   868: invokevirtual println : (Ljava/lang/String;)V
    //   871: aload_0
    //   872: getfield mAvailIndices : Ljava/util/ArrayList;
    //   875: ifnull -> 914
    //   878: aload_0
    //   879: getfield mAvailIndices : Ljava/util/ArrayList;
    //   882: invokevirtual size : ()I
    //   885: ifle -> 914
    //   888: aload_3
    //   889: aload_1
    //   890: invokevirtual print : (Ljava/lang/String;)V
    //   893: aload_3
    //   894: ldc_w '  mAvailIndices: '
    //   897: invokevirtual print : (Ljava/lang/String;)V
    //   900: aload_3
    //   901: aload_0
    //   902: getfield mAvailIndices : Ljava/util/ArrayList;
    //   905: invokevirtual toArray : ()[Ljava/lang/Object;
    //   908: invokestatic toString : ([Ljava/lang/Object;)Ljava/lang/String;
    //   911: invokevirtual println : (Ljava/lang/String;)V
    //   914: return
    // Exception table:
    //   from	to	target	type
    //   454	470	683	finally
    //   475	487	683	finally
    //   497	540	683	finally
    //   546	589	683	finally
    //   589	591	683	finally
    //   684	686	683	finally
  }
  
  public void enqueueAction(Runnable paramRunnable, boolean paramBoolean) {
    // Byte code:
    //   0: iload_2
    //   1: ifne -> 8
    //   4: aload_0
    //   5: invokespecial checkStateLoss : ()V
    //   8: aload_0
    //   9: monitorenter
    //   10: aload_0
    //   11: getfield mDestroyed : Z
    //   14: ifne -> 24
    //   17: aload_0
    //   18: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   21: ifnonnull -> 42
    //   24: new java/lang/IllegalStateException
    //   27: astore_1
    //   28: aload_1
    //   29: ldc_w 'Activity has been destroyed'
    //   32: invokespecial <init> : (Ljava/lang/String;)V
    //   35: aload_1
    //   36: athrow
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: athrow
    //   42: aload_0
    //   43: getfield mPendingActions : Ljava/util/ArrayList;
    //   46: ifnonnull -> 62
    //   49: new java/util/ArrayList
    //   52: astore_3
    //   53: aload_3
    //   54: invokespecial <init> : ()V
    //   57: aload_0
    //   58: aload_3
    //   59: putfield mPendingActions : Ljava/util/ArrayList;
    //   62: aload_0
    //   63: getfield mPendingActions : Ljava/util/ArrayList;
    //   66: aload_1
    //   67: invokevirtual add : (Ljava/lang/Object;)Z
    //   70: pop
    //   71: aload_0
    //   72: getfield mPendingActions : Ljava/util/ArrayList;
    //   75: invokevirtual size : ()I
    //   78: iconst_1
    //   79: if_icmpne -> 111
    //   82: aload_0
    //   83: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   86: getfield mHandler : Landroid/os/Handler;
    //   89: aload_0
    //   90: getfield mExecCommit : Ljava/lang/Runnable;
    //   93: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   96: aload_0
    //   97: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   100: getfield mHandler : Landroid/os/Handler;
    //   103: aload_0
    //   104: getfield mExecCommit : Ljava/lang/Runnable;
    //   107: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   110: pop
    //   111: aload_0
    //   112: monitorexit
    //   113: return
    // Exception table:
    //   from	to	target	type
    //   10	24	37	finally
    //   24	37	37	finally
    //   38	40	37	finally
    //   42	62	37	finally
    //   62	111	37	finally
    //   111	113	37	finally
  }
  
  public boolean execPendingActions() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mExecutingActions : Z
    //   4: ifeq -> 18
    //   7: new java/lang/IllegalStateException
    //   10: dup
    //   11: ldc_w 'Recursive entry to executePendingTransactions'
    //   14: invokespecial <init> : (Ljava/lang/String;)V
    //   17: athrow
    //   18: invokestatic myLooper : ()Landroid/os/Looper;
    //   21: aload_0
    //   22: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   25: getfield mHandler : Landroid/os/Handler;
    //   28: invokevirtual getLooper : ()Landroid/os/Looper;
    //   31: if_acmpeq -> 45
    //   34: new java/lang/IllegalStateException
    //   37: dup
    //   38: ldc_w 'Must be called from main thread of process'
    //   41: invokespecial <init> : (Ljava/lang/String;)V
    //   44: athrow
    //   45: iconst_0
    //   46: istore_1
    //   47: aload_0
    //   48: monitorenter
    //   49: aload_0
    //   50: getfield mPendingActions : Ljava/util/ArrayList;
    //   53: ifnull -> 66
    //   56: aload_0
    //   57: getfield mPendingActions : Ljava/util/ArrayList;
    //   60: invokevirtual size : ()I
    //   63: ifne -> 143
    //   66: aload_0
    //   67: monitorexit
    //   68: aload_0
    //   69: getfield mHavePendingDeferredStart : Z
    //   72: ifeq -> 276
    //   75: iconst_0
    //   76: istore_2
    //   77: iconst_0
    //   78: istore_3
    //   79: iload_3
    //   80: aload_0
    //   81: getfield mActive : Ljava/util/ArrayList;
    //   84: invokevirtual size : ()I
    //   87: if_icmpge -> 263
    //   90: aload_0
    //   91: getfield mActive : Ljava/util/ArrayList;
    //   94: iload_3
    //   95: invokevirtual get : (I)Ljava/lang/Object;
    //   98: checkcast android/support/v4/app/Fragment
    //   101: astore #4
    //   103: iload_2
    //   104: istore #5
    //   106: aload #4
    //   108: ifnull -> 134
    //   111: iload_2
    //   112: istore #5
    //   114: aload #4
    //   116: getfield mLoaderManager : Landroid/support/v4/app/LoaderManagerImpl;
    //   119: ifnull -> 134
    //   122: iload_2
    //   123: aload #4
    //   125: getfield mLoaderManager : Landroid/support/v4/app/LoaderManagerImpl;
    //   128: invokevirtual hasRunningLoaders : ()Z
    //   131: ior
    //   132: istore #5
    //   134: iinc #3, 1
    //   137: iload #5
    //   139: istore_2
    //   140: goto -> 79
    //   143: aload_0
    //   144: getfield mPendingActions : Ljava/util/ArrayList;
    //   147: invokevirtual size : ()I
    //   150: istore_2
    //   151: aload_0
    //   152: getfield mTmpActions : [Ljava/lang/Runnable;
    //   155: ifnull -> 167
    //   158: aload_0
    //   159: getfield mTmpActions : [Ljava/lang/Runnable;
    //   162: arraylength
    //   163: iload_2
    //   164: if_icmpge -> 175
    //   167: aload_0
    //   168: iload_2
    //   169: anewarray java/lang/Runnable
    //   172: putfield mTmpActions : [Ljava/lang/Runnable;
    //   175: aload_0
    //   176: getfield mPendingActions : Ljava/util/ArrayList;
    //   179: aload_0
    //   180: getfield mTmpActions : [Ljava/lang/Runnable;
    //   183: invokevirtual toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
    //   186: pop
    //   187: aload_0
    //   188: getfield mPendingActions : Ljava/util/ArrayList;
    //   191: invokevirtual clear : ()V
    //   194: aload_0
    //   195: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   198: getfield mHandler : Landroid/os/Handler;
    //   201: aload_0
    //   202: getfield mExecCommit : Ljava/lang/Runnable;
    //   205: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   208: aload_0
    //   209: monitorexit
    //   210: aload_0
    //   211: iconst_1
    //   212: putfield mExecutingActions : Z
    //   215: iconst_0
    //   216: istore_3
    //   217: iload_3
    //   218: iload_2
    //   219: if_icmpge -> 253
    //   222: aload_0
    //   223: getfield mTmpActions : [Ljava/lang/Runnable;
    //   226: iload_3
    //   227: aaload
    //   228: invokeinterface run : ()V
    //   233: aload_0
    //   234: getfield mTmpActions : [Ljava/lang/Runnable;
    //   237: iload_3
    //   238: aconst_null
    //   239: aastore
    //   240: iinc #3, 1
    //   243: goto -> 217
    //   246: astore #4
    //   248: aload_0
    //   249: monitorexit
    //   250: aload #4
    //   252: athrow
    //   253: aload_0
    //   254: iconst_0
    //   255: putfield mExecutingActions : Z
    //   258: iconst_1
    //   259: istore_1
    //   260: goto -> 47
    //   263: iload_2
    //   264: ifne -> 276
    //   267: aload_0
    //   268: iconst_0
    //   269: putfield mHavePendingDeferredStart : Z
    //   272: aload_0
    //   273: invokevirtual startPendingDeferredFragments : ()V
    //   276: iload_1
    //   277: ireturn
    // Exception table:
    //   from	to	target	type
    //   49	66	246	finally
    //   66	68	246	finally
    //   143	167	246	finally
    //   167	175	246	finally
    //   175	210	246	finally
    //   248	250	246	finally
  }
  
  public boolean executePendingTransactions() {
    return execPendingActions();
  }
  
  public Fragment findFragmentById(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mAdded : Ljava/util/ArrayList;
    //   4: ifnull -> 53
    //   7: aload_0
    //   8: getfield mAdded : Ljava/util/ArrayList;
    //   11: invokevirtual size : ()I
    //   14: iconst_1
    //   15: isub
    //   16: istore_2
    //   17: iload_2
    //   18: iflt -> 53
    //   21: aload_0
    //   22: getfield mAdded : Ljava/util/ArrayList;
    //   25: iload_2
    //   26: invokevirtual get : (I)Ljava/lang/Object;
    //   29: checkcast android/support/v4/app/Fragment
    //   32: astore_3
    //   33: aload_3
    //   34: ifnull -> 47
    //   37: aload_3
    //   38: getfield mFragmentId : I
    //   41: iload_1
    //   42: if_icmpne -> 47
    //   45: aload_3
    //   46: areturn
    //   47: iinc #2, -1
    //   50: goto -> 17
    //   53: aload_0
    //   54: getfield mActive : Ljava/util/ArrayList;
    //   57: ifnull -> 110
    //   60: aload_0
    //   61: getfield mActive : Ljava/util/ArrayList;
    //   64: invokevirtual size : ()I
    //   67: iconst_1
    //   68: isub
    //   69: istore_2
    //   70: iload_2
    //   71: iflt -> 110
    //   74: aload_0
    //   75: getfield mActive : Ljava/util/ArrayList;
    //   78: iload_2
    //   79: invokevirtual get : (I)Ljava/lang/Object;
    //   82: checkcast android/support/v4/app/Fragment
    //   85: astore #4
    //   87: aload #4
    //   89: ifnull -> 104
    //   92: aload #4
    //   94: astore_3
    //   95: aload #4
    //   97: getfield mFragmentId : I
    //   100: iload_1
    //   101: if_icmpeq -> 45
    //   104: iinc #2, -1
    //   107: goto -> 70
    //   110: aconst_null
    //   111: astore_3
    //   112: goto -> 45
  }
  
  public Fragment findFragmentByTag(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mAdded : Ljava/util/ArrayList;
    //   4: ifnull -> 60
    //   7: aload_1
    //   8: ifnull -> 60
    //   11: aload_0
    //   12: getfield mAdded : Ljava/util/ArrayList;
    //   15: invokevirtual size : ()I
    //   18: iconst_1
    //   19: isub
    //   20: istore_2
    //   21: iload_2
    //   22: iflt -> 60
    //   25: aload_0
    //   26: getfield mAdded : Ljava/util/ArrayList;
    //   29: iload_2
    //   30: invokevirtual get : (I)Ljava/lang/Object;
    //   33: checkcast android/support/v4/app/Fragment
    //   36: astore_3
    //   37: aload_3
    //   38: ifnull -> 54
    //   41: aload_1
    //   42: aload_3
    //   43: getfield mTag : Ljava/lang/String;
    //   46: invokevirtual equals : (Ljava/lang/Object;)Z
    //   49: ifeq -> 54
    //   52: aload_3
    //   53: areturn
    //   54: iinc #2, -1
    //   57: goto -> 21
    //   60: aload_0
    //   61: getfield mActive : Ljava/util/ArrayList;
    //   64: ifnull -> 124
    //   67: aload_1
    //   68: ifnull -> 124
    //   71: aload_0
    //   72: getfield mActive : Ljava/util/ArrayList;
    //   75: invokevirtual size : ()I
    //   78: iconst_1
    //   79: isub
    //   80: istore_2
    //   81: iload_2
    //   82: iflt -> 124
    //   85: aload_0
    //   86: getfield mActive : Ljava/util/ArrayList;
    //   89: iload_2
    //   90: invokevirtual get : (I)Ljava/lang/Object;
    //   93: checkcast android/support/v4/app/Fragment
    //   96: astore #4
    //   98: aload #4
    //   100: ifnull -> 118
    //   103: aload #4
    //   105: astore_3
    //   106: aload_1
    //   107: aload #4
    //   109: getfield mTag : Ljava/lang/String;
    //   112: invokevirtual equals : (Ljava/lang/Object;)Z
    //   115: ifne -> 52
    //   118: iinc #2, -1
    //   121: goto -> 81
    //   124: aconst_null
    //   125: astore_3
    //   126: goto -> 52
  }
  
  public Fragment findFragmentByWho(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mActive : Ljava/util/ArrayList;
    //   4: ifnull -> 61
    //   7: aload_1
    //   8: ifnull -> 61
    //   11: aload_0
    //   12: getfield mActive : Ljava/util/ArrayList;
    //   15: invokevirtual size : ()I
    //   18: iconst_1
    //   19: isub
    //   20: istore_2
    //   21: iload_2
    //   22: iflt -> 61
    //   25: aload_0
    //   26: getfield mActive : Ljava/util/ArrayList;
    //   29: iload_2
    //   30: invokevirtual get : (I)Ljava/lang/Object;
    //   33: checkcast android/support/v4/app/Fragment
    //   36: astore_3
    //   37: aload_3
    //   38: ifnull -> 55
    //   41: aload_3
    //   42: aload_1
    //   43: invokevirtual findFragmentByWho : (Ljava/lang/String;)Landroid/support/v4/app/Fragment;
    //   46: astore_3
    //   47: aload_3
    //   48: ifnull -> 55
    //   51: aload_3
    //   52: astore_1
    //   53: aload_1
    //   54: areturn
    //   55: iinc #2, -1
    //   58: goto -> 21
    //   61: aconst_null
    //   62: astore_1
    //   63: goto -> 53
  }
  
  public void freeBackStackIndex(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   6: iload_1
    //   7: aconst_null
    //   8: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   11: pop
    //   12: aload_0
    //   13: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   16: ifnonnull -> 32
    //   19: new java/util/ArrayList
    //   22: astore_2
    //   23: aload_2
    //   24: invokespecial <init> : ()V
    //   27: aload_0
    //   28: aload_2
    //   29: putfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   32: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   35: ifeq -> 66
    //   38: new java/lang/StringBuilder
    //   41: astore_2
    //   42: aload_2
    //   43: invokespecial <init> : ()V
    //   46: ldc 'FragmentManager'
    //   48: aload_2
    //   49: ldc_w 'Freeing back stack index '
    //   52: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   55: iload_1
    //   56: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   59: invokevirtual toString : ()Ljava/lang/String;
    //   62: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   65: pop
    //   66: aload_0
    //   67: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   70: iload_1
    //   71: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   74: invokevirtual add : (Ljava/lang/Object;)Z
    //   77: pop
    //   78: aload_0
    //   79: monitorexit
    //   80: return
    //   81: astore_2
    //   82: aload_0
    //   83: monitorexit
    //   84: aload_2
    //   85: athrow
    // Exception table:
    //   from	to	target	type
    //   2	32	81	finally
    //   32	66	81	finally
    //   66	80	81	finally
    //   82	84	81	finally
  }
  
  public FragmentManager.BackStackEntry getBackStackEntryAt(int paramInt) {
    return this.mBackStack.get(paramInt);
  }
  
  public int getBackStackEntryCount() {
    return (this.mBackStack != null) ? this.mBackStack.size() : 0;
  }
  
  public Fragment getFragment(Bundle paramBundle, String paramString) {
    int i = paramBundle.getInt(paramString, -1);
    if (i == -1)
      return null; 
    if (i >= this.mActive.size())
      throwException(new IllegalStateException("Fragement no longer exists for key " + paramString + ": index " + i)); 
    Fragment fragment2 = this.mActive.get(i);
    Fragment fragment1 = fragment2;
    if (fragment2 == null) {
      throwException(new IllegalStateException("Fragement no longer exists for key " + paramString + ": index " + i));
      fragment1 = fragment2;
    } 
    return fragment1;
  }
  
  public List<Fragment> getFragments() {
    return this.mActive;
  }
  
  public void hideFragment(Fragment paramFragment, int paramInt1, int paramInt2) {
    if (DEBUG)
      Log.v("FragmentManager", "hide: " + paramFragment); 
    if (!paramFragment.mHidden) {
      paramFragment.mHidden = true;
      if (paramFragment.mView != null) {
        Animation animation = loadAnimation(paramFragment, paramInt1, false, paramInt2);
        if (animation != null)
          paramFragment.mView.startAnimation(animation); 
        paramFragment.mView.setVisibility(8);
      } 
      if (paramFragment.mAdded && paramFragment.mHasMenu && paramFragment.mMenuVisible)
        this.mNeedMenuInvalidate = true; 
      paramFragment.onHiddenChanged(true);
    } 
  }
  
  Animation loadAnimation(Fragment paramFragment, int paramInt1, boolean paramBoolean, int paramInt2) {
    Animation animation = paramFragment.onCreateAnimation(paramInt1, paramBoolean, paramFragment.mNextAnim);
    if (animation != null)
      return animation; 
    if (paramFragment.mNextAnim != 0) {
      Animation animation1 = AnimationUtils.loadAnimation((Context)this.mActivity, paramFragment.mNextAnim);
      if (animation1 != null)
        return animation1; 
    } 
    if (paramInt1 == 0)
      return null; 
    paramInt1 = transitToStyleIndex(paramInt1, paramBoolean);
    if (paramInt1 < 0)
      return null; 
    switch (paramInt1) {
      default:
        paramInt1 = paramInt2;
        if (paramInt2 == 0) {
          paramInt1 = paramInt2;
          if (this.mActivity.getWindow() != null)
            paramInt1 = (this.mActivity.getWindow().getAttributes()).windowAnimations; 
        } 
        if (paramInt1 == 0)
          return null; 
        break;
      case 1:
        return makeOpenCloseAnimation((Context)this.mActivity, 1.125F, 1.0F, 0.0F, 1.0F);
      case 2:
        return makeOpenCloseAnimation((Context)this.mActivity, 1.0F, 0.975F, 1.0F, 0.0F);
      case 3:
        return makeOpenCloseAnimation((Context)this.mActivity, 0.975F, 1.0F, 0.0F, 1.0F);
      case 4:
        return makeOpenCloseAnimation((Context)this.mActivity, 1.0F, 1.075F, 1.0F, 0.0F);
      case 5:
        return makeFadeAnimation((Context)this.mActivity, 0.0F, 1.0F);
      case 6:
        return makeFadeAnimation((Context)this.mActivity, 1.0F, 0.0F);
    } 
    return null;
  }
  
  void makeActive(Fragment paramFragment) {
    if (paramFragment.mIndex < 0) {
      if (this.mAvailIndices == null || this.mAvailIndices.size() <= 0) {
        if (this.mActive == null)
          this.mActive = new ArrayList<Fragment>(); 
        paramFragment.setIndex(this.mActive.size(), this.mParent);
        this.mActive.add(paramFragment);
      } else {
        paramFragment.setIndex(((Integer)this.mAvailIndices.remove(this.mAvailIndices.size() - 1)).intValue(), this.mParent);
        this.mActive.set(paramFragment.mIndex, paramFragment);
      } 
      if (DEBUG)
        Log.v("FragmentManager", "Allocated fragment index " + paramFragment); 
    } 
  }
  
  void makeInactive(Fragment paramFragment) {
    if (paramFragment.mIndex >= 0) {
      if (DEBUG)
        Log.v("FragmentManager", "Freeing fragment index " + paramFragment); 
      this.mActive.set(paramFragment.mIndex, null);
      if (this.mAvailIndices == null)
        this.mAvailIndices = new ArrayList<Integer>(); 
      this.mAvailIndices.add(Integer.valueOf(paramFragment.mIndex));
      this.mActivity.invalidateSupportFragment(paramFragment.mWho);
      paramFragment.initState();
    } 
  }
  
  void moveToState(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    if (this.mActivity == null && paramInt1 != 0)
      throw new IllegalStateException("No activity"); 
    if (paramBoolean || this.mCurState != paramInt1) {
      this.mCurState = paramInt1;
      if (this.mActive != null) {
        boolean bool = false;
        byte b = 0;
        while (b < this.mActive.size()) {
          Fragment fragment = this.mActive.get(b);
          boolean bool1 = bool;
          if (fragment != null) {
            moveToState(fragment, paramInt1, paramInt2, paramInt3, false);
            bool1 = bool;
            if (fragment.mLoaderManager != null)
              bool1 = bool | fragment.mLoaderManager.hasRunningLoaders(); 
          } 
          b++;
          bool = bool1;
        } 
        if (!bool)
          startPendingDeferredFragments(); 
        if (this.mNeedMenuInvalidate && this.mActivity != null && this.mCurState == 5) {
          this.mActivity.supportInvalidateOptionsMenu();
          this.mNeedMenuInvalidate = false;
        } 
      } 
    } 
  }
  
  void moveToState(int paramInt, boolean paramBoolean) {
    moveToState(paramInt, 0, 0, paramBoolean);
  }
  
  void moveToState(Fragment paramFragment) {
    moveToState(paramFragment, this.mCurState, 0, 0, false);
  }
  
  void moveToState(Fragment paramFragment, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: getfield mAdded : Z
    //   4: ifeq -> 17
    //   7: iload_2
    //   8: istore #6
    //   10: aload_1
    //   11: getfield mDetached : Z
    //   14: ifeq -> 28
    //   17: iload_2
    //   18: istore #6
    //   20: iload_2
    //   21: iconst_1
    //   22: if_icmple -> 28
    //   25: iconst_1
    //   26: istore #6
    //   28: iload #6
    //   30: istore #7
    //   32: aload_1
    //   33: getfield mRemoving : Z
    //   36: ifeq -> 58
    //   39: iload #6
    //   41: istore #7
    //   43: iload #6
    //   45: aload_1
    //   46: getfield mState : I
    //   49: if_icmple -> 58
    //   52: aload_1
    //   53: getfield mState : I
    //   56: istore #7
    //   58: iload #7
    //   60: istore_2
    //   61: aload_1
    //   62: getfield mDeferStart : Z
    //   65: ifeq -> 90
    //   68: iload #7
    //   70: istore_2
    //   71: aload_1
    //   72: getfield mState : I
    //   75: iconst_4
    //   76: if_icmpge -> 90
    //   79: iload #7
    //   81: istore_2
    //   82: iload #7
    //   84: iconst_3
    //   85: if_icmple -> 90
    //   88: iconst_3
    //   89: istore_2
    //   90: aload_1
    //   91: getfield mState : I
    //   94: iload_2
    //   95: if_icmpge -> 1014
    //   98: aload_1
    //   99: getfield mFromLayout : Z
    //   102: ifeq -> 113
    //   105: aload_1
    //   106: getfield mInLayout : Z
    //   109: ifne -> 113
    //   112: return
    //   113: aload_1
    //   114: getfield mAnimatingAway : Landroid/view/View;
    //   117: ifnull -> 137
    //   120: aload_1
    //   121: aconst_null
    //   122: putfield mAnimatingAway : Landroid/view/View;
    //   125: aload_0
    //   126: aload_1
    //   127: aload_1
    //   128: getfield mStateAfterAnimating : I
    //   131: iconst_0
    //   132: iconst_0
    //   133: iconst_1
    //   134: invokevirtual moveToState : (Landroid/support/v4/app/Fragment;IIIZ)V
    //   137: iload_2
    //   138: istore #7
    //   140: iload_2
    //   141: istore #8
    //   143: iload_2
    //   144: istore #6
    //   146: aload_1
    //   147: getfield mState : I
    //   150: tableswitch default -> 184, 0 -> 196, 1 -> 555, 2 -> 876, 3 -> 876, 4 -> 926
    //   184: iload_2
    //   185: istore #7
    //   187: aload_1
    //   188: iload #7
    //   190: putfield mState : I
    //   193: goto -> 112
    //   196: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   199: ifeq -> 228
    //   202: ldc 'FragmentManager'
    //   204: new java/lang/StringBuilder
    //   207: dup
    //   208: invokespecial <init> : ()V
    //   211: ldc_w 'moveto CREATED: '
    //   214: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   217: aload_1
    //   218: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   221: invokevirtual toString : ()Ljava/lang/String;
    //   224: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   227: pop
    //   228: iload_2
    //   229: istore #6
    //   231: aload_1
    //   232: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   235: ifnull -> 326
    //   238: aload_1
    //   239: aload_1
    //   240: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   243: ldc 'android:view_state'
    //   245: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   248: putfield mSavedViewState : Landroid/util/SparseArray;
    //   251: aload_1
    //   252: aload_0
    //   253: aload_1
    //   254: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   257: ldc 'android:target_state'
    //   259: invokevirtual getFragment : (Landroid/os/Bundle;Ljava/lang/String;)Landroid/support/v4/app/Fragment;
    //   262: putfield mTarget : Landroid/support/v4/app/Fragment;
    //   265: aload_1
    //   266: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   269: ifnull -> 286
    //   272: aload_1
    //   273: aload_1
    //   274: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   277: ldc 'android:target_req_state'
    //   279: iconst_0
    //   280: invokevirtual getInt : (Ljava/lang/String;I)I
    //   283: putfield mTargetRequestCode : I
    //   286: aload_1
    //   287: aload_1
    //   288: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   291: ldc 'android:user_visible_hint'
    //   293: iconst_1
    //   294: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   297: putfield mUserVisibleHint : Z
    //   300: iload_2
    //   301: istore #6
    //   303: aload_1
    //   304: getfield mUserVisibleHint : Z
    //   307: ifne -> 326
    //   310: aload_1
    //   311: iconst_1
    //   312: putfield mDeferStart : Z
    //   315: iload_2
    //   316: istore #6
    //   318: iload_2
    //   319: iconst_3
    //   320: if_icmple -> 326
    //   323: iconst_3
    //   324: istore #6
    //   326: aload_1
    //   327: aload_0
    //   328: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   331: putfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   334: aload_1
    //   335: aload_0
    //   336: getfield mParent : Landroid/support/v4/app/Fragment;
    //   339: putfield mParentFragment : Landroid/support/v4/app/Fragment;
    //   342: aload_0
    //   343: getfield mParent : Landroid/support/v4/app/Fragment;
    //   346: ifnull -> 418
    //   349: aload_0
    //   350: getfield mParent : Landroid/support/v4/app/Fragment;
    //   353: getfield mChildFragmentManager : Landroid/support/v4/app/FragmentManagerImpl;
    //   356: astore #9
    //   358: aload_1
    //   359: aload #9
    //   361: putfield mFragmentManager : Landroid/support/v4/app/FragmentManagerImpl;
    //   364: aload_1
    //   365: iconst_0
    //   366: putfield mCalled : Z
    //   369: aload_1
    //   370: aload_0
    //   371: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   374: invokevirtual onAttach : (Landroid/app/Activity;)V
    //   377: aload_1
    //   378: getfield mCalled : Z
    //   381: ifne -> 430
    //   384: new android/support/v4/app/SuperNotCalledException
    //   387: dup
    //   388: new java/lang/StringBuilder
    //   391: dup
    //   392: invokespecial <init> : ()V
    //   395: ldc_w 'Fragment '
    //   398: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   401: aload_1
    //   402: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   405: ldc_w ' did not call through to super.onAttach()'
    //   408: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   411: invokevirtual toString : ()Ljava/lang/String;
    //   414: invokespecial <init> : (Ljava/lang/String;)V
    //   417: athrow
    //   418: aload_0
    //   419: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   422: getfield mFragments : Landroid/support/v4/app/FragmentManagerImpl;
    //   425: astore #9
    //   427: goto -> 358
    //   430: aload_1
    //   431: getfield mParentFragment : Landroid/support/v4/app/Fragment;
    //   434: ifnonnull -> 445
    //   437: aload_0
    //   438: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   441: aload_1
    //   442: invokevirtual onAttachFragment : (Landroid/support/v4/app/Fragment;)V
    //   445: aload_1
    //   446: getfield mRetaining : Z
    //   449: ifne -> 460
    //   452: aload_1
    //   453: aload_1
    //   454: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   457: invokevirtual performCreate : (Landroid/os/Bundle;)V
    //   460: aload_1
    //   461: iconst_0
    //   462: putfield mRetaining : Z
    //   465: iload #6
    //   467: istore #7
    //   469: aload_1
    //   470: getfield mFromLayout : Z
    //   473: ifeq -> 555
    //   476: aload_1
    //   477: aload_1
    //   478: aload_1
    //   479: aload_1
    //   480: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   483: invokevirtual getLayoutInflater : (Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    //   486: aconst_null
    //   487: aload_1
    //   488: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   491: invokevirtual performCreateView : (Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    //   494: putfield mView : Landroid/view/View;
    //   497: aload_1
    //   498: getfield mView : Landroid/view/View;
    //   501: ifnull -> 994
    //   504: aload_1
    //   505: aload_1
    //   506: getfield mView : Landroid/view/View;
    //   509: putfield mInnerView : Landroid/view/View;
    //   512: aload_1
    //   513: aload_1
    //   514: getfield mView : Landroid/view/View;
    //   517: invokestatic wrap : (Landroid/view/View;)Landroid/view/ViewGroup;
    //   520: putfield mView : Landroid/view/View;
    //   523: aload_1
    //   524: getfield mHidden : Z
    //   527: ifeq -> 539
    //   530: aload_1
    //   531: getfield mView : Landroid/view/View;
    //   534: bipush #8
    //   536: invokevirtual setVisibility : (I)V
    //   539: aload_1
    //   540: aload_1
    //   541: getfield mView : Landroid/view/View;
    //   544: aload_1
    //   545: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   548: invokevirtual onViewCreated : (Landroid/view/View;Landroid/os/Bundle;)V
    //   551: iload #6
    //   553: istore #7
    //   555: iload #7
    //   557: istore #8
    //   559: iload #7
    //   561: iconst_1
    //   562: if_icmple -> 876
    //   565: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   568: ifeq -> 597
    //   571: ldc 'FragmentManager'
    //   573: new java/lang/StringBuilder
    //   576: dup
    //   577: invokespecial <init> : ()V
    //   580: ldc_w 'moveto ACTIVITY_CREATED: '
    //   583: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   586: aload_1
    //   587: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   590: invokevirtual toString : ()Ljava/lang/String;
    //   593: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   596: pop
    //   597: aload_1
    //   598: getfield mFromLayout : Z
    //   601: ifne -> 844
    //   604: aconst_null
    //   605: astore #9
    //   607: aload_1
    //   608: getfield mContainerId : I
    //   611: ifeq -> 723
    //   614: aload_0
    //   615: getfield mContainer : Landroid/support/v4/app/FragmentContainer;
    //   618: aload_1
    //   619: getfield mContainerId : I
    //   622: invokeinterface findViewById : (I)Landroid/view/View;
    //   627: checkcast android/view/ViewGroup
    //   630: astore #10
    //   632: aload #10
    //   634: astore #9
    //   636: aload #10
    //   638: ifnonnull -> 723
    //   641: aload #10
    //   643: astore #9
    //   645: aload_1
    //   646: getfield mRestored : Z
    //   649: ifne -> 723
    //   652: aload_0
    //   653: new java/lang/IllegalArgumentException
    //   656: dup
    //   657: new java/lang/StringBuilder
    //   660: dup
    //   661: invokespecial <init> : ()V
    //   664: ldc_w 'No view found for id 0x'
    //   667: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   670: aload_1
    //   671: getfield mContainerId : I
    //   674: invokestatic toHexString : (I)Ljava/lang/String;
    //   677: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   680: ldc_w ' ('
    //   683: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   686: aload_1
    //   687: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   690: aload_1
    //   691: getfield mContainerId : I
    //   694: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   697: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   700: ldc_w ') for fragment '
    //   703: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   706: aload_1
    //   707: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   710: invokevirtual toString : ()Ljava/lang/String;
    //   713: invokespecial <init> : (Ljava/lang/String;)V
    //   716: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   719: aload #10
    //   721: astore #9
    //   723: aload_1
    //   724: aload #9
    //   726: putfield mContainer : Landroid/view/ViewGroup;
    //   729: aload_1
    //   730: aload_1
    //   731: aload_1
    //   732: aload_1
    //   733: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   736: invokevirtual getLayoutInflater : (Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    //   739: aload #9
    //   741: aload_1
    //   742: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   745: invokevirtual performCreateView : (Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    //   748: putfield mView : Landroid/view/View;
    //   751: aload_1
    //   752: getfield mView : Landroid/view/View;
    //   755: ifnull -> 1006
    //   758: aload_1
    //   759: aload_1
    //   760: getfield mView : Landroid/view/View;
    //   763: putfield mInnerView : Landroid/view/View;
    //   766: aload_1
    //   767: aload_1
    //   768: getfield mView : Landroid/view/View;
    //   771: invokestatic wrap : (Landroid/view/View;)Landroid/view/ViewGroup;
    //   774: putfield mView : Landroid/view/View;
    //   777: aload #9
    //   779: ifnull -> 816
    //   782: aload_0
    //   783: aload_1
    //   784: iload_3
    //   785: iconst_1
    //   786: iload #4
    //   788: invokevirtual loadAnimation : (Landroid/support/v4/app/Fragment;IZI)Landroid/view/animation/Animation;
    //   791: astore #10
    //   793: aload #10
    //   795: ifnull -> 807
    //   798: aload_1
    //   799: getfield mView : Landroid/view/View;
    //   802: aload #10
    //   804: invokevirtual startAnimation : (Landroid/view/animation/Animation;)V
    //   807: aload #9
    //   809: aload_1
    //   810: getfield mView : Landroid/view/View;
    //   813: invokevirtual addView : (Landroid/view/View;)V
    //   816: aload_1
    //   817: getfield mHidden : Z
    //   820: ifeq -> 832
    //   823: aload_1
    //   824: getfield mView : Landroid/view/View;
    //   827: bipush #8
    //   829: invokevirtual setVisibility : (I)V
    //   832: aload_1
    //   833: aload_1
    //   834: getfield mView : Landroid/view/View;
    //   837: aload_1
    //   838: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   841: invokevirtual onViewCreated : (Landroid/view/View;Landroid/os/Bundle;)V
    //   844: aload_1
    //   845: aload_1
    //   846: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   849: invokevirtual performActivityCreated : (Landroid/os/Bundle;)V
    //   852: aload_1
    //   853: getfield mView : Landroid/view/View;
    //   856: ifnull -> 867
    //   859: aload_1
    //   860: aload_1
    //   861: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   864: invokevirtual restoreViewState : (Landroid/os/Bundle;)V
    //   867: aload_1
    //   868: aconst_null
    //   869: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   872: iload #7
    //   874: istore #8
    //   876: iload #8
    //   878: istore #6
    //   880: iload #8
    //   882: iconst_3
    //   883: if_icmple -> 926
    //   886: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   889: ifeq -> 918
    //   892: ldc 'FragmentManager'
    //   894: new java/lang/StringBuilder
    //   897: dup
    //   898: invokespecial <init> : ()V
    //   901: ldc_w 'moveto STARTED: '
    //   904: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   907: aload_1
    //   908: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   911: invokevirtual toString : ()Ljava/lang/String;
    //   914: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   917: pop
    //   918: aload_1
    //   919: invokevirtual performStart : ()V
    //   922: iload #8
    //   924: istore #6
    //   926: iload #6
    //   928: istore #7
    //   930: iload #6
    //   932: iconst_4
    //   933: if_icmple -> 187
    //   936: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   939: ifeq -> 968
    //   942: ldc 'FragmentManager'
    //   944: new java/lang/StringBuilder
    //   947: dup
    //   948: invokespecial <init> : ()V
    //   951: ldc_w 'moveto RESUMED: '
    //   954: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   957: aload_1
    //   958: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   961: invokevirtual toString : ()Ljava/lang/String;
    //   964: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   967: pop
    //   968: aload_1
    //   969: iconst_1
    //   970: putfield mResumed : Z
    //   973: aload_1
    //   974: invokevirtual performResume : ()V
    //   977: aload_1
    //   978: aconst_null
    //   979: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   982: aload_1
    //   983: aconst_null
    //   984: putfield mSavedViewState : Landroid/util/SparseArray;
    //   987: iload #6
    //   989: istore #7
    //   991: goto -> 187
    //   994: aload_1
    //   995: aconst_null
    //   996: putfield mInnerView : Landroid/view/View;
    //   999: iload #6
    //   1001: istore #7
    //   1003: goto -> 555
    //   1006: aload_1
    //   1007: aconst_null
    //   1008: putfield mInnerView : Landroid/view/View;
    //   1011: goto -> 844
    //   1014: iload_2
    //   1015: istore #7
    //   1017: aload_1
    //   1018: getfield mState : I
    //   1021: iload_2
    //   1022: if_icmple -> 187
    //   1025: aload_1
    //   1026: getfield mState : I
    //   1029: tableswitch default -> 1064, 1 -> 1070, 2 -> 1254, 3 -> 1213, 4 -> 1172, 5 -> 1126
    //   1064: iload_2
    //   1065: istore #7
    //   1067: goto -> 187
    //   1070: iload_2
    //   1071: istore #7
    //   1073: iload_2
    //   1074: iconst_1
    //   1075: if_icmpge -> 187
    //   1078: aload_0
    //   1079: getfield mDestroyed : Z
    //   1082: ifeq -> 1108
    //   1085: aload_1
    //   1086: getfield mAnimatingAway : Landroid/view/View;
    //   1089: ifnull -> 1108
    //   1092: aload_1
    //   1093: getfield mAnimatingAway : Landroid/view/View;
    //   1096: astore #9
    //   1098: aload_1
    //   1099: aconst_null
    //   1100: putfield mAnimatingAway : Landroid/view/View;
    //   1103: aload #9
    //   1105: invokevirtual clearAnimation : ()V
    //   1108: aload_1
    //   1109: getfield mAnimatingAway : Landroid/view/View;
    //   1112: ifnull -> 1444
    //   1115: aload_1
    //   1116: iload_2
    //   1117: putfield mStateAfterAnimating : I
    //   1120: iconst_1
    //   1121: istore #7
    //   1123: goto -> 187
    //   1126: iload_2
    //   1127: iconst_5
    //   1128: if_icmpge -> 1172
    //   1131: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1134: ifeq -> 1163
    //   1137: ldc 'FragmentManager'
    //   1139: new java/lang/StringBuilder
    //   1142: dup
    //   1143: invokespecial <init> : ()V
    //   1146: ldc_w 'movefrom RESUMED: '
    //   1149: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1152: aload_1
    //   1153: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1156: invokevirtual toString : ()Ljava/lang/String;
    //   1159: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1162: pop
    //   1163: aload_1
    //   1164: invokevirtual performPause : ()V
    //   1167: aload_1
    //   1168: iconst_0
    //   1169: putfield mResumed : Z
    //   1172: iload_2
    //   1173: iconst_4
    //   1174: if_icmpge -> 1213
    //   1177: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1180: ifeq -> 1209
    //   1183: ldc 'FragmentManager'
    //   1185: new java/lang/StringBuilder
    //   1188: dup
    //   1189: invokespecial <init> : ()V
    //   1192: ldc_w 'movefrom STARTED: '
    //   1195: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1198: aload_1
    //   1199: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1202: invokevirtual toString : ()Ljava/lang/String;
    //   1205: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1208: pop
    //   1209: aload_1
    //   1210: invokevirtual performStop : ()V
    //   1213: iload_2
    //   1214: iconst_3
    //   1215: if_icmpge -> 1254
    //   1218: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1221: ifeq -> 1250
    //   1224: ldc 'FragmentManager'
    //   1226: new java/lang/StringBuilder
    //   1229: dup
    //   1230: invokespecial <init> : ()V
    //   1233: ldc_w 'movefrom STOPPED: '
    //   1236: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1239: aload_1
    //   1240: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1243: invokevirtual toString : ()Ljava/lang/String;
    //   1246: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1249: pop
    //   1250: aload_1
    //   1251: invokevirtual performReallyStop : ()V
    //   1254: iload_2
    //   1255: iconst_2
    //   1256: if_icmpge -> 1070
    //   1259: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1262: ifeq -> 1291
    //   1265: ldc 'FragmentManager'
    //   1267: new java/lang/StringBuilder
    //   1270: dup
    //   1271: invokespecial <init> : ()V
    //   1274: ldc_w 'movefrom ACTIVITY_CREATED: '
    //   1277: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1280: aload_1
    //   1281: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1284: invokevirtual toString : ()Ljava/lang/String;
    //   1287: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1290: pop
    //   1291: aload_1
    //   1292: getfield mView : Landroid/view/View;
    //   1295: ifnull -> 1320
    //   1298: aload_0
    //   1299: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   1302: invokevirtual isFinishing : ()Z
    //   1305: ifne -> 1320
    //   1308: aload_1
    //   1309: getfield mSavedViewState : Landroid/util/SparseArray;
    //   1312: ifnonnull -> 1320
    //   1315: aload_0
    //   1316: aload_1
    //   1317: invokevirtual saveFragmentViewState : (Landroid/support/v4/app/Fragment;)V
    //   1320: aload_1
    //   1321: invokevirtual performDestroyView : ()V
    //   1324: aload_1
    //   1325: getfield mView : Landroid/view/View;
    //   1328: ifnull -> 1426
    //   1331: aload_1
    //   1332: getfield mContainer : Landroid/view/ViewGroup;
    //   1335: ifnull -> 1426
    //   1338: aconst_null
    //   1339: astore #10
    //   1341: aload #10
    //   1343: astore #9
    //   1345: aload_0
    //   1346: getfield mCurState : I
    //   1349: ifle -> 1374
    //   1352: aload #10
    //   1354: astore #9
    //   1356: aload_0
    //   1357: getfield mDestroyed : Z
    //   1360: ifne -> 1374
    //   1363: aload_0
    //   1364: aload_1
    //   1365: iload_3
    //   1366: iconst_0
    //   1367: iload #4
    //   1369: invokevirtual loadAnimation : (Landroid/support/v4/app/Fragment;IZI)Landroid/view/animation/Animation;
    //   1372: astore #9
    //   1374: aload #9
    //   1376: ifnull -> 1415
    //   1379: aload_1
    //   1380: aload_1
    //   1381: getfield mView : Landroid/view/View;
    //   1384: putfield mAnimatingAway : Landroid/view/View;
    //   1387: aload_1
    //   1388: iload_2
    //   1389: putfield mStateAfterAnimating : I
    //   1392: aload #9
    //   1394: new android/support/v4/app/FragmentManagerImpl$5
    //   1397: dup
    //   1398: aload_0
    //   1399: aload_1
    //   1400: invokespecial <init> : (Landroid/support/v4/app/FragmentManagerImpl;Landroid/support/v4/app/Fragment;)V
    //   1403: invokevirtual setAnimationListener : (Landroid/view/animation/Animation$AnimationListener;)V
    //   1406: aload_1
    //   1407: getfield mView : Landroid/view/View;
    //   1410: aload #9
    //   1412: invokevirtual startAnimation : (Landroid/view/animation/Animation;)V
    //   1415: aload_1
    //   1416: getfield mContainer : Landroid/view/ViewGroup;
    //   1419: aload_1
    //   1420: getfield mView : Landroid/view/View;
    //   1423: invokevirtual removeView : (Landroid/view/View;)V
    //   1426: aload_1
    //   1427: aconst_null
    //   1428: putfield mContainer : Landroid/view/ViewGroup;
    //   1431: aload_1
    //   1432: aconst_null
    //   1433: putfield mView : Landroid/view/View;
    //   1436: aload_1
    //   1437: aconst_null
    //   1438: putfield mInnerView : Landroid/view/View;
    //   1441: goto -> 1070
    //   1444: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1447: ifeq -> 1476
    //   1450: ldc 'FragmentManager'
    //   1452: new java/lang/StringBuilder
    //   1455: dup
    //   1456: invokespecial <init> : ()V
    //   1459: ldc_w 'movefrom CREATED: '
    //   1462: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1465: aload_1
    //   1466: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1469: invokevirtual toString : ()Ljava/lang/String;
    //   1472: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1475: pop
    //   1476: aload_1
    //   1477: getfield mRetaining : Z
    //   1480: ifne -> 1487
    //   1483: aload_1
    //   1484: invokevirtual performDestroy : ()V
    //   1487: aload_1
    //   1488: iconst_0
    //   1489: putfield mCalled : Z
    //   1492: aload_1
    //   1493: invokevirtual onDetach : ()V
    //   1496: aload_1
    //   1497: getfield mCalled : Z
    //   1500: ifne -> 1537
    //   1503: new android/support/v4/app/SuperNotCalledException
    //   1506: dup
    //   1507: new java/lang/StringBuilder
    //   1510: dup
    //   1511: invokespecial <init> : ()V
    //   1514: ldc_w 'Fragment '
    //   1517: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1520: aload_1
    //   1521: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1524: ldc_w ' did not call through to super.onDetach()'
    //   1527: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1530: invokevirtual toString : ()Ljava/lang/String;
    //   1533: invokespecial <init> : (Ljava/lang/String;)V
    //   1536: athrow
    //   1537: iload_2
    //   1538: istore #7
    //   1540: iload #5
    //   1542: ifne -> 187
    //   1545: aload_1
    //   1546: getfield mRetaining : Z
    //   1549: ifne -> 1563
    //   1552: aload_0
    //   1553: aload_1
    //   1554: invokevirtual makeInactive : (Landroid/support/v4/app/Fragment;)V
    //   1557: iload_2
    //   1558: istore #7
    //   1560: goto -> 187
    //   1563: aload_1
    //   1564: aconst_null
    //   1565: putfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   1568: aload_1
    //   1569: aconst_null
    //   1570: putfield mFragmentManager : Landroid/support/v4/app/FragmentManagerImpl;
    //   1573: iload_2
    //   1574: istore #7
    //   1576: goto -> 187
  }
  
  public void noteStateNotSaved() {
    this.mStateSaved = false;
  }
  
  public void performPendingDeferredStart(Fragment paramFragment) {
    if (paramFragment.mDeferStart) {
      if (this.mExecutingActions) {
        this.mHavePendingDeferredStart = true;
        return;
      } 
    } else {
      return;
    } 
    paramFragment.mDeferStart = false;
    moveToState(paramFragment, this.mCurState, 0, 0, false);
  }
  
  public void popBackStack() {
    enqueueAction(new Runnable() {
          public void run() {
            FragmentManagerImpl.this.popBackStackState(FragmentManagerImpl.this.mActivity.mHandler, null, -1, 0);
          }
        }false);
  }
  
  public void popBackStack(final int id, final int flags) {
    if (id < 0)
      throw new IllegalArgumentException("Bad id: " + id); 
    enqueueAction(new Runnable() {
          public void run() {
            FragmentManagerImpl.this.popBackStackState(FragmentManagerImpl.this.mActivity.mHandler, null, id, flags);
          }
        }false);
  }
  
  public void popBackStack(final String name, final int flags) {
    enqueueAction(new Runnable() {
          public void run() {
            FragmentManagerImpl.this.popBackStackState(FragmentManagerImpl.this.mActivity.mHandler, name, -1, flags);
          }
        }false);
  }
  
  public boolean popBackStackImmediate() {
    checkStateLoss();
    executePendingTransactions();
    return popBackStackState(this.mActivity.mHandler, null, -1, 0);
  }
  
  public boolean popBackStackImmediate(int paramInt1, int paramInt2) {
    checkStateLoss();
    executePendingTransactions();
    if (paramInt1 < 0)
      throw new IllegalArgumentException("Bad id: " + paramInt1); 
    return popBackStackState(this.mActivity.mHandler, null, paramInt1, paramInt2);
  }
  
  public boolean popBackStackImmediate(String paramString, int paramInt) {
    checkStateLoss();
    executePendingTransactions();
    return popBackStackState(this.mActivity.mHandler, paramString, -1, paramInt);
  }
  
  boolean popBackStackState(Handler paramHandler, String paramString, int paramInt1, int paramInt2) {
    boolean bool = false;
    if (this.mBackStack == null)
      return bool; 
    if (paramString == null && paramInt1 < 0 && (paramInt2 & 0x1) == 0) {
      paramInt1 = this.mBackStack.size() - 1;
      boolean bool1 = bool;
      if (paramInt1 >= 0) {
        ((BackStackRecord)this.mBackStack.remove(paramInt1)).popFromBackStack(true);
        reportBackStackChanged();
      } else {
        return bool1;
      } 
    } else {
      int i = -1;
      if (paramString != null || paramInt1 >= 0) {
        int j = this.mBackStack.size() - 1;
        while (true) {
          if (j >= 0) {
            BackStackRecord backStackRecord = this.mBackStack.get(j);
            if ((paramString == null || !paramString.equals(backStackRecord.getName())) && (paramInt1 < 0 || paramInt1 != backStackRecord.mIndex)) {
              j--;
              continue;
            } 
          } 
          boolean bool2 = bool;
          if (j >= 0) {
            i = j;
            if ((paramInt2 & 0x1) != 0)
              for (paramInt2 = j - 1;; paramInt2--) {
                i = paramInt2;
                if (paramInt2 >= 0) {
                  BackStackRecord backStackRecord = this.mBackStack.get(paramInt2);
                  if (paramString == null || !paramString.equals(backStackRecord.getName())) {
                    i = paramInt2;
                    if (paramInt1 >= 0) {
                      i = paramInt2;
                      if (paramInt1 == backStackRecord.mIndex)
                        continue; 
                    } 
                    break;
                  } 
                  continue;
                } 
                break;
              }  
            break;
          } 
          return bool2;
        } 
      } 
      boolean bool1 = bool;
      if (i != this.mBackStack.size() - 1) {
        ArrayList<String> arrayList = new ArrayList();
        for (paramInt1 = this.mBackStack.size() - 1; paramInt1 > i; paramInt1--)
          arrayList.add(this.mBackStack.remove(paramInt1)); 
        paramInt2 = arrayList.size() - 1;
        for (paramInt1 = 0; paramInt1 <= paramInt2; paramInt1++) {
          if (DEBUG)
            Log.v("FragmentManager", "Popping back stack state: " + arrayList.get(paramInt1)); 
          BackStackRecord backStackRecord = (BackStackRecord)arrayList.get(paramInt1);
          if (paramInt1 == paramInt2) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          backStackRecord.popFromBackStack(bool1);
        } 
        reportBackStackChanged();
      } else {
        return bool1;
      } 
    } 
    return true;
  }
  
  public void putFragment(Bundle paramBundle, String paramString, Fragment paramFragment) {
    if (paramFragment.mIndex < 0)
      throwException(new IllegalStateException("Fragment " + paramFragment + " is not currently in the FragmentManager")); 
    paramBundle.putInt(paramString, paramFragment.mIndex);
  }
  
  public void removeFragment(Fragment paramFragment, int paramInt1, int paramInt2) {
    boolean bool;
    if (DEBUG)
      Log.v("FragmentManager", "remove: " + paramFragment + " nesting=" + paramFragment.mBackStackNesting); 
    if (!paramFragment.isInBackStack()) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!paramFragment.mDetached || bool) {
      if (this.mAdded != null)
        this.mAdded.remove(paramFragment); 
      if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
        this.mNeedMenuInvalidate = true; 
      paramFragment.mAdded = false;
      paramFragment.mRemoving = true;
      if (bool) {
        bool = false;
      } else {
        bool = true;
      } 
      moveToState(paramFragment, bool, paramInt1, paramInt2, false);
    } 
  }
  
  public void removeOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener) {
    if (this.mBackStackChangeListeners != null)
      this.mBackStackChangeListeners.remove(paramOnBackStackChangedListener); 
  }
  
  void reportBackStackChanged() {
    if (this.mBackStackChangeListeners != null)
      for (byte b = 0; b < this.mBackStackChangeListeners.size(); b++)
        ((FragmentManager.OnBackStackChangedListener)this.mBackStackChangeListeners.get(b)).onBackStackChanged();  
  }
  
  void restoreAllState(Parcelable paramParcelable, ArrayList<Fragment> paramArrayList) {
    if (paramParcelable != null) {
      paramParcelable = paramParcelable;
      if (((FragmentManagerState)paramParcelable).mActive != null) {
        if (paramArrayList != null)
          for (byte b1 = 0; b1 < paramArrayList.size(); b1++) {
            Fragment fragment = paramArrayList.get(b1);
            if (DEBUG)
              Log.v("FragmentManager", "restoreAllState: re-attaching retained " + fragment); 
            FragmentState fragmentState = ((FragmentManagerState)paramParcelable).mActive[fragment.mIndex];
            fragmentState.mInstance = fragment;
            fragment.mSavedViewState = null;
            fragment.mBackStackNesting = 0;
            fragment.mInLayout = false;
            fragment.mAdded = false;
            fragment.mTarget = null;
            if (fragmentState.mSavedFragmentState != null) {
              fragmentState.mSavedFragmentState.setClassLoader(this.mActivity.getClassLoader());
              fragment.mSavedViewState = fragmentState.mSavedFragmentState.getSparseParcelableArray("android:view_state");
            } 
          }  
        this.mActive = new ArrayList<Fragment>(((FragmentManagerState)paramParcelable).mActive.length);
        if (this.mAvailIndices != null)
          this.mAvailIndices.clear(); 
        byte b;
        for (b = 0; b < ((FragmentManagerState)paramParcelable).mActive.length; b++) {
          FragmentState fragmentState = ((FragmentManagerState)paramParcelable).mActive[b];
          if (fragmentState != null) {
            Fragment fragment = fragmentState.instantiate(this.mActivity, this.mParent);
            if (DEBUG)
              Log.v("FragmentManager", "restoreAllState: active #" + b + ": " + fragment); 
            this.mActive.add(fragment);
            fragmentState.mInstance = null;
          } else {
            this.mActive.add(null);
            if (this.mAvailIndices == null)
              this.mAvailIndices = new ArrayList<Integer>(); 
            if (DEBUG)
              Log.v("FragmentManager", "restoreAllState: avail #" + b); 
            this.mAvailIndices.add(Integer.valueOf(b));
          } 
        } 
        if (paramArrayList != null)
          for (b = 0; b < paramArrayList.size(); b++) {
            Fragment fragment = paramArrayList.get(b);
            if (fragment.mTargetIndex >= 0)
              if (fragment.mTargetIndex < this.mActive.size()) {
                fragment.mTarget = this.mActive.get(fragment.mTargetIndex);
              } else {
                Log.w("FragmentManager", "Re-attaching retained fragment " + fragment + " target no longer exists: " + fragment.mTargetIndex);
                fragment.mTarget = null;
              }  
          }  
        if (((FragmentManagerState)paramParcelable).mAdded != null) {
          this.mAdded = new ArrayList<Fragment>(((FragmentManagerState)paramParcelable).mAdded.length);
          for (b = 0; b < ((FragmentManagerState)paramParcelable).mAdded.length; b++) {
            Fragment fragment = this.mActive.get(((FragmentManagerState)paramParcelable).mAdded[b]);
            if (fragment == null)
              throwException(new IllegalStateException("No instantiated fragment for index #" + ((FragmentManagerState)paramParcelable).mAdded[b])); 
            fragment.mAdded = true;
            if (DEBUG)
              Log.v("FragmentManager", "restoreAllState: added #" + b + ": " + fragment); 
            if (this.mAdded.contains(fragment))
              throw new IllegalStateException("Already added!"); 
            this.mAdded.add(fragment);
          } 
        } else {
          this.mAdded = null;
        } 
        if (((FragmentManagerState)paramParcelable).mBackStack != null) {
          this.mBackStack = new ArrayList<BackStackRecord>(((FragmentManagerState)paramParcelable).mBackStack.length);
          b = 0;
          while (true) {
            if (b < ((FragmentManagerState)paramParcelable).mBackStack.length) {
              BackStackRecord backStackRecord = ((FragmentManagerState)paramParcelable).mBackStack[b].instantiate(this);
              if (DEBUG) {
                Log.v("FragmentManager", "restoreAllState: back stack #" + b + " (index " + backStackRecord.mIndex + "): " + backStackRecord);
                backStackRecord.dump("  ", new PrintWriter((Writer)new LogWriter("FragmentManager")), false);
              } 
              this.mBackStack.add(backStackRecord);
              if (backStackRecord.mIndex >= 0)
                setBackStackIndex(backStackRecord.mIndex, backStackRecord); 
              b++;
              continue;
            } 
            return;
          } 
        } 
        this.mBackStack = null;
      } 
    } 
  }
  
  ArrayList<Fragment> retainNonConfig() {
    ArrayList<Fragment> arrayList1 = null;
    ArrayList<Fragment> arrayList2 = null;
    if (this.mActive != null) {
      byte b = 0;
      while (true) {
        arrayList1 = arrayList2;
        if (b < this.mActive.size()) {
          Fragment fragment = this.mActive.get(b);
          ArrayList<Fragment> arrayList = arrayList2;
          if (fragment != null) {
            arrayList = arrayList2;
            if (fragment.mRetainInstance) {
              byte b1;
              arrayList1 = arrayList2;
              if (arrayList2 == null)
                arrayList1 = new ArrayList(); 
              arrayList1.add(fragment);
              fragment.mRetaining = true;
              if (fragment.mTarget != null) {
                b1 = fragment.mTarget.mIndex;
              } else {
                b1 = -1;
              } 
              fragment.mTargetIndex = b1;
              arrayList = arrayList1;
              if (DEBUG) {
                Log.v("FragmentManager", "retainNonConfig: keeping retained " + fragment);
                arrayList = arrayList1;
              } 
            } 
          } 
          b++;
          arrayList2 = arrayList;
          continue;
        } 
        break;
      } 
    } 
    return arrayList1;
  }
  
  Parcelable saveAllState() {
    BackStackState[] arrayOfBackStackState;
    int[] arrayOfInt;
    Parcelable parcelable1 = null;
    execPendingActions();
    if (HONEYCOMB)
      this.mStateSaved = true; 
    Parcelable parcelable2 = parcelable1;
    if (this.mActive != null) {
      if (this.mActive.size() <= 0)
        return parcelable1; 
    } else {
      return parcelable2;
    } 
    int i = this.mActive.size();
    FragmentState[] arrayOfFragmentState = new FragmentState[i];
    int j = 0;
    byte b;
    for (b = 0; b < i; b++) {
      Fragment fragment = this.mActive.get(b);
      if (fragment != null) {
        if (fragment.mIndex < 0)
          throwException(new IllegalStateException("Failure saving state: active " + fragment + " has cleared index: " + fragment.mIndex)); 
        byte b1 = 1;
        parcelable2 = new FragmentState(fragment);
        arrayOfFragmentState[b] = (FragmentState)parcelable2;
        if (fragment.mState > 0 && ((FragmentState)parcelable2).mSavedFragmentState == null) {
          ((FragmentState)parcelable2).mSavedFragmentState = saveFragmentBasicState(fragment);
          if (fragment.mTarget != null) {
            if (fragment.mTarget.mIndex < 0)
              throwException(new IllegalStateException("Failure saving state: " + fragment + " has target not in fragment manager: " + fragment.mTarget)); 
            if (((FragmentState)parcelable2).mSavedFragmentState == null)
              ((FragmentState)parcelable2).mSavedFragmentState = new Bundle(); 
            putFragment(((FragmentState)parcelable2).mSavedFragmentState, "android:target_state", fragment.mTarget);
            if (fragment.mTargetRequestCode != 0)
              ((FragmentState)parcelable2).mSavedFragmentState.putInt("android:target_req_state", fragment.mTargetRequestCode); 
          } 
        } else {
          ((FragmentState)parcelable2).mSavedFragmentState = fragment.mSavedFragmentState;
        } 
        j = b1;
        if (DEBUG) {
          Log.v("FragmentManager", "Saved state of " + fragment + ": " + ((FragmentState)parcelable2).mSavedFragmentState);
          j = b1;
        } 
      } 
    } 
    if (!j) {
      parcelable2 = parcelable1;
      if (DEBUG) {
        Log.v("FragmentManager", "saveAllState: no fragments!");
        parcelable2 = parcelable1;
      } 
      return parcelable2;
    } 
    parcelable1 = null;
    Parcelable parcelable3 = null;
    parcelable2 = parcelable1;
    if (this.mAdded != null) {
      j = this.mAdded.size();
      parcelable2 = parcelable1;
      if (j > 0) {
        int[] arrayOfInt1 = new int[j];
        b = 0;
        while (true) {
          arrayOfInt = arrayOfInt1;
          if (b < j) {
            arrayOfInt1[b] = ((Fragment)this.mAdded.get(b)).mIndex;
            if (arrayOfInt1[b] < 0)
              throwException(new IllegalStateException("Failure saving state: active " + this.mAdded.get(b) + " has cleared index: " + arrayOfInt1[b])); 
            if (DEBUG)
              Log.v("FragmentManager", "saveAllState: adding fragment #" + b + ": " + this.mAdded.get(b)); 
            b++;
            continue;
          } 
          break;
        } 
      } 
    } 
    parcelable1 = parcelable3;
    if (this.mBackStack != null) {
      j = this.mBackStack.size();
      parcelable1 = parcelable3;
      if (j > 0) {
        BackStackState[] arrayOfBackStackState1 = new BackStackState[j];
        b = 0;
        while (true) {
          arrayOfBackStackState = arrayOfBackStackState1;
          if (b < j) {
            arrayOfBackStackState1[b] = new BackStackState(this, this.mBackStack.get(b));
            if (DEBUG)
              Log.v("FragmentManager", "saveAllState: adding back stack #" + b + ": " + this.mBackStack.get(b)); 
            b++;
            continue;
          } 
          break;
        } 
      } 
    } 
    parcelable3 = new FragmentManagerState();
    ((FragmentManagerState)parcelable3).mActive = arrayOfFragmentState;
    ((FragmentManagerState)parcelable3).mAdded = arrayOfInt;
    ((FragmentManagerState)parcelable3).mBackStack = arrayOfBackStackState;
    return parcelable3;
  }
  
  Bundle saveFragmentBasicState(Fragment paramFragment) {
    Bundle bundle1 = null;
    if (this.mStateBundle == null)
      this.mStateBundle = new Bundle(); 
    paramFragment.performSaveInstanceState(this.mStateBundle);
    if (!this.mStateBundle.isEmpty()) {
      bundle1 = this.mStateBundle;
      this.mStateBundle = null;
    } 
    if (paramFragment.mView != null)
      saveFragmentViewState(paramFragment); 
    Bundle bundle2 = bundle1;
    if (paramFragment.mSavedViewState != null) {
      bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      bundle2.putSparseParcelableArray("android:view_state", paramFragment.mSavedViewState);
    } 
    bundle1 = bundle2;
    if (!paramFragment.mUserVisibleHint) {
      bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle1.putBoolean("android:user_visible_hint", paramFragment.mUserVisibleHint);
    } 
    return bundle1;
  }
  
  public Fragment.SavedState saveFragmentInstanceState(Fragment paramFragment) {
    Fragment.SavedState savedState1 = null;
    if (paramFragment.mIndex < 0)
      throwException(new IllegalStateException("Fragment " + paramFragment + " is not currently in the FragmentManager")); 
    Fragment.SavedState savedState2 = savedState1;
    if (paramFragment.mState > 0) {
      Bundle bundle = saveFragmentBasicState(paramFragment);
      savedState2 = savedState1;
      if (bundle != null)
        savedState2 = new Fragment.SavedState(bundle); 
    } 
    return savedState2;
  }
  
  void saveFragmentViewState(Fragment paramFragment) {
    if (paramFragment.mInnerView != null) {
      if (this.mStateArray == null) {
        this.mStateArray = new SparseArray();
      } else {
        this.mStateArray.clear();
      } 
      paramFragment.mInnerView.saveHierarchyState(this.mStateArray);
      if (this.mStateArray.size() > 0) {
        paramFragment.mSavedViewState = this.mStateArray;
        this.mStateArray = null;
      } 
    } 
  }
  
  public void setBackStackIndex(int paramInt, BackStackRecord paramBackStackRecord) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   6: ifnonnull -> 22
    //   9: new java/util/ArrayList
    //   12: astore_3
    //   13: aload_3
    //   14: invokespecial <init> : ()V
    //   17: aload_0
    //   18: aload_3
    //   19: putfield mBackStackIndices : Ljava/util/ArrayList;
    //   22: aload_0
    //   23: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   26: invokevirtual size : ()I
    //   29: istore #4
    //   31: iload #4
    //   33: istore #5
    //   35: iload_1
    //   36: iload #4
    //   38: if_icmpge -> 98
    //   41: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   44: ifeq -> 85
    //   47: new java/lang/StringBuilder
    //   50: astore_3
    //   51: aload_3
    //   52: invokespecial <init> : ()V
    //   55: ldc 'FragmentManager'
    //   57: aload_3
    //   58: ldc_w 'Setting back stack index '
    //   61: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: iload_1
    //   65: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   68: ldc_w ' to '
    //   71: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   74: aload_2
    //   75: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   78: invokevirtual toString : ()Ljava/lang/String;
    //   81: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   84: pop
    //   85: aload_0
    //   86: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   89: iload_1
    //   90: aload_2
    //   91: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   94: pop
    //   95: aload_0
    //   96: monitorexit
    //   97: return
    //   98: iload #5
    //   100: iload_1
    //   101: if_icmpge -> 187
    //   104: aload_0
    //   105: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   108: aconst_null
    //   109: invokevirtual add : (Ljava/lang/Object;)Z
    //   112: pop
    //   113: aload_0
    //   114: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   117: ifnonnull -> 133
    //   120: new java/util/ArrayList
    //   123: astore_3
    //   124: aload_3
    //   125: invokespecial <init> : ()V
    //   128: aload_0
    //   129: aload_3
    //   130: putfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   133: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   136: ifeq -> 168
    //   139: new java/lang/StringBuilder
    //   142: astore_3
    //   143: aload_3
    //   144: invokespecial <init> : ()V
    //   147: ldc 'FragmentManager'
    //   149: aload_3
    //   150: ldc_w 'Adding available back stack index '
    //   153: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   156: iload #5
    //   158: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   161: invokevirtual toString : ()Ljava/lang/String;
    //   164: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   167: pop
    //   168: aload_0
    //   169: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   172: iload #5
    //   174: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   177: invokevirtual add : (Ljava/lang/Object;)Z
    //   180: pop
    //   181: iinc #5, 1
    //   184: goto -> 98
    //   187: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   190: ifeq -> 231
    //   193: new java/lang/StringBuilder
    //   196: astore_3
    //   197: aload_3
    //   198: invokespecial <init> : ()V
    //   201: ldc 'FragmentManager'
    //   203: aload_3
    //   204: ldc_w 'Adding back stack index '
    //   207: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   210: iload_1
    //   211: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   214: ldc_w ' with '
    //   217: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   220: aload_2
    //   221: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   224: invokevirtual toString : ()Ljava/lang/String;
    //   227: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   230: pop
    //   231: aload_0
    //   232: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   235: aload_2
    //   236: invokevirtual add : (Ljava/lang/Object;)Z
    //   239: pop
    //   240: goto -> 95
    //   243: astore_2
    //   244: aload_0
    //   245: monitorexit
    //   246: aload_2
    //   247: athrow
    // Exception table:
    //   from	to	target	type
    //   2	22	243	finally
    //   22	31	243	finally
    //   41	85	243	finally
    //   85	95	243	finally
    //   95	97	243	finally
    //   104	133	243	finally
    //   133	168	243	finally
    //   168	181	243	finally
    //   187	231	243	finally
    //   231	240	243	finally
    //   244	246	243	finally
  }
  
  public void showFragment(Fragment paramFragment, int paramInt1, int paramInt2) {
    if (DEBUG)
      Log.v("FragmentManager", "show: " + paramFragment); 
    if (paramFragment.mHidden) {
      paramFragment.mHidden = false;
      if (paramFragment.mView != null) {
        Animation animation = loadAnimation(paramFragment, paramInt1, true, paramInt2);
        if (animation != null)
          paramFragment.mView.startAnimation(animation); 
        paramFragment.mView.setVisibility(0);
      } 
      if (paramFragment.mAdded && paramFragment.mHasMenu && paramFragment.mMenuVisible)
        this.mNeedMenuInvalidate = true; 
      paramFragment.onHiddenChanged(false);
    } 
  }
  
  void startPendingDeferredFragments() {
    if (this.mActive != null) {
      byte b = 0;
      while (true) {
        if (b < this.mActive.size()) {
          Fragment fragment = this.mActive.get(b);
          if (fragment != null)
            performPendingDeferredStart(fragment); 
          b++;
          continue;
        } 
        return;
      } 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    if (this.mParent != null) {
      DebugUtils.buildShortClassTag(this.mParent, stringBuilder);
      stringBuilder.append("}}");
      return stringBuilder.toString();
    } 
    DebugUtils.buildShortClassTag(this.mActivity, stringBuilder);
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  static {
    boolean bool = false;
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeCMCC-dex2jar.jar!/android/support/v4/app/FragmentManagerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */