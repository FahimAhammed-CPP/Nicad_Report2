package android.support.v4.app;

import android.support.v4.util.LogWriter;
import android.util.Log;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;

final class BackStackRecord extends FragmentTransaction implements FragmentManager.BackStackEntry, Runnable {
  static final int OP_ADD = 1;
  
  static final int OP_ATTACH = 7;
  
  static final int OP_DETACH = 6;
  
  static final int OP_HIDE = 4;
  
  static final int OP_NULL = 0;
  
  static final int OP_REMOVE = 3;
  
  static final int OP_REPLACE = 2;
  
  static final int OP_SHOW = 5;
  
  static final String TAG = "FragmentManager";
  
  boolean mAddToBackStack;
  
  boolean mAllowAddToBackStack = true;
  
  int mBreadCrumbShortTitleRes;
  
  CharSequence mBreadCrumbShortTitleText;
  
  int mBreadCrumbTitleRes;
  
  CharSequence mBreadCrumbTitleText;
  
  boolean mCommitted;
  
  int mEnterAnim;
  
  int mExitAnim;
  
  Op mHead;
  
  int mIndex = -1;
  
  final FragmentManagerImpl mManager;
  
  String mName;
  
  int mNumOp;
  
  int mPopEnterAnim;
  
  int mPopExitAnim;
  
  Op mTail;
  
  int mTransition;
  
  int mTransitionStyle;
  
  public BackStackRecord(FragmentManagerImpl paramFragmentManagerImpl) {
    this.mManager = paramFragmentManagerImpl;
  }
  
  private void doAddOp(int paramInt1, Fragment paramFragment, String paramString, int paramInt2) {
    paramFragment.mFragmentManager = this.mManager;
    if (paramString != null) {
      if (paramFragment.mTag != null && !paramString.equals(paramFragment.mTag))
        throw new IllegalStateException("Can't change tag of fragment " + paramFragment + ": was " + paramFragment.mTag + " now " + paramString); 
      paramFragment.mTag = paramString;
    } 
    if (paramInt1 != 0) {
      if (paramFragment.mFragmentId != 0 && paramFragment.mFragmentId != paramInt1)
        throw new IllegalStateException("Can't change container ID of fragment " + paramFragment + ": was " + paramFragment.mFragmentId + " now " + paramInt1); 
      paramFragment.mFragmentId = paramInt1;
      paramFragment.mContainerId = paramInt1;
    } 
    Op op = new Op();
    op.cmd = paramInt2;
    op.fragment = paramFragment;
    addOp(op);
  }
  
  public FragmentTransaction add(int paramInt, Fragment paramFragment) {
    doAddOp(paramInt, paramFragment, null, 1);
    return this;
  }
  
  public FragmentTransaction add(int paramInt, Fragment paramFragment, String paramString) {
    doAddOp(paramInt, paramFragment, paramString, 1);
    return this;
  }
  
  public FragmentTransaction add(Fragment paramFragment, String paramString) {
    doAddOp(0, paramFragment, paramString, 1);
    return this;
  }
  
  void addOp(Op paramOp) {
    if (this.mHead == null) {
      this.mTail = paramOp;
      this.mHead = paramOp;
    } else {
      paramOp.prev = this.mTail;
      this.mTail.next = paramOp;
      this.mTail = paramOp;
    } 
    paramOp.enterAnim = this.mEnterAnim;
    paramOp.exitAnim = this.mExitAnim;
    paramOp.popEnterAnim = this.mPopEnterAnim;
    paramOp.popExitAnim = this.mPopExitAnim;
    this.mNumOp++;
  }
  
  public FragmentTransaction addToBackStack(String paramString) {
    if (!this.mAllowAddToBackStack)
      throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack."); 
    this.mAddToBackStack = true;
    this.mName = paramString;
    return this;
  }
  
  public FragmentTransaction attach(Fragment paramFragment) {
    Op op = new Op();
    op.cmd = 7;
    op.fragment = paramFragment;
    addOp(op);
    return this;
  }
  
  void bumpBackStackNesting(int paramInt) {
    if (this.mAddToBackStack) {
      if (FragmentManagerImpl.DEBUG)
        Log.v("FragmentManager", "Bump nesting in " + this + " by " + paramInt); 
      Op op = this.mHead;
      while (true) {
        if (op != null) {
          if (op.fragment != null) {
            Fragment fragment = op.fragment;
            fragment.mBackStackNesting += paramInt;
            if (FragmentManagerImpl.DEBUG)
              Log.v("FragmentManager", "Bump nesting of " + op.fragment + " to " + op.fragment.mBackStackNesting); 
          } 
          if (op.removed != null)
            for (int i = op.removed.size() - 1; i >= 0; i--) {
              Fragment fragment = op.removed.get(i);
              fragment.mBackStackNesting += paramInt;
              if (FragmentManagerImpl.DEBUG)
                Log.v("FragmentManager", "Bump nesting of " + fragment + " to " + fragment.mBackStackNesting); 
            }  
          op = op.next;
          continue;
        } 
        return;
      } 
    } 
  }
  
  public int commit() {
    return commitInternal(false);
  }
  
  public int commitAllowingStateLoss() {
    return commitInternal(true);
  }
  
  int commitInternal(boolean paramBoolean) {
    if (this.mCommitted)
      throw new IllegalStateException("commit already called"); 
    if (FragmentManagerImpl.DEBUG) {
      Log.v("FragmentManager", "Commit: " + this);
      dump("  ", null, new PrintWriter((Writer)new LogWriter("FragmentManager")), null);
    } 
    this.mCommitted = true;
    if (this.mAddToBackStack) {
      this.mIndex = this.mManager.allocBackStackIndex(this);
      this.mManager.enqueueAction(this, paramBoolean);
      return this.mIndex;
    } 
    this.mIndex = -1;
    this.mManager.enqueueAction(this, paramBoolean);
    return this.mIndex;
  }
  
  public FragmentTransaction detach(Fragment paramFragment) {
    Op op = new Op();
    op.cmd = 6;
    op.fragment = paramFragment;
    addOp(op);
    return this;
  }
  
  public FragmentTransaction disallowAddToBackStack() {
    if (this.mAddToBackStack)
      throw new IllegalStateException("This transaction is already being added to the back stack"); 
    this.mAllowAddToBackStack = false;
    return this;
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    dump(paramString, paramPrintWriter, true);
  }
  
  public void dump(String paramString, PrintWriter paramPrintWriter, boolean paramBoolean) {
    // Byte code:
    //   0: iload_3
    //   1: ifeq -> 316
    //   4: aload_2
    //   5: aload_1
    //   6: invokevirtual print : (Ljava/lang/String;)V
    //   9: aload_2
    //   10: ldc_w 'mName='
    //   13: invokevirtual print : (Ljava/lang/String;)V
    //   16: aload_2
    //   17: aload_0
    //   18: getfield mName : Ljava/lang/String;
    //   21: invokevirtual print : (Ljava/lang/String;)V
    //   24: aload_2
    //   25: ldc_w ' mIndex='
    //   28: invokevirtual print : (Ljava/lang/String;)V
    //   31: aload_2
    //   32: aload_0
    //   33: getfield mIndex : I
    //   36: invokevirtual print : (I)V
    //   39: aload_2
    //   40: ldc_w ' mCommitted='
    //   43: invokevirtual print : (Ljava/lang/String;)V
    //   46: aload_2
    //   47: aload_0
    //   48: getfield mCommitted : Z
    //   51: invokevirtual println : (Z)V
    //   54: aload_0
    //   55: getfield mTransition : I
    //   58: ifeq -> 102
    //   61: aload_2
    //   62: aload_1
    //   63: invokevirtual print : (Ljava/lang/String;)V
    //   66: aload_2
    //   67: ldc_w 'mTransition=#'
    //   70: invokevirtual print : (Ljava/lang/String;)V
    //   73: aload_2
    //   74: aload_0
    //   75: getfield mTransition : I
    //   78: invokestatic toHexString : (I)Ljava/lang/String;
    //   81: invokevirtual print : (Ljava/lang/String;)V
    //   84: aload_2
    //   85: ldc_w ' mTransitionStyle=#'
    //   88: invokevirtual print : (Ljava/lang/String;)V
    //   91: aload_2
    //   92: aload_0
    //   93: getfield mTransitionStyle : I
    //   96: invokestatic toHexString : (I)Ljava/lang/String;
    //   99: invokevirtual println : (Ljava/lang/String;)V
    //   102: aload_0
    //   103: getfield mEnterAnim : I
    //   106: ifne -> 116
    //   109: aload_0
    //   110: getfield mExitAnim : I
    //   113: ifeq -> 157
    //   116: aload_2
    //   117: aload_1
    //   118: invokevirtual print : (Ljava/lang/String;)V
    //   121: aload_2
    //   122: ldc_w 'mEnterAnim=#'
    //   125: invokevirtual print : (Ljava/lang/String;)V
    //   128: aload_2
    //   129: aload_0
    //   130: getfield mEnterAnim : I
    //   133: invokestatic toHexString : (I)Ljava/lang/String;
    //   136: invokevirtual print : (Ljava/lang/String;)V
    //   139: aload_2
    //   140: ldc_w ' mExitAnim=#'
    //   143: invokevirtual print : (Ljava/lang/String;)V
    //   146: aload_2
    //   147: aload_0
    //   148: getfield mExitAnim : I
    //   151: invokestatic toHexString : (I)Ljava/lang/String;
    //   154: invokevirtual println : (Ljava/lang/String;)V
    //   157: aload_0
    //   158: getfield mPopEnterAnim : I
    //   161: ifne -> 171
    //   164: aload_0
    //   165: getfield mPopExitAnim : I
    //   168: ifeq -> 212
    //   171: aload_2
    //   172: aload_1
    //   173: invokevirtual print : (Ljava/lang/String;)V
    //   176: aload_2
    //   177: ldc_w 'mPopEnterAnim=#'
    //   180: invokevirtual print : (Ljava/lang/String;)V
    //   183: aload_2
    //   184: aload_0
    //   185: getfield mPopEnterAnim : I
    //   188: invokestatic toHexString : (I)Ljava/lang/String;
    //   191: invokevirtual print : (Ljava/lang/String;)V
    //   194: aload_2
    //   195: ldc_w ' mPopExitAnim=#'
    //   198: invokevirtual print : (Ljava/lang/String;)V
    //   201: aload_2
    //   202: aload_0
    //   203: getfield mPopExitAnim : I
    //   206: invokestatic toHexString : (I)Ljava/lang/String;
    //   209: invokevirtual println : (Ljava/lang/String;)V
    //   212: aload_0
    //   213: getfield mBreadCrumbTitleRes : I
    //   216: ifne -> 226
    //   219: aload_0
    //   220: getfield mBreadCrumbTitleText : Ljava/lang/CharSequence;
    //   223: ifnull -> 264
    //   226: aload_2
    //   227: aload_1
    //   228: invokevirtual print : (Ljava/lang/String;)V
    //   231: aload_2
    //   232: ldc_w 'mBreadCrumbTitleRes=#'
    //   235: invokevirtual print : (Ljava/lang/String;)V
    //   238: aload_2
    //   239: aload_0
    //   240: getfield mBreadCrumbTitleRes : I
    //   243: invokestatic toHexString : (I)Ljava/lang/String;
    //   246: invokevirtual print : (Ljava/lang/String;)V
    //   249: aload_2
    //   250: ldc_w ' mBreadCrumbTitleText='
    //   253: invokevirtual print : (Ljava/lang/String;)V
    //   256: aload_2
    //   257: aload_0
    //   258: getfield mBreadCrumbTitleText : Ljava/lang/CharSequence;
    //   261: invokevirtual println : (Ljava/lang/Object;)V
    //   264: aload_0
    //   265: getfield mBreadCrumbShortTitleRes : I
    //   268: ifne -> 278
    //   271: aload_0
    //   272: getfield mBreadCrumbShortTitleText : Ljava/lang/CharSequence;
    //   275: ifnull -> 316
    //   278: aload_2
    //   279: aload_1
    //   280: invokevirtual print : (Ljava/lang/String;)V
    //   283: aload_2
    //   284: ldc_w 'mBreadCrumbShortTitleRes=#'
    //   287: invokevirtual print : (Ljava/lang/String;)V
    //   290: aload_2
    //   291: aload_0
    //   292: getfield mBreadCrumbShortTitleRes : I
    //   295: invokestatic toHexString : (I)Ljava/lang/String;
    //   298: invokevirtual print : (Ljava/lang/String;)V
    //   301: aload_2
    //   302: ldc_w ' mBreadCrumbShortTitleText='
    //   305: invokevirtual print : (Ljava/lang/String;)V
    //   308: aload_2
    //   309: aload_0
    //   310: getfield mBreadCrumbShortTitleText : Ljava/lang/CharSequence;
    //   313: invokevirtual println : (Ljava/lang/Object;)V
    //   316: aload_0
    //   317: getfield mHead : Landroid/support/v4/app/BackStackRecord$Op;
    //   320: ifnull -> 817
    //   323: aload_2
    //   324: aload_1
    //   325: invokevirtual print : (Ljava/lang/String;)V
    //   328: aload_2
    //   329: ldc_w 'Operations:'
    //   332: invokevirtual println : (Ljava/lang/String;)V
    //   335: new java/lang/StringBuilder
    //   338: dup
    //   339: invokespecial <init> : ()V
    //   342: aload_1
    //   343: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   346: ldc_w '    '
    //   349: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   352: invokevirtual toString : ()Ljava/lang/String;
    //   355: astore #4
    //   357: aload_0
    //   358: getfield mHead : Landroid/support/v4/app/BackStackRecord$Op;
    //   361: astore #5
    //   363: iconst_0
    //   364: istore #6
    //   366: aload #5
    //   368: ifnull -> 817
    //   371: aload #5
    //   373: getfield cmd : I
    //   376: tableswitch default -> 424, 0 -> 699, 1 -> 707, 2 -> 715, 3 -> 723, 4 -> 731, 5 -> 739, 6 -> 747, 7 -> 755
    //   424: new java/lang/StringBuilder
    //   427: dup
    //   428: invokespecial <init> : ()V
    //   431: ldc_w 'cmd='
    //   434: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   437: aload #5
    //   439: getfield cmd : I
    //   442: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   445: invokevirtual toString : ()Ljava/lang/String;
    //   448: astore #7
    //   450: aload_2
    //   451: aload_1
    //   452: invokevirtual print : (Ljava/lang/String;)V
    //   455: aload_2
    //   456: ldc_w '  Op #'
    //   459: invokevirtual print : (Ljava/lang/String;)V
    //   462: aload_2
    //   463: iload #6
    //   465: invokevirtual print : (I)V
    //   468: aload_2
    //   469: ldc_w ': '
    //   472: invokevirtual print : (Ljava/lang/String;)V
    //   475: aload_2
    //   476: aload #7
    //   478: invokevirtual print : (Ljava/lang/String;)V
    //   481: aload_2
    //   482: ldc_w ' '
    //   485: invokevirtual print : (Ljava/lang/String;)V
    //   488: aload_2
    //   489: aload #5
    //   491: getfield fragment : Landroid/support/v4/app/Fragment;
    //   494: invokevirtual println : (Ljava/lang/Object;)V
    //   497: iload_3
    //   498: ifeq -> 619
    //   501: aload #5
    //   503: getfield enterAnim : I
    //   506: ifne -> 517
    //   509: aload #5
    //   511: getfield exitAnim : I
    //   514: ifeq -> 560
    //   517: aload_2
    //   518: aload_1
    //   519: invokevirtual print : (Ljava/lang/String;)V
    //   522: aload_2
    //   523: ldc_w 'enterAnim=#'
    //   526: invokevirtual print : (Ljava/lang/String;)V
    //   529: aload_2
    //   530: aload #5
    //   532: getfield enterAnim : I
    //   535: invokestatic toHexString : (I)Ljava/lang/String;
    //   538: invokevirtual print : (Ljava/lang/String;)V
    //   541: aload_2
    //   542: ldc_w ' exitAnim=#'
    //   545: invokevirtual print : (Ljava/lang/String;)V
    //   548: aload_2
    //   549: aload #5
    //   551: getfield exitAnim : I
    //   554: invokestatic toHexString : (I)Ljava/lang/String;
    //   557: invokevirtual println : (Ljava/lang/String;)V
    //   560: aload #5
    //   562: getfield popEnterAnim : I
    //   565: ifne -> 576
    //   568: aload #5
    //   570: getfield popExitAnim : I
    //   573: ifeq -> 619
    //   576: aload_2
    //   577: aload_1
    //   578: invokevirtual print : (Ljava/lang/String;)V
    //   581: aload_2
    //   582: ldc_w 'popEnterAnim=#'
    //   585: invokevirtual print : (Ljava/lang/String;)V
    //   588: aload_2
    //   589: aload #5
    //   591: getfield popEnterAnim : I
    //   594: invokestatic toHexString : (I)Ljava/lang/String;
    //   597: invokevirtual print : (Ljava/lang/String;)V
    //   600: aload_2
    //   601: ldc_w ' popExitAnim=#'
    //   604: invokevirtual print : (Ljava/lang/String;)V
    //   607: aload_2
    //   608: aload #5
    //   610: getfield popExitAnim : I
    //   613: invokestatic toHexString : (I)Ljava/lang/String;
    //   616: invokevirtual println : (Ljava/lang/String;)V
    //   619: aload #5
    //   621: getfield removed : Ljava/util/ArrayList;
    //   624: ifnull -> 804
    //   627: aload #5
    //   629: getfield removed : Ljava/util/ArrayList;
    //   632: invokevirtual size : ()I
    //   635: ifle -> 804
    //   638: iconst_0
    //   639: istore #8
    //   641: iload #8
    //   643: aload #5
    //   645: getfield removed : Ljava/util/ArrayList;
    //   648: invokevirtual size : ()I
    //   651: if_icmpge -> 804
    //   654: aload_2
    //   655: aload #4
    //   657: invokevirtual print : (Ljava/lang/String;)V
    //   660: aload #5
    //   662: getfield removed : Ljava/util/ArrayList;
    //   665: invokevirtual size : ()I
    //   668: iconst_1
    //   669: if_icmpne -> 763
    //   672: aload_2
    //   673: ldc_w 'Removed: '
    //   676: invokevirtual print : (Ljava/lang/String;)V
    //   679: aload_2
    //   680: aload #5
    //   682: getfield removed : Ljava/util/ArrayList;
    //   685: iload #8
    //   687: invokevirtual get : (I)Ljava/lang/Object;
    //   690: invokevirtual println : (Ljava/lang/Object;)V
    //   693: iinc #8, 1
    //   696: goto -> 641
    //   699: ldc_w 'NULL'
    //   702: astore #7
    //   704: goto -> 450
    //   707: ldc_w 'ADD'
    //   710: astore #7
    //   712: goto -> 450
    //   715: ldc_w 'REPLACE'
    //   718: astore #7
    //   720: goto -> 450
    //   723: ldc_w 'REMOVE'
    //   726: astore #7
    //   728: goto -> 450
    //   731: ldc_w 'HIDE'
    //   734: astore #7
    //   736: goto -> 450
    //   739: ldc_w 'SHOW'
    //   742: astore #7
    //   744: goto -> 450
    //   747: ldc_w 'DETACH'
    //   750: astore #7
    //   752: goto -> 450
    //   755: ldc_w 'ATTACH'
    //   758: astore #7
    //   760: goto -> 450
    //   763: iload #8
    //   765: ifne -> 775
    //   768: aload_2
    //   769: ldc_w 'Removed:'
    //   772: invokevirtual println : (Ljava/lang/String;)V
    //   775: aload_2
    //   776: aload #4
    //   778: invokevirtual print : (Ljava/lang/String;)V
    //   781: aload_2
    //   782: ldc_w '  #'
    //   785: invokevirtual print : (Ljava/lang/String;)V
    //   788: aload_2
    //   789: iload #8
    //   791: invokevirtual print : (I)V
    //   794: aload_2
    //   795: ldc_w ': '
    //   798: invokevirtual print : (Ljava/lang/String;)V
    //   801: goto -> 679
    //   804: aload #5
    //   806: getfield next : Landroid/support/v4/app/BackStackRecord$Op;
    //   809: astore #5
    //   811: iinc #6, 1
    //   814: goto -> 366
    //   817: return
  }
  
  public CharSequence getBreadCrumbShortTitle() {
    return (this.mBreadCrumbShortTitleRes != 0) ? this.mManager.mActivity.getText(this.mBreadCrumbShortTitleRes) : this.mBreadCrumbShortTitleText;
  }
  
  public int getBreadCrumbShortTitleRes() {
    return this.mBreadCrumbShortTitleRes;
  }
  
  public CharSequence getBreadCrumbTitle() {
    return (this.mBreadCrumbTitleRes != 0) ? this.mManager.mActivity.getText(this.mBreadCrumbTitleRes) : this.mBreadCrumbTitleText;
  }
  
  public int getBreadCrumbTitleRes() {
    return this.mBreadCrumbTitleRes;
  }
  
  public int getId() {
    return this.mIndex;
  }
  
  public String getName() {
    return this.mName;
  }
  
  public int getTransition() {
    return this.mTransition;
  }
  
  public int getTransitionStyle() {
    return this.mTransitionStyle;
  }
  
  public FragmentTransaction hide(Fragment paramFragment) {
    Op op = new Op();
    op.cmd = 4;
    op.fragment = paramFragment;
    addOp(op);
    return this;
  }
  
  public boolean isAddToBackStackAllowed() {
    return this.mAllowAddToBackStack;
  }
  
  public boolean isEmpty() {
    return (this.mNumOp == 0);
  }
  
  public void popFromBackStack(boolean paramBoolean) {
    if (FragmentManagerImpl.DEBUG) {
      Log.v("FragmentManager", "popFromBackStack: " + this);
      dump("  ", null, new PrintWriter((Writer)new LogWriter("FragmentManager")), null);
    } 
    bumpBackStackNesting(-1);
    Op op = this.mTail;
    label35: while (op != null) {
      switch (op.cmd) {
        default:
          throw new IllegalArgumentException("Unknown cmd: " + op.cmd);
        case 1:
          fragment = op.fragment;
          fragment.mNextAnim = op.popExitAnim;
          this.mManager.removeFragment(fragment, FragmentManagerImpl.reverseTransit(this.mTransition), this.mTransitionStyle);
          continue;
        case 2:
          fragment = op.fragment;
          if (fragment != null) {
            fragment.mNextAnim = op.popExitAnim;
            this.mManager.removeFragment(fragment, FragmentManagerImpl.reverseTransit(this.mTransition), this.mTransitionStyle);
          } 
          if (op.removed != null) {
            byte b = 0;
            while (true) {
              if (b < op.removed.size()) {
                fragment = op.removed.get(b);
                fragment.mNextAnim = op.popEnterAnim;
                this.mManager.addFragment(fragment, false);
                b++;
                continue;
              } 
              op = op.prev;
              continue label35;
            } 
          } 
          continue;
        case 3:
          fragment = op.fragment;
          fragment.mNextAnim = op.popEnterAnim;
          this.mManager.addFragment(fragment, false);
          continue;
        case 4:
          fragment = op.fragment;
          fragment.mNextAnim = op.popEnterAnim;
          this.mManager.showFragment(fragment, FragmentManagerImpl.reverseTransit(this.mTransition), this.mTransitionStyle);
          continue;
        case 5:
          fragment = op.fragment;
          fragment.mNextAnim = op.popExitAnim;
          this.mManager.hideFragment(fragment, FragmentManagerImpl.reverseTransit(this.mTransition), this.mTransitionStyle);
          continue;
        case 6:
          fragment = op.fragment;
          fragment.mNextAnim = op.popEnterAnim;
          this.mManager.attachFragment(fragment, FragmentManagerImpl.reverseTransit(this.mTransition), this.mTransitionStyle);
          continue;
        case 7:
          break;
      } 
      Fragment fragment = op.fragment;
      fragment.mNextAnim = op.popEnterAnim;
      this.mManager.detachFragment(fragment, FragmentManagerImpl.reverseTransit(this.mTransition), this.mTransitionStyle);
      continue;
    } 
    if (paramBoolean)
      this.mManager.moveToState(this.mManager.mCurState, FragmentManagerImpl.reverseTransit(this.mTransition), this.mTransitionStyle, true); 
    if (this.mIndex >= 0) {
      this.mManager.freeBackStackIndex(this.mIndex);
      this.mIndex = -1;
    } 
  }
  
  public FragmentTransaction remove(Fragment paramFragment) {
    Op op = new Op();
    op.cmd = 3;
    op.fragment = paramFragment;
    addOp(op);
    return this;
  }
  
  public FragmentTransaction replace(int paramInt, Fragment paramFragment) {
    return replace(paramInt, paramFragment, null);
  }
  
  public FragmentTransaction replace(int paramInt, Fragment paramFragment, String paramString) {
    if (paramInt == 0)
      throw new IllegalArgumentException("Must use non-zero containerViewId"); 
    doAddOp(paramInt, paramFragment, paramString, 2);
    return this;
  }
  
  public void run() {
    if (FragmentManagerImpl.DEBUG)
      Log.v("FragmentManager", "Run: " + this); 
    if (this.mAddToBackStack && this.mIndex < 0)
      throw new IllegalStateException("addToBackStack() called after commit()"); 
    bumpBackStackNesting(1);
    Op op = this.mHead;
    while (op != null) {
      continue;
      switch (op.cmd) {
        case 1:
          fragment1 = op.fragment;
          fragment1.mNextAnim = op.enterAnim;
          this.mManager.addFragment(fragment1, false);
          op = op.next;
          break;
        case 2:
          fragment1 = op.fragment;
          fragment2 = fragment1;
        case 3:
          fragment1 = op.fragment;
          fragment1.mNextAnim = op.exitAnim;
          this.mManager.removeFragment(fragment1, this.mTransition, this.mTransitionStyle);
          op = op.next;
          break;
        case 4:
          fragment1 = op.fragment;
          fragment1.mNextAnim = op.exitAnim;
          this.mManager.hideFragment(fragment1, this.mTransition, this.mTransitionStyle);
          op = op.next;
          break;
        case 5:
          fragment1 = op.fragment;
          fragment1.mNextAnim = op.enterAnim;
          this.mManager.showFragment(fragment1, this.mTransition, this.mTransitionStyle);
          op = op.next;
          break;
        case 6:
          fragment1 = op.fragment;
          fragment1.mNextAnim = op.exitAnim;
          this.mManager.detachFragment(fragment1, this.mTransition, this.mTransitionStyle);
          op = op.next;
          break;
        case 7:
          fragment1 = op.fragment;
          fragment1.mNextAnim = op.enterAnim;
          this.mManager.attachFragment(fragment1, this.mTransition, this.mTransitionStyle);
          op = op.next;
          break;
      } 
    } 
    this.mManager.moveToState(this.mManager.mCurState, this.mTransition, this.mTransitionStyle, true);
    if (this.mAddToBackStack)
      this.mManager.addBackStackState(this); 
  }
  
  public FragmentTransaction setBreadCrumbShortTitle(int paramInt) {
    this.mBreadCrumbShortTitleRes = paramInt;
    this.mBreadCrumbShortTitleText = null;
    return this;
  }
  
  public FragmentTransaction setBreadCrumbShortTitle(CharSequence paramCharSequence) {
    this.mBreadCrumbShortTitleRes = 0;
    this.mBreadCrumbShortTitleText = paramCharSequence;
    return this;
  }
  
  public FragmentTransaction setBreadCrumbTitle(int paramInt) {
    this.mBreadCrumbTitleRes = paramInt;
    this.mBreadCrumbTitleText = null;
    return this;
  }
  
  public FragmentTransaction setBreadCrumbTitle(CharSequence paramCharSequence) {
    this.mBreadCrumbTitleRes = 0;
    this.mBreadCrumbTitleText = paramCharSequence;
    return this;
  }
  
  public FragmentTransaction setCustomAnimations(int paramInt1, int paramInt2) {
    return setCustomAnimations(paramInt1, paramInt2, 0, 0);
  }
  
  public FragmentTransaction setCustomAnimations(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mEnterAnim = paramInt1;
    this.mExitAnim = paramInt2;
    this.mPopEnterAnim = paramInt3;
    this.mPopExitAnim = paramInt4;
    return this;
  }
  
  public FragmentTransaction setTransition(int paramInt) {
    this.mTransition = paramInt;
    return this;
  }
  
  public FragmentTransaction setTransitionStyle(int paramInt) {
    this.mTransitionStyle = paramInt;
    return this;
  }
  
  public FragmentTransaction show(Fragment paramFragment) {
    Op op = new Op();
    op.cmd = 5;
    op.fragment = paramFragment;
    addOp(op);
    return this;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("BackStackEntry{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    if (this.mIndex >= 0) {
      stringBuilder.append(" #");
      stringBuilder.append(this.mIndex);
    } 
    if (this.mName != null) {
      stringBuilder.append(" ");
      stringBuilder.append(this.mName);
    } 
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  static final class Op {
    int cmd;
    
    int enterAnim;
    
    int exitAnim;
    
    Fragment fragment;
    
    Op next;
    
    int popEnterAnim;
    
    int popExitAnim;
    
    Op prev;
    
    ArrayList<Fragment> removed;
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeCMCC-dex2jar.jar!/android/support/v4/app/BackStackRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */