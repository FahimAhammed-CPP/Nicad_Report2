package android.support.v4.view;

import android.os.Build;
import android.view.View;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;

public class ViewParentCompat {
  static final ViewParentCompatImpl IMPL = new ViewParentCompatStubImpl();
  
  public static boolean requestSendAccessibilityEvent(ViewParent paramViewParent, View paramView, AccessibilityEvent paramAccessibilityEvent) {
    return IMPL.requestSendAccessibilityEvent(paramViewParent, paramView, paramAccessibilityEvent);
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 14) {
      IMPL = new ViewParentCompatICSImpl();
      return;
    } 
  }
  
  static class ViewParentCompatICSImpl extends ViewParentCompatStubImpl {
    public boolean requestSendAccessibilityEvent(ViewParent param1ViewParent, View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return ViewParentCompatICS.requestSendAccessibilityEvent(param1ViewParent, param1View, param1AccessibilityEvent);
    }
  }
  
  static interface ViewParentCompatImpl {
    boolean requestSendAccessibilityEvent(ViewParent param1ViewParent, View param1View, AccessibilityEvent param1AccessibilityEvent);
  }
  
  static class ViewParentCompatStubImpl implements ViewParentCompatImpl {
    public boolean requestSendAccessibilityEvent(ViewParent param1ViewParent, View param1View, AccessibilityEvent param1AccessibilityEvent) {
      if (param1View == null)
        return false; 
      ((AccessibilityManager)param1View.getContext().getSystemService("accessibility")).sendAccessibilityEvent(param1AccessibilityEvent);
      return true;
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeCMCC-dex2jar.jar!/android/support/v4/view/ViewParentCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */