package android.support.v4.view;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;

public class GestureDetectorCompat {
  private final GestureDetectorCompatImpl mImpl;
  
  public GestureDetectorCompat(Context paramContext, GestureDetector.OnGestureListener paramOnGestureListener) {
    this(paramContext, paramOnGestureListener, null);
  }
  
  public GestureDetectorCompat(Context paramContext, GestureDetector.OnGestureListener paramOnGestureListener, Handler paramHandler) {
    if (Build.VERSION.SDK_INT > 17) {
      this.mImpl = new GestureDetectorCompatImplJellybeanMr2(paramContext, paramOnGestureListener, paramHandler);
      return;
    } 
    this.mImpl = new GestureDetectorCompatImplBase(paramContext, paramOnGestureListener, paramHandler);
  }
  
  public boolean isLongpressEnabled() {
    return this.mImpl.isLongpressEnabled();
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    return this.mImpl.onTouchEvent(paramMotionEvent);
  }
  
  public void setIsLongpressEnabled(boolean paramBoolean) {
    this.mImpl.setIsLongpressEnabled(paramBoolean);
  }
  
  public void setOnDoubleTapListener(GestureDetector.OnDoubleTapListener paramOnDoubleTapListener) {
    this.mImpl.setOnDoubleTapListener(paramOnDoubleTapListener);
  }
  
  static interface GestureDetectorCompatImpl {
    boolean isLongpressEnabled();
    
    boolean onTouchEvent(MotionEvent param1MotionEvent);
    
    void setIsLongpressEnabled(boolean param1Boolean);
    
    void setOnDoubleTapListener(GestureDetector.OnDoubleTapListener param1OnDoubleTapListener);
  }
  
  static class GestureDetectorCompatImplBase implements GestureDetectorCompatImpl {
    private static final int DOUBLE_TAP_TIMEOUT = ViewConfiguration.getDoubleTapTimeout();
    
    private static final int LONGPRESS_TIMEOUT = ViewConfiguration.getLongPressTimeout();
    
    private static final int LONG_PRESS = 2;
    
    private static final int SHOW_PRESS = 1;
    
    private static final int TAP = 3;
    
    private static final int TAP_TIMEOUT = ViewConfiguration.getTapTimeout();
    
    private boolean mAlwaysInBiggerTapRegion;
    
    private boolean mAlwaysInTapRegion;
    
    private MotionEvent mCurrentDownEvent;
    
    private boolean mDeferConfirmSingleTap;
    
    private GestureDetector.OnDoubleTapListener mDoubleTapListener;
    
    private int mDoubleTapSlopSquare;
    
    private float mDownFocusX;
    
    private float mDownFocusY;
    
    private final Handler mHandler;
    
    private boolean mInLongPress;
    
    private boolean mIsDoubleTapping;
    
    private boolean mIsLongpressEnabled;
    
    private float mLastFocusX;
    
    private float mLastFocusY;
    
    private final GestureDetector.OnGestureListener mListener;
    
    private int mMaximumFlingVelocity;
    
    private int mMinimumFlingVelocity;
    
    private MotionEvent mPreviousUpEvent;
    
    private boolean mStillDown;
    
    private int mTouchSlopSquare;
    
    private VelocityTracker mVelocityTracker;
    
    static {
    
    }
    
    public GestureDetectorCompatImplBase(Context param1Context, GestureDetector.OnGestureListener param1OnGestureListener, Handler param1Handler) {
      if (param1Handler != null) {
        this.mHandler = new GestureHandler(param1Handler);
      } else {
        this.mHandler = new GestureHandler();
      } 
      this.mListener = param1OnGestureListener;
      if (param1OnGestureListener instanceof GestureDetector.OnDoubleTapListener)
        setOnDoubleTapListener((GestureDetector.OnDoubleTapListener)param1OnGestureListener); 
      init(param1Context);
    }
    
    private void cancel() {
      this.mHandler.removeMessages(1);
      this.mHandler.removeMessages(2);
      this.mHandler.removeMessages(3);
      this.mVelocityTracker.recycle();
      this.mVelocityTracker = null;
      this.mIsDoubleTapping = false;
      this.mStillDown = false;
      this.mAlwaysInTapRegion = false;
      this.mAlwaysInBiggerTapRegion = false;
      this.mDeferConfirmSingleTap = false;
      if (this.mInLongPress)
        this.mInLongPress = false; 
    }
    
    private void cancelTaps() {
      this.mHandler.removeMessages(1);
      this.mHandler.removeMessages(2);
      this.mHandler.removeMessages(3);
      this.mIsDoubleTapping = false;
      this.mAlwaysInTapRegion = false;
      this.mAlwaysInBiggerTapRegion = false;
      this.mDeferConfirmSingleTap = false;
      if (this.mInLongPress)
        this.mInLongPress = false; 
    }
    
    private void dispatchLongPress() {
      this.mHandler.removeMessages(3);
      this.mDeferConfirmSingleTap = false;
      this.mInLongPress = true;
      this.mListener.onLongPress(this.mCurrentDownEvent);
    }
    
    private void init(Context param1Context) {
      if (param1Context == null)
        throw new IllegalArgumentException("Context must not be null"); 
      if (this.mListener == null)
        throw new IllegalArgumentException("OnGestureListener must not be null"); 
      this.mIsLongpressEnabled = true;
      ViewConfiguration viewConfiguration = ViewConfiguration.get(param1Context);
      int i = viewConfiguration.getScaledTouchSlop();
      int j = viewConfiguration.getScaledDoubleTapSlop();
      this.mMinimumFlingVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
      this.mMaximumFlingVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
      this.mTouchSlopSquare = i * i;
      this.mDoubleTapSlopSquare = j * j;
    }
    
    private boolean isConsideredDoubleTap(MotionEvent param1MotionEvent1, MotionEvent param1MotionEvent2, MotionEvent param1MotionEvent3) {
      boolean bool1 = false;
      if (!this.mAlwaysInBiggerTapRegion)
        return bool1; 
      boolean bool2 = bool1;
      if (param1MotionEvent3.getEventTime() - param1MotionEvent2.getEventTime() <= DOUBLE_TAP_TIMEOUT) {
        int i = (int)param1MotionEvent1.getX() - (int)param1MotionEvent3.getX();
        int j = (int)param1MotionEvent1.getY() - (int)param1MotionEvent3.getY();
        bool2 = bool1;
        if (i * i + j * j < this.mDoubleTapSlopSquare)
          bool2 = true; 
      } 
      return bool2;
    }
    
    public boolean isLongpressEnabled() {
      return this.mIsLongpressEnabled;
    }
    
    public boolean onTouchEvent(MotionEvent param1MotionEvent) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual getAction : ()I
      //   4: istore_2
      //   5: aload_0
      //   6: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   9: ifnonnull -> 19
      //   12: aload_0
      //   13: invokestatic obtain : ()Landroid/view/VelocityTracker;
      //   16: putfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   19: aload_0
      //   20: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   23: aload_1
      //   24: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
      //   27: iload_2
      //   28: sipush #255
      //   31: iand
      //   32: bipush #6
      //   34: if_icmpne -> 84
      //   37: iconst_1
      //   38: istore_3
      //   39: iload_3
      //   40: ifeq -> 89
      //   43: aload_1
      //   44: invokestatic getActionIndex : (Landroid/view/MotionEvent;)I
      //   47: istore #4
      //   49: fconst_0
      //   50: fstore #5
      //   52: fconst_0
      //   53: fstore #6
      //   55: aload_1
      //   56: invokestatic getPointerCount : (Landroid/view/MotionEvent;)I
      //   59: istore #7
      //   61: iconst_0
      //   62: istore #8
      //   64: iload #8
      //   66: iload #7
      //   68: if_icmpge -> 120
      //   71: iload #4
      //   73: iload #8
      //   75: if_icmpne -> 95
      //   78: iinc #8, 1
      //   81: goto -> 64
      //   84: iconst_0
      //   85: istore_3
      //   86: goto -> 39
      //   89: iconst_m1
      //   90: istore #4
      //   92: goto -> 49
      //   95: fload #5
      //   97: aload_1
      //   98: iload #8
      //   100: invokestatic getX : (Landroid/view/MotionEvent;I)F
      //   103: fadd
      //   104: fstore #5
      //   106: fload #6
      //   108: aload_1
      //   109: iload #8
      //   111: invokestatic getY : (Landroid/view/MotionEvent;I)F
      //   114: fadd
      //   115: fstore #6
      //   117: goto -> 78
      //   120: iload_3
      //   121: ifeq -> 215
      //   124: iload #7
      //   126: iconst_1
      //   127: isub
      //   128: istore_3
      //   129: fload #5
      //   131: iload_3
      //   132: i2f
      //   133: fdiv
      //   134: fstore #5
      //   136: fload #6
      //   138: iload_3
      //   139: i2f
      //   140: fdiv
      //   141: fstore #9
      //   143: iconst_0
      //   144: istore #4
      //   146: iconst_0
      //   147: istore #10
      //   149: iconst_0
      //   150: istore #11
      //   152: iconst_0
      //   153: istore #12
      //   155: iload #12
      //   157: istore #13
      //   159: iload_2
      //   160: sipush #255
      //   163: iand
      //   164: tableswitch default -> 208, 0 -> 403, 1 -> 917, 2 -> 672, 3 -> 1199, 4 -> 212, 5 -> 221, 6 -> 256
      //   208: iload #12
      //   210: istore #13
      //   212: iload #13
      //   214: ireturn
      //   215: iload #7
      //   217: istore_3
      //   218: goto -> 129
      //   221: aload_0
      //   222: fload #5
      //   224: putfield mLastFocusX : F
      //   227: aload_0
      //   228: fload #5
      //   230: putfield mDownFocusX : F
      //   233: aload_0
      //   234: fload #9
      //   236: putfield mLastFocusY : F
      //   239: aload_0
      //   240: fload #9
      //   242: putfield mDownFocusY : F
      //   245: aload_0
      //   246: invokespecial cancelTaps : ()V
      //   249: iload #12
      //   251: istore #13
      //   253: goto -> 212
      //   256: aload_0
      //   257: fload #5
      //   259: putfield mLastFocusX : F
      //   262: aload_0
      //   263: fload #5
      //   265: putfield mDownFocusX : F
      //   268: aload_0
      //   269: fload #9
      //   271: putfield mLastFocusY : F
      //   274: aload_0
      //   275: fload #9
      //   277: putfield mDownFocusY : F
      //   280: aload_0
      //   281: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   284: sipush #1000
      //   287: aload_0
      //   288: getfield mMaximumFlingVelocity : I
      //   291: i2f
      //   292: invokevirtual computeCurrentVelocity : (IF)V
      //   295: aload_1
      //   296: invokestatic getActionIndex : (Landroid/view/MotionEvent;)I
      //   299: istore #4
      //   301: aload_1
      //   302: iload #4
      //   304: invokestatic getPointerId : (Landroid/view/MotionEvent;I)I
      //   307: istore_3
      //   308: aload_0
      //   309: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   312: iload_3
      //   313: invokestatic getXVelocity : (Landroid/view/VelocityTracker;I)F
      //   316: fstore #6
      //   318: aload_0
      //   319: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   322: iload_3
      //   323: invokestatic getYVelocity : (Landroid/view/VelocityTracker;I)F
      //   326: fstore #5
      //   328: iconst_0
      //   329: istore_3
      //   330: iload #12
      //   332: istore #13
      //   334: iload_3
      //   335: iload #7
      //   337: if_icmpge -> 212
      //   340: iload_3
      //   341: iload #4
      //   343: if_icmpne -> 352
      //   346: iinc #3, 1
      //   349: goto -> 330
      //   352: aload_1
      //   353: iload_3
      //   354: invokestatic getPointerId : (Landroid/view/MotionEvent;I)I
      //   357: istore #8
      //   359: fload #6
      //   361: aload_0
      //   362: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   365: iload #8
      //   367: invokestatic getXVelocity : (Landroid/view/VelocityTracker;I)F
      //   370: fmul
      //   371: fload #5
      //   373: aload_0
      //   374: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   377: iload #8
      //   379: invokestatic getYVelocity : (Landroid/view/VelocityTracker;I)F
      //   382: fmul
      //   383: fadd
      //   384: fconst_0
      //   385: fcmpg
      //   386: ifge -> 346
      //   389: aload_0
      //   390: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   393: invokevirtual clear : ()V
      //   396: iload #12
      //   398: istore #13
      //   400: goto -> 212
      //   403: iload #4
      //   405: istore_3
      //   406: aload_0
      //   407: getfield mDoubleTapListener : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   410: ifnull -> 503
      //   413: aload_0
      //   414: getfield mHandler : Landroid/os/Handler;
      //   417: iconst_3
      //   418: invokevirtual hasMessages : (I)Z
      //   421: istore #13
      //   423: iload #13
      //   425: ifeq -> 436
      //   428: aload_0
      //   429: getfield mHandler : Landroid/os/Handler;
      //   432: iconst_3
      //   433: invokevirtual removeMessages : (I)V
      //   436: aload_0
      //   437: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   440: ifnull -> 653
      //   443: aload_0
      //   444: getfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   447: ifnull -> 653
      //   450: iload #13
      //   452: ifeq -> 653
      //   455: aload_0
      //   456: aload_0
      //   457: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   460: aload_0
      //   461: getfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   464: aload_1
      //   465: invokespecial isConsideredDoubleTap : (Landroid/view/MotionEvent;Landroid/view/MotionEvent;Landroid/view/MotionEvent;)Z
      //   468: ifeq -> 653
      //   471: aload_0
      //   472: iconst_1
      //   473: putfield mIsDoubleTapping : Z
      //   476: iconst_0
      //   477: aload_0
      //   478: getfield mDoubleTapListener : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   481: aload_0
      //   482: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   485: invokeinterface onDoubleTap : (Landroid/view/MotionEvent;)Z
      //   490: ior
      //   491: aload_0
      //   492: getfield mDoubleTapListener : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   495: aload_1
      //   496: invokeinterface onDoubleTapEvent : (Landroid/view/MotionEvent;)Z
      //   501: ior
      //   502: istore_3
      //   503: aload_0
      //   504: fload #5
      //   506: putfield mLastFocusX : F
      //   509: aload_0
      //   510: fload #5
      //   512: putfield mDownFocusX : F
      //   515: aload_0
      //   516: fload #9
      //   518: putfield mLastFocusY : F
      //   521: aload_0
      //   522: fload #9
      //   524: putfield mDownFocusY : F
      //   527: aload_0
      //   528: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   531: ifnull -> 541
      //   534: aload_0
      //   535: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   538: invokevirtual recycle : ()V
      //   541: aload_0
      //   542: aload_1
      //   543: invokestatic obtain : (Landroid/view/MotionEvent;)Landroid/view/MotionEvent;
      //   546: putfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   549: aload_0
      //   550: iconst_1
      //   551: putfield mAlwaysInTapRegion : Z
      //   554: aload_0
      //   555: iconst_1
      //   556: putfield mAlwaysInBiggerTapRegion : Z
      //   559: aload_0
      //   560: iconst_1
      //   561: putfield mStillDown : Z
      //   564: aload_0
      //   565: iconst_0
      //   566: putfield mInLongPress : Z
      //   569: aload_0
      //   570: iconst_0
      //   571: putfield mDeferConfirmSingleTap : Z
      //   574: aload_0
      //   575: getfield mIsLongpressEnabled : Z
      //   578: ifeq -> 615
      //   581: aload_0
      //   582: getfield mHandler : Landroid/os/Handler;
      //   585: iconst_2
      //   586: invokevirtual removeMessages : (I)V
      //   589: aload_0
      //   590: getfield mHandler : Landroid/os/Handler;
      //   593: iconst_2
      //   594: aload_0
      //   595: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   598: invokevirtual getDownTime : ()J
      //   601: getstatic android/support/v4/view/GestureDetectorCompat$GestureDetectorCompatImplBase.TAP_TIMEOUT : I
      //   604: i2l
      //   605: ladd
      //   606: getstatic android/support/v4/view/GestureDetectorCompat$GestureDetectorCompatImplBase.LONGPRESS_TIMEOUT : I
      //   609: i2l
      //   610: ladd
      //   611: invokevirtual sendEmptyMessageAtTime : (IJ)Z
      //   614: pop
      //   615: aload_0
      //   616: getfield mHandler : Landroid/os/Handler;
      //   619: iconst_1
      //   620: aload_0
      //   621: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   624: invokevirtual getDownTime : ()J
      //   627: getstatic android/support/v4/view/GestureDetectorCompat$GestureDetectorCompatImplBase.TAP_TIMEOUT : I
      //   630: i2l
      //   631: ladd
      //   632: invokevirtual sendEmptyMessageAtTime : (IJ)Z
      //   635: pop
      //   636: iload_3
      //   637: aload_0
      //   638: getfield mListener : Landroid/view/GestureDetector$OnGestureListener;
      //   641: aload_1
      //   642: invokeinterface onDown : (Landroid/view/MotionEvent;)Z
      //   647: ior
      //   648: istore #13
      //   650: goto -> 212
      //   653: aload_0
      //   654: getfield mHandler : Landroid/os/Handler;
      //   657: iconst_3
      //   658: getstatic android/support/v4/view/GestureDetectorCompat$GestureDetectorCompatImplBase.DOUBLE_TAP_TIMEOUT : I
      //   661: i2l
      //   662: invokevirtual sendEmptyMessageDelayed : (IJ)Z
      //   665: pop
      //   666: iload #4
      //   668: istore_3
      //   669: goto -> 503
      //   672: iload #12
      //   674: istore #13
      //   676: aload_0
      //   677: getfield mInLongPress : Z
      //   680: ifne -> 212
      //   683: aload_0
      //   684: getfield mLastFocusX : F
      //   687: fload #5
      //   689: fsub
      //   690: fstore #14
      //   692: aload_0
      //   693: getfield mLastFocusY : F
      //   696: fload #9
      //   698: fsub
      //   699: fstore #6
      //   701: aload_0
      //   702: getfield mIsDoubleTapping : Z
      //   705: ifeq -> 725
      //   708: iconst_0
      //   709: aload_0
      //   710: getfield mDoubleTapListener : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   713: aload_1
      //   714: invokeinterface onDoubleTapEvent : (Landroid/view/MotionEvent;)Z
      //   719: ior
      //   720: istore #13
      //   722: goto -> 212
      //   725: aload_0
      //   726: getfield mAlwaysInTapRegion : Z
      //   729: ifeq -> 858
      //   732: fload #5
      //   734: aload_0
      //   735: getfield mDownFocusX : F
      //   738: fsub
      //   739: f2i
      //   740: istore #4
      //   742: fload #9
      //   744: aload_0
      //   745: getfield mDownFocusY : F
      //   748: fsub
      //   749: f2i
      //   750: istore_3
      //   751: iload #4
      //   753: iload #4
      //   755: imul
      //   756: iload_3
      //   757: iload_3
      //   758: imul
      //   759: iadd
      //   760: istore_3
      //   761: iload #10
      //   763: istore #12
      //   765: iload_3
      //   766: aload_0
      //   767: getfield mTouchSlopSquare : I
      //   770: if_icmple -> 834
      //   773: aload_0
      //   774: getfield mListener : Landroid/view/GestureDetector$OnGestureListener;
      //   777: aload_0
      //   778: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   781: aload_1
      //   782: fload #14
      //   784: fload #6
      //   786: invokeinterface onScroll : (Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
      //   791: istore #12
      //   793: aload_0
      //   794: fload #5
      //   796: putfield mLastFocusX : F
      //   799: aload_0
      //   800: fload #9
      //   802: putfield mLastFocusY : F
      //   805: aload_0
      //   806: iconst_0
      //   807: putfield mAlwaysInTapRegion : Z
      //   810: aload_0
      //   811: getfield mHandler : Landroid/os/Handler;
      //   814: iconst_3
      //   815: invokevirtual removeMessages : (I)V
      //   818: aload_0
      //   819: getfield mHandler : Landroid/os/Handler;
      //   822: iconst_1
      //   823: invokevirtual removeMessages : (I)V
      //   826: aload_0
      //   827: getfield mHandler : Landroid/os/Handler;
      //   830: iconst_2
      //   831: invokevirtual removeMessages : (I)V
      //   834: iload #12
      //   836: istore #13
      //   838: iload_3
      //   839: aload_0
      //   840: getfield mTouchSlopSquare : I
      //   843: if_icmple -> 212
      //   846: aload_0
      //   847: iconst_0
      //   848: putfield mAlwaysInBiggerTapRegion : Z
      //   851: iload #12
      //   853: istore #13
      //   855: goto -> 212
      //   858: fload #14
      //   860: invokestatic abs : (F)F
      //   863: fconst_1
      //   864: fcmpl
      //   865: ifge -> 882
      //   868: iload #12
      //   870: istore #13
      //   872: fload #6
      //   874: invokestatic abs : (F)F
      //   877: fconst_1
      //   878: fcmpl
      //   879: iflt -> 212
      //   882: aload_0
      //   883: getfield mListener : Landroid/view/GestureDetector$OnGestureListener;
      //   886: aload_0
      //   887: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   890: aload_1
      //   891: fload #14
      //   893: fload #6
      //   895: invokeinterface onScroll : (Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
      //   900: istore #13
      //   902: aload_0
      //   903: fload #5
      //   905: putfield mLastFocusX : F
      //   908: aload_0
      //   909: fload #9
      //   911: putfield mLastFocusY : F
      //   914: goto -> 212
      //   917: aload_0
      //   918: iconst_0
      //   919: putfield mStillDown : Z
      //   922: aload_1
      //   923: invokestatic obtain : (Landroid/view/MotionEvent;)Landroid/view/MotionEvent;
      //   926: astore #15
      //   928: aload_0
      //   929: getfield mIsDoubleTapping : Z
      //   932: ifeq -> 1017
      //   935: iconst_0
      //   936: aload_0
      //   937: getfield mDoubleTapListener : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   940: aload_1
      //   941: invokeinterface onDoubleTapEvent : (Landroid/view/MotionEvent;)Z
      //   946: ior
      //   947: istore #13
      //   949: aload_0
      //   950: getfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   953: ifnull -> 963
      //   956: aload_0
      //   957: getfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   960: invokevirtual recycle : ()V
      //   963: aload_0
      //   964: aload #15
      //   966: putfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   969: aload_0
      //   970: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   973: ifnull -> 988
      //   976: aload_0
      //   977: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   980: invokevirtual recycle : ()V
      //   983: aload_0
      //   984: aconst_null
      //   985: putfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   988: aload_0
      //   989: iconst_0
      //   990: putfield mIsDoubleTapping : Z
      //   993: aload_0
      //   994: iconst_0
      //   995: putfield mDeferConfirmSingleTap : Z
      //   998: aload_0
      //   999: getfield mHandler : Landroid/os/Handler;
      //   1002: iconst_1
      //   1003: invokevirtual removeMessages : (I)V
      //   1006: aload_0
      //   1007: getfield mHandler : Landroid/os/Handler;
      //   1010: iconst_2
      //   1011: invokevirtual removeMessages : (I)V
      //   1014: goto -> 212
      //   1017: aload_0
      //   1018: getfield mInLongPress : Z
      //   1021: ifeq -> 1044
      //   1024: aload_0
      //   1025: getfield mHandler : Landroid/os/Handler;
      //   1028: iconst_3
      //   1029: invokevirtual removeMessages : (I)V
      //   1032: aload_0
      //   1033: iconst_0
      //   1034: putfield mInLongPress : Z
      //   1037: iload #11
      //   1039: istore #13
      //   1041: goto -> 949
      //   1044: aload_0
      //   1045: getfield mAlwaysInTapRegion : Z
      //   1048: ifeq -> 1103
      //   1051: aload_0
      //   1052: getfield mListener : Landroid/view/GestureDetector$OnGestureListener;
      //   1055: aload_1
      //   1056: invokeinterface onSingleTapUp : (Landroid/view/MotionEvent;)Z
      //   1061: istore #12
      //   1063: iload #12
      //   1065: istore #13
      //   1067: aload_0
      //   1068: getfield mDeferConfirmSingleTap : Z
      //   1071: ifeq -> 949
      //   1074: iload #12
      //   1076: istore #13
      //   1078: aload_0
      //   1079: getfield mDoubleTapListener : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   1082: ifnull -> 949
      //   1085: aload_0
      //   1086: getfield mDoubleTapListener : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   1089: aload_1
      //   1090: invokeinterface onSingleTapConfirmed : (Landroid/view/MotionEvent;)Z
      //   1095: pop
      //   1096: iload #12
      //   1098: istore #13
      //   1100: goto -> 949
      //   1103: aload_0
      //   1104: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   1107: astore #16
      //   1109: aload_1
      //   1110: iconst_0
      //   1111: invokestatic getPointerId : (Landroid/view/MotionEvent;I)I
      //   1114: istore_3
      //   1115: aload #16
      //   1117: sipush #1000
      //   1120: aload_0
      //   1121: getfield mMaximumFlingVelocity : I
      //   1124: i2f
      //   1125: invokevirtual computeCurrentVelocity : (IF)V
      //   1128: aload #16
      //   1130: iload_3
      //   1131: invokestatic getYVelocity : (Landroid/view/VelocityTracker;I)F
      //   1134: fstore #6
      //   1136: aload #16
      //   1138: iload_3
      //   1139: invokestatic getXVelocity : (Landroid/view/VelocityTracker;I)F
      //   1142: fstore #5
      //   1144: fload #6
      //   1146: invokestatic abs : (F)F
      //   1149: aload_0
      //   1150: getfield mMinimumFlingVelocity : I
      //   1153: i2f
      //   1154: fcmpl
      //   1155: ifgt -> 1176
      //   1158: iload #11
      //   1160: istore #13
      //   1162: fload #5
      //   1164: invokestatic abs : (F)F
      //   1167: aload_0
      //   1168: getfield mMinimumFlingVelocity : I
      //   1171: i2f
      //   1172: fcmpl
      //   1173: ifle -> 949
      //   1176: aload_0
      //   1177: getfield mListener : Landroid/view/GestureDetector$OnGestureListener;
      //   1180: aload_0
      //   1181: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   1184: aload_1
      //   1185: fload #5
      //   1187: fload #6
      //   1189: invokeinterface onFling : (Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
      //   1194: istore #13
      //   1196: goto -> 949
      //   1199: aload_0
      //   1200: invokespecial cancel : ()V
      //   1203: iload #12
      //   1205: istore #13
      //   1207: goto -> 212
    }
    
    public void setIsLongpressEnabled(boolean param1Boolean) {
      this.mIsLongpressEnabled = param1Boolean;
    }
    
    public void setOnDoubleTapListener(GestureDetector.OnDoubleTapListener param1OnDoubleTapListener) {
      this.mDoubleTapListener = param1OnDoubleTapListener;
    }
    
    private class GestureHandler extends Handler {
      GestureHandler() {}
      
      GestureHandler(Handler param2Handler) {
        super(param2Handler.getLooper());
      }
      
      public void handleMessage(Message param2Message) {
        switch (param2Message.what) {
          default:
            throw new RuntimeException("Unknown message " + param2Message);
          case 1:
            GestureDetectorCompat.GestureDetectorCompatImplBase.this.mListener.onShowPress(GestureDetectorCompat.GestureDetectorCompatImplBase.this.mCurrentDownEvent);
            return;
          case 2:
            GestureDetectorCompat.GestureDetectorCompatImplBase.this.dispatchLongPress();
            return;
          case 3:
            break;
        } 
        if (GestureDetectorCompat.GestureDetectorCompatImplBase.this.mDoubleTapListener != null) {
          if (!GestureDetectorCompat.GestureDetectorCompatImplBase.this.mStillDown) {
            GestureDetectorCompat.GestureDetectorCompatImplBase.this.mDoubleTapListener.onSingleTapConfirmed(GestureDetectorCompat.GestureDetectorCompatImplBase.this.mCurrentDownEvent);
            return;
          } 
          GestureDetectorCompat.GestureDetectorCompatImplBase.access$502(GestureDetectorCompat.GestureDetectorCompatImplBase.this, true);
        } 
      }
    }
  }
  
  private class GestureHandler extends Handler {
    GestureHandler() {}
    
    GestureHandler(Handler param1Handler) {
      super(param1Handler.getLooper());
    }
    
    public void handleMessage(Message param1Message) {
      switch (param1Message.what) {
        default:
          throw new RuntimeException("Unknown message " + param1Message);
        case 1:
          this.this$0.mListener.onShowPress(this.this$0.mCurrentDownEvent);
          return;
        case 2:
          this.this$0.dispatchLongPress();
          return;
        case 3:
          break;
      } 
      if (this.this$0.mDoubleTapListener != null) {
        if (!this.this$0.mStillDown) {
          this.this$0.mDoubleTapListener.onSingleTapConfirmed(this.this$0.mCurrentDownEvent);
          return;
        } 
        GestureDetectorCompat.GestureDetectorCompatImplBase.access$502(this.this$0, true);
      } 
    }
  }
  
  static class GestureDetectorCompatImplJellybeanMr2 implements GestureDetectorCompatImpl {
    private final GestureDetector mDetector;
    
    public GestureDetectorCompatImplJellybeanMr2(Context param1Context, GestureDetector.OnGestureListener param1OnGestureListener, Handler param1Handler) {
      this.mDetector = new GestureDetector(param1Context, param1OnGestureListener, param1Handler);
    }
    
    public boolean isLongpressEnabled() {
      return this.mDetector.isLongpressEnabled();
    }
    
    public boolean onTouchEvent(MotionEvent param1MotionEvent) {
      return this.mDetector.onTouchEvent(param1MotionEvent);
    }
    
    public void setIsLongpressEnabled(boolean param1Boolean) {
      this.mDetector.setIsLongpressEnabled(param1Boolean);
    }
    
    public void setOnDoubleTapListener(GestureDetector.OnDoubleTapListener param1OnDoubleTapListener) {
      this.mDetector.setOnDoubleTapListener(param1OnDoubleTapListener);
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeCMCC-dex2jar.jar!/android/support/v4/view/GestureDetectorCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */