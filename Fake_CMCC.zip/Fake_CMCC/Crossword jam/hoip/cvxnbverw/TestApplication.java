package hgfhh.hoip.cvxnbverw;

import android.app.Application;

public class TestApplication extends Application {
  private static int curIndex;
  
  public static int getCurIndex() {
    return curIndex;
  }
  
  public static void setCurIndex(int paramInt) {
    curIndex = paramInt;
  }
  
  public void onCreate() {
    super.onCreate();
  }
  
  public void onTerminate() {
    super.onTerminate();
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeCMCC-dex2jar.jar!/hgfhh/hoip/cvxnbverw/TestApplication.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */