package com.android.internal.telephony;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface ITelephony extends IInterface {
  void answerRingingCall() throws RemoteException;
  
  boolean endCall() throws RemoteException;
  
  public static abstract class Stub extends Binder implements ITelephony {
    private static final String DESCRIPTOR = "com.android.internal.telephony.ITelephony";
    
    static final int TRANSACTION_answerRingingCall = 2;
    
    static final int TRANSACTION_endCall = 1;
    
    public Stub() {
      attachInterface(this, "com.android.internal.telephony.ITelephony");
    }
    
    public static ITelephony asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.android.internal.telephony.ITelephony");
      return (iInterface != null && iInterface instanceof ITelephony) ? (ITelephony)iInterface : new Proxy(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      boolean bool;
      null = true;
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.android.internal.telephony.ITelephony");
          return SYNTHETIC_LOCAL_VARIABLE_5;
        case 1:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          bool = endCall();
          param1Parcel2.writeNoException();
          if (bool) {
            param1Int1 = 1;
          } else {
            param1Int1 = 0;
          } 
          param1Parcel2.writeInt(param1Int1);
          return SYNTHETIC_LOCAL_VARIABLE_5;
        case 2:
          break;
      } 
      param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
      answerRingingCall();
      param1Parcel2.writeNoException();
      return SYNTHETIC_LOCAL_VARIABLE_5;
    }
    
    private static class Proxy implements ITelephony {
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public void answerRingingCall() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(2, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public boolean endCall() throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i == 0)
            bool = false; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getInterfaceDescriptor() {
        return "com.android.internal.telephony.ITelephony";
      }
    }
  }
  
  private static class Proxy implements ITelephony {
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public void answerRingingCall() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public boolean endCall() throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i == 0)
          bool = false; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getInterfaceDescriptor() {
      return "com.android.internal.telephony.ITelephony";
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeBank-dex2jar.jar!/com/android/internal/telephony/ITelephony.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */