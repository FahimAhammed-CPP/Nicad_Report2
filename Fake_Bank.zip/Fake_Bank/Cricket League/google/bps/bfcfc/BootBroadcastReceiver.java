package com.google.bps.bfcfc;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootBroadcastReceiver extends BroadcastReceiver {
  static final String action_boot = "android.intent.action.BOOT_COMPLETED";
  
  static final String action_unlock = "android.intent.action.USER_PRESENT";
  
  private static String _1004937(String paramString) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: bipush #19
    //   4: newarray byte
    //   6: astore_2
    //   7: aload_2
    //   8: dup
    //   9: iconst_0
    //   10: ldc 65
    //   12: bastore
    //   13: dup
    //   14: iconst_1
    //   15: ldc 78
    //   17: bastore
    //   18: dup
    //   19: iconst_2
    //   20: ldc 68
    //   22: bastore
    //   23: dup
    //   24: iconst_3
    //   25: ldc 82
    //   27: bastore
    //   28: dup
    //   29: iconst_4
    //   30: ldc 79
    //   32: bastore
    //   33: dup
    //   34: iconst_5
    //   35: ldc 73
    //   37: bastore
    //   38: dup
    //   39: bipush #6
    //   41: ldc 68
    //   43: bastore
    //   44: dup
    //   45: bipush #7
    //   47: ldc 14
    //   49: bastore
    //   50: dup
    //   51: bipush #8
    //   53: ldc 85
    //   55: bastore
    //   56: dup
    //   57: bipush #9
    //   59: ldc 84
    //   61: bastore
    //   62: dup
    //   63: bipush #10
    //   65: ldc 73
    //   67: bastore
    //   68: dup
    //   69: bipush #11
    //   71: ldc 76
    //   73: bastore
    //   74: dup
    //   75: bipush #12
    //   77: ldc 14
    //   79: bastore
    //   80: dup
    //   81: bipush #13
    //   83: ldc 98
    //   85: bastore
    //   86: dup
    //   87: bipush #14
    //   89: ldc 65
    //   91: bastore
    //   92: dup
    //   93: bipush #15
    //   95: ldc 83
    //   97: bastore
    //   98: dup
    //   99: bipush #16
    //   101: ldc 69
    //   103: bastore
    //   104: dup
    //   105: bipush #17
    //   107: ldc 22
    //   109: bastore
    //   110: dup
    //   111: bipush #18
    //   113: ldc 20
    //   115: bastore
    //   116: pop
    //   117: aload_0
    //   118: iconst_0
    //   119: iconst_2
    //   120: invokevirtual substring : (II)Ljava/lang/String;
    //   123: astore_3
    //   124: new java/lang/StringBuilder
    //   127: dup
    //   128: aload_0
    //   129: aload_0
    //   130: invokevirtual length : ()I
    //   133: iconst_2
    //   134: isub
    //   135: invokevirtual substring : (I)Ljava/lang/String;
    //   138: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   141: invokespecial <init> : (Ljava/lang/String;)V
    //   144: aload_0
    //   145: iconst_2
    //   146: aload_0
    //   147: invokevirtual length : ()I
    //   150: iconst_2
    //   151: isub
    //   152: invokevirtual substring : (II)Ljava/lang/String;
    //   155: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   158: aload_3
    //   159: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   162: invokevirtual toString : ()Ljava/lang/String;
    //   165: astore_0
    //   166: iconst_0
    //   167: istore #4
    //   169: iload #4
    //   171: bipush #19
    //   173: if_icmplt -> 583
    //   176: new java/lang/String
    //   179: dup
    //   180: aload_2
    //   181: invokespecial <init> : ([B)V
    //   184: astore_2
    //   185: new java/lang/StringBuilder
    //   188: dup
    //   189: aload_2
    //   190: iconst_2
    //   191: iconst_3
    //   192: invokevirtual substring : (II)Ljava/lang/String;
    //   195: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   198: invokespecial <init> : (Ljava/lang/String;)V
    //   201: aload_2
    //   202: bipush #16
    //   204: bipush #17
    //   206: invokevirtual substring : (II)Ljava/lang/String;
    //   209: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   212: invokevirtual toString : ()Ljava/lang/String;
    //   215: astore_3
    //   216: new java/lang/StringBuilder
    //   219: dup
    //   220: new java/lang/StringBuilder
    //   223: dup
    //   224: new java/lang/StringBuilder
    //   227: dup
    //   228: aload_3
    //   229: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   232: invokespecial <init> : (Ljava/lang/String;)V
    //   235: ldc 'c'
    //   237: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   240: invokevirtual toString : ()Ljava/lang/String;
    //   243: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   246: invokespecial <init> : (Ljava/lang/String;)V
    //   249: aload_2
    //   250: iconst_4
    //   251: iconst_5
    //   252: invokevirtual substring : (II)Ljava/lang/String;
    //   255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   258: invokevirtual toString : ()Ljava/lang/String;
    //   261: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   264: invokespecial <init> : (Ljava/lang/String;)V
    //   267: aload_3
    //   268: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   271: invokevirtual toString : ()Ljava/lang/String;
    //   274: astore_3
    //   275: aload_2
    //   276: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   279: astore_2
    //   280: aload_2
    //   281: aload_3
    //   282: iconst_2
    //   283: anewarray java/lang/Class
    //   286: dup
    //   287: iconst_0
    //   288: ldc java/lang/String
    //   290: aastore
    //   291: dup
    //   292: iconst_1
    //   293: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   296: aastore
    //   297: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   300: aload_2
    //   301: iconst_2
    //   302: anewarray java/lang/Object
    //   305: dup
    //   306: iconst_0
    //   307: aload_0
    //   308: aastore
    //   309: dup
    //   310: iconst_1
    //   311: iconst_0
    //   312: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   315: aastore
    //   316: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   319: checkcast [B
    //   322: astore_0
    //   323: aload_0
    //   324: arraylength
    //   325: istore #5
    //   327: iload #5
    //   329: iconst_1
    //   330: isub
    //   331: aload_0
    //   332: iload #5
    //   334: iconst_1
    //   335: isub
    //   336: baload
    //   337: i2c
    //   338: invokestatic valueOf : (C)Ljava/lang/String;
    //   341: invokestatic parseInt : (Ljava/lang/String;)I
    //   344: isub
    //   345: istore #6
    //   347: aload_0
    //   348: iload #6
    //   350: iconst_1
    //   351: isub
    //   352: baload
    //   353: iconst_1
    //   354: if_icmpne -> 652
    //   357: iconst_1
    //   358: istore #4
    //   360: iinc #6, -1
    //   363: aload_0
    //   364: iload #6
    //   366: iconst_2
    //   367: isub
    //   368: baload
    //   369: i2c
    //   370: istore #7
    //   372: aload_0
    //   373: iload #6
    //   375: iconst_1
    //   376: isub
    //   377: baload
    //   378: i2c
    //   379: istore #8
    //   381: new java/lang/StringBuilder
    //   384: dup
    //   385: iload #7
    //   387: invokestatic valueOf : (C)Ljava/lang/String;
    //   390: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   393: invokespecial <init> : (Ljava/lang/String;)V
    //   396: iload #8
    //   398: invokestatic valueOf : (C)Ljava/lang/String;
    //   401: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   404: invokevirtual toString : ()Ljava/lang/String;
    //   407: bipush #16
    //   409: invokestatic parseInt : (Ljava/lang/String;I)I
    //   412: i2b
    //   413: bipush #37
    //   415: iadd
    //   416: i2b
    //   417: istore #9
    //   419: iload #6
    //   421: iconst_2
    //   422: isub
    //   423: istore #10
    //   425: iconst_0
    //   426: istore #6
    //   428: iload #6
    //   430: iload #10
    //   432: if_icmplt -> 658
    //   435: iload #10
    //   437: istore #6
    //   439: iload #6
    //   441: iload #5
    //   443: if_icmplt -> 677
    //   446: iload #4
    //   448: iconst_1
    //   449: if_icmpne -> 559
    //   452: new java/lang/Exception
    //   455: dup
    //   456: invokespecial <init> : ()V
    //   459: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
    //   462: iconst_1
    //   463: aaload
    //   464: astore_3
    //   465: aload_3
    //   466: invokevirtual getClassName : ()Ljava/lang/String;
    //   469: astore_2
    //   470: aload_2
    //   471: ldc '.'
    //   473: invokevirtual lastIndexOf : (Ljava/lang/String;)I
    //   476: istore #4
    //   478: aload_2
    //   479: astore_1
    //   480: iload #4
    //   482: iconst_m1
    //   483: if_icmpeq -> 495
    //   486: aload_2
    //   487: iload #4
    //   489: iconst_1
    //   490: iadd
    //   491: invokevirtual substring : (I)Ljava/lang/String;
    //   494: astore_1
    //   495: aload_3
    //   496: invokevirtual getMethodName : ()Ljava/lang/String;
    //   499: astore_2
    //   500: new java/lang/StringBuilder
    //   503: dup
    //   504: aload_1
    //   505: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   508: invokespecial <init> : (Ljava/lang/String;)V
    //   511: aload_2
    //   512: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   515: invokevirtual toString : ()Ljava/lang/String;
    //   518: astore_2
    //   519: aload_2
    //   520: astore_1
    //   521: aload_2
    //   522: invokevirtual length : ()I
    //   525: sipush #256
    //   528: if_icmple -> 540
    //   531: aload_2
    //   532: iconst_0
    //   533: sipush #256
    //   536: invokevirtual substring : (II)Ljava/lang/String;
    //   539: astore_1
    //   540: aload_1
    //   541: invokevirtual length : ()I
    //   544: istore #4
    //   546: iconst_0
    //   547: istore #6
    //   549: iinc #4, -1
    //   552: iload #6
    //   554: iload #10
    //   556: if_icmplt -> 689
    //   559: iload #10
    //   561: newarray byte
    //   563: astore_1
    //   564: iconst_0
    //   565: istore #4
    //   567: iload #4
    //   569: iload #10
    //   571: if_icmplt -> 740
    //   574: new java/lang/String
    //   577: dup
    //   578: aload_1
    //   579: invokespecial <init> : ([B)V
    //   582: areturn
    //   583: aload_2
    //   584: iload #4
    //   586: aload_2
    //   587: iload #4
    //   589: baload
    //   590: bipush #32
    //   592: ixor
    //   593: i2b
    //   594: i2b
    //   595: bastore
    //   596: iinc #4, 1
    //   599: goto -> 169
    //   602: astore_0
    //   603: aload_0
    //   604: invokevirtual printStackTrace : ()V
    //   607: aload_1
    //   608: astore_0
    //   609: goto -> 323
    //   612: astore_0
    //   613: aload_0
    //   614: invokevirtual printStackTrace : ()V
    //   617: aload_1
    //   618: astore_0
    //   619: goto -> 323
    //   622: astore_0
    //   623: aload_0
    //   624: invokevirtual printStackTrace : ()V
    //   627: aload_1
    //   628: astore_0
    //   629: goto -> 323
    //   632: astore_0
    //   633: aload_0
    //   634: invokevirtual printStackTrace : ()V
    //   637: aload_1
    //   638: astore_0
    //   639: goto -> 323
    //   642: astore_0
    //   643: aload_0
    //   644: invokevirtual printStackTrace : ()V
    //   647: aload_1
    //   648: astore_0
    //   649: goto -> 323
    //   652: iconst_0
    //   653: istore #4
    //   655: goto -> 360
    //   658: aload_0
    //   659: iload #6
    //   661: aload_0
    //   662: iload #6
    //   664: baload
    //   665: iload #9
    //   667: ixor
    //   668: i2b
    //   669: i2b
    //   670: bastore
    //   671: iinc #6, 1
    //   674: goto -> 428
    //   677: aload_0
    //   678: iload #6
    //   680: iconst_0
    //   681: i2b
    //   682: bastore
    //   683: iinc #6, 1
    //   686: goto -> 439
    //   689: aload_0
    //   690: iload #6
    //   692: baload
    //   693: istore #9
    //   695: iload #4
    //   697: iconst_1
    //   698: isub
    //   699: istore #5
    //   701: aload_0
    //   702: iload #6
    //   704: iload #9
    //   706: aload_1
    //   707: iload #4
    //   709: invokevirtual charAt : (I)C
    //   712: i2b
    //   713: ixor
    //   714: i2b
    //   715: i2b
    //   716: bastore
    //   717: iload #5
    //   719: istore #4
    //   721: iload #5
    //   723: ifge -> 734
    //   726: aload_1
    //   727: invokevirtual length : ()I
    //   730: iconst_1
    //   731: isub
    //   732: istore #4
    //   734: iinc #6, 1
    //   737: goto -> 552
    //   740: aload_1
    //   741: iload #4
    //   743: aload_0
    //   744: iload #4
    //   746: baload
    //   747: i2b
    //   748: bastore
    //   749: iinc #4, 1
    //   752: goto -> 567
    // Exception table:
    //   from	to	target	type
    //   275	323	602	java/lang/ClassNotFoundException
    //   275	323	612	java/lang/IllegalAccessException
    //   275	323	622	java/lang/NoSuchMethodException
    //   275	323	632	java/lang/IllegalArgumentException
    //   275	323	642	java/lang/reflect/InvocationTargetException
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    throw new VerifyError("bad dex opcode");
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeBank-dex2jar.jar!/com/google/bps/bfcfc/BootBroadcastReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */