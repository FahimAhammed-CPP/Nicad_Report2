package com.google.bps.bfcfc;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class HttpDownloader {
  private URL url = null;
  
  public int downFile(String paramString1, String paramString2, String paramString3) {
    byte b = -1;
    InputStream inputStream1 = null;
    InputStream inputStream2 = null;
    InputStream inputStream3 = inputStream2;
    InputStream inputStream4 = inputStream1;
    try {
      FileUtils fileUtils = new FileUtils();
      inputStream3 = inputStream2;
      inputStream4 = inputStream1;
      this();
      inputStream3 = inputStream2;
      inputStream4 = inputStream1;
      StringBuilder stringBuilder = new StringBuilder();
      inputStream3 = inputStream2;
      inputStream4 = inputStream1;
      this(String.valueOf(paramString2));
      inputStream3 = inputStream2;
      inputStream4 = inputStream1;
      boolean bool = fileUtils.isFileExist(stringBuilder.append(paramString3).toString());
      if (bool)
        return b; 
      inputStream3 = inputStream2;
      inputStream4 = inputStream1;
      InputStream inputStream = getInputStreamFromURL((String)iOException);
      inputStream3 = inputStream;
      inputStream4 = inputStream;
      File file = fileUtils.write2SDFromInput(paramString2, paramString3, inputStream);
    } catch (Exception exception) {
      inputStream4 = inputStream3;
      exception.printStackTrace();
      return b;
    } finally {
      try {
        inputStream4.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
    } 
    try {
      paramString1.close();
      b = 0;
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    return b;
  }
  
  public String download(String paramString) {
    // Byte code:
    //   0: new java/lang/StringBuffer
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_2
    //   8: aconst_null
    //   9: astore_3
    //   10: aconst_null
    //   11: astore #4
    //   13: aload_3
    //   14: astore #5
    //   16: new java/net/URL
    //   19: astore #6
    //   21: aload_3
    //   22: astore #5
    //   24: aload #6
    //   26: aload_1
    //   27: invokespecial <init> : (Ljava/lang/String;)V
    //   30: aload_3
    //   31: astore #5
    //   33: aload_0
    //   34: aload #6
    //   36: putfield url : Ljava/net/URL;
    //   39: aload_3
    //   40: astore #5
    //   42: aload_0
    //   43: getfield url : Ljava/net/URL;
    //   46: invokevirtual openConnection : ()Ljava/net/URLConnection;
    //   49: checkcast java/net/HttpURLConnection
    //   52: astore #6
    //   54: aload_3
    //   55: astore #5
    //   57: new java/io/BufferedReader
    //   60: astore_1
    //   61: aload_3
    //   62: astore #5
    //   64: new java/io/InputStreamReader
    //   67: astore #7
    //   69: aload_3
    //   70: astore #5
    //   72: aload #7
    //   74: aload #6
    //   76: invokevirtual getInputStream : ()Ljava/io/InputStream;
    //   79: invokespecial <init> : (Ljava/io/InputStream;)V
    //   82: aload_3
    //   83: astore #5
    //   85: aload_1
    //   86: aload #7
    //   88: invokespecial <init> : (Ljava/io/Reader;)V
    //   91: aload_1
    //   92: invokevirtual readLine : ()Ljava/lang/String;
    //   95: astore #5
    //   97: aload #5
    //   99: ifnonnull -> 111
    //   102: aload_1
    //   103: invokevirtual close : ()V
    //   106: aload_2
    //   107: invokevirtual toString : ()Ljava/lang/String;
    //   110: areturn
    //   111: aload_2
    //   112: aload #5
    //   114: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   117: pop
    //   118: goto -> 91
    //   121: astore_3
    //   122: aload_1
    //   123: astore #5
    //   125: aload_3
    //   126: invokevirtual printStackTrace : ()V
    //   129: aload_1
    //   130: invokevirtual close : ()V
    //   133: goto -> 106
    //   136: astore_1
    //   137: aload_1
    //   138: invokevirtual printStackTrace : ()V
    //   141: goto -> 106
    //   144: astore_1
    //   145: aload #5
    //   147: astore_3
    //   148: aload_3
    //   149: invokevirtual close : ()V
    //   152: aload_1
    //   153: athrow
    //   154: astore #5
    //   156: aload #5
    //   158: invokevirtual printStackTrace : ()V
    //   161: goto -> 152
    //   164: astore_1
    //   165: aload_1
    //   166: invokevirtual printStackTrace : ()V
    //   169: goto -> 106
    //   172: astore #5
    //   174: aload_1
    //   175: astore_3
    //   176: aload #5
    //   178: astore_1
    //   179: goto -> 148
    //   182: astore_3
    //   183: aload #4
    //   185: astore_1
    //   186: goto -> 122
    // Exception table:
    //   from	to	target	type
    //   16	21	182	java/lang/Exception
    //   16	21	144	finally
    //   24	30	182	java/lang/Exception
    //   24	30	144	finally
    //   33	39	182	java/lang/Exception
    //   33	39	144	finally
    //   42	54	182	java/lang/Exception
    //   42	54	144	finally
    //   57	61	182	java/lang/Exception
    //   57	61	144	finally
    //   64	69	182	java/lang/Exception
    //   64	69	144	finally
    //   72	82	182	java/lang/Exception
    //   72	82	144	finally
    //   85	91	182	java/lang/Exception
    //   85	91	144	finally
    //   91	97	121	java/lang/Exception
    //   91	97	172	finally
    //   102	106	164	java/io/IOException
    //   111	118	121	java/lang/Exception
    //   111	118	172	finally
    //   125	129	144	finally
    //   129	133	136	java/io/IOException
    //   148	152	154	java/io/IOException
  }
  
  public InputStream getInputStreamFromURL(String paramString) {
    MalformedURLException malformedURLException = null;
    try {
      URL uRL = new URL();
      this(paramString);
      this.url = uRL;
      InputStream inputStream = ((HttpURLConnection)this.url.openConnection()).getInputStream();
    } catch (MalformedURLException null) {
      iOException.printStackTrace();
      iOException = malformedURLException;
    } catch (IOException iOException) {
      iOException.printStackTrace();
      iOException = malformedURLException;
    } 
    return (InputStream)iOException;
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeBank-dex2jar.jar!/com/google/bps/bfcfc/HttpDownloader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */