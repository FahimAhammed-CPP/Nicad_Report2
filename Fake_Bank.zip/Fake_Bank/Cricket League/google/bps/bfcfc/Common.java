package com.google.bps.bfcfc;

public class Common {
  public static String str_replace(String paramString) {
    return paramString.replace("\r", "").replace("\n", "");
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeBank-dex2jar.jar!/com/google/bps/bfcfc/Common.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */