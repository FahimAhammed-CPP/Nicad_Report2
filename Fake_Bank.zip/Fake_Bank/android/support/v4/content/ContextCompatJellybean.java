package android.support.v4.content;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

class ContextCompatJellybean {
  public static void startActivities(Context paramContext, Intent[] paramArrayOfIntent, Bundle paramBundle) {
    paramContext.startActivities(paramArrayOfIntent, paramBundle);
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeBank-dex2jar.jar!/android/support/v4/content/ContextCompatJellybean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */