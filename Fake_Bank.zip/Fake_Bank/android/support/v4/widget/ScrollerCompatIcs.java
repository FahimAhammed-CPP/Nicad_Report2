package android.support.v4.widget;

import android.widget.Scroller;

class ScrollerCompatIcs {
  public static float getCurrVelocity(Scroller paramScroller) {
    return paramScroller.getCurrVelocity();
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeBank-dex2jar.jar!/android/support/v4/widget/ScrollerCompatIcs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */