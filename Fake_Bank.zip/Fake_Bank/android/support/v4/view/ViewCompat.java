package android.support.v4.view;

import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.v4.view.accessibility.AccessibilityNodeProviderCompat;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;

public class ViewCompat {
  private static final long FAKE_FRAME_TIME = 10L;
  
  static final ViewCompatImpl IMPL = new BaseViewCompatImpl();
  
  public static final int IMPORTANT_FOR_ACCESSIBILITY_AUTO = 0;
  
  public static final int IMPORTANT_FOR_ACCESSIBILITY_NO = 2;
  
  public static final int IMPORTANT_FOR_ACCESSIBILITY_YES = 1;
  
  public static final int LAYER_TYPE_HARDWARE = 2;
  
  public static final int LAYER_TYPE_NONE = 0;
  
  public static final int LAYER_TYPE_SOFTWARE = 1;
  
  public static final int OVER_SCROLL_ALWAYS = 0;
  
  public static final int OVER_SCROLL_IF_CONTENT_SCROLLS = 1;
  
  public static final int OVER_SCROLL_NEVER = 2;
  
  public static boolean canScrollHorizontally(View paramView, int paramInt) {
    return IMPL.canScrollHorizontally(paramView, paramInt);
  }
  
  public static boolean canScrollVertically(View paramView, int paramInt) {
    return IMPL.canScrollVertically(paramView, paramInt);
  }
  
  public static AccessibilityNodeProviderCompat getAccessibilityNodeProvider(View paramView) {
    return IMPL.getAccessibilityNodeProvider(paramView);
  }
  
  public static int getImportantForAccessibility(View paramView) {
    return IMPL.getImportantForAccessibility(paramView);
  }
  
  public static int getLabelFor(View paramView) {
    return IMPL.getLabelFor(paramView);
  }
  
  public static int getLayerType(View paramView) {
    return IMPL.getLayerType(paramView);
  }
  
  public static int getOverScrollMode(View paramView) {
    return IMPL.getOverScrollMode(paramView);
  }
  
  public static boolean hasTransientState(View paramView) {
    return IMPL.hasTransientState(paramView);
  }
  
  public static void onInitializeAccessibilityEvent(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    IMPL.onInitializeAccessibilityEvent(paramView, paramAccessibilityEvent);
  }
  
  public static void onInitializeAccessibilityNodeInfo(View paramView, AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat) {
    IMPL.onInitializeAccessibilityNodeInfo(paramView, paramAccessibilityNodeInfoCompat);
  }
  
  public static void onPopulateAccessibilityEvent(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    IMPL.onPopulateAccessibilityEvent(paramView, paramAccessibilityEvent);
  }
  
  public static boolean performAccessibilityAction(View paramView, int paramInt, Bundle paramBundle) {
    return IMPL.performAccessibilityAction(paramView, paramInt, paramBundle);
  }
  
  public static void postInvalidateOnAnimation(View paramView) {
    IMPL.postInvalidateOnAnimation(paramView);
  }
  
  public static void postInvalidateOnAnimation(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    IMPL.postInvalidateOnAnimation(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static void postOnAnimation(View paramView, Runnable paramRunnable) {
    IMPL.postOnAnimation(paramView, paramRunnable);
  }
  
  public static void postOnAnimationDelayed(View paramView, Runnable paramRunnable, long paramLong) {
    IMPL.postOnAnimationDelayed(paramView, paramRunnable, paramLong);
  }
  
  public static void setAccessibilityDelegate(View paramView, AccessibilityDelegateCompat paramAccessibilityDelegateCompat) {
    IMPL.setAccessibilityDelegate(paramView, paramAccessibilityDelegateCompat);
  }
  
  public static void setHasTransientState(View paramView, boolean paramBoolean) {
    IMPL.setHasTransientState(paramView, paramBoolean);
  }
  
  public static void setImportantForAccessibility(View paramView, int paramInt) {
    IMPL.setImportantForAccessibility(paramView, paramInt);
  }
  
  public static void setLabelFor(View paramView, int paramInt) {
    IMPL.setLabelFor(paramView, paramInt);
  }
  
  public static void setLayerType(View paramView, int paramInt, Paint paramPaint) {
    IMPL.setLayerType(paramView, paramInt, paramPaint);
  }
  
  public static void setOverScrollMode(View paramView, int paramInt) {
    IMPL.setOverScrollMode(paramView, paramInt);
  }
  
  static {
    int i = Build.VERSION.SDK_INT;
    if (i >= 17) {
      IMPL = new JbMr1ViewCompatImpl();
      return;
    } 
    if (i >= 16) {
      IMPL = new JBViewCompatImpl();
      return;
    } 
    if (i >= 14) {
      IMPL = new ICSViewCompatImpl();
      return;
    } 
    if (i >= 11) {
      IMPL = new HCViewCompatImpl();
      return;
    } 
    if (i >= 9) {
      IMPL = new GBViewCompatImpl();
      return;
    } 
  }
  
  static class BaseViewCompatImpl implements ViewCompatImpl {
    public boolean canScrollHorizontally(View param1View, int param1Int) {
      return false;
    }
    
    public boolean canScrollVertically(View param1View, int param1Int) {
      return false;
    }
    
    public AccessibilityNodeProviderCompat getAccessibilityNodeProvider(View param1View) {
      return null;
    }
    
    long getFrameTime() {
      return 10L;
    }
    
    public int getImportantForAccessibility(View param1View) {
      return 0;
    }
    
    public int getLabelFor(View param1View) {
      return 0;
    }
    
    public int getLayerType(View param1View) {
      return 0;
    }
    
    public int getOverScrollMode(View param1View) {
      return 2;
    }
    
    public boolean hasTransientState(View param1View) {
      return false;
    }
    
    public void onInitializeAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {}
    
    public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat) {}
    
    public void onPopulateAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {}
    
    public boolean performAccessibilityAction(View param1View, int param1Int, Bundle param1Bundle) {
      return false;
    }
    
    public void postInvalidateOnAnimation(View param1View) {
      param1View.postInvalidateDelayed(getFrameTime());
    }
    
    public void postInvalidateOnAnimation(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      param1View.postInvalidateDelayed(getFrameTime(), param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    public void postOnAnimation(View param1View, Runnable param1Runnable) {
      param1View.postDelayed(param1Runnable, getFrameTime());
    }
    
    public void postOnAnimationDelayed(View param1View, Runnable param1Runnable, long param1Long) {
      param1View.postDelayed(param1Runnable, getFrameTime() + param1Long);
    }
    
    public void setAccessibilityDelegate(View param1View, AccessibilityDelegateCompat param1AccessibilityDelegateCompat) {}
    
    public void setHasTransientState(View param1View, boolean param1Boolean) {}
    
    public void setImportantForAccessibility(View param1View, int param1Int) {}
    
    public void setLabelFor(View param1View, int param1Int) {}
    
    public void setLayerType(View param1View, int param1Int, Paint param1Paint) {}
    
    public void setOverScrollMode(View param1View, int param1Int) {}
  }
  
  static class GBViewCompatImpl extends BaseViewCompatImpl {
    public int getOverScrollMode(View param1View) {
      return ViewCompatGingerbread.getOverScrollMode(param1View);
    }
    
    public void setOverScrollMode(View param1View, int param1Int) {
      ViewCompatGingerbread.setOverScrollMode(param1View, param1Int);
    }
  }
  
  static class HCViewCompatImpl extends GBViewCompatImpl {
    long getFrameTime() {
      return ViewCompatHC.getFrameTime();
    }
    
    public int getLayerType(View param1View) {
      return ViewCompatHC.getLayerType(param1View);
    }
    
    public void setLayerType(View param1View, int param1Int, Paint param1Paint) {
      ViewCompatHC.setLayerType(param1View, param1Int, param1Paint);
    }
  }
  
  static class ICSViewCompatImpl extends HCViewCompatImpl {
    public boolean canScrollHorizontally(View param1View, int param1Int) {
      return ViewCompatICS.canScrollHorizontally(param1View, param1Int);
    }
    
    public boolean canScrollVertically(View param1View, int param1Int) {
      return ViewCompatICS.canScrollVertically(param1View, param1Int);
    }
    
    public void onInitializeAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      ViewCompatICS.onInitializeAccessibilityEvent(param1View, param1AccessibilityEvent);
    }
    
    public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat) {
      ViewCompatICS.onInitializeAccessibilityNodeInfo(param1View, param1AccessibilityNodeInfoCompat.getInfo());
    }
    
    public void onPopulateAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      ViewCompatICS.onPopulateAccessibilityEvent(param1View, param1AccessibilityEvent);
    }
    
    public void setAccessibilityDelegate(View param1View, AccessibilityDelegateCompat param1AccessibilityDelegateCompat) {
      ViewCompatICS.setAccessibilityDelegate(param1View, param1AccessibilityDelegateCompat.getBridge());
    }
  }
  
  static class JBViewCompatImpl extends ICSViewCompatImpl {
    public AccessibilityNodeProviderCompat getAccessibilityNodeProvider(View param1View) {
      null = ViewCompatJB.getAccessibilityNodeProvider(param1View);
      return (null != null) ? new AccessibilityNodeProviderCompat(null) : null;
    }
    
    public int getImportantForAccessibility(View param1View) {
      return ViewCompatJB.getImportantForAccessibility(param1View);
    }
    
    public boolean hasTransientState(View param1View) {
      return ViewCompatJB.hasTransientState(param1View);
    }
    
    public boolean performAccessibilityAction(View param1View, int param1Int, Bundle param1Bundle) {
      return ViewCompatJB.performAccessibilityAction(param1View, param1Int, param1Bundle);
    }
    
    public void postInvalidateOnAnimation(View param1View) {
      ViewCompatJB.postInvalidateOnAnimation(param1View);
    }
    
    public void postInvalidateOnAnimation(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      ViewCompatJB.postInvalidateOnAnimation(param1View, param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    public void postOnAnimation(View param1View, Runnable param1Runnable) {
      ViewCompatJB.postOnAnimation(param1View, param1Runnable);
    }
    
    public void postOnAnimationDelayed(View param1View, Runnable param1Runnable, long param1Long) {
      ViewCompatJB.postOnAnimationDelayed(param1View, param1Runnable, param1Long);
    }
    
    public void setHasTransientState(View param1View, boolean param1Boolean) {
      ViewCompatJB.setHasTransientState(param1View, param1Boolean);
    }
    
    public void setImportantForAccessibility(View param1View, int param1Int) {
      ViewCompatJB.setImportantForAccessibility(param1View, param1Int);
    }
  }
  
  static class JbMr1ViewCompatImpl extends JBViewCompatImpl {
    public int getLabelFor(View param1View) {
      return ViewCompatJellybeanMr1.getLabelFor(param1View);
    }
    
    public void setLabelFor(View param1View, int param1Int) {
      ViewCompatJellybeanMr1.setLabelFor(param1View, param1Int);
    }
  }
  
  static interface ViewCompatImpl {
    boolean canScrollHorizontally(View param1View, int param1Int);
    
    boolean canScrollVertically(View param1View, int param1Int);
    
    AccessibilityNodeProviderCompat getAccessibilityNodeProvider(View param1View);
    
    int getImportantForAccessibility(View param1View);
    
    int getLabelFor(View param1View);
    
    int getLayerType(View param1View);
    
    int getOverScrollMode(View param1View);
    
    boolean hasTransientState(View param1View);
    
    void onInitializeAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent);
    
    void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat);
    
    void onPopulateAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent);
    
    boolean performAccessibilityAction(View param1View, int param1Int, Bundle param1Bundle);
    
    void postInvalidateOnAnimation(View param1View);
    
    void postInvalidateOnAnimation(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4);
    
    void postOnAnimation(View param1View, Runnable param1Runnable);
    
    void postOnAnimationDelayed(View param1View, Runnable param1Runnable, long param1Long);
    
    void setAccessibilityDelegate(View param1View, AccessibilityDelegateCompat param1AccessibilityDelegateCompat);
    
    void setHasTransientState(View param1View, boolean param1Boolean);
    
    void setImportantForAccessibility(View param1View, int param1Int);
    
    void setLabelFor(View param1View, int param1Int);
    
    void setLayerType(View param1View, int param1Int, Paint param1Paint);
    
    void setOverScrollMode(View param1View, int param1Int);
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeBank-dex2jar.jar!/android/support/v4/view/ViewCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */