package android.support.v4.view;

import android.os.Build;
import android.view.MenuItem;
import android.view.View;

public class MenuItemCompat {
  static final MenuVersionImpl IMPL = new BaseMenuVersionImpl();
  
  public static final int SHOW_AS_ACTION_ALWAYS = 2;
  
  public static final int SHOW_AS_ACTION_COLLAPSE_ACTION_VIEW = 8;
  
  public static final int SHOW_AS_ACTION_IF_ROOM = 1;
  
  public static final int SHOW_AS_ACTION_NEVER = 0;
  
  public static final int SHOW_AS_ACTION_WITH_TEXT = 4;
  
  public static MenuItem setActionView(MenuItem paramMenuItem, View paramView) {
    return IMPL.setActionView(paramMenuItem, paramView);
  }
  
  public static boolean setShowAsAction(MenuItem paramMenuItem, int paramInt) {
    return IMPL.setShowAsAction(paramMenuItem, paramInt);
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 11) {
      IMPL = new HoneycombMenuVersionImpl();
      return;
    } 
  }
  
  static class BaseMenuVersionImpl implements MenuVersionImpl {
    public MenuItem setActionView(MenuItem param1MenuItem, View param1View) {
      return param1MenuItem;
    }
    
    public boolean setShowAsAction(MenuItem param1MenuItem, int param1Int) {
      return false;
    }
  }
  
  static class HoneycombMenuVersionImpl implements MenuVersionImpl {
    public MenuItem setActionView(MenuItem param1MenuItem, View param1View) {
      return MenuItemCompatHoneycomb.setActionView(param1MenuItem, param1View);
    }
    
    public boolean setShowAsAction(MenuItem param1MenuItem, int param1Int) {
      MenuItemCompatHoneycomb.setShowAsAction(param1MenuItem, param1Int);
      return true;
    }
  }
  
  static interface MenuVersionImpl {
    MenuItem setActionView(MenuItem param1MenuItem, View param1View);
    
    boolean setShowAsAction(MenuItem param1MenuItem, int param1Int);
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeBank-dex2jar.jar!/android/support/v4/view/MenuItemCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */