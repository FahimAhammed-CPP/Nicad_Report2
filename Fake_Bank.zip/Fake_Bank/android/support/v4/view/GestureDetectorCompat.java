package android.support.v4.view;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;

public class GestureDetectorCompat {
  private final GestureDetectorCompatImpl mImpl;
  
  public GestureDetectorCompat(Context paramContext, GestureDetector.OnGestureListener paramOnGestureListener) {
    this(paramContext, paramOnGestureListener, null);
  }
  
  public GestureDetectorCompat(Context paramContext, GestureDetector.OnGestureListener paramOnGestureListener, Handler paramHandler) {
    if (Build.VERSION.SDK_INT >= 17) {
      this.mImpl = new GestureDetectorCompatImplJellybeanMr1(paramContext, paramOnGestureListener, paramHandler);
      return;
    } 
    this.mImpl = new GestureDetectorCompatImplBase(paramContext, paramOnGestureListener, paramHandler);
  }
  
  public boolean isLongpressEnabled() {
    return this.mImpl.isLongpressEnabled();
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    return this.mImpl.onTouchEvent(paramMotionEvent);
  }
  
  public void setIsLongpressEnabled(boolean paramBoolean) {
    this.mImpl.setIsLongpressEnabled(paramBoolean);
  }
  
  public void setOnDoubleTapListener(GestureDetector.OnDoubleTapListener paramOnDoubleTapListener) {
    this.mImpl.setOnDoubleTapListener(paramOnDoubleTapListener);
  }
  
  static interface GestureDetectorCompatImpl {
    boolean isLongpressEnabled();
    
    boolean onTouchEvent(MotionEvent param1MotionEvent);
    
    void setIsLongpressEnabled(boolean param1Boolean);
    
    void setOnDoubleTapListener(GestureDetector.OnDoubleTapListener param1OnDoubleTapListener);
  }
  
  static class GestureDetectorCompatImplBase implements GestureDetectorCompatImpl {
    private static final int DOUBLE_TAP_TIMEOUT = ViewConfiguration.getDoubleTapTimeout();
    
    private static final int LONGPRESS_TIMEOUT = ViewConfiguration.getLongPressTimeout();
    
    private static final int LONG_PRESS = 2;
    
    private static final int SHOW_PRESS = 1;
    
    private static final int TAP = 3;
    
    private static final int TAP_TIMEOUT = ViewConfiguration.getTapTimeout();
    
    private boolean mAlwaysInBiggerTapRegion;
    
    private boolean mAlwaysInTapRegion;
    
    private MotionEvent mCurrentDownEvent;
    
    private GestureDetector.OnDoubleTapListener mDoubleTapListener;
    
    private int mDoubleTapSlopSquare;
    
    private float mDownFocusX;
    
    private float mDownFocusY;
    
    private final Handler mHandler;
    
    private boolean mInLongPress;
    
    private boolean mIsDoubleTapping;
    
    private boolean mIsLongpressEnabled;
    
    private float mLastFocusX;
    
    private float mLastFocusY;
    
    private final GestureDetector.OnGestureListener mListener;
    
    private int mMaximumFlingVelocity;
    
    private int mMinimumFlingVelocity;
    
    private MotionEvent mPreviousUpEvent;
    
    private boolean mStillDown;
    
    private int mTouchSlopSquare;
    
    private VelocityTracker mVelocityTracker;
    
    static {
    
    }
    
    public GestureDetectorCompatImplBase(Context param1Context, GestureDetector.OnGestureListener param1OnGestureListener, Handler param1Handler) {
      if (param1Handler != null) {
        this.mHandler = new GestureHandler(param1Handler);
      } else {
        this.mHandler = new GestureHandler();
      } 
      this.mListener = param1OnGestureListener;
      if (param1OnGestureListener instanceof GestureDetector.OnDoubleTapListener)
        setOnDoubleTapListener((GestureDetector.OnDoubleTapListener)param1OnGestureListener); 
      init(param1Context);
    }
    
    private void cancel() {
      this.mHandler.removeMessages(1);
      this.mHandler.removeMessages(2);
      this.mHandler.removeMessages(3);
      this.mVelocityTracker.recycle();
      this.mVelocityTracker = null;
      this.mIsDoubleTapping = false;
      this.mStillDown = false;
      this.mAlwaysInTapRegion = false;
      this.mAlwaysInBiggerTapRegion = false;
      if (this.mInLongPress)
        this.mInLongPress = false; 
    }
    
    private void cancelTaps() {
      this.mHandler.removeMessages(1);
      this.mHandler.removeMessages(2);
      this.mHandler.removeMessages(3);
      this.mIsDoubleTapping = false;
      this.mAlwaysInTapRegion = false;
      this.mAlwaysInBiggerTapRegion = false;
      if (this.mInLongPress)
        this.mInLongPress = false; 
    }
    
    private void dispatchLongPress() {
      this.mHandler.removeMessages(3);
      this.mInLongPress = true;
      this.mListener.onLongPress(this.mCurrentDownEvent);
    }
    
    private void init(Context param1Context) {
      if (param1Context == null)
        throw new IllegalArgumentException("Context must not be null"); 
      if (this.mListener == null)
        throw new IllegalArgumentException("OnGestureListener must not be null"); 
      this.mIsLongpressEnabled = true;
      ViewConfiguration viewConfiguration = ViewConfiguration.get(param1Context);
      int i = viewConfiguration.getScaledTouchSlop();
      int j = viewConfiguration.getScaledDoubleTapSlop();
      this.mMinimumFlingVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
      this.mMaximumFlingVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
      this.mTouchSlopSquare = i * i;
      this.mDoubleTapSlopSquare = j * j;
    }
    
    private boolean isConsideredDoubleTap(MotionEvent param1MotionEvent1, MotionEvent param1MotionEvent2, MotionEvent param1MotionEvent3) {
      boolean bool1 = false;
      if (!this.mAlwaysInBiggerTapRegion)
        return bool1; 
      boolean bool2 = bool1;
      if (param1MotionEvent3.getEventTime() - param1MotionEvent2.getEventTime() <= DOUBLE_TAP_TIMEOUT) {
        int i = (int)param1MotionEvent1.getX() - (int)param1MotionEvent3.getX();
        int j = (int)param1MotionEvent1.getY() - (int)param1MotionEvent3.getY();
        bool2 = bool1;
        if (i * i + j * j < this.mDoubleTapSlopSquare)
          bool2 = true; 
      } 
      return bool2;
    }
    
    public boolean isLongpressEnabled() {
      return this.mIsLongpressEnabled;
    }
    
    public boolean onTouchEvent(MotionEvent param1MotionEvent) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual getAction : ()I
      //   4: istore_2
      //   5: aload_0
      //   6: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   9: ifnonnull -> 19
      //   12: aload_0
      //   13: invokestatic obtain : ()Landroid/view/VelocityTracker;
      //   16: putfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   19: aload_0
      //   20: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   23: aload_1
      //   24: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
      //   27: iload_2
      //   28: sipush #255
      //   31: iand
      //   32: bipush #6
      //   34: if_icmpne -> 84
      //   37: iconst_1
      //   38: istore_3
      //   39: iload_3
      //   40: ifeq -> 89
      //   43: aload_1
      //   44: invokestatic getActionIndex : (Landroid/view/MotionEvent;)I
      //   47: istore #4
      //   49: fconst_0
      //   50: fstore #5
      //   52: fconst_0
      //   53: fstore #6
      //   55: aload_1
      //   56: invokestatic getPointerCount : (Landroid/view/MotionEvent;)I
      //   59: istore #7
      //   61: iconst_0
      //   62: istore #8
      //   64: iload #8
      //   66: iload #7
      //   68: if_icmpge -> 120
      //   71: iload #4
      //   73: iload #8
      //   75: if_icmpne -> 95
      //   78: iinc #8, 1
      //   81: goto -> 64
      //   84: iconst_0
      //   85: istore_3
      //   86: goto -> 39
      //   89: iconst_m1
      //   90: istore #4
      //   92: goto -> 49
      //   95: fload #5
      //   97: aload_1
      //   98: iload #8
      //   100: invokestatic getX : (Landroid/view/MotionEvent;I)F
      //   103: fadd
      //   104: fstore #5
      //   106: fload #6
      //   108: aload_1
      //   109: iload #8
      //   111: invokestatic getY : (Landroid/view/MotionEvent;I)F
      //   114: fadd
      //   115: fstore #6
      //   117: goto -> 78
      //   120: iload_3
      //   121: ifeq -> 215
      //   124: iload #7
      //   126: iconst_1
      //   127: isub
      //   128: istore_3
      //   129: fload #5
      //   131: iload_3
      //   132: i2f
      //   133: fdiv
      //   134: fstore #5
      //   136: fload #6
      //   138: iload_3
      //   139: i2f
      //   140: fdiv
      //   141: fstore #6
      //   143: iconst_0
      //   144: istore #4
      //   146: iconst_0
      //   147: istore #9
      //   149: iconst_0
      //   150: istore #10
      //   152: iconst_0
      //   153: istore #11
      //   155: iload #11
      //   157: istore #12
      //   159: iload_2
      //   160: sipush #255
      //   163: iand
      //   164: tableswitch default -> 208, 0 -> 403, 1 -> 912, 2 -> 667, 3 -> 1152, 4 -> 212, 5 -> 221, 6 -> 256
      //   208: iload #11
      //   210: istore #12
      //   212: iload #12
      //   214: ireturn
      //   215: iload #7
      //   217: istore_3
      //   218: goto -> 129
      //   221: aload_0
      //   222: fload #5
      //   224: putfield mLastFocusX : F
      //   227: aload_0
      //   228: fload #5
      //   230: putfield mDownFocusX : F
      //   233: aload_0
      //   234: fload #6
      //   236: putfield mLastFocusY : F
      //   239: aload_0
      //   240: fload #6
      //   242: putfield mDownFocusY : F
      //   245: aload_0
      //   246: invokespecial cancelTaps : ()V
      //   249: iload #11
      //   251: istore #12
      //   253: goto -> 212
      //   256: aload_0
      //   257: fload #5
      //   259: putfield mLastFocusX : F
      //   262: aload_0
      //   263: fload #5
      //   265: putfield mDownFocusX : F
      //   268: aload_0
      //   269: fload #6
      //   271: putfield mLastFocusY : F
      //   274: aload_0
      //   275: fload #6
      //   277: putfield mDownFocusY : F
      //   280: aload_0
      //   281: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   284: sipush #1000
      //   287: aload_0
      //   288: getfield mMaximumFlingVelocity : I
      //   291: i2f
      //   292: invokevirtual computeCurrentVelocity : (IF)V
      //   295: aload_1
      //   296: invokestatic getActionIndex : (Landroid/view/MotionEvent;)I
      //   299: istore #4
      //   301: aload_1
      //   302: iload #4
      //   304: invokestatic getPointerId : (Landroid/view/MotionEvent;I)I
      //   307: istore_3
      //   308: aload_0
      //   309: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   312: iload_3
      //   313: invokestatic getXVelocity : (Landroid/view/VelocityTracker;I)F
      //   316: fstore #5
      //   318: aload_0
      //   319: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   322: iload_3
      //   323: invokestatic getYVelocity : (Landroid/view/VelocityTracker;I)F
      //   326: fstore #6
      //   328: iconst_0
      //   329: istore_3
      //   330: iload #11
      //   332: istore #12
      //   334: iload_3
      //   335: iload #7
      //   337: if_icmpge -> 212
      //   340: iload_3
      //   341: iload #4
      //   343: if_icmpne -> 352
      //   346: iinc #3, 1
      //   349: goto -> 330
      //   352: aload_1
      //   353: iload_3
      //   354: invokestatic getPointerId : (Landroid/view/MotionEvent;I)I
      //   357: istore #8
      //   359: fload #5
      //   361: aload_0
      //   362: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   365: iload #8
      //   367: invokestatic getXVelocity : (Landroid/view/VelocityTracker;I)F
      //   370: fmul
      //   371: fload #6
      //   373: aload_0
      //   374: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   377: iload #8
      //   379: invokestatic getYVelocity : (Landroid/view/VelocityTracker;I)F
      //   382: fmul
      //   383: fadd
      //   384: fconst_0
      //   385: fcmpg
      //   386: ifge -> 346
      //   389: aload_0
      //   390: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   393: invokevirtual clear : ()V
      //   396: iload #11
      //   398: istore #12
      //   400: goto -> 212
      //   403: iload #4
      //   405: istore_3
      //   406: aload_0
      //   407: getfield mDoubleTapListener : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   410: ifnull -> 503
      //   413: aload_0
      //   414: getfield mHandler : Landroid/os/Handler;
      //   417: iconst_3
      //   418: invokevirtual hasMessages : (I)Z
      //   421: istore #12
      //   423: iload #12
      //   425: ifeq -> 436
      //   428: aload_0
      //   429: getfield mHandler : Landroid/os/Handler;
      //   432: iconst_3
      //   433: invokevirtual removeMessages : (I)V
      //   436: aload_0
      //   437: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   440: ifnull -> 648
      //   443: aload_0
      //   444: getfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   447: ifnull -> 648
      //   450: iload #12
      //   452: ifeq -> 648
      //   455: aload_0
      //   456: aload_0
      //   457: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   460: aload_0
      //   461: getfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   464: aload_1
      //   465: invokespecial isConsideredDoubleTap : (Landroid/view/MotionEvent;Landroid/view/MotionEvent;Landroid/view/MotionEvent;)Z
      //   468: ifeq -> 648
      //   471: aload_0
      //   472: iconst_1
      //   473: putfield mIsDoubleTapping : Z
      //   476: iconst_0
      //   477: aload_0
      //   478: getfield mDoubleTapListener : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   481: aload_0
      //   482: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   485: invokeinterface onDoubleTap : (Landroid/view/MotionEvent;)Z
      //   490: ior
      //   491: aload_0
      //   492: getfield mDoubleTapListener : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   495: aload_1
      //   496: invokeinterface onDoubleTapEvent : (Landroid/view/MotionEvent;)Z
      //   501: ior
      //   502: istore_3
      //   503: aload_0
      //   504: fload #5
      //   506: putfield mLastFocusX : F
      //   509: aload_0
      //   510: fload #5
      //   512: putfield mDownFocusX : F
      //   515: aload_0
      //   516: fload #6
      //   518: putfield mLastFocusY : F
      //   521: aload_0
      //   522: fload #6
      //   524: putfield mDownFocusY : F
      //   527: aload_0
      //   528: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   531: ifnull -> 541
      //   534: aload_0
      //   535: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   538: invokevirtual recycle : ()V
      //   541: aload_0
      //   542: aload_1
      //   543: invokestatic obtain : (Landroid/view/MotionEvent;)Landroid/view/MotionEvent;
      //   546: putfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   549: aload_0
      //   550: iconst_1
      //   551: putfield mAlwaysInTapRegion : Z
      //   554: aload_0
      //   555: iconst_1
      //   556: putfield mAlwaysInBiggerTapRegion : Z
      //   559: aload_0
      //   560: iconst_1
      //   561: putfield mStillDown : Z
      //   564: aload_0
      //   565: iconst_0
      //   566: putfield mInLongPress : Z
      //   569: aload_0
      //   570: getfield mIsLongpressEnabled : Z
      //   573: ifeq -> 610
      //   576: aload_0
      //   577: getfield mHandler : Landroid/os/Handler;
      //   580: iconst_2
      //   581: invokevirtual removeMessages : (I)V
      //   584: aload_0
      //   585: getfield mHandler : Landroid/os/Handler;
      //   588: iconst_2
      //   589: aload_0
      //   590: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   593: invokevirtual getDownTime : ()J
      //   596: getstatic android/support/v4/view/GestureDetectorCompat$GestureDetectorCompatImplBase.TAP_TIMEOUT : I
      //   599: i2l
      //   600: ladd
      //   601: getstatic android/support/v4/view/GestureDetectorCompat$GestureDetectorCompatImplBase.LONGPRESS_TIMEOUT : I
      //   604: i2l
      //   605: ladd
      //   606: invokevirtual sendEmptyMessageAtTime : (IJ)Z
      //   609: pop
      //   610: aload_0
      //   611: getfield mHandler : Landroid/os/Handler;
      //   614: iconst_1
      //   615: aload_0
      //   616: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   619: invokevirtual getDownTime : ()J
      //   622: getstatic android/support/v4/view/GestureDetectorCompat$GestureDetectorCompatImplBase.TAP_TIMEOUT : I
      //   625: i2l
      //   626: ladd
      //   627: invokevirtual sendEmptyMessageAtTime : (IJ)Z
      //   630: pop
      //   631: iload_3
      //   632: aload_0
      //   633: getfield mListener : Landroid/view/GestureDetector$OnGestureListener;
      //   636: aload_1
      //   637: invokeinterface onDown : (Landroid/view/MotionEvent;)Z
      //   642: ior
      //   643: istore #12
      //   645: goto -> 212
      //   648: aload_0
      //   649: getfield mHandler : Landroid/os/Handler;
      //   652: iconst_3
      //   653: getstatic android/support/v4/view/GestureDetectorCompat$GestureDetectorCompatImplBase.DOUBLE_TAP_TIMEOUT : I
      //   656: i2l
      //   657: invokevirtual sendEmptyMessageDelayed : (IJ)Z
      //   660: pop
      //   661: iload #4
      //   663: istore_3
      //   664: goto -> 503
      //   667: iload #11
      //   669: istore #12
      //   671: aload_0
      //   672: getfield mInLongPress : Z
      //   675: ifne -> 212
      //   678: aload_0
      //   679: getfield mLastFocusX : F
      //   682: fload #5
      //   684: fsub
      //   685: fstore #13
      //   687: aload_0
      //   688: getfield mLastFocusY : F
      //   691: fload #6
      //   693: fsub
      //   694: fstore #14
      //   696: aload_0
      //   697: getfield mIsDoubleTapping : Z
      //   700: ifeq -> 720
      //   703: iconst_0
      //   704: aload_0
      //   705: getfield mDoubleTapListener : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   708: aload_1
      //   709: invokeinterface onDoubleTapEvent : (Landroid/view/MotionEvent;)Z
      //   714: ior
      //   715: istore #12
      //   717: goto -> 212
      //   720: aload_0
      //   721: getfield mAlwaysInTapRegion : Z
      //   724: ifeq -> 853
      //   727: fload #5
      //   729: aload_0
      //   730: getfield mDownFocusX : F
      //   733: fsub
      //   734: f2i
      //   735: istore #4
      //   737: fload #6
      //   739: aload_0
      //   740: getfield mDownFocusY : F
      //   743: fsub
      //   744: f2i
      //   745: istore_3
      //   746: iload #4
      //   748: iload #4
      //   750: imul
      //   751: iload_3
      //   752: iload_3
      //   753: imul
      //   754: iadd
      //   755: istore_3
      //   756: iload #9
      //   758: istore #11
      //   760: iload_3
      //   761: aload_0
      //   762: getfield mTouchSlopSquare : I
      //   765: if_icmple -> 829
      //   768: aload_0
      //   769: getfield mListener : Landroid/view/GestureDetector$OnGestureListener;
      //   772: aload_0
      //   773: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   776: aload_1
      //   777: fload #13
      //   779: fload #14
      //   781: invokeinterface onScroll : (Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
      //   786: istore #11
      //   788: aload_0
      //   789: fload #5
      //   791: putfield mLastFocusX : F
      //   794: aload_0
      //   795: fload #6
      //   797: putfield mLastFocusY : F
      //   800: aload_0
      //   801: iconst_0
      //   802: putfield mAlwaysInTapRegion : Z
      //   805: aload_0
      //   806: getfield mHandler : Landroid/os/Handler;
      //   809: iconst_3
      //   810: invokevirtual removeMessages : (I)V
      //   813: aload_0
      //   814: getfield mHandler : Landroid/os/Handler;
      //   817: iconst_1
      //   818: invokevirtual removeMessages : (I)V
      //   821: aload_0
      //   822: getfield mHandler : Landroid/os/Handler;
      //   825: iconst_2
      //   826: invokevirtual removeMessages : (I)V
      //   829: iload #11
      //   831: istore #12
      //   833: iload_3
      //   834: aload_0
      //   835: getfield mTouchSlopSquare : I
      //   838: if_icmple -> 212
      //   841: aload_0
      //   842: iconst_0
      //   843: putfield mAlwaysInBiggerTapRegion : Z
      //   846: iload #11
      //   848: istore #12
      //   850: goto -> 212
      //   853: fload #13
      //   855: invokestatic abs : (F)F
      //   858: fconst_1
      //   859: fcmpl
      //   860: ifge -> 877
      //   863: iload #11
      //   865: istore #12
      //   867: fload #14
      //   869: invokestatic abs : (F)F
      //   872: fconst_1
      //   873: fcmpl
      //   874: iflt -> 212
      //   877: aload_0
      //   878: getfield mListener : Landroid/view/GestureDetector$OnGestureListener;
      //   881: aload_0
      //   882: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   885: aload_1
      //   886: fload #13
      //   888: fload #14
      //   890: invokeinterface onScroll : (Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
      //   895: istore #12
      //   897: aload_0
      //   898: fload #5
      //   900: putfield mLastFocusX : F
      //   903: aload_0
      //   904: fload #6
      //   906: putfield mLastFocusY : F
      //   909: goto -> 212
      //   912: aload_0
      //   913: iconst_0
      //   914: putfield mStillDown : Z
      //   917: aload_1
      //   918: invokestatic obtain : (Landroid/view/MotionEvent;)Landroid/view/MotionEvent;
      //   921: astore #15
      //   923: aload_0
      //   924: getfield mIsDoubleTapping : Z
      //   927: ifeq -> 1007
      //   930: iconst_0
      //   931: aload_0
      //   932: getfield mDoubleTapListener : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   935: aload_1
      //   936: invokeinterface onDoubleTapEvent : (Landroid/view/MotionEvent;)Z
      //   941: ior
      //   942: istore #12
      //   944: aload_0
      //   945: getfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   948: ifnull -> 958
      //   951: aload_0
      //   952: getfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   955: invokevirtual recycle : ()V
      //   958: aload_0
      //   959: aload #15
      //   961: putfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   964: aload_0
      //   965: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   968: ifnull -> 983
      //   971: aload_0
      //   972: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   975: invokevirtual recycle : ()V
      //   978: aload_0
      //   979: aconst_null
      //   980: putfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   983: aload_0
      //   984: iconst_0
      //   985: putfield mIsDoubleTapping : Z
      //   988: aload_0
      //   989: getfield mHandler : Landroid/os/Handler;
      //   992: iconst_1
      //   993: invokevirtual removeMessages : (I)V
      //   996: aload_0
      //   997: getfield mHandler : Landroid/os/Handler;
      //   1000: iconst_2
      //   1001: invokevirtual removeMessages : (I)V
      //   1004: goto -> 212
      //   1007: aload_0
      //   1008: getfield mInLongPress : Z
      //   1011: ifeq -> 1034
      //   1014: aload_0
      //   1015: getfield mHandler : Landroid/os/Handler;
      //   1018: iconst_3
      //   1019: invokevirtual removeMessages : (I)V
      //   1022: aload_0
      //   1023: iconst_0
      //   1024: putfield mInLongPress : Z
      //   1027: iload #10
      //   1029: istore #12
      //   1031: goto -> 944
      //   1034: aload_0
      //   1035: getfield mAlwaysInTapRegion : Z
      //   1038: ifeq -> 1056
      //   1041: aload_0
      //   1042: getfield mListener : Landroid/view/GestureDetector$OnGestureListener;
      //   1045: aload_1
      //   1046: invokeinterface onSingleTapUp : (Landroid/view/MotionEvent;)Z
      //   1051: istore #12
      //   1053: goto -> 944
      //   1056: aload_0
      //   1057: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   1060: astore #16
      //   1062: aload_1
      //   1063: iconst_0
      //   1064: invokestatic getPointerId : (Landroid/view/MotionEvent;I)I
      //   1067: istore_3
      //   1068: aload #16
      //   1070: sipush #1000
      //   1073: aload_0
      //   1074: getfield mMaximumFlingVelocity : I
      //   1077: i2f
      //   1078: invokevirtual computeCurrentVelocity : (IF)V
      //   1081: aload #16
      //   1083: iload_3
      //   1084: invokestatic getYVelocity : (Landroid/view/VelocityTracker;I)F
      //   1087: fstore #5
      //   1089: aload #16
      //   1091: iload_3
      //   1092: invokestatic getXVelocity : (Landroid/view/VelocityTracker;I)F
      //   1095: fstore #6
      //   1097: fload #5
      //   1099: invokestatic abs : (F)F
      //   1102: aload_0
      //   1103: getfield mMinimumFlingVelocity : I
      //   1106: i2f
      //   1107: fcmpl
      //   1108: ifgt -> 1129
      //   1111: iload #10
      //   1113: istore #12
      //   1115: fload #6
      //   1117: invokestatic abs : (F)F
      //   1120: aload_0
      //   1121: getfield mMinimumFlingVelocity : I
      //   1124: i2f
      //   1125: fcmpl
      //   1126: ifle -> 944
      //   1129: aload_0
      //   1130: getfield mListener : Landroid/view/GestureDetector$OnGestureListener;
      //   1133: aload_0
      //   1134: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   1137: aload_1
      //   1138: fload #6
      //   1140: fload #5
      //   1142: invokeinterface onFling : (Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
      //   1147: istore #12
      //   1149: goto -> 944
      //   1152: aload_0
      //   1153: invokespecial cancel : ()V
      //   1156: iload #11
      //   1158: istore #12
      //   1160: goto -> 212
    }
    
    public void setIsLongpressEnabled(boolean param1Boolean) {
      this.mIsLongpressEnabled = param1Boolean;
    }
    
    public void setOnDoubleTapListener(GestureDetector.OnDoubleTapListener param1OnDoubleTapListener) {
      this.mDoubleTapListener = param1OnDoubleTapListener;
    }
    
    private class GestureHandler extends Handler {
      GestureHandler() {}
      
      GestureHandler(Handler param2Handler) {
        super(param2Handler.getLooper());
      }
      
      public void handleMessage(Message param2Message) {
        switch (param2Message.what) {
          default:
            throw new RuntimeException("Unknown message " + param2Message);
          case 1:
            GestureDetectorCompat.GestureDetectorCompatImplBase.this.mListener.onShowPress(GestureDetectorCompat.GestureDetectorCompatImplBase.this.mCurrentDownEvent);
            return;
          case 2:
            GestureDetectorCompat.GestureDetectorCompatImplBase.this.dispatchLongPress();
            return;
          case 3:
            break;
        } 
        if (GestureDetectorCompat.GestureDetectorCompatImplBase.this.mDoubleTapListener != null && !GestureDetectorCompat.GestureDetectorCompatImplBase.this.mStillDown)
          GestureDetectorCompat.GestureDetectorCompatImplBase.this.mDoubleTapListener.onSingleTapConfirmed(GestureDetectorCompat.GestureDetectorCompatImplBase.this.mCurrentDownEvent); 
      }
    }
  }
  
  private class GestureHandler extends Handler {
    GestureHandler() {}
    
    GestureHandler(Handler param1Handler) {
      super(param1Handler.getLooper());
    }
    
    public void handleMessage(Message param1Message) {
      switch (param1Message.what) {
        default:
          throw new RuntimeException("Unknown message " + param1Message);
        case 1:
          this.this$0.mListener.onShowPress(this.this$0.mCurrentDownEvent);
          return;
        case 2:
          this.this$0.dispatchLongPress();
          return;
        case 3:
          break;
      } 
      if (this.this$0.mDoubleTapListener != null && !this.this$0.mStillDown)
        this.this$0.mDoubleTapListener.onSingleTapConfirmed(this.this$0.mCurrentDownEvent); 
    }
  }
  
  static class GestureDetectorCompatImplJellybeanMr1 implements GestureDetectorCompatImpl {
    private final GestureDetector mDetector;
    
    public GestureDetectorCompatImplJellybeanMr1(Context param1Context, GestureDetector.OnGestureListener param1OnGestureListener, Handler param1Handler) {
      this.mDetector = new GestureDetector(param1Context, param1OnGestureListener, param1Handler);
    }
    
    public boolean isLongpressEnabled() {
      return this.mDetector.isLongpressEnabled();
    }
    
    public boolean onTouchEvent(MotionEvent param1MotionEvent) {
      return this.mDetector.onTouchEvent(param1MotionEvent);
    }
    
    public void setIsLongpressEnabled(boolean param1Boolean) {
      this.mDetector.setIsLongpressEnabled(param1Boolean);
    }
    
    public void setOnDoubleTapListener(GestureDetector.OnDoubleTapListener param1OnDoubleTapListener) {
      this.mDetector.setOnDoubleTapListener(param1OnDoubleTapListener);
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeBank-dex2jar.jar!/android/support/v4/view/GestureDetectorCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */