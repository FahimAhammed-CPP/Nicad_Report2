package android.support.v4.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.support.v4.os.ParcelableCompat;
import android.support.v4.os.ParcelableCompatCreatorCallbacks;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.v4.widget.EdgeEffectCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.Scroller;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ViewPager extends ViewGroup {
  private static final int CLOSE_ENOUGH = 2;
  
  private static final Comparator<ItemInfo> COMPARATOR;
  
  private static final boolean DEBUG = false;
  
  private static final int DEFAULT_GUTTER_SIZE = 16;
  
  private static final int DEFAULT_OFFSCREEN_PAGES = 1;
  
  private static final int DRAW_ORDER_DEFAULT = 0;
  
  private static final int DRAW_ORDER_FORWARD = 1;
  
  private static final int DRAW_ORDER_REVERSE = 2;
  
  private static final int INVALID_POINTER = -1;
  
  private static final int[] LAYOUT_ATTRS = new int[] { 16842931 };
  
  private static final int MAX_SETTLE_DURATION = 600;
  
  private static final int MIN_DISTANCE_FOR_FLING = 25;
  
  public static final int SCROLL_STATE_DRAGGING = 1;
  
  public static final int SCROLL_STATE_IDLE = 0;
  
  public static final int SCROLL_STATE_SETTLING = 2;
  
  private static final String TAG = "ViewPager";
  
  private static final boolean USE_CACHE = false;
  
  private static final Interpolator sInterpolator;
  
  private static final ViewPositionComparator sPositionComparator;
  
  private int mActivePointerId = -1;
  
  private PagerAdapter mAdapter;
  
  private OnAdapterChangeListener mAdapterChangeListener;
  
  private int mBottomPageBounds;
  
  private boolean mCalledSuper;
  
  private int mChildHeightMeasureSpec;
  
  private int mChildWidthMeasureSpec;
  
  private int mCloseEnough;
  
  private int mCurItem;
  
  private int mDecorChildCount;
  
  private int mDefaultGutterSize;
  
  private int mDrawingOrder;
  
  private ArrayList<View> mDrawingOrderedChildren;
  
  private final Runnable mEndScrollRunnable = new Runnable() {
      public void run() {
        ViewPager.this.setScrollState(0);
        ViewPager.this.populate();
      }
    };
  
  private long mFakeDragBeginTime;
  
  private boolean mFakeDragging;
  
  private boolean mFirstLayout = true;
  
  private float mFirstOffset = -3.4028235E38F;
  
  private int mFlingDistance;
  
  private int mGutterSize;
  
  private boolean mIgnoreGutter;
  
  private boolean mInLayout;
  
  private float mInitialMotionX;
  
  private OnPageChangeListener mInternalPageChangeListener;
  
  private boolean mIsBeingDragged;
  
  private boolean mIsUnableToDrag;
  
  private final ArrayList<ItemInfo> mItems = new ArrayList<ItemInfo>();
  
  private float mLastMotionX;
  
  private float mLastMotionY;
  
  private float mLastOffset = Float.MAX_VALUE;
  
  private EdgeEffectCompat mLeftEdge;
  
  private Drawable mMarginDrawable;
  
  private int mMaximumVelocity;
  
  private int mMinimumVelocity;
  
  private boolean mNeedCalculatePageOffsets = false;
  
  private PagerObserver mObserver;
  
  private int mOffscreenPageLimit = 1;
  
  private OnPageChangeListener mOnPageChangeListener;
  
  private int mPageMargin;
  
  private PageTransformer mPageTransformer;
  
  private boolean mPopulatePending;
  
  private Parcelable mRestoredAdapterState = null;
  
  private ClassLoader mRestoredClassLoader = null;
  
  private int mRestoredCurItem = -1;
  
  private EdgeEffectCompat mRightEdge;
  
  private int mScrollState = 0;
  
  private Scroller mScroller;
  
  private boolean mScrollingCacheEnabled;
  
  private int mSeenPositionMax;
  
  private int mSeenPositionMin;
  
  private Method mSetChildrenDrawingOrderEnabled;
  
  private final ItemInfo mTempItem = new ItemInfo();
  
  private final Rect mTempRect = new Rect();
  
  private int mTopPageBounds;
  
  private int mTouchSlop;
  
  private VelocityTracker mVelocityTracker;
  
  static {
    COMPARATOR = new Comparator<ItemInfo>() {
        public int compare(ViewPager.ItemInfo param1ItemInfo1, ViewPager.ItemInfo param1ItemInfo2) {
          return param1ItemInfo1.position - param1ItemInfo2.position;
        }
      };
    sInterpolator = new Interpolator() {
        public float getInterpolation(float param1Float) {
          param1Float--;
          return param1Float * param1Float * param1Float * param1Float * param1Float + 1.0F;
        }
      };
    sPositionComparator = new ViewPositionComparator();
  }
  
  public ViewPager(Context paramContext) {
    super(paramContext);
    initViewPager();
  }
  
  public ViewPager(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    initViewPager();
  }
  
  private void calculatePageOffsets(ItemInfo paramItemInfo1, int paramInt, ItemInfo paramItemInfo2) {
    float f1;
    int i = this.mAdapter.getCount();
    int j = getWidth();
    if (j > 0) {
      f1 = this.mPageMargin / j;
    } else {
      f1 = 0.0F;
    } 
    if (paramItemInfo2 != null) {
      j = paramItemInfo2.position;
      if (j < paramItemInfo1.position) {
        byte b = 0;
        f2 = paramItemInfo2.offset + paramItemInfo2.widthFactor + f1;
        while (++j <= paramItemInfo1.position && b < this.mItems.size()) {
          float f;
          int n;
          paramItemInfo2 = this.mItems.get(b);
          while (true) {
            f = f2;
            n = j;
            if (j > paramItemInfo2.position) {
              f = f2;
              n = j;
              if (b < this.mItems.size() - 1) {
                paramItemInfo2 = this.mItems.get(++b);
                continue;
              } 
            } 
            break;
          } 
          while (n < paramItemInfo2.position) {
            f += this.mAdapter.getPageWidth(n) + f1;
            n++;
          } 
          paramItemInfo2.offset = f;
          f2 = f + paramItemInfo2.widthFactor + f1;
          j = n + 1;
        } 
      } else if (j > paramItemInfo1.position) {
        int n = this.mItems.size() - 1;
        f2 = paramItemInfo2.offset;
        while (--j >= paramItemInfo1.position && n >= 0) {
          float f;
          int i1;
          paramItemInfo2 = this.mItems.get(n);
          while (true) {
            f = f2;
            i1 = j;
            if (j < paramItemInfo2.position) {
              f = f2;
              i1 = j;
              if (n > 0) {
                paramItemInfo2 = this.mItems.get(--n);
                continue;
              } 
            } 
            break;
          } 
          while (i1 > paramItemInfo2.position) {
            f -= this.mAdapter.getPageWidth(i1) + f1;
            i1--;
          } 
          f2 = f - paramItemInfo2.widthFactor + f1;
          paramItemInfo2.offset = f2;
          j = i1 - 1;
        } 
      } 
    } 
    int m = this.mItems.size();
    float f3 = paramItemInfo1.offset;
    j = paramItemInfo1.position - 1;
    if (paramItemInfo1.position == 0) {
      f2 = paramItemInfo1.offset;
    } else {
      f2 = -3.4028235E38F;
    } 
    this.mFirstOffset = f2;
    if (paramItemInfo1.position == i - 1) {
      f2 = paramItemInfo1.offset + paramItemInfo1.widthFactor - 1.0F;
    } else {
      f2 = Float.MAX_VALUE;
    } 
    this.mLastOffset = f2;
    int k = paramInt - 1;
    float f2 = f3;
    while (k >= 0) {
      paramItemInfo2 = this.mItems.get(k);
      while (j > paramItemInfo2.position) {
        f2 -= this.mAdapter.getPageWidth(j) + f1;
        j--;
      } 
      f2 -= paramItemInfo2.widthFactor + f1;
      paramItemInfo2.offset = f2;
      if (paramItemInfo2.position == 0)
        this.mFirstOffset = f2; 
      k--;
      j--;
    } 
    f2 = paramItemInfo1.offset + paramItemInfo1.widthFactor + f1;
    j = paramItemInfo1.position + 1;
    k = paramInt + 1;
    paramInt = j;
    j = k;
    while (j < m) {
      paramItemInfo1 = this.mItems.get(j);
      while (paramInt < paramItemInfo1.position) {
        f2 += this.mAdapter.getPageWidth(paramInt) + f1;
        paramInt++;
      } 
      if (paramItemInfo1.position == i - 1)
        this.mLastOffset = paramItemInfo1.widthFactor + f2 - 1.0F; 
      paramItemInfo1.offset = f2;
      f2 += paramItemInfo1.widthFactor + f1;
      j++;
      paramInt++;
    } 
    this.mNeedCalculatePageOffsets = false;
  }
  
  private void completeScroll(boolean paramBoolean) {
    if (this.mScrollState == 2) {
      b1 = 1;
    } else {
      b1 = 0;
    } 
    if (b1) {
      setScrollingCacheEnabled(false);
      this.mScroller.abortAnimation();
      int i = getScrollX();
      int j = getScrollY();
      int k = this.mScroller.getCurrX();
      int m = this.mScroller.getCurrY();
      if (i != k || j != m)
        scrollTo(k, m); 
    } 
    this.mPopulatePending = false;
    byte b2 = 0;
    byte b3 = b1;
    byte b1;
    for (b1 = b2; b1 < this.mItems.size(); b1++) {
      ItemInfo itemInfo = this.mItems.get(b1);
      if (itemInfo.scrolling) {
        b3 = 1;
        itemInfo.scrolling = false;
      } 
    } 
    if (b3 != 0) {
      if (paramBoolean) {
        ViewCompat.postOnAnimation((View)this, this.mEndScrollRunnable);
        return;
      } 
    } else {
      return;
    } 
    this.mEndScrollRunnable.run();
  }
  
  private int determineTargetPage(int paramInt1, float paramFloat, int paramInt2, int paramInt3) {
    if (Math.abs(paramInt3) > this.mFlingDistance && Math.abs(paramInt2) > this.mMinimumVelocity) {
      if (paramInt2 <= 0)
        paramInt1++; 
    } else if (this.mSeenPositionMin >= 0 && this.mSeenPositionMin < paramInt1 && paramFloat < 0.5F) {
      paramInt1++;
    } else if (this.mSeenPositionMax >= 0 && this.mSeenPositionMax > paramInt1 + 1 && paramFloat >= 0.5F) {
      paramInt1--;
    } else {
      paramInt1 = (int)(paramInt1 + paramFloat + 0.5F);
    } 
    paramInt2 = paramInt1;
    if (this.mItems.size() > 0) {
      ItemInfo itemInfo1 = this.mItems.get(0);
      ItemInfo itemInfo2 = this.mItems.get(this.mItems.size() - 1);
      paramInt2 = Math.max(itemInfo1.position, Math.min(paramInt1, itemInfo2.position));
    } 
    return paramInt2;
  }
  
  private void enableLayers(boolean paramBoolean) {
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      boolean bool;
      if (paramBoolean) {
        bool = true;
      } else {
        bool = false;
      } 
      ViewCompat.setLayerType(getChildAt(b), bool, null);
    } 
  }
  
  private void endDrag() {
    this.mIsBeingDragged = false;
    this.mIsUnableToDrag = false;
    if (this.mVelocityTracker != null) {
      this.mVelocityTracker.recycle();
      this.mVelocityTracker = null;
    } 
  }
  
  private Rect getChildRectInPagerCoordinates(Rect paramRect, View paramView) {
    Rect rect = paramRect;
    if (paramRect == null)
      rect = new Rect(); 
    if (paramView == null) {
      rect.set(0, 0, 0, 0);
      return rect;
    } 
    rect.left = paramView.getLeft();
    rect.right = paramView.getRight();
    rect.top = paramView.getTop();
    rect.bottom = paramView.getBottom();
    ViewParent viewParent = paramView.getParent();
    while (true) {
      if (viewParent instanceof ViewGroup && viewParent != this) {
        ViewGroup viewGroup = (ViewGroup)viewParent;
        rect.left += viewGroup.getLeft();
        rect.right += viewGroup.getRight();
        rect.top += viewGroup.getTop();
        rect.bottom += viewGroup.getBottom();
        ViewParent viewParent1 = viewGroup.getParent();
        continue;
      } 
      return rect;
    } 
  }
  
  private ItemInfo infoForCurrentScrollPosition() {
    // Byte code:
    //   0: fconst_0
    //   1: fstore_1
    //   2: aload_0
    //   3: invokevirtual getWidth : ()I
    //   6: istore_2
    //   7: iload_2
    //   8: ifle -> 221
    //   11: aload_0
    //   12: invokevirtual getScrollX : ()I
    //   15: i2f
    //   16: iload_2
    //   17: i2f
    //   18: fdiv
    //   19: fstore_3
    //   20: iload_2
    //   21: ifle -> 33
    //   24: aload_0
    //   25: getfield mPageMargin : I
    //   28: i2f
    //   29: iload_2
    //   30: i2f
    //   31: fdiv
    //   32: fstore_1
    //   33: iconst_m1
    //   34: istore #4
    //   36: fconst_0
    //   37: fstore #5
    //   39: fconst_0
    //   40: fstore #6
    //   42: iconst_1
    //   43: istore #7
    //   45: aconst_null
    //   46: astore #8
    //   48: iconst_0
    //   49: istore_2
    //   50: aload #8
    //   52: astore #9
    //   54: iload_2
    //   55: aload_0
    //   56: getfield mItems : Ljava/util/ArrayList;
    //   59: invokevirtual size : ()I
    //   62: if_icmpge -> 218
    //   65: aload_0
    //   66: getfield mItems : Ljava/util/ArrayList;
    //   69: iload_2
    //   70: invokevirtual get : (I)Ljava/lang/Object;
    //   73: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   76: astore #9
    //   78: iload_2
    //   79: istore #10
    //   81: aload #9
    //   83: astore #11
    //   85: iload #7
    //   87: ifne -> 158
    //   90: iload_2
    //   91: istore #10
    //   93: aload #9
    //   95: astore #11
    //   97: aload #9
    //   99: getfield position : I
    //   102: iload #4
    //   104: iconst_1
    //   105: iadd
    //   106: if_icmpeq -> 158
    //   109: aload_0
    //   110: getfield mTempItem : Landroid/support/v4/view/ViewPager$ItemInfo;
    //   113: astore #11
    //   115: aload #11
    //   117: fload #5
    //   119: fload #6
    //   121: fadd
    //   122: fload_1
    //   123: fadd
    //   124: putfield offset : F
    //   127: aload #11
    //   129: iload #4
    //   131: iconst_1
    //   132: iadd
    //   133: putfield position : I
    //   136: aload #11
    //   138: aload_0
    //   139: getfield mAdapter : Landroid/support/v4/view/PagerAdapter;
    //   142: aload #11
    //   144: getfield position : I
    //   147: invokevirtual getPageWidth : (I)F
    //   150: putfield widthFactor : F
    //   153: iload_2
    //   154: iconst_1
    //   155: isub
    //   156: istore #10
    //   158: aload #11
    //   160: getfield offset : F
    //   163: fstore #5
    //   165: aload #11
    //   167: getfield widthFactor : F
    //   170: fstore #6
    //   172: iload #7
    //   174: ifne -> 188
    //   177: aload #8
    //   179: astore #9
    //   181: fload_3
    //   182: fload #5
    //   184: fcmpl
    //   185: iflt -> 218
    //   188: fload_3
    //   189: fload #6
    //   191: fload #5
    //   193: fadd
    //   194: fload_1
    //   195: fadd
    //   196: fcmpg
    //   197: iflt -> 214
    //   200: iload #10
    //   202: aload_0
    //   203: getfield mItems : Ljava/util/ArrayList;
    //   206: invokevirtual size : ()I
    //   209: iconst_1
    //   210: isub
    //   211: if_icmpne -> 226
    //   214: aload #11
    //   216: astore #9
    //   218: aload #9
    //   220: areturn
    //   221: fconst_0
    //   222: fstore_3
    //   223: goto -> 20
    //   226: iconst_0
    //   227: istore #7
    //   229: aload #11
    //   231: getfield position : I
    //   234: istore #4
    //   236: aload #11
    //   238: getfield widthFactor : F
    //   241: fstore #6
    //   243: iload #10
    //   245: iconst_1
    //   246: iadd
    //   247: istore_2
    //   248: aload #11
    //   250: astore #8
    //   252: goto -> 50
  }
  
  private boolean isGutterDrag(float paramFloat1, float paramFloat2) {
    return ((paramFloat1 < this.mGutterSize && paramFloat2 > 0.0F) || (paramFloat1 > (getWidth() - this.mGutterSize) && paramFloat2 < 0.0F));
  }
  
  private void onSecondaryPointerUp(MotionEvent paramMotionEvent) {
    int i = MotionEventCompat.getActionIndex(paramMotionEvent);
    if (MotionEventCompat.getPointerId(paramMotionEvent, i) == this.mActivePointerId) {
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      this.mLastMotionX = MotionEventCompat.getX(paramMotionEvent, i);
      this.mActivePointerId = MotionEventCompat.getPointerId(paramMotionEvent, i);
      if (this.mVelocityTracker != null)
        this.mVelocityTracker.clear(); 
    } 
  }
  
  private boolean pageScrolled(int paramInt) {
    boolean bool = false;
    if (this.mItems.size() == 0) {
      this.mCalledSuper = false;
      onPageScrolled(0, 0.0F, 0);
      if (!this.mCalledSuper)
        throw new IllegalStateException("onPageScrolled did not call superclass implementation"); 
    } else {
      ItemInfo itemInfo = infoForCurrentScrollPosition();
      int i = getWidth();
      int j = this.mPageMargin;
      float f = this.mPageMargin / i;
      int k = itemInfo.position;
      f = (paramInt / i - itemInfo.offset) / (itemInfo.widthFactor + f);
      paramInt = (int)((i + j) * f);
      this.mCalledSuper = false;
      onPageScrolled(k, f, paramInt);
      if (!this.mCalledSuper)
        throw new IllegalStateException("onPageScrolled did not call superclass implementation"); 
      bool = true;
    } 
    return bool;
  }
  
  private boolean performDrag(float paramFloat) {
    boolean bool1 = false;
    boolean bool2 = false;
    boolean bool = false;
    float f1 = this.mLastMotionX;
    this.mLastMotionX = paramFloat;
    float f2 = getScrollX() + f1 - paramFloat;
    int i = getWidth();
    paramFloat = i * this.mFirstOffset;
    f1 = i * this.mLastOffset;
    boolean bool3 = true;
    boolean bool4 = true;
    ItemInfo itemInfo1 = this.mItems.get(0);
    ItemInfo itemInfo2 = this.mItems.get(this.mItems.size() - 1);
    if (itemInfo1.position != 0) {
      bool3 = false;
      paramFloat = itemInfo1.offset * i;
    } 
    if (itemInfo2.position != this.mAdapter.getCount() - 1) {
      bool4 = false;
      f1 = itemInfo2.offset * i;
    } 
    if (f2 < paramFloat) {
      if (bool3)
        bool = this.mLeftEdge.onPull(Math.abs(paramFloat - f2) / i); 
      this.mLastMotionX += paramFloat - (int)paramFloat;
      scrollTo((int)paramFloat, getScrollY());
      pageScrolled((int)paramFloat);
      return bool;
    } 
    bool = bool1;
    paramFloat = f2;
    if (f2 > f1) {
      bool = bool2;
      if (bool4)
        bool = this.mRightEdge.onPull(Math.abs(f2 - f1) / i); 
      paramFloat = f1;
    } 
    this.mLastMotionX += paramFloat - (int)paramFloat;
    scrollTo((int)paramFloat, getScrollY());
    pageScrolled((int)paramFloat);
    return bool;
  }
  
  private void recomputeScrollPosition(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    float f;
    if (paramInt2 > 0 && !this.mItems.isEmpty()) {
      f = getScrollX() / (paramInt2 + paramInt4);
      paramInt2 = (int)((paramInt1 + paramInt3) * f);
      scrollTo(paramInt2, getScrollY());
      if (!this.mScroller.isFinished()) {
        paramInt3 = this.mScroller.getDuration();
        paramInt4 = this.mScroller.timePassed();
        ItemInfo itemInfo1 = infoForPosition(this.mCurItem);
        this.mScroller.startScroll(paramInt2, 0, (int)(itemInfo1.offset * paramInt1), 0, paramInt3 - paramInt4);
      } 
      return;
    } 
    ItemInfo itemInfo = infoForPosition(this.mCurItem);
    if (itemInfo != null) {
      f = Math.min(itemInfo.offset, this.mLastOffset);
    } else {
      f = 0.0F;
    } 
    paramInt1 = (int)(paramInt1 * f);
    if (paramInt1 != getScrollX()) {
      completeScroll(false);
      scrollTo(paramInt1, getScrollY());
    } 
  }
  
  private void removeNonDecorViews() {
    for (int i = 0; i < getChildCount(); i = j + 1) {
      int j = i;
      if (!((LayoutParams)getChildAt(i).getLayoutParams()).isDecor) {
        removeViewAt(i);
        j = i - 1;
      } 
    } 
  }
  
  private void scrollToItem(int paramInt1, boolean paramBoolean1, int paramInt2, boolean paramBoolean2) {
    ItemInfo itemInfo = infoForPosition(paramInt1);
    int i = 0;
    if (itemInfo != null)
      i = (int)(getWidth() * Math.max(this.mFirstOffset, Math.min(itemInfo.offset, this.mLastOffset))); 
    if (paramBoolean1) {
      smoothScrollTo(i, 0, paramInt2);
      if (paramBoolean2 && this.mOnPageChangeListener != null)
        this.mOnPageChangeListener.onPageSelected(paramInt1); 
      if (paramBoolean2 && this.mInternalPageChangeListener != null)
        this.mInternalPageChangeListener.onPageSelected(paramInt1); 
      return;
    } 
    if (paramBoolean2 && this.mOnPageChangeListener != null)
      this.mOnPageChangeListener.onPageSelected(paramInt1); 
    if (paramBoolean2 && this.mInternalPageChangeListener != null)
      this.mInternalPageChangeListener.onPageSelected(paramInt1); 
    completeScroll(false);
    scrollTo(i, 0);
  }
  
  private void setScrollState(int paramInt) {
    boolean bool = true;
    if (this.mScrollState != paramInt) {
      this.mScrollState = paramInt;
      if (paramInt == 1) {
        this.mSeenPositionMax = -1;
        this.mSeenPositionMin = -1;
      } 
      if (this.mPageTransformer != null) {
        if (paramInt == 0)
          bool = false; 
        enableLayers(bool);
      } 
      if (this.mOnPageChangeListener != null)
        this.mOnPageChangeListener.onPageScrollStateChanged(paramInt); 
    } 
  }
  
  private void setScrollingCacheEnabled(boolean paramBoolean) {
    if (this.mScrollingCacheEnabled != paramBoolean)
      this.mScrollingCacheEnabled = paramBoolean; 
  }
  
  public void addFocusables(ArrayList<View> paramArrayList, int paramInt1, int paramInt2) {
    int i = paramArrayList.size();
    int j = getDescendantFocusability();
    if (j != 393216)
      for (byte b = 0; b < getChildCount(); b++) {
        View view = getChildAt(b);
        if (view.getVisibility() == 0) {
          ItemInfo itemInfo = infoForChild(view);
          if (itemInfo != null && itemInfo.position == this.mCurItem)
            view.addFocusables(paramArrayList, paramInt1, paramInt2); 
        } 
      }  
    if ((j != 262144 || i == paramArrayList.size()) && isFocusable() && ((paramInt2 & 0x1) != 1 || !isInTouchMode() || isFocusableInTouchMode()) && paramArrayList != null)
      paramArrayList.add(this); 
  }
  
  ItemInfo addNewItem(int paramInt1, int paramInt2) {
    ItemInfo itemInfo = new ItemInfo();
    itemInfo.position = paramInt1;
    itemInfo.object = this.mAdapter.instantiateItem(this, paramInt1);
    itemInfo.widthFactor = this.mAdapter.getPageWidth(paramInt1);
    if (paramInt2 < 0 || paramInt2 >= this.mItems.size()) {
      this.mItems.add(itemInfo);
      return itemInfo;
    } 
    this.mItems.add(paramInt2, itemInfo);
    return itemInfo;
  }
  
  public void addTouchables(ArrayList<View> paramArrayList) {
    for (byte b = 0; b < getChildCount(); b++) {
      View view = getChildAt(b);
      if (view.getVisibility() == 0) {
        ItemInfo itemInfo = infoForChild(view);
        if (itemInfo != null && itemInfo.position == this.mCurItem)
          view.addTouchables(paramArrayList); 
      } 
    } 
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    ViewGroup.LayoutParams layoutParams = paramLayoutParams;
    if (!checkLayoutParams(paramLayoutParams))
      layoutParams = generateLayoutParams(paramLayoutParams); 
    paramLayoutParams = layoutParams;
    ((LayoutParams)paramLayoutParams).isDecor |= paramView instanceof Decor;
    if (this.mInLayout) {
      if (paramLayoutParams != null && ((LayoutParams)paramLayoutParams).isDecor)
        throw new IllegalStateException("Cannot add pager decor view during layout"); 
      ((LayoutParams)paramLayoutParams).needsMeasure = true;
      addViewInLayout(paramView, paramInt, layoutParams);
      return;
    } 
    super.addView(paramView, paramInt, layoutParams);
  }
  
  public boolean arrowScroll(int paramInt) {
    View view1 = findFocus();
    View view2 = view1;
    if (view1 == this)
      view2 = null; 
    boolean bool = false;
    view1 = FocusFinder.getInstance().findNextFocus(this, view2, paramInt);
    if (view1 != null && view1 != view2) {
      if (paramInt == 17) {
        int i = (getChildRectInPagerCoordinates(this.mTempRect, view1)).left;
        int j = (getChildRectInPagerCoordinates(this.mTempRect, view2)).left;
        if (view2 != null && i >= j) {
          bool = pageLeft();
        } else {
          bool = view1.requestFocus();
        } 
      } else if (paramInt == 66) {
        int j = (getChildRectInPagerCoordinates(this.mTempRect, view1)).left;
        int i = (getChildRectInPagerCoordinates(this.mTempRect, view2)).left;
        if (view2 != null && j <= i) {
          bool = pageRight();
        } else {
          bool = view1.requestFocus();
        } 
      } 
    } else if (paramInt == 17 || paramInt == 1) {
      bool = pageLeft();
    } else if (paramInt == 66 || paramInt == 2) {
      bool = pageRight();
    } 
    if (bool)
      playSoundEffect(SoundEffectConstants.getContantForFocusDirection(paramInt)); 
    return bool;
  }
  
  public boolean beginFakeDrag() {
    boolean bool = false;
    if (!this.mIsBeingDragged) {
      this.mFakeDragging = true;
      setScrollState(1);
      this.mLastMotionX = 0.0F;
      this.mInitialMotionX = 0.0F;
      if (this.mVelocityTracker == null) {
        this.mVelocityTracker = VelocityTracker.obtain();
      } else {
        this.mVelocityTracker.clear();
      } 
      long l = SystemClock.uptimeMillis();
      MotionEvent motionEvent = MotionEvent.obtain(l, l, 0, 0.0F, 0.0F, 0);
      this.mVelocityTracker.addMovement(motionEvent);
      motionEvent.recycle();
      this.mFakeDragBeginTime = l;
      bool = true;
    } 
    return bool;
  }
  
  protected boolean canScroll(View paramView, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3) {
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      int i = paramView.getScrollX();
      int j = paramView.getScrollY();
      for (int k = viewGroup.getChildCount() - 1; k >= 0; k--) {
        View view = viewGroup.getChildAt(k);
        if (paramInt2 + i >= view.getLeft() && paramInt2 + i < view.getRight() && paramInt3 + j >= view.getTop() && paramInt3 + j < view.getBottom() && canScroll(view, true, paramInt1, paramInt2 + i - view.getLeft(), paramInt3 + j - view.getTop()))
          return true; 
      } 
    } 
    return (paramBoolean && ViewCompat.canScrollHorizontally(paramView, -paramInt1));
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof LayoutParams && super.checkLayoutParams(paramLayoutParams));
  }
  
  public void computeScroll() {
    if (!this.mScroller.isFinished() && this.mScroller.computeScrollOffset()) {
      int i = getScrollX();
      int j = getScrollY();
      int k = this.mScroller.getCurrX();
      int m = this.mScroller.getCurrY();
      if (i != k || j != m) {
        scrollTo(k, m);
        if (!pageScrolled(k)) {
          this.mScroller.abortAnimation();
          scrollTo(0, m);
        } 
      } 
      ViewCompat.postInvalidateOnAnimation((View)this);
      return;
    } 
    completeScroll(true);
  }
  
  void dataSetChanged() {
    byte b;
    if (this.mItems.size() < this.mOffscreenPageLimit * 2 + 1 && this.mItems.size() < this.mAdapter.getCount()) {
      b = 1;
    } else {
      b = 0;
    } 
    int i = this.mCurItem;
    int j = 0;
    int k = 0;
    while (k < this.mItems.size()) {
      int n;
      int i1;
      int i2;
      ItemInfo itemInfo = this.mItems.get(k);
      int m = this.mAdapter.getItemPosition(itemInfo.object);
      if (m == -1) {
        n = i;
        i1 = j;
        i2 = k;
      } else if (m == -2) {
        this.mItems.remove(k);
        m = k - 1;
        k = j;
        if (!j) {
          this.mAdapter.startUpdate(this);
          k = 1;
        } 
        this.mAdapter.destroyItem(this, itemInfo.position, itemInfo.object);
        b = 1;
        i2 = m;
        i1 = k;
        n = i;
        if (this.mCurItem == itemInfo.position) {
          n = Math.max(0, Math.min(this.mCurItem, this.mAdapter.getCount() - 1));
          b = 1;
          i2 = m;
          i1 = k;
        } 
      } else {
        i2 = k;
        i1 = j;
        n = i;
        if (itemInfo.position != m) {
          if (itemInfo.position == this.mCurItem)
            i = m; 
          itemInfo.position = m;
          b = 1;
          i2 = k;
          i1 = j;
          n = i;
        } 
      } 
      k = i2 + 1;
      j = i1;
      i = n;
    } 
    if (j != 0)
      this.mAdapter.finishUpdate(this); 
    Collections.sort(this.mItems, COMPARATOR);
    if (b) {
      j = getChildCount();
      for (b = 0; b < j; b++) {
        LayoutParams layoutParams = (LayoutParams)getChildAt(b).getLayoutParams();
        if (!layoutParams.isDecor)
          layoutParams.widthFactor = 0.0F; 
      } 
      setCurrentItemInternal(i, false, true);
      requestLayout();
    } 
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return (super.dispatchKeyEvent(paramKeyEvent) || executeKeyEvent(paramKeyEvent));
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getChildCount : ()I
    //   4: istore_2
    //   5: iconst_0
    //   6: istore_3
    //   7: iload_3
    //   8: iload_2
    //   9: if_icmpge -> 73
    //   12: aload_0
    //   13: iload_3
    //   14: invokevirtual getChildAt : (I)Landroid/view/View;
    //   17: astore #4
    //   19: aload #4
    //   21: invokevirtual getVisibility : ()I
    //   24: ifne -> 67
    //   27: aload_0
    //   28: aload #4
    //   30: invokevirtual infoForChild : (Landroid/view/View;)Landroid/support/v4/view/ViewPager$ItemInfo;
    //   33: astore #5
    //   35: aload #5
    //   37: ifnull -> 67
    //   40: aload #5
    //   42: getfield position : I
    //   45: aload_0
    //   46: getfield mCurItem : I
    //   49: if_icmpne -> 67
    //   52: aload #4
    //   54: aload_1
    //   55: invokevirtual dispatchPopulateAccessibilityEvent : (Landroid/view/accessibility/AccessibilityEvent;)Z
    //   58: ifeq -> 67
    //   61: iconst_1
    //   62: istore #6
    //   64: iload #6
    //   66: ireturn
    //   67: iinc #3, 1
    //   70: goto -> 7
    //   73: iconst_0
    //   74: istore #6
    //   76: goto -> 64
  }
  
  float distanceInfluenceForSnapDuration(float paramFloat) {
    return (float)Math.sin((float)((paramFloat - 0.5F) * 0.4712389167638204D));
  }
  
  public void draw(Canvas paramCanvas) {
    boolean bool;
    super.draw(paramCanvas);
    int i = 0;
    int j = 0;
    int k = ViewCompat.getOverScrollMode((View)this);
    if (k == 0 || (k == 1 && this.mAdapter != null && this.mAdapter.getCount() > 1)) {
      if (!this.mLeftEdge.isFinished()) {
        i = paramCanvas.save();
        j = getHeight() - getPaddingTop() - getPaddingBottom();
        k = getWidth();
        paramCanvas.rotate(270.0F);
        paramCanvas.translate((-j + getPaddingTop()), this.mFirstOffset * k);
        this.mLeftEdge.setSize(j, k);
        j = false | this.mLeftEdge.draw(paramCanvas);
        paramCanvas.restoreToCount(i);
      } 
      i = j;
      if (!this.mRightEdge.isFinished()) {
        k = paramCanvas.save();
        i = getWidth();
        int m = getHeight();
        int n = getPaddingTop();
        int i1 = getPaddingBottom();
        paramCanvas.rotate(90.0F);
        paramCanvas.translate(-getPaddingTop(), -(this.mLastOffset + 1.0F) * i);
        this.mRightEdge.setSize(m - n - i1, i);
        bool = j | this.mRightEdge.draw(paramCanvas);
        paramCanvas.restoreToCount(k);
      } 
    } else {
      this.mLeftEdge.finish();
      this.mRightEdge.finish();
    } 
    if (bool)
      ViewCompat.postInvalidateOnAnimation((View)this); 
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    Drawable drawable = this.mMarginDrawable;
    if (drawable != null && drawable.isStateful())
      drawable.setState(getDrawableState()); 
  }
  
  public void endFakeDrag() {
    if (!this.mFakeDragging)
      throw new IllegalStateException("No fake drag in progress. Call beginFakeDrag first."); 
    VelocityTracker velocityTracker = this.mVelocityTracker;
    velocityTracker.computeCurrentVelocity(1000, this.mMaximumVelocity);
    int i = (int)VelocityTrackerCompat.getXVelocity(velocityTracker, this.mActivePointerId);
    this.mPopulatePending = true;
    int j = getWidth();
    int k = getScrollX();
    ItemInfo itemInfo = infoForCurrentScrollPosition();
    setCurrentItemInternal(determineTargetPage(itemInfo.position, (k / j - itemInfo.offset) / itemInfo.widthFactor, i, (int)(this.mLastMotionX - this.mInitialMotionX)), true, true, i);
    endDrag();
    this.mFakeDragging = false;
  }
  
  public boolean executeKeyEvent(KeyEvent paramKeyEvent) {
    boolean bool1 = false;
    boolean bool2 = bool1;
    if (paramKeyEvent.getAction() == 0) {
      switch (paramKeyEvent.getKeyCode()) {
        default:
          return bool1;
        case 21:
          return arrowScroll(17);
        case 22:
          return arrowScroll(66);
        case 61:
          break;
      } 
    } else {
      return bool2;
    } 
    bool2 = bool1;
    if (Build.VERSION.SDK_INT >= 11) {
      if (KeyEventCompat.hasNoModifiers(paramKeyEvent))
        return arrowScroll(2); 
      bool2 = bool1;
      if (KeyEventCompat.hasModifiers(paramKeyEvent, 1))
        bool2 = arrowScroll(1); 
    } 
    return bool2;
  }
  
  public void fakeDragBy(float paramFloat) {
    if (!this.mFakeDragging)
      throw new IllegalStateException("No fake drag in progress. Call beginFakeDrag first."); 
    this.mLastMotionX += paramFloat;
    float f1 = getScrollX() - paramFloat;
    int i = getWidth();
    paramFloat = i * this.mFirstOffset;
    float f2 = i * this.mLastOffset;
    ItemInfo itemInfo1 = this.mItems.get(0);
    ItemInfo itemInfo2 = this.mItems.get(this.mItems.size() - 1);
    if (itemInfo1.position != 0)
      paramFloat = itemInfo1.offset * i; 
    if (itemInfo2.position != this.mAdapter.getCount() - 1)
      f2 = itemInfo2.offset * i; 
    if (f1 >= paramFloat) {
      paramFloat = f1;
      if (f1 > f2)
        paramFloat = f2; 
    } 
    this.mLastMotionX += paramFloat - (int)paramFloat;
    scrollTo((int)paramFloat, getScrollY());
    pageScrolled((int)paramFloat);
    long l = SystemClock.uptimeMillis();
    MotionEvent motionEvent = MotionEvent.obtain(this.mFakeDragBeginTime, l, 2, this.mLastMotionX, 0.0F, 0);
    this.mVelocityTracker.addMovement(motionEvent);
    motionEvent.recycle();
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return new LayoutParams();
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return generateDefaultLayoutParams();
  }
  
  public PagerAdapter getAdapter() {
    return this.mAdapter;
  }
  
  protected int getChildDrawingOrder(int paramInt1, int paramInt2) {
    if (this.mDrawingOrder == 2)
      paramInt2 = paramInt1 - 1 - paramInt2; 
    return ((LayoutParams)((View)this.mDrawingOrderedChildren.get(paramInt2)).getLayoutParams()).childIndex;
  }
  
  public int getCurrentItem() {
    return this.mCurItem;
  }
  
  public int getOffscreenPageLimit() {
    return this.mOffscreenPageLimit;
  }
  
  public int getPageMargin() {
    return this.mPageMargin;
  }
  
  ItemInfo infoForAnyChild(View paramView) {
    while (true) {
      ViewParent viewParent = paramView.getParent();
      if (viewParent != this) {
        if (viewParent == null || !(viewParent instanceof View))
          return null; 
        paramView = (View)viewParent;
        continue;
      } 
      return infoForChild(paramView);
    } 
  }
  
  ItemInfo infoForChild(View paramView) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: iload_2
    //   3: aload_0
    //   4: getfield mItems : Ljava/util/ArrayList;
    //   7: invokevirtual size : ()I
    //   10: if_icmpge -> 50
    //   13: aload_0
    //   14: getfield mItems : Ljava/util/ArrayList;
    //   17: iload_2
    //   18: invokevirtual get : (I)Ljava/lang/Object;
    //   21: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   24: astore_3
    //   25: aload_0
    //   26: getfield mAdapter : Landroid/support/v4/view/PagerAdapter;
    //   29: aload_1
    //   30: aload_3
    //   31: getfield object : Ljava/lang/Object;
    //   34: invokevirtual isViewFromObject : (Landroid/view/View;Ljava/lang/Object;)Z
    //   37: ifeq -> 44
    //   40: aload_3
    //   41: astore_1
    //   42: aload_1
    //   43: areturn
    //   44: iinc #2, 1
    //   47: goto -> 2
    //   50: aconst_null
    //   51: astore_1
    //   52: goto -> 42
  }
  
  ItemInfo infoForPosition(int paramInt) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: iload_2
    //   3: aload_0
    //   4: getfield mItems : Ljava/util/ArrayList;
    //   7: invokevirtual size : ()I
    //   10: if_icmpge -> 41
    //   13: aload_0
    //   14: getfield mItems : Ljava/util/ArrayList;
    //   17: iload_2
    //   18: invokevirtual get : (I)Ljava/lang/Object;
    //   21: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   24: astore_3
    //   25: aload_3
    //   26: getfield position : I
    //   29: iload_1
    //   30: if_icmpne -> 35
    //   33: aload_3
    //   34: areturn
    //   35: iinc #2, 1
    //   38: goto -> 2
    //   41: aconst_null
    //   42: astore_3
    //   43: goto -> 33
  }
  
  void initViewPager() {
    setWillNotDraw(false);
    setDescendantFocusability(262144);
    setFocusable(true);
    Context context = getContext();
    this.mScroller = new Scroller(context, sInterpolator);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
    this.mTouchSlop = ViewConfigurationCompat.getScaledPagingTouchSlop(viewConfiguration);
    this.mMinimumVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
    this.mMaximumVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
    this.mLeftEdge = new EdgeEffectCompat(context);
    this.mRightEdge = new EdgeEffectCompat(context);
    float f = (context.getResources().getDisplayMetrics()).density;
    this.mFlingDistance = (int)(25.0F * f);
    this.mCloseEnough = (int)(2.0F * f);
    this.mDefaultGutterSize = (int)(16.0F * f);
    ViewCompat.setAccessibilityDelegate((View)this, new MyAccessibilityDelegate());
    if (ViewCompat.getImportantForAccessibility((View)this) == 0)
      ViewCompat.setImportantForAccessibility((View)this, 1); 
  }
  
  public boolean isFakeDragging() {
    return this.mFakeDragging;
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.mFirstLayout = true;
  }
  
  protected void onDetachedFromWindow() {
    removeCallbacks(this.mEndScrollRunnable);
    super.onDetachedFromWindow();
  }
  
  protected void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.mPageMargin > 0 && this.mMarginDrawable != null && this.mItems.size() > 0 && this.mAdapter != null) {
      int i = getScrollX();
      int j = getWidth();
      float f1 = this.mPageMargin / j;
      byte b = 0;
      ItemInfo itemInfo = this.mItems.get(0);
      float f2 = itemInfo.offset;
      int k = this.mItems.size();
      int m = itemInfo.position;
      int n = ((ItemInfo)this.mItems.get(k - 1)).position;
      while (true) {
        if (m < n) {
          ItemInfo itemInfo1;
          float f;
          while (m > itemInfo.position && b < k) {
            ArrayList<ItemInfo> arrayList = this.mItems;
            itemInfo1 = arrayList.get(++b);
          } 
          if (m == itemInfo1.position) {
            f = (itemInfo1.offset + itemInfo1.widthFactor) * j;
            f2 = itemInfo1.offset + itemInfo1.widthFactor + f1;
          } else {
            float f3 = this.mAdapter.getPageWidth(m);
            f = (f2 + f3) * j;
            f2 += f3 + f1;
          } 
          if (this.mPageMargin + f > i) {
            this.mMarginDrawable.setBounds((int)f, this.mTopPageBounds, (int)(this.mPageMargin + f + 0.5F), this.mBottomPageBounds);
            this.mMarginDrawable.draw(paramCanvas);
          } 
          if (f <= (i + j)) {
            m++;
            continue;
          } 
        } 
        return;
      } 
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    float f;
    int i = paramMotionEvent.getAction() & 0xFF;
    if (i == 3 || i == 1) {
      this.mIsBeingDragged = false;
      this.mIsUnableToDrag = false;
      this.mActivePointerId = -1;
      if (this.mVelocityTracker != null) {
        this.mVelocityTracker.recycle();
        this.mVelocityTracker = null;
      } 
      return false;
    } 
    if (i != 0) {
      if (this.mIsBeingDragged)
        return true; 
      if (this.mIsUnableToDrag)
        return false; 
    } 
    switch (i) {
      default:
        if (this.mVelocityTracker == null)
          this.mVelocityTracker = VelocityTracker.obtain(); 
        this.mVelocityTracker.addMovement(paramMotionEvent);
        return this.mIsBeingDragged;
      case 2:
        i = this.mActivePointerId;
        if (i != -1) {
          i = MotionEventCompat.findPointerIndex(paramMotionEvent, i);
          float f1 = MotionEventCompat.getX(paramMotionEvent, i);
          float f2 = f1 - this.mLastMotionX;
          float f3 = Math.abs(f2);
          float f4 = MotionEventCompat.getY(paramMotionEvent, i);
          float f5 = Math.abs(f4 - this.mLastMotionY);
          if (f2 != 0.0F && !isGutterDrag(this.mLastMotionX, f2) && canScroll((View)this, false, (int)f2, (int)f1, (int)f4)) {
            this.mLastMotionX = f1;
            this.mInitialMotionX = f1;
            this.mLastMotionY = f4;
            this.mIsUnableToDrag = true;
            return false;
          } 
          if (f3 > this.mTouchSlop && f3 > f5) {
            this.mIsBeingDragged = true;
            setScrollState(1);
            if (f2 > 0.0F) {
              f3 = this.mInitialMotionX + this.mTouchSlop;
            } else {
              f3 = this.mInitialMotionX - this.mTouchSlop;
            } 
            this.mLastMotionX = f3;
            setScrollingCacheEnabled(true);
          } else if (f5 > this.mTouchSlop) {
            this.mIsUnableToDrag = true;
          } 
          if (this.mIsBeingDragged && performDrag(f1))
            ViewCompat.postInvalidateOnAnimation((View)this); 
        } 
      case 0:
        f = paramMotionEvent.getX();
        this.mInitialMotionX = f;
        this.mLastMotionX = f;
        this.mLastMotionY = paramMotionEvent.getY();
        this.mActivePointerId = MotionEventCompat.getPointerId(paramMotionEvent, 0);
        this.mIsUnableToDrag = false;
        this.mScroller.computeScrollOffset();
        if (this.mScrollState == 2 && Math.abs(this.mScroller.getFinalX() - this.mScroller.getCurrX()) > this.mCloseEnough) {
          this.mScroller.abortAnimation();
          this.mPopulatePending = false;
          populate();
          this.mIsBeingDragged = true;
          setScrollState(1);
        } else {
          completeScroll(false);
          this.mIsBeingDragged = false;
        } 
      case 6:
        break;
    } 
    onSecondaryPointerUp(paramMotionEvent);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_1
    //   2: putfield mInLayout : Z
    //   5: aload_0
    //   6: invokevirtual populate : ()V
    //   9: aload_0
    //   10: iconst_0
    //   11: putfield mInLayout : Z
    //   14: aload_0
    //   15: invokevirtual getChildCount : ()I
    //   18: istore #6
    //   20: iload #4
    //   22: iload_2
    //   23: isub
    //   24: istore #7
    //   26: iload #5
    //   28: iload_3
    //   29: isub
    //   30: istore #8
    //   32: aload_0
    //   33: invokevirtual getPaddingLeft : ()I
    //   36: istore_3
    //   37: aload_0
    //   38: invokevirtual getPaddingTop : ()I
    //   41: istore_2
    //   42: aload_0
    //   43: invokevirtual getPaddingRight : ()I
    //   46: istore #9
    //   48: aload_0
    //   49: invokevirtual getPaddingBottom : ()I
    //   52: istore #5
    //   54: aload_0
    //   55: invokevirtual getScrollX : ()I
    //   58: istore #10
    //   60: iconst_0
    //   61: istore #11
    //   63: iconst_0
    //   64: istore #12
    //   66: iload #12
    //   68: iload #6
    //   70: if_icmpge -> 439
    //   73: aload_0
    //   74: iload #12
    //   76: invokevirtual getChildAt : (I)Landroid/view/View;
    //   79: astore #13
    //   81: iload #11
    //   83: istore #14
    //   85: iload #5
    //   87: istore #15
    //   89: iload_3
    //   90: istore #16
    //   92: iload #9
    //   94: istore #17
    //   96: iload_2
    //   97: istore #4
    //   99: aload #13
    //   101: invokevirtual getVisibility : ()I
    //   104: bipush #8
    //   106: if_icmpeq -> 293
    //   109: aload #13
    //   111: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   114: checkcast android/support/v4/view/ViewPager$LayoutParams
    //   117: astore #18
    //   119: iload #11
    //   121: istore #14
    //   123: iload #5
    //   125: istore #15
    //   127: iload_3
    //   128: istore #16
    //   130: iload #9
    //   132: istore #17
    //   134: iload_2
    //   135: istore #4
    //   137: aload #18
    //   139: getfield isDecor : Z
    //   142: ifeq -> 293
    //   145: aload #18
    //   147: getfield gravity : I
    //   150: istore #4
    //   152: aload #18
    //   154: getfield gravity : I
    //   157: istore #17
    //   159: iload #4
    //   161: bipush #7
    //   163: iand
    //   164: tableswitch default -> 200, 1 -> 332, 2 -> 200, 3 -> 317, 4 -> 200, 5 -> 354
    //   200: iload_3
    //   201: istore #4
    //   203: iload_3
    //   204: istore #16
    //   206: iload #17
    //   208: bipush #112
    //   210: iand
    //   211: lookupswitch default -> 244, 16 -> 396, 48 -> 383, 80 -> 414
    //   244: iload_2
    //   245: istore_3
    //   246: iload #4
    //   248: iload #10
    //   250: iadd
    //   251: istore #4
    //   253: aload #13
    //   255: iload #4
    //   257: iload_3
    //   258: aload #13
    //   260: invokevirtual getMeasuredWidth : ()I
    //   263: iload #4
    //   265: iadd
    //   266: aload #13
    //   268: invokevirtual getMeasuredHeight : ()I
    //   271: iload_3
    //   272: iadd
    //   273: invokevirtual layout : (IIII)V
    //   276: iload #11
    //   278: iconst_1
    //   279: iadd
    //   280: istore #14
    //   282: iload_2
    //   283: istore #4
    //   285: iload #9
    //   287: istore #17
    //   289: iload #5
    //   291: istore #15
    //   293: iinc #12, 1
    //   296: iload #14
    //   298: istore #11
    //   300: iload #15
    //   302: istore #5
    //   304: iload #16
    //   306: istore_3
    //   307: iload #17
    //   309: istore #9
    //   311: iload #4
    //   313: istore_2
    //   314: goto -> 66
    //   317: iload_3
    //   318: istore #4
    //   320: iload_3
    //   321: aload #13
    //   323: invokevirtual getMeasuredWidth : ()I
    //   326: iadd
    //   327: istore #16
    //   329: goto -> 206
    //   332: iload #7
    //   334: aload #13
    //   336: invokevirtual getMeasuredWidth : ()I
    //   339: isub
    //   340: iconst_2
    //   341: idiv
    //   342: iload_3
    //   343: invokestatic max : (II)I
    //   346: istore #4
    //   348: iload_3
    //   349: istore #16
    //   351: goto -> 206
    //   354: iload #7
    //   356: iload #9
    //   358: isub
    //   359: aload #13
    //   361: invokevirtual getMeasuredWidth : ()I
    //   364: isub
    //   365: istore #4
    //   367: iload #9
    //   369: aload #13
    //   371: invokevirtual getMeasuredWidth : ()I
    //   374: iadd
    //   375: istore #9
    //   377: iload_3
    //   378: istore #16
    //   380: goto -> 206
    //   383: iload_2
    //   384: istore_3
    //   385: iload_2
    //   386: aload #13
    //   388: invokevirtual getMeasuredHeight : ()I
    //   391: iadd
    //   392: istore_2
    //   393: goto -> 246
    //   396: iload #8
    //   398: aload #13
    //   400: invokevirtual getMeasuredHeight : ()I
    //   403: isub
    //   404: iconst_2
    //   405: idiv
    //   406: iload_2
    //   407: invokestatic max : (II)I
    //   410: istore_3
    //   411: goto -> 246
    //   414: iload #8
    //   416: iload #5
    //   418: isub
    //   419: aload #13
    //   421: invokevirtual getMeasuredHeight : ()I
    //   424: isub
    //   425: istore_3
    //   426: iload #5
    //   428: aload #13
    //   430: invokevirtual getMeasuredHeight : ()I
    //   433: iadd
    //   434: istore #5
    //   436: goto -> 246
    //   439: iconst_0
    //   440: istore #4
    //   442: iload #4
    //   444: iload #6
    //   446: if_icmpge -> 594
    //   449: aload_0
    //   450: iload #4
    //   452: invokevirtual getChildAt : (I)Landroid/view/View;
    //   455: astore #18
    //   457: aload #18
    //   459: invokevirtual getVisibility : ()I
    //   462: bipush #8
    //   464: if_icmpeq -> 588
    //   467: aload #18
    //   469: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   472: checkcast android/support/v4/view/ViewPager$LayoutParams
    //   475: astore #19
    //   477: aload #19
    //   479: getfield isDecor : Z
    //   482: ifne -> 588
    //   485: aload_0
    //   486: aload #18
    //   488: invokevirtual infoForChild : (Landroid/view/View;)Landroid/support/v4/view/ViewPager$ItemInfo;
    //   491: astore #13
    //   493: aload #13
    //   495: ifnull -> 588
    //   498: iload_3
    //   499: iload #7
    //   501: i2f
    //   502: aload #13
    //   504: getfield offset : F
    //   507: fmul
    //   508: f2i
    //   509: iadd
    //   510: istore #16
    //   512: aload #19
    //   514: getfield needsMeasure : Z
    //   517: ifeq -> 565
    //   520: aload #19
    //   522: iconst_0
    //   523: putfield needsMeasure : Z
    //   526: aload #18
    //   528: iload #7
    //   530: iload_3
    //   531: isub
    //   532: iload #9
    //   534: isub
    //   535: i2f
    //   536: aload #19
    //   538: getfield widthFactor : F
    //   541: fmul
    //   542: f2i
    //   543: ldc_w 1073741824
    //   546: invokestatic makeMeasureSpec : (II)I
    //   549: iload #8
    //   551: iload_2
    //   552: isub
    //   553: iload #5
    //   555: isub
    //   556: ldc_w 1073741824
    //   559: invokestatic makeMeasureSpec : (II)I
    //   562: invokevirtual measure : (II)V
    //   565: aload #18
    //   567: iload #16
    //   569: iload_2
    //   570: aload #18
    //   572: invokevirtual getMeasuredWidth : ()I
    //   575: iload #16
    //   577: iadd
    //   578: aload #18
    //   580: invokevirtual getMeasuredHeight : ()I
    //   583: iload_2
    //   584: iadd
    //   585: invokevirtual layout : (IIII)V
    //   588: iinc #4, 1
    //   591: goto -> 442
    //   594: aload_0
    //   595: iload_2
    //   596: putfield mTopPageBounds : I
    //   599: aload_0
    //   600: iload #8
    //   602: iload #5
    //   604: isub
    //   605: putfield mBottomPageBounds : I
    //   608: aload_0
    //   609: iload #11
    //   611: putfield mDecorChildCount : I
    //   614: aload_0
    //   615: iconst_0
    //   616: putfield mFirstLayout : Z
    //   619: return
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    setMeasuredDimension(getDefaultSize(0, paramInt1), getDefaultSize(0, paramInt2));
    paramInt1 = getMeasuredWidth();
    this.mGutterSize = Math.min(paramInt1 / 10, this.mDefaultGutterSize);
    paramInt1 = paramInt1 - getPaddingLeft() - getPaddingRight();
    paramInt2 = getMeasuredHeight() - getPaddingTop() - getPaddingBottom();
    int i = getChildCount();
    byte b = 0;
    while (b < i) {
      View view = getChildAt(b);
      int k = paramInt2;
      int m = paramInt1;
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        k = paramInt2;
        m = paramInt1;
        if (layoutParams != null) {
          k = paramInt2;
          m = paramInt1;
          if (layoutParams.isDecor) {
            boolean bool;
            k = layoutParams.gravity & 0x7;
            int n = layoutParams.gravity & 0x70;
            int i1 = Integer.MIN_VALUE;
            m = Integer.MIN_VALUE;
            if (n == 48 || n == 80) {
              n = 1;
            } else {
              n = 0;
            } 
            if (k == 3 || k == 5) {
              bool = true;
            } else {
              bool = false;
            } 
            if (n != 0) {
              k = 1073741824;
            } else {
              k = i1;
              if (bool) {
                m = 1073741824;
                k = i1;
              } 
            } 
            int i2 = paramInt1;
            i1 = paramInt2;
            int i3 = i2;
            if (layoutParams.width != -2) {
              int i4 = 1073741824;
              k = i4;
              i3 = i2;
              if (layoutParams.width != -1) {
                i3 = layoutParams.width;
                k = i4;
              } 
            } 
            i2 = i1;
            if (layoutParams.height != -2) {
              int i4 = 1073741824;
              m = i4;
              i2 = i1;
              if (layoutParams.height != -1) {
                i2 = layoutParams.height;
                m = i4;
              } 
            } 
            view.measure(View.MeasureSpec.makeMeasureSpec(i3, k), View.MeasureSpec.makeMeasureSpec(i2, m));
            if (n != 0) {
              k = paramInt2 - view.getMeasuredHeight();
              m = paramInt1;
            } else {
              k = paramInt2;
              m = paramInt1;
              if (bool) {
                m = paramInt1 - view.getMeasuredWidth();
                k = paramInt2;
              } 
            } 
          } 
        } 
      } 
      b++;
      paramInt2 = k;
      paramInt1 = m;
    } 
    this.mChildWidthMeasureSpec = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
    this.mChildHeightMeasureSpec = View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824);
    this.mInLayout = true;
    populate();
    this.mInLayout = false;
    int j = getChildCount();
    for (paramInt2 = 0; paramInt2 < j; paramInt2++) {
      View view = getChildAt(paramInt2);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams == null || !layoutParams.isDecor)
          view.measure(View.MeasureSpec.makeMeasureSpec((int)(paramInt1 * layoutParams.widthFactor), 1073741824), this.mChildHeightMeasureSpec); 
      } 
    } 
  }
  
  protected void onPageScrolled(int paramInt1, float paramFloat, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mDecorChildCount : I
    //   4: ifle -> 247
    //   7: aload_0
    //   8: invokevirtual getScrollX : ()I
    //   11: istore #4
    //   13: aload_0
    //   14: invokevirtual getPaddingLeft : ()I
    //   17: istore #5
    //   19: aload_0
    //   20: invokevirtual getPaddingRight : ()I
    //   23: istore #6
    //   25: aload_0
    //   26: invokevirtual getWidth : ()I
    //   29: istore #7
    //   31: aload_0
    //   32: invokevirtual getChildCount : ()I
    //   35: istore #8
    //   37: iconst_0
    //   38: istore #9
    //   40: iload #9
    //   42: iload #8
    //   44: if_icmpge -> 247
    //   47: aload_0
    //   48: iload #9
    //   50: invokevirtual getChildAt : (I)Landroid/view/View;
    //   53: astore #10
    //   55: aload #10
    //   57: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   60: checkcast android/support/v4/view/ViewPager$LayoutParams
    //   63: astore #11
    //   65: aload #11
    //   67: getfield isDecor : Z
    //   70: ifne -> 95
    //   73: iload #6
    //   75: istore #12
    //   77: iload #5
    //   79: istore #13
    //   81: iinc #9, 1
    //   84: iload #13
    //   86: istore #5
    //   88: iload #12
    //   90: istore #6
    //   92: goto -> 40
    //   95: aload #11
    //   97: getfield gravity : I
    //   100: bipush #7
    //   102: iand
    //   103: tableswitch default -> 136, 1 -> 201, 2 -> 136, 3 -> 184, 4 -> 136, 5 -> 221
    //   136: iload #5
    //   138: istore #12
    //   140: iload #12
    //   142: iload #4
    //   144: iadd
    //   145: aload #10
    //   147: invokevirtual getLeft : ()I
    //   150: isub
    //   151: istore #14
    //   153: iload #5
    //   155: istore #13
    //   157: iload #6
    //   159: istore #12
    //   161: iload #14
    //   163: ifeq -> 81
    //   166: aload #10
    //   168: iload #14
    //   170: invokevirtual offsetLeftAndRight : (I)V
    //   173: iload #5
    //   175: istore #13
    //   177: iload #6
    //   179: istore #12
    //   181: goto -> 81
    //   184: iload #5
    //   186: istore #12
    //   188: iload #5
    //   190: aload #10
    //   192: invokevirtual getWidth : ()I
    //   195: iadd
    //   196: istore #5
    //   198: goto -> 140
    //   201: iload #7
    //   203: aload #10
    //   205: invokevirtual getMeasuredWidth : ()I
    //   208: isub
    //   209: iconst_2
    //   210: idiv
    //   211: iload #5
    //   213: invokestatic max : (II)I
    //   216: istore #12
    //   218: goto -> 140
    //   221: iload #7
    //   223: iload #6
    //   225: isub
    //   226: aload #10
    //   228: invokevirtual getMeasuredWidth : ()I
    //   231: isub
    //   232: istore #12
    //   234: iload #6
    //   236: aload #10
    //   238: invokevirtual getMeasuredWidth : ()I
    //   241: iadd
    //   242: istore #6
    //   244: goto -> 140
    //   247: aload_0
    //   248: getfield mSeenPositionMin : I
    //   251: iflt -> 262
    //   254: iload_1
    //   255: aload_0
    //   256: getfield mSeenPositionMin : I
    //   259: if_icmpge -> 267
    //   262: aload_0
    //   263: iload_1
    //   264: putfield mSeenPositionMin : I
    //   267: aload_0
    //   268: getfield mSeenPositionMax : I
    //   271: iflt -> 290
    //   274: iload_1
    //   275: i2f
    //   276: fload_2
    //   277: fadd
    //   278: invokestatic ceil : (F)F
    //   281: aload_0
    //   282: getfield mSeenPositionMax : I
    //   285: i2f
    //   286: fcmpl
    //   287: ifle -> 297
    //   290: aload_0
    //   291: iload_1
    //   292: iconst_1
    //   293: iadd
    //   294: putfield mSeenPositionMax : I
    //   297: aload_0
    //   298: getfield mOnPageChangeListener : Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    //   301: ifnull -> 316
    //   304: aload_0
    //   305: getfield mOnPageChangeListener : Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    //   308: iload_1
    //   309: fload_2
    //   310: iload_3
    //   311: invokeinterface onPageScrolled : (IFI)V
    //   316: aload_0
    //   317: getfield mInternalPageChangeListener : Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    //   320: ifnull -> 335
    //   323: aload_0
    //   324: getfield mInternalPageChangeListener : Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    //   327: iload_1
    //   328: fload_2
    //   329: iload_3
    //   330: invokeinterface onPageScrolled : (IFI)V
    //   335: aload_0
    //   336: getfield mPageTransformer : Landroid/support/v4/view/ViewPager$PageTransformer;
    //   339: ifnull -> 418
    //   342: aload_0
    //   343: invokevirtual getScrollX : ()I
    //   346: istore #5
    //   348: aload_0
    //   349: invokevirtual getChildCount : ()I
    //   352: istore_3
    //   353: iconst_0
    //   354: istore_1
    //   355: iload_1
    //   356: iload_3
    //   357: if_icmpge -> 418
    //   360: aload_0
    //   361: iload_1
    //   362: invokevirtual getChildAt : (I)Landroid/view/View;
    //   365: astore #10
    //   367: aload #10
    //   369: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   372: checkcast android/support/v4/view/ViewPager$LayoutParams
    //   375: getfield isDecor : Z
    //   378: ifeq -> 387
    //   381: iinc #1, 1
    //   384: goto -> 355
    //   387: aload #10
    //   389: invokevirtual getLeft : ()I
    //   392: iload #5
    //   394: isub
    //   395: i2f
    //   396: aload_0
    //   397: invokevirtual getWidth : ()I
    //   400: i2f
    //   401: fdiv
    //   402: fstore_2
    //   403: aload_0
    //   404: getfield mPageTransformer : Landroid/support/v4/view/ViewPager$PageTransformer;
    //   407: aload #10
    //   409: fload_2
    //   410: invokeinterface transformPage : (Landroid/view/View;F)V
    //   415: goto -> 381
    //   418: aload_0
    //   419: iconst_1
    //   420: putfield mCalledSuper : Z
    //   423: return
  }
  
  protected boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getChildCount : ()I
    //   4: istore_3
    //   5: iload_1
    //   6: iconst_2
    //   7: iand
    //   8: ifeq -> 80
    //   11: iconst_0
    //   12: istore #4
    //   14: iconst_1
    //   15: istore #5
    //   17: iload #4
    //   19: iload_3
    //   20: if_icmpeq -> 103
    //   23: aload_0
    //   24: iload #4
    //   26: invokevirtual getChildAt : (I)Landroid/view/View;
    //   29: astore #6
    //   31: aload #6
    //   33: invokevirtual getVisibility : ()I
    //   36: ifne -> 93
    //   39: aload_0
    //   40: aload #6
    //   42: invokevirtual infoForChild : (Landroid/view/View;)Landroid/support/v4/view/ViewPager$ItemInfo;
    //   45: astore #7
    //   47: aload #7
    //   49: ifnull -> 93
    //   52: aload #7
    //   54: getfield position : I
    //   57: aload_0
    //   58: getfield mCurItem : I
    //   61: if_icmpne -> 93
    //   64: aload #6
    //   66: iload_1
    //   67: aload_2
    //   68: invokevirtual requestFocus : (ILandroid/graphics/Rect;)Z
    //   71: ifeq -> 93
    //   74: iconst_1
    //   75: istore #8
    //   77: iload #8
    //   79: ireturn
    //   80: iload_3
    //   81: iconst_1
    //   82: isub
    //   83: istore #4
    //   85: iconst_m1
    //   86: istore #5
    //   88: iconst_m1
    //   89: istore_3
    //   90: goto -> 17
    //   93: iload #4
    //   95: iload #5
    //   97: iadd
    //   98: istore #4
    //   100: goto -> 17
    //   103: iconst_0
    //   104: istore #8
    //   106: goto -> 77
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.getSuperState());
    if (this.mAdapter != null) {
      this.mAdapter.restoreState(savedState.adapterState, savedState.loader);
      setCurrentItemInternal(savedState.position, false, true);
      return;
    } 
    this.mRestoredCurItem = savedState.position;
    this.mRestoredAdapterState = savedState.adapterState;
    this.mRestoredClassLoader = savedState.loader;
  }
  
  public Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    savedState.position = this.mCurItem;
    if (this.mAdapter != null)
      savedState.adapterState = this.mAdapter.saveState(); 
    return (Parcelable)savedState;
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramInt1 != paramInt3)
      recomputeScrollPosition(paramInt1, paramInt3, this.mPageMargin, this.mPageMargin); 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    float f;
    if (this.mFakeDragging)
      return true; 
    if (paramMotionEvent.getAction() == 0 && paramMotionEvent.getEdgeFlags() != 0)
      return false; 
    if (this.mAdapter == null || this.mAdapter.getCount() == 0)
      return false; 
    if (this.mVelocityTracker == null)
      this.mVelocityTracker = VelocityTracker.obtain(); 
    this.mVelocityTracker.addMovement(paramMotionEvent);
    int i = paramMotionEvent.getAction();
    int j = 0;
    int k = j;
    switch (i & 0xFF) {
      default:
        k = j;
      case 4:
        if (k)
          ViewCompat.postInvalidateOnAnimation((View)this); 
        return true;
      case 0:
        this.mScroller.abortAnimation();
        this.mPopulatePending = false;
        populate();
        this.mIsBeingDragged = true;
        setScrollState(1);
        f = paramMotionEvent.getX();
        this.mInitialMotionX = f;
        this.mLastMotionX = f;
        this.mActivePointerId = MotionEventCompat.getPointerId(paramMotionEvent, 0);
        k = j;
      case 2:
        if (!this.mIsBeingDragged) {
          k = MotionEventCompat.findPointerIndex(paramMotionEvent, this.mActivePointerId);
          float f1 = MotionEventCompat.getX(paramMotionEvent, k);
          float f2 = Math.abs(f1 - this.mLastMotionX);
          f = Math.abs(MotionEventCompat.getY(paramMotionEvent, k) - this.mLastMotionY);
          if (f2 > this.mTouchSlop && f2 > f) {
            this.mIsBeingDragged = true;
            if (f1 - this.mInitialMotionX > 0.0F) {
              f = this.mInitialMotionX + this.mTouchSlop;
            } else {
              f = this.mInitialMotionX - this.mTouchSlop;
            } 
            this.mLastMotionX = f;
            setScrollState(1);
            setScrollingCacheEnabled(true);
          } 
        } 
        k = j;
        if (this.mIsBeingDragged)
          k = false | performDrag(MotionEventCompat.getX(paramMotionEvent, MotionEventCompat.findPointerIndex(paramMotionEvent, this.mActivePointerId))); 
      case 1:
        k = j;
        if (this.mIsBeingDragged) {
          VelocityTracker velocityTracker = this.mVelocityTracker;
          velocityTracker.computeCurrentVelocity(1000, this.mMaximumVelocity);
          k = (int)VelocityTrackerCompat.getXVelocity(velocityTracker, this.mActivePointerId);
          this.mPopulatePending = true;
          j = getWidth();
          i = getScrollX();
          ItemInfo itemInfo = infoForCurrentScrollPosition();
          setCurrentItemInternal(determineTargetPage(itemInfo.position, (i / j - itemInfo.offset) / itemInfo.widthFactor, k, (int)(MotionEventCompat.getX(paramMotionEvent, MotionEventCompat.findPointerIndex(paramMotionEvent, this.mActivePointerId)) - this.mInitialMotionX)), true, true, k);
          this.mActivePointerId = -1;
          endDrag();
          k = this.mLeftEdge.onRelease() | this.mRightEdge.onRelease();
        } 
      case 3:
        k = j;
        if (this.mIsBeingDragged) {
          scrollToItem(this.mCurItem, true, 0, false);
          this.mActivePointerId = -1;
          endDrag();
          k = this.mLeftEdge.onRelease() | this.mRightEdge.onRelease();
        } 
      case 5:
        k = MotionEventCompat.getActionIndex(paramMotionEvent);
        this.mLastMotionX = MotionEventCompat.getX(paramMotionEvent, k);
        this.mActivePointerId = MotionEventCompat.getPointerId(paramMotionEvent, k);
        k = j;
      case 6:
        break;
    } 
    onSecondaryPointerUp(paramMotionEvent);
    this.mLastMotionX = MotionEventCompat.getX(paramMotionEvent, MotionEventCompat.findPointerIndex(paramMotionEvent, this.mActivePointerId));
    k = j;
  }
  
  boolean pageLeft() {
    null = true;
    if (this.mCurItem > 0) {
      setCurrentItem(this.mCurItem - 1, true);
      return null;
    } 
    return false;
  }
  
  boolean pageRight() {
    null = true;
    if (this.mAdapter != null && this.mCurItem < this.mAdapter.getCount() - 1) {
      setCurrentItem(this.mCurItem + 1, true);
      return null;
    } 
    return false;
  }
  
  void populate() {
    populate(this.mCurItem);
  }
  
  void populate(int paramInt) {
    ItemInfo itemInfo = null;
    if (this.mCurItem != paramInt) {
      itemInfo = infoForPosition(this.mCurItem);
      this.mCurItem = paramInt;
    } 
    if (this.mAdapter != null && !this.mPopulatePending && getWindowToken() != null) {
      this.mAdapter.startUpdate(this);
      paramInt = this.mOffscreenPageLimit;
      int i = Math.max(0, this.mCurItem - paramInt);
      int j = this.mAdapter.getCount();
      int k = Math.min(j - 1, this.mCurItem + paramInt);
      ItemInfo itemInfo1 = null;
      paramInt = 0;
      while (true) {
        ItemInfo itemInfo2 = itemInfo1;
        if (paramInt < this.mItems.size()) {
          ItemInfo itemInfo3 = this.mItems.get(paramInt);
          if (itemInfo3.position >= this.mCurItem) {
            itemInfo2 = itemInfo1;
            if (itemInfo3.position == this.mCurItem)
              itemInfo2 = itemInfo3; 
          } else {
            paramInt++;
            continue;
          } 
        } 
        itemInfo1 = itemInfo2;
        if (itemInfo2 == null) {
          itemInfo1 = itemInfo2;
          if (j > 0)
            itemInfo1 = addNewItem(this.mCurItem, paramInt); 
        } 
        if (itemInfo1 != null) {
          Object object1;
          Object object2;
          float f1 = 0.0F;
          int m = paramInt - 1;
          if (m >= 0) {
            itemInfo2 = this.mItems.get(m);
          } else {
            itemInfo2 = null;
          } 
          float f2 = itemInfo1.widthFactor;
          int n = this.mCurItem - 1;
          ItemInfo itemInfo3 = itemInfo2;
          int i1 = paramInt;
          while (true) {
            float f4;
            if (n >= 0)
              if (object1 >= 2.0F - f2) {
                if (n < i) {
                  if (itemInfo3 != null) {
                    paramInt = i1;
                    Object object4 = object1;
                    itemInfo2 = itemInfo3;
                    Object object3 = object2;
                    if (n == itemInfo3.position) {
                      paramInt = i1;
                      object4 = object1;
                      itemInfo2 = itemInfo3;
                      object3 = object2;
                      if (!itemInfo3.scrolling) {
                        this.mItems.remove(object2);
                        this.mAdapter.destroyItem(this, n, itemInfo3.object);
                        int i2 = object2 - 1;
                        paramInt = i1 - 1;
                        if (i2 >= 0) {
                          itemInfo2 = this.mItems.get(i2);
                          object4 = object1;
                        } else {
                          itemInfo2 = null;
                          object4 = object1;
                        } 
                      } 
                    } 
                    continue;
                  } 
                } else {
                  if (itemInfo3 != null && n == itemInfo3.position) {
                    f4 = object1 + itemInfo3.widthFactor;
                    int i2 = object2 - 1;
                    if (i2 >= 0) {
                      itemInfo2 = this.mItems.get(i2);
                    } else {
                      itemInfo2 = null;
                    } 
                    paramInt = i1;
                  } else {
                    f4 = object1 + (addNewItem(n, object2 + 1)).widthFactor;
                    paramInt = i1 + 1;
                    if (object2 >= null) {
                      itemInfo2 = this.mItems.get(object2);
                    } else {
                      itemInfo2 = null;
                    } 
                    Object object = object2;
                  } 
                  continue;
                } 
              } else {
                continue;
              }  
            float f3 = itemInfo1.widthFactor;
            n = i1 + 1;
            if (f3 < 2.0F) {
              if (n < this.mItems.size()) {
                itemInfo2 = this.mItems.get(n);
              } else {
                itemInfo2 = null;
              } 
              int i2 = this.mCurItem + 1;
              itemInfo3 = itemInfo2;
              while (true) {
                if (i2 < j)
                  if (f3 >= 2.0F && i2 > k) {
                    if (itemInfo3 != null) {
                      f4 = f3;
                      itemInfo2 = itemInfo3;
                      paramInt = n;
                      if (i2 == itemInfo3.position) {
                        f4 = f3;
                        itemInfo2 = itemInfo3;
                        paramInt = n;
                        if (!itemInfo3.scrolling) {
                          this.mItems.remove(n);
                          this.mAdapter.destroyItem(this, i2, itemInfo3.object);
                          if (n < this.mItems.size()) {
                            itemInfo2 = this.mItems.get(n);
                            paramInt = n;
                            f4 = f3;
                          } else {
                            itemInfo2 = null;
                            f4 = f3;
                            paramInt = n;
                          } 
                        } 
                      } 
                      continue;
                    } 
                  } else {
                    if (itemInfo3 != null && i2 == itemInfo3.position) {
                      f4 = f3 + itemInfo3.widthFactor;
                      paramInt = n + 1;
                      if (paramInt < this.mItems.size()) {
                        itemInfo2 = this.mItems.get(paramInt);
                      } else {
                        itemInfo2 = null;
                      } 
                    } else {
                      itemInfo2 = addNewItem(i2, n);
                      paramInt = n + 1;
                      f4 = f3 + itemInfo2.widthFactor;
                      if (paramInt < this.mItems.size()) {
                        itemInfo2 = this.mItems.get(paramInt);
                      } else {
                        itemInfo2 = null;
                      } 
                    } 
                    continue;
                  }  
                calculatePageOffsets(itemInfo1, i1, itemInfo);
                PagerAdapter pagerAdapter = this.mAdapter;
                paramInt = this.mCurItem;
                if (itemInfo1 != null) {
                  Object object = itemInfo1.object;
                } else {
                  itemInfo2 = null;
                } 
                pagerAdapter.setPrimaryItem(this, paramInt, itemInfo2);
                this.mAdapter.finishUpdate(this);
                if (this.mDrawingOrder != 0) {
                  paramInt = 1;
                } else {
                  paramInt = 0;
                } 
                if (paramInt != 0)
                  if (this.mDrawingOrderedChildren == null) {
                    this.mDrawingOrderedChildren = new ArrayList<View>();
                  } else {
                    this.mDrawingOrderedChildren.clear();
                  }  
                i1 = getChildCount();
                for (i2 = 0; i2 < i1; i2++) {
                  View view = getChildAt(i2);
                  LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
                  layoutParams.childIndex = i2;
                  if (!layoutParams.isDecor && layoutParams.widthFactor == 0.0F) {
                    itemInfo2 = infoForChild(view);
                    if (itemInfo2 != null) {
                      layoutParams.widthFactor = itemInfo2.widthFactor;
                      layoutParams.position = itemInfo2.position;
                    } 
                  } 
                  if (paramInt != 0)
                    this.mDrawingOrderedChildren.add(view); 
                } 
                if (paramInt != 0)
                  Collections.sort(this.mDrawingOrderedChildren, sPositionComparator); 
                if (hasFocus()) {
                  View view = findFocus();
                  if (view != null) {
                    ItemInfo itemInfo4 = infoForAnyChild(view);
                  } else {
                    view = null;
                  } 
                  if (view == null || ((ItemInfo)view).position != this.mCurItem) {
                    paramInt = 0;
                    while (true) {
                      if (paramInt < getChildCount()) {
                        View view1 = getChildAt(paramInt);
                        ItemInfo itemInfo4 = infoForChild(view1);
                        if (itemInfo4 == null || itemInfo4.position != this.mCurItem || !view1.requestFocus(2)) {
                          paramInt++;
                          continue;
                        } 
                      } 
                      return;
                    } 
                    break;
                  } 
                  // Byte code: goto -> 31
                } 
                // Byte code: goto -> 31
                i2++;
                f3 = f4;
                itemInfo3 = itemInfo2;
                n = paramInt;
              } 
              break;
            } 
            continue;
            n--;
            i1 = paramInt;
            object1 = SYNTHETIC_LOCAL_VARIABLE_15;
            itemInfo3 = itemInfo2;
            object2 = SYNTHETIC_LOCAL_VARIABLE_14;
          } 
        } 
        continue;
      } 
    } 
  }
  
  public void setAdapter(PagerAdapter paramPagerAdapter) {
    if (this.mAdapter != null) {
      this.mAdapter.unregisterDataSetObserver(this.mObserver);
      this.mAdapter.startUpdate(this);
      for (byte b = 0; b < this.mItems.size(); b++) {
        ItemInfo itemInfo = this.mItems.get(b);
        this.mAdapter.destroyItem(this, itemInfo.position, itemInfo.object);
      } 
      this.mAdapter.finishUpdate(this);
      this.mItems.clear();
      removeNonDecorViews();
      this.mCurItem = 0;
      scrollTo(0, 0);
    } 
    PagerAdapter pagerAdapter = this.mAdapter;
    this.mAdapter = paramPagerAdapter;
    if (this.mAdapter != null) {
      if (this.mObserver == null)
        this.mObserver = new PagerObserver(); 
      this.mAdapter.registerDataSetObserver(this.mObserver);
      this.mPopulatePending = false;
      this.mFirstLayout = true;
      if (this.mRestoredCurItem >= 0) {
        this.mAdapter.restoreState(this.mRestoredAdapterState, this.mRestoredClassLoader);
        setCurrentItemInternal(this.mRestoredCurItem, false, true);
        this.mRestoredCurItem = -1;
        this.mRestoredAdapterState = null;
        this.mRestoredClassLoader = null;
      } else {
        populate();
      } 
    } 
    if (this.mAdapterChangeListener != null && pagerAdapter != paramPagerAdapter)
      this.mAdapterChangeListener.onAdapterChanged(pagerAdapter, paramPagerAdapter); 
  }
  
  void setChildrenDrawingOrderEnabledCompat(boolean paramBoolean) {
    if (this.mSetChildrenDrawingOrderEnabled == null)
      try {
        this.mSetChildrenDrawingOrderEnabled = ViewGroup.class.getDeclaredMethod("setChildrenDrawingOrderEnabled", new Class[] { boolean.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("ViewPager", "Can't find setChildrenDrawingOrderEnabled", noSuchMethodException);
      }  
    try {
      this.mSetChildrenDrawingOrderEnabled.invoke(this, new Object[] { Boolean.valueOf(paramBoolean) });
    } catch (Exception exception) {
      Log.e("ViewPager", "Error changing children drawing order", exception);
    } 
  }
  
  public void setCurrentItem(int paramInt) {
    boolean bool;
    this.mPopulatePending = false;
    if (!this.mFirstLayout) {
      bool = true;
    } else {
      bool = false;
    } 
    setCurrentItemInternal(paramInt, bool, false);
  }
  
  public void setCurrentItem(int paramInt, boolean paramBoolean) {
    this.mPopulatePending = false;
    setCurrentItemInternal(paramInt, paramBoolean, false);
  }
  
  void setCurrentItemInternal(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    setCurrentItemInternal(paramInt, paramBoolean1, paramBoolean2, 0);
  }
  
  void setCurrentItemInternal(int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2) {
    int i;
    boolean bool = true;
    if (this.mAdapter == null || this.mAdapter.getCount() <= 0) {
      setScrollingCacheEnabled(false);
      return;
    } 
    if (!paramBoolean2 && this.mCurItem == paramInt1 && this.mItems.size() != 0) {
      setScrollingCacheEnabled(false);
      return;
    } 
    if (paramInt1 < 0) {
      i = 0;
    } else {
      i = paramInt1;
      if (paramInt1 >= this.mAdapter.getCount())
        i = this.mAdapter.getCount() - 1; 
    } 
    paramInt1 = this.mOffscreenPageLimit;
    if (i > this.mCurItem + paramInt1 || i < this.mCurItem - paramInt1)
      for (paramInt1 = 0; paramInt1 < this.mItems.size(); paramInt1++)
        ((ItemInfo)this.mItems.get(paramInt1)).scrolling = true;  
    if (this.mCurItem != i) {
      paramBoolean2 = bool;
    } else {
      paramBoolean2 = false;
    } 
    populate(i);
    scrollToItem(i, paramBoolean1, paramInt2, paramBoolean2);
  }
  
  OnPageChangeListener setInternalPageChangeListener(OnPageChangeListener paramOnPageChangeListener) {
    OnPageChangeListener onPageChangeListener = this.mInternalPageChangeListener;
    this.mInternalPageChangeListener = paramOnPageChangeListener;
    return onPageChangeListener;
  }
  
  public void setOffscreenPageLimit(int paramInt) {
    int i = paramInt;
    if (paramInt < 1) {
      Log.w("ViewPager", "Requested offscreen page limit " + paramInt + " too small; defaulting to " + '\001');
      i = 1;
    } 
    if (i != this.mOffscreenPageLimit) {
      this.mOffscreenPageLimit = i;
      populate();
    } 
  }
  
  void setOnAdapterChangeListener(OnAdapterChangeListener paramOnAdapterChangeListener) {
    this.mAdapterChangeListener = paramOnAdapterChangeListener;
  }
  
  public void setOnPageChangeListener(OnPageChangeListener paramOnPageChangeListener) {
    this.mOnPageChangeListener = paramOnPageChangeListener;
  }
  
  public void setPageMargin(int paramInt) {
    int i = this.mPageMargin;
    this.mPageMargin = paramInt;
    int j = getWidth();
    recomputeScrollPosition(j, j, paramInt, i);
    requestLayout();
  }
  
  public void setPageMarginDrawable(int paramInt) {
    setPageMarginDrawable(getContext().getResources().getDrawable(paramInt));
  }
  
  public void setPageMarginDrawable(Drawable paramDrawable) {
    boolean bool;
    this.mMarginDrawable = paramDrawable;
    if (paramDrawable != null)
      refreshDrawableState(); 
    if (paramDrawable == null) {
      bool = true;
    } else {
      bool = false;
    } 
    setWillNotDraw(bool);
    invalidate();
  }
  
  public void setPageTransformer(boolean paramBoolean, PageTransformer paramPageTransformer) {
    byte b = 1;
    if (Build.VERSION.SDK_INT >= 11) {
      boolean bool1;
      boolean bool2;
      boolean bool3;
      if (paramPageTransformer != null) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (this.mPageTransformer != null) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      if (bool1 != bool2) {
        bool3 = true;
      } else {
        bool3 = false;
      } 
      this.mPageTransformer = paramPageTransformer;
      setChildrenDrawingOrderEnabledCompat(bool1);
      if (bool1) {
        if (paramBoolean)
          b = 2; 
        this.mDrawingOrder = b;
      } else {
        this.mDrawingOrder = 0;
      } 
      if (bool3)
        populate(); 
    } 
  }
  
  void smoothScrollTo(int paramInt1, int paramInt2) {
    smoothScrollTo(paramInt1, paramInt2, 0);
  }
  
  void smoothScrollTo(int paramInt1, int paramInt2, int paramInt3) {
    if (getChildCount() == 0) {
      setScrollingCacheEnabled(false);
      return;
    } 
    int i = getScrollX();
    int j = getScrollY();
    int k = paramInt1 - i;
    paramInt2 -= j;
    if (k == 0 && paramInt2 == 0) {
      completeScroll(false);
      populate();
      setScrollState(0);
      return;
    } 
    setScrollingCacheEnabled(true);
    setScrollState(2);
    paramInt1 = getWidth();
    int m = paramInt1 / 2;
    float f1 = Math.min(1.0F, 1.0F * Math.abs(k) / paramInt1);
    float f2 = m;
    float f3 = m;
    f1 = distanceInfluenceForSnapDuration(f1);
    paramInt3 = Math.abs(paramInt3);
    if (paramInt3 > 0) {
      paramInt1 = Math.round(1000.0F * Math.abs((f2 + f3 * f1) / paramInt3)) * 4;
    } else {
      f3 = paramInt1;
      f2 = this.mAdapter.getPageWidth(this.mCurItem);
      paramInt1 = (int)((1.0F + Math.abs(k) / (this.mPageMargin + f3 * f2)) * 100.0F);
    } 
    paramInt1 = Math.min(paramInt1, 600);
    this.mScroller.startScroll(i, j, k, paramInt2, paramInt1);
    ViewCompat.postInvalidateOnAnimation((View)this);
  }
  
  protected boolean verifyDrawable(Drawable paramDrawable) {
    return (super.verifyDrawable(paramDrawable) || paramDrawable == this.mMarginDrawable);
  }
  
  static interface Decor {}
  
  static class ItemInfo {
    Object object;
    
    float offset;
    
    int position;
    
    boolean scrolling;
    
    float widthFactor;
  }
  
  public static class LayoutParams extends ViewGroup.LayoutParams {
    int childIndex;
    
    public int gravity;
    
    public boolean isDecor;
    
    boolean needsMeasure;
    
    int position;
    
    float widthFactor = 0.0F;
    
    public LayoutParams() {
      super(-1, -1);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, ViewPager.LAYOUT_ATTRS);
      this.gravity = typedArray.getInteger(0, 48);
      typedArray.recycle();
    }
  }
  
  class MyAccessibilityDelegate extends AccessibilityDelegateCompat {
    public void onInitializeAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1View, param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName(ViewPager.class.getName());
    }
    
    public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat) {
      boolean bool = true;
      super.onInitializeAccessibilityNodeInfo(param1View, param1AccessibilityNodeInfoCompat);
      param1AccessibilityNodeInfoCompat.setClassName(ViewPager.class.getName());
      if (ViewPager.this.mAdapter == null || ViewPager.this.mAdapter.getCount() <= 1)
        bool = false; 
      param1AccessibilityNodeInfoCompat.setScrollable(bool);
      if (ViewPager.this.mAdapter != null && ViewPager.this.mCurItem >= 0 && ViewPager.this.mCurItem < ViewPager.this.mAdapter.getCount() - 1)
        param1AccessibilityNodeInfoCompat.addAction(4096); 
      if (ViewPager.this.mAdapter != null && ViewPager.this.mCurItem > 0 && ViewPager.this.mCurItem < ViewPager.this.mAdapter.getCount())
        param1AccessibilityNodeInfoCompat.addAction(8192); 
    }
    
    public boolean performAccessibilityAction(View param1View, int param1Int, Bundle param1Bundle) {
      boolean bool = true;
      if (!super.performAccessibilityAction(param1View, param1Int, param1Bundle)) {
        switch (param1Int) {
          default:
            return false;
          case 4096:
            if (ViewPager.this.mAdapter != null && ViewPager.this.mCurItem >= 0 && ViewPager.this.mCurItem < ViewPager.this.mAdapter.getCount() - 1) {
              ViewPager.this.setCurrentItem(ViewPager.this.mCurItem + 1);
              return bool;
            } 
            return false;
          case 8192:
            break;
        } 
        if (ViewPager.this.mAdapter != null && ViewPager.this.mCurItem > 0 && ViewPager.this.mCurItem < ViewPager.this.mAdapter.getCount()) {
          ViewPager.this.setCurrentItem(ViewPager.this.mCurItem - 1);
          return bool;
        } 
        bool = false;
      } 
      return bool;
    }
  }
  
  static interface OnAdapterChangeListener {
    void onAdapterChanged(PagerAdapter param1PagerAdapter1, PagerAdapter param1PagerAdapter2);
  }
  
  public static interface OnPageChangeListener {
    void onPageScrollStateChanged(int param1Int);
    
    void onPageScrolled(int param1Int1, float param1Float, int param1Int2);
    
    void onPageSelected(int param1Int);
  }
  
  public static interface PageTransformer {
    void transformPage(View param1View, float param1Float);
  }
  
  private class PagerObserver extends DataSetObserver {
    private PagerObserver() {}
    
    public void onChanged() {
      ViewPager.this.dataSetChanged();
    }
    
    public void onInvalidated() {
      ViewPager.this.dataSetChanged();
    }
  }
  
  public static class SavedState extends View.BaseSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = ParcelableCompat.newCreator(new ParcelableCompatCreatorCallbacks<SavedState>() {
          public ViewPager.SavedState createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
            return new ViewPager.SavedState(param2Parcel, param2ClassLoader);
          }
          
          public ViewPager.SavedState[] newArray(int param2Int) {
            return new ViewPager.SavedState[param2Int];
          }
        });
    
    Parcelable adapterState;
    
    ClassLoader loader;
    
    int position;
    
    SavedState(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel);
      ClassLoader classLoader = param1ClassLoader;
      if (param1ClassLoader == null)
        classLoader = getClass().getClassLoader(); 
      this.position = param1Parcel.readInt();
      this.adapterState = param1Parcel.readParcelable(classLoader);
      this.loader = classLoader;
    }
    
    public SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      return "FragmentPager.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " position=" + this.position + "}";
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.position);
      param1Parcel.writeParcelable(this.adapterState, param1Int);
    }
  }
  
  static final class null implements ParcelableCompatCreatorCallbacks<SavedState> {
    public ViewPager.SavedState createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new ViewPager.SavedState(param1Parcel, param1ClassLoader);
    }
    
    public ViewPager.SavedState[] newArray(int param1Int) {
      return new ViewPager.SavedState[param1Int];
    }
  }
  
  public static class SimpleOnPageChangeListener implements OnPageChangeListener {
    public void onPageScrollStateChanged(int param1Int) {}
    
    public void onPageScrolled(int param1Int1, float param1Float, int param1Int2) {}
    
    public void onPageSelected(int param1Int) {}
  }
  
  static class ViewPositionComparator implements Comparator<View> {
    public int compare(View param1View1, View param1View2) {
      ViewPager.LayoutParams layoutParams1 = (ViewPager.LayoutParams)param1View1.getLayoutParams();
      ViewPager.LayoutParams layoutParams2 = (ViewPager.LayoutParams)param1View2.getLayoutParams();
      return (layoutParams1.isDecor != layoutParams2.isDecor) ? (layoutParams1.isDecor ? 1 : -1) : (layoutParams1.position - layoutParams2.position);
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakFakeBank-dex2jar.jar!/android/support/v4/view/ViewPager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */