package com.facebook.ads;

public interface InstreamVideoAdListener extends AdListener {
  void onAdVideoComplete(Ad paramAd);
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/InstreamVideoAdListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */