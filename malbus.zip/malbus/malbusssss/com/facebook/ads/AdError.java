package com.facebook.ads;

import android.text.TextUtils;

public class AdError {
  public static final AdError INTERNAL_ERROR;
  
  public static final int INTERNAL_ERROR_CODE = 2001;
  
  public static final AdError LOAD_TOO_FREQUENTLY;
  
  public static final int LOAD_TOO_FREQUENTLY_ERROR_CODE = 1002;
  
  public static final AdError MEDIATION_ERROR;
  
  public static final int MEDIATION_ERROR_CODE = 3001;
  
  @Deprecated
  public static final AdError MISSING_PROPERTIES;
  
  public static final AdError NETWORK_ERROR = new AdError(1000, "Network Error");
  
  public static final int NETWORK_ERROR_CODE = 1000;
  
  public static final AdError NO_FILL = new AdError(1001, "No Fill");
  
  public static final int NO_FILL_ERROR_CODE = 1001;
  
  public static final AdError SERVER_ERROR;
  
  public static final int SERVER_ERROR_CODE = 2000;
  
  private final int a;
  
  private final String b;
  
  static {
    LOAD_TOO_FREQUENTLY = new AdError(1002, "Ad was re-loaded too frequently");
    SERVER_ERROR = new AdError(2000, "Server Error");
    INTERNAL_ERROR = new AdError(2001, "Internal Error");
    MEDIATION_ERROR = new AdError(3001, "Mediation Error");
    MISSING_PROPERTIES = new AdError(2002, "Native ad failed to load due to missing properties");
  }
  
  public AdError(int paramInt, String paramString) {
    String str = paramString;
    if (TextUtils.isEmpty(paramString))
      str = "unknown error"; 
    this.a = paramInt;
    this.b = str;
  }
  
  public int getErrorCode() {
    return this.a;
  }
  
  public String getErrorMessage() {
    return this.b;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/AdError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */