package com.facebook.ads;

import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.facebook.ads.internal.adapters.g;
import com.facebook.ads.internal.g.f;
import com.facebook.ads.internal.g.g;
import com.facebook.ads.internal.util.p;
import com.facebook.ads.internal.view.e;
import com.facebook.ads.internal.view.hscroll.b;
import com.facebook.ads.internal.view.i;

public class MediaView extends RelativeLayout {
  private static final String a = MediaView.class.getSimpleName();
  
  private static final int b = Color.argb(51, 145, 150, 165);
  
  @Nullable
  private MediaViewListener c;
  
  private final e d;
  
  private final i e;
  
  private final b f;
  
  private boolean g = false;
  
  @Deprecated
  private boolean h = true;
  
  public MediaView(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public MediaView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setBackgroundColor(b);
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
    this.d = new e(paramContext);
    this.d.setVisibility(8);
    addView((View)this.d, (ViewGroup.LayoutParams)layoutParams);
    this.e = new i(paramContext, this, getAdEventManager());
    this.e.setVisibility(8);
    layoutParams.addRule(13);
    addView((View)this.e, (ViewGroup.LayoutParams)layoutParams);
    float f = (paramContext.getResources().getDisplayMetrics()).density;
    int j = Math.round(4.0F * f);
    int k = Math.round(f * 12.0F);
    this.f = new b(getContext());
    this.f.setChildSpacing(j);
    this.f.setPadding(0, k, 0, k);
    this.f.setVisibility(8);
    addView((View)this.f, (ViewGroup.LayoutParams)layoutParams);
  }
  
  private boolean a(NativeAd paramNativeAd) {
    return (Build.VERSION.SDK_INT >= 14 && !TextUtils.isEmpty(paramNativeAd.c()));
  }
  
  private boolean b(NativeAd paramNativeAd) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual g : ()Ljava/util/List;
    //   4: ifnonnull -> 11
    //   7: iconst_0
    //   8: istore_2
    //   9: iload_2
    //   10: ireturn
    //   11: aload_1
    //   12: invokevirtual g : ()Ljava/util/List;
    //   15: invokeinterface iterator : ()Ljava/util/Iterator;
    //   20: astore_1
    //   21: aload_1
    //   22: invokeinterface hasNext : ()Z
    //   27: ifeq -> 50
    //   30: aload_1
    //   31: invokeinterface next : ()Ljava/lang/Object;
    //   36: checkcast com/facebook/ads/NativeAd
    //   39: invokevirtual getAdCoverImage : ()Lcom/facebook/ads/NativeAd$Image;
    //   42: ifnonnull -> 21
    //   45: iconst_0
    //   46: istore_2
    //   47: goto -> 9
    //   50: iconst_1
    //   51: istore_2
    //   52: goto -> 9
  }
  
  protected f getAdEventManager() {
    return (f)g.a(getContext());
  }
  
  @Deprecated
  public boolean isAutoplay() {
    return this.h;
  }
  
  @Deprecated
  public void setAutoplay(boolean paramBoolean) {
    this.h = paramBoolean;
    this.e.setAutoplay(paramBoolean);
  }
  
  @Deprecated
  public void setAutoplayOnMobile(boolean paramBoolean) {
    this.e.setIsAutoplayOnMobile(paramBoolean);
  }
  
  public void setListener(MediaViewListener paramMediaViewListener) {
    this.c = paramMediaViewListener;
    this.e.setListener(paramMediaViewListener);
  }
  
  public void setNativeAd(NativeAd paramNativeAd) {
    String str;
    paramNativeAd.b(true);
    paramNativeAd.setMediaViewAutoplay(this.h);
    if (this.g) {
      this.d.a(null, null);
      this.g = false;
    } 
    if (paramNativeAd.getAdCoverImage() != null) {
      str = paramNativeAd.getAdCoverImage().getUrl();
    } else {
      str = null;
    } 
    if (b(paramNativeAd)) {
      this.d.setVisibility(8);
      this.e.setVisibility(8);
      this.f.setVisibility(0);
      bringChildToFront((View)this.f);
      this.f.setCurrentPosition(0);
      this.f.setAdapter((RecyclerView.Adapter)new g(this.f, paramNativeAd.g()));
      return;
    } 
    if (a(paramNativeAd)) {
      String str1 = paramNativeAd.c();
      String str2 = paramNativeAd.d();
      this.e.setImage(null);
      this.d.setVisibility(8);
      this.e.setVisibility(0);
      this.f.setVisibility(8);
      bringChildToFront((View)this.e);
      this.g = true;
      this.e.setAutoplay(this.h);
      this.e.setIsAutoPlayFromServer(paramNativeAd.f());
      if (str != null)
        this.e.setImage(str); 
      this.e.a(paramNativeAd.e(), paramNativeAd.h());
      this.e.setVideoMPD(str2);
      this.e.setVideoURI(str1);
      return;
    } 
    if (str != null) {
      this.d.setVisibility(0);
      this.e.setVisibility(8);
      this.f.setVisibility(8);
      bringChildToFront((View)this.d);
      this.g = true;
      (new p(this.d)).a(new String[] { str });
    } 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/MediaView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */