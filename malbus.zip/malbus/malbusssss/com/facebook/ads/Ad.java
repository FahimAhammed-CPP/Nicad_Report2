package com.facebook.ads;

public interface Ad {
  void destroy();
  
  String getPlacementId();
  
  void loadAd();
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/Ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */