package com.facebook.ads;

public interface MediaViewListener {
  void onComplete(MediaView paramMediaView);
  
  void onEnterFullscreen(MediaView paramMediaView);
  
  void onExitFullscreen(MediaView paramMediaView);
  
  void onFullscreenBackground(MediaView paramMediaView);
  
  void onFullscreenForeground(MediaView paramMediaView);
  
  void onPause(MediaView paramMediaView);
  
  void onPlay(MediaView paramMediaView);
  
  void onVolumeChange(MediaView paramMediaView, float paramFloat);
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/MediaViewListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */