package com.facebook.ads;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Rect;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.facebook.ads.internal.DisplayAdController;
import com.facebook.ads.internal.a;
import com.facebook.ads.internal.adapters.AdAdapter;
import com.facebook.ads.internal.adapters.b;
import com.facebook.ads.internal.adapters.u;
import com.facebook.ads.internal.adapters.v;
import com.facebook.ads.internal.b;
import com.facebook.ads.internal.c;
import com.facebook.ads.internal.c.a;
import com.facebook.ads.internal.c.b;
import com.facebook.ads.internal.e;
import com.facebook.ads.internal.f.e;
import com.facebook.ads.internal.h;
import com.facebook.ads.internal.j.a;
import com.facebook.ads.internal.server.AdPlacementType;
import com.facebook.ads.internal.util.ag;
import com.facebook.ads.internal.util.aj;
import com.facebook.ads.internal.util.c;
import com.facebook.ads.internal.util.d;
import com.facebook.ads.internal.util.h;
import com.facebook.ads.internal.util.p;
import com.facebook.ads.internal.view.r;
import com.facebook.ads.internal.view.s;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;
import org.json.JSONObject;

public class NativeAd implements Ad {
  private static final c b = c.a;
  
  private static final String c = NativeAd.class.getSimpleName();
  
  private static WeakHashMap<View, WeakReference<NativeAd>> d = new WeakHashMap<View, WeakReference<NativeAd>>();
  
  private long A;
  
  private String B;
  
  private boolean C = false;
  
  @Nullable
  protected v a;
  
  private final Context e;
  
  private final String f;
  
  private final String g = UUID.randomUUID().toString();
  
  private final b h;
  
  private AdListener i;
  
  private ImpressionListener j;
  
  private DisplayAdController k;
  
  private volatile boolean l;
  
  private e m;
  
  private View n;
  
  private final List<View> o = new ArrayList<View>();
  
  private View.OnTouchListener p;
  
  private a q;
  
  private final ag r = new ag();
  
  @Nullable
  private u s;
  
  private a t;
  
  private b u;
  
  private s v;
  
  private NativeAdView.Type w;
  
  private boolean x;
  
  private boolean y;
  
  @Deprecated
  private boolean z;
  
  public NativeAd(Context paramContext, v paramv, e parame) {
    this(paramContext, null);
    this.m = parame;
    this.l = true;
    this.a = paramv;
  }
  
  public NativeAd(Context paramContext, String paramString) {
    this.e = paramContext;
    this.f = paramString;
    this.h = new b(paramContext);
  }
  
  NativeAd(NativeAd paramNativeAd) {
    this(paramNativeAd.e, null);
    this.m = paramNativeAd.m;
    this.l = true;
    this.a = paramNativeAd.a;
  }
  
  private void a(View paramView) {
    this.o.add(paramView);
    paramView.setOnClickListener(this.t);
    paramView.setOnTouchListener(this.t);
  }
  
  private void a(List<View> paramList, View paramView) {
    if (!(paramView instanceof com.facebook.ads.internal.view.m) && !(paramView instanceof AdChoicesView) && !(paramView instanceof com.facebook.ads.internal.view.hscroll.b)) {
      paramList.add(paramView);
      if (paramView instanceof ViewGroup) {
        ViewGroup viewGroup = (ViewGroup)paramView;
        byte b1 = 0;
        while (true) {
          if (b1 < viewGroup.getChildCount()) {
            a(paramList, viewGroup.getChildAt(b1));
            b1++;
            continue;
          } 
          return;
        } 
      } 
    } 
  }
  
  public static void downloadAndDisplayImage(Image paramImage, ImageView paramImageView) {
    if (paramImage != null && paramImageView != null)
      (new p(paramImageView)).a(new String[] { paramImage.getUrl() }); 
  }
  
  private int getMinViewabilityPercentage() {
    byte b1 = 1;
    if (this.m != null)
      return this.m.e(); 
    int i = b1;
    if (this.k != null) {
      i = b1;
      if (this.k.a() != null)
        i = this.k.a().e(); 
    } 
    return i;
  }
  
  private int i() {
    byte b1 = 0;
    if (this.m != null)
      return this.m.f(); 
    int i = b1;
    if (this.k != null) {
      i = b1;
      if (this.k.a() != null)
        i = this.k.a().f(); 
    } 
    return i;
  }
  
  private int j() {
    return (this.m != null) ? this.m.g() : ((this.a != null) ? this.a.i() : ((this.k != null && this.k.a() != null) ? this.k.a().g() : 0));
  }
  
  private int k() {
    return (this.m != null) ? this.m.h() : ((this.a != null) ? this.a.j() : ((this.k != null && this.k.a() != null) ? this.k.a().h() : 1000));
  }
  
  private boolean l() {
    return (f() == aj.c) ? this.z : ((f() == aj.a));
  }
  
  private void logExternalClick(String paramString) {
    if (this.a != null) {
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      hashMap.put("eil", String.valueOf(true));
      hashMap.put("eil_source", paramString);
      this.a.b(hashMap);
    } 
  }
  
  private void logExternalImpression() {
    if (this.s != null)
      this.s.a(); 
  }
  
  private void m() {
    for (View view : this.o) {
      view.setOnClickListener(null);
      view.setOnTouchListener(null);
    } 
    this.o.clear();
  }
  
  private void n() {
    if (this.a != null && this.a.c()) {
      this.u = new b();
      this.u.a();
      b b1 = new b(this) {
          public boolean a() {
            return true;
          }
        };
      this.s = new u(this.e, b1, this.q, this.a);
    } 
  }
  
  private void o() {
    if (this.C) {
      c c1 = new c(this) {
          public boolean b() {
            return true;
          }
          
          public String c() {
            return NativeAd.p(this.a);
          }
        };
      this.s = new u(this.e, c1, this.q, this.a);
    } 
  }
  
  private void registerExternalLogReceiver(String paramString) {
    this.C = true;
    this.B = paramString;
  }
  
  v a() {
    return this.a;
  }
  
  void a(NativeAdView.Type paramType) {
    this.w = paramType;
  }
  
  void a(boolean paramBoolean) {
    this.x = paramBoolean;
  }
  
  String b() {
    return !isAdLoaded() ? null : this.a.v();
  }
  
  void b(boolean paramBoolean) {
    this.y = paramBoolean;
  }
  
  String c() {
    return (!isAdLoaded() || TextUtils.isEmpty(this.a.w())) ? null : this.h.c(this.a.w());
  }
  
  String d() {
    return !isAdLoaded() ? null : this.a.x();
  }
  
  public void destroy() {
    if (this.u != null) {
      this.u.b();
      this.u = null;
    } 
    if (this.k != null) {
      this.k.d();
      this.k = null;
    } 
  }
  
  String e() {
    return !isAdLoaded() ? null : this.a.z();
  }
  
  aj f() {
    return !isAdLoaded() ? aj.c : this.a.y();
  }
  
  List<NativeAd> g() {
    return !isAdLoaded() ? null : this.a.A();
  }
  
  public String getAdBody() {
    return !isAdLoaded() ? null : this.a.p();
  }
  
  public String getAdCallToAction() {
    return !isAdLoaded() ? null : this.a.q();
  }
  
  public Image getAdChoicesIcon() {
    return !isAdLoaded() ? null : this.a.t();
  }
  
  public String getAdChoicesLinkUrl() {
    return !isAdLoaded() ? null : this.a.u();
  }
  
  public Image getAdCoverImage() {
    return !isAdLoaded() ? null : this.a.l();
  }
  
  public Image getAdIcon() {
    return !isAdLoaded() ? null : this.a.k();
  }
  
  @Nullable
  public AdNetwork getAdNetwork() {
    return (isAdLoaded() && this.a != null) ? this.a.C() : null;
  }
  
  public String getAdSocialContext() {
    return !isAdLoaded() ? null : this.a.r();
  }
  
  @Deprecated
  public Rating getAdStarRating() {
    return !isAdLoaded() ? null : this.a.s();
  }
  
  public String getAdSubtitle() {
    return !isAdLoaded() ? null : this.a.o();
  }
  
  public String getAdTitle() {
    return !isAdLoaded() ? null : this.a.n();
  }
  
  public NativeAdViewAttributes getAdViewAttributes() {
    return !isAdLoaded() ? null : this.a.m();
  }
  
  public String getId() {
    return !isAdLoaded() ? null : this.g;
  }
  
  public String getPlacementId() {
    return this.f;
  }
  
  @Nullable
  String h() {
    return !isAdLoaded() ? null : this.a.B();
  }
  
  public boolean isAdLoaded() {
    return (this.a != null && this.a.b());
  }
  
  public boolean isNativeConfigEnabled() {
    return (isAdLoaded() && this.a.f());
  }
  
  public void loadAd() {
    loadAd(EnumSet.of(MediaCacheFlag.NONE));
  }
  
  public void loadAd(EnumSet<MediaCacheFlag> paramEnumSet) {
    if (this.l)
      throw new IllegalStateException("loadAd cannot be called more than once"); 
    this.A = System.currentTimeMillis();
    this.l = true;
    e e1 = e.j;
    this.k = new DisplayAdController(this.e, this.f, e1, AdPlacementType.NATIVE, null, b, 1, true);
    this.k.a(new a(this, paramEnumSet) {
          public void a() {
            if (NativeAd.a(this.b) != null)
              NativeAd.a(this.b).onAdClicked(this.b); 
          }
          
          public void a(AdAdapter param1AdAdapter) {
            if (NativeAd.b(this.b) != null)
              NativeAd.b(this.b).c(); 
          }
          
          public void a(v param1v) {
            d.a(c.a(c.b.a, AdPlacementType.NATIVE, System.currentTimeMillis() - NativeAd.c(this.b), null));
            if (param1v != null) {
              if (this.a.contains(NativeAd.MediaCacheFlag.ICON) && param1v.k() != null)
                NativeAd.d(this.b).a(param1v.k().getUrl()); 
              if (this.a.contains(NativeAd.MediaCacheFlag.IMAGE)) {
                if (param1v.l() != null)
                  NativeAd.d(this.b).a(param1v.l().getUrl()); 
                if (param1v.A() != null)
                  for (NativeAd nativeAd : param1v.A()) {
                    if (nativeAd.getAdCoverImage() != null)
                      NativeAd.d(this.b).a(nativeAd.getAdCoverImage().getUrl()); 
                  }  
              } 
              if (this.a.contains(NativeAd.MediaCacheFlag.VIDEO) && !TextUtils.isEmpty(param1v.w()))
                NativeAd.d(this.b).b(param1v.w()); 
              NativeAd.d(this.b).a(new a(this, param1v) {
                    public void a() {
                      this.b.b.a = this.a;
                      NativeAd.e(this.b.b);
                      NativeAd.f(this.b.b);
                      if (NativeAd.a(this.b.b) != null)
                        NativeAd.a(this.b.b).onAdLoaded(this.b.b); 
                    }
                  });
              if (NativeAd.a(this.b) != null && param1v.A() != null) {
                Iterator<NativeAd> iterator = param1v.A().iterator();
                while (true) {
                  if (iterator.hasNext()) {
                    ((NativeAd)iterator.next()).setAdListener(NativeAd.a(this.b));
                    continue;
                  } 
                  return;
                } 
              } 
            } 
          }
          
          public void a(b param1b) {
            if (NativeAd.a(this.b) != null)
              NativeAd.a(this.b).onError(this.b, param1b.b()); 
          }
          
          public void b() {
            throw new IllegalStateException("Native ads manager their own impressions.");
          }
        });
    this.k.b();
  }
  
  public void registerViewForInteraction(View paramView) {
    ArrayList<View> arrayList = new ArrayList();
    a(arrayList, paramView);
    registerViewForInteraction(paramView, arrayList);
  }
  
  public void registerViewForInteraction(View paramView, List<View> paramList) {
    if (paramView == null)
      throw new IllegalArgumentException("Must provide a View"); 
    if (paramList == null || paramList.size() == 0)
      throw new IllegalArgumentException("Invalid set of clickable views"); 
    if (!isAdLoaded()) {
      Log.e(c, "Ad not loaded");
      return;
    } 
    if (this.n != null) {
      Log.w(c, "Native Ad was already registered with a View. Auto unregistering and proceeding.");
      unregisterView();
    } 
    if (d.containsKey(paramView)) {
      Log.w(c, "View already registered with a NativeAd. Auto unregistering and proceeding.");
      ((NativeAd)((WeakReference<NativeAd>)d.get(paramView)).get()).unregisterView();
    } 
    this.t = new a();
    this.n = paramView;
    if (paramView instanceof ViewGroup) {
      this.v = new s(paramView.getContext(), new r(this) {
            public void a(int param1Int) {
              if (this.a.a != null)
                this.a.a.a(param1Int); 
            }
          });
      ((ViewGroup)paramView).addView((View)this.v);
    } 
    Iterator<View> iterator = paramList.iterator();
    while (iterator.hasNext())
      a(iterator.next()); 
    this.a.a(paramView, paramList);
    int i = getMinViewabilityPercentage();
    this.q = new a(this.n, i, i(), true, new a.a(this) {
          public void a() {
            NativeAd.g(this.a).a();
            NativeAd.h(this.a).b();
            if (NativeAd.i(this.a) == null) {
              if (NativeAd.h(this.a) != null) {
                NativeAd.h(this.a).b();
                NativeAd.a(this.a, (a)null);
              } 
              return;
            } 
            NativeAd.i(this.a).a(NativeAd.j(this.a));
            NativeAd.i(this.a).a(NativeAd.k(this.a));
            NativeAd.i(this.a).a(NativeAd.l(this.a));
            NativeAd.i(this.a).b(NativeAd.m(this.a));
            NativeAd.i(this.a).c(NativeAd.n(this.a));
            NativeAd.i(this.a).a();
          }
        });
    this.q.a(j());
    this.q.b(k());
    this.q.a();
    this.s = new u(this.e, new c(), this.q, this.a);
    this.s.a(paramList);
    d.put(paramView, new WeakReference<NativeAd>(this));
  }
  
  public void setAdListener(AdListener paramAdListener) {
    this.i = paramAdListener;
  }
  
  @Deprecated
  public void setImpressionListener(ImpressionListener paramImpressionListener) {
    this.j = paramImpressionListener;
  }
  
  @Deprecated
  public void setMediaViewAutoplay(boolean paramBoolean) {
    this.z = paramBoolean;
  }
  
  public void setOnTouchListener(View.OnTouchListener paramOnTouchListener) {
    this.p = paramOnTouchListener;
  }
  
  public void unregisterView() {
    if (this.n != null) {
      if (!d.containsKey(this.n) || ((WeakReference<NativeAd>)d.get(this.n)).get() != this)
        throw new IllegalStateException("View not registered with this NativeAd"); 
      if (this.n instanceof ViewGroup && this.v != null) {
        ((ViewGroup)this.n).removeView((View)this.v);
        this.v = null;
      } 
      if (this.a != null)
        this.a.a(); 
      d.remove(this.n);
      m();
      this.n = null;
      if (this.q != null) {
        this.q.b();
        this.q = null;
      } 
      this.s = null;
    } 
  }
  
  public static class Image {
    private final String a;
    
    private final int b;
    
    private final int c;
    
    public Image(String param1String, int param1Int1, int param1Int2) {
      this.a = param1String;
      this.b = param1Int1;
      this.c = param1Int2;
    }
    
    public static Image fromJSONObject(JSONObject param1JSONObject) {
      Image image = null;
      if (param1JSONObject != null) {
        String str = param1JSONObject.optString("url");
        if (str != null)
          image = new Image(str, param1JSONObject.optInt("width", 0), param1JSONObject.optInt("height", 0)); 
      } 
      return image;
    }
    
    public int getHeight() {
      return this.c;
    }
    
    public String getUrl() {
      return this.a;
    }
    
    public int getWidth() {
      return this.b;
    }
  }
  
  public enum MediaCacheFlag {
    ICON,
    IMAGE,
    NONE(0L),
    VIDEO(0L);
    
    public static final EnumSet<MediaCacheFlag> ALL;
    
    private final long a;
    
    static {
      ALL = EnumSet.allOf(MediaCacheFlag.class);
    }
    
    MediaCacheFlag(long param1Long) {
      this.a = param1Long;
    }
    
    public long getCacheFlagValue() {
      return this.a;
    }
  }
  
  public static class Rating {
    private final double a;
    
    private final double b;
    
    public Rating(double param1Double1, double param1Double2) {
      this.a = param1Double1;
      this.b = param1Double2;
    }
    
    public static Rating fromJSONObject(JSONObject param1JSONObject) {
      Rating rating;
      JSONObject jSONObject = null;
      if (param1JSONObject == null)
        return (Rating)jSONObject; 
      double d1 = param1JSONObject.optDouble("value", 0.0D);
      double d2 = param1JSONObject.optDouble("scale", 0.0D);
      param1JSONObject = jSONObject;
      if (d1 != 0.0D) {
        param1JSONObject = jSONObject;
        if (d2 != 0.0D)
          rating = new Rating(d1, d2); 
      } 
      return rating;
    }
    
    public double getScale() {
      return this.b;
    }
    
    public double getValue() {
      return this.a;
    }
  }
  
  private class a implements View.OnClickListener, View.OnTouchListener {
    private int b;
    
    private int c;
    
    private int d;
    
    private int e;
    
    private float f;
    
    private float g;
    
    private int h;
    
    private int i;
    
    private a(NativeAd this$0) {}
    
    private Map<String, String> a() {
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      hashMap.put("clickX", String.valueOf(this.b));
      hashMap.put("clickY", String.valueOf(this.c));
      hashMap.put("width", String.valueOf(this.d));
      hashMap.put("height", String.valueOf(this.e));
      hashMap.put("adPositionX", String.valueOf(this.f));
      hashMap.put("adPositionY", String.valueOf(this.g));
      hashMap.put("visibleWidth", String.valueOf(this.i));
      hashMap.put("visibleHeight", String.valueOf(this.h));
      return (Map)hashMap;
    }
    
    public void onClick(View param1View) {
      Map map;
      if (!NativeAd.g(this.a).d())
        Log.e("FBAudienceNetworkLog", "No touch data recorded, please ensure touch events reach the ad View by returning false if you intercept the event."); 
      int i = h.g(NativeAd.q(this.a));
      if (i >= 0 && NativeAd.g(this.a).c() < i) {
        if (!NativeAd.g(this.a).b()) {
          Log.e("FBAudienceNetworkLog", "Ad cannot be clicked before it is viewed.");
          return;
        } 
        Log.e("FBAudienceNetworkLog", "Clicks happened too fast.");
        return;
      } 
      if (!(param1View instanceof AdChoicesView) && NativeAd.g(this.a).a(h.h(NativeAd.q(this.a)))) {
        Log.e("FBAudienceNetworkLog", "Clicks are too close to the border of the view.");
        return;
      } 
      if (TextUtils.isEmpty(this.a.h())) {
        map = a();
      } else {
        map = NativeAd.g(this.a).e();
      } 
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      hashMap.put("touch", h.a(map));
      if (NativeAd.k(this.a) != null)
        hashMap.put("nti", String.valueOf(NativeAd.k(this.a).getValue())); 
      if (NativeAd.l(this.a))
        hashMap.put("nhs", String.valueOf(NativeAd.l(this.a))); 
      NativeAd.h(this.a).a(hashMap);
      this.a.a.b(hashMap);
    }
    
    public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
      boolean bool = true;
      NativeAd.g(this.a).a(param1MotionEvent, NativeAd.j(this.a), param1View);
      if (param1MotionEvent.getAction() == 0 && NativeAd.j(this.a) != null && TextUtils.isEmpty(this.a.h())) {
        this.d = NativeAd.j(this.a).getWidth();
        this.e = NativeAd.j(this.a).getHeight();
        int[] arrayOfInt1 = new int[2];
        NativeAd.j(this.a).getLocationInWindow(arrayOfInt1);
        this.f = arrayOfInt1[0];
        this.g = arrayOfInt1[1];
        Rect rect = new Rect();
        NativeAd.j(this.a).getGlobalVisibleRect(rect);
        this.i = rect.width();
        this.h = rect.height();
        int[] arrayOfInt2 = new int[2];
        param1View.getLocationInWindow(arrayOfInt2);
        this.b = (int)param1MotionEvent.getX() + arrayOfInt2[0] - arrayOfInt1[0];
        int i = (int)param1MotionEvent.getY();
        this.c = arrayOfInt2[1] + i - arrayOfInt1[1];
      } 
      if (NativeAd.r(this.a) == null || !NativeAd.r(this.a).onTouch(param1View, param1MotionEvent))
        bool = false; 
      return bool;
    }
  }
  
  private class b extends BroadcastReceiver {
    private boolean b;
    
    private b(NativeAd this$0) {}
    
    public void a() {
      IntentFilter intentFilter = new IntentFilter();
      intentFilter.addAction("com.facebook.ads.native.impression:" + NativeAd.s(this.a));
      intentFilter.addAction("com.facebook.ads.native.click:" + NativeAd.s(this.a));
      LocalBroadcastManager.getInstance(NativeAd.q(this.a)).registerReceiver(this, intentFilter);
      this.b = true;
    }
    
    public void b() {
      if (this.b)
        try {
          LocalBroadcastManager.getInstance(NativeAd.q(this.a)).unregisterReceiver(this);
        } catch (Exception exception) {} 
    }
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      String str = param1Intent.getAction().split(":")[0];
      if ("com.facebook.ads.native.impression".equals(str) && NativeAd.i(this.a) != null) {
        NativeAd.i(this.a).a();
        return;
      } 
      if ("com.facebook.ads.native.click".equals(str) && this.a.a != null) {
        HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
        hashMap.put("mil", String.valueOf(true));
        this.a.a.b(hashMap);
      } 
    }
  }
  
  private class c extends b {
    private c(NativeAd this$0) {}
    
    public boolean a() {
      return false;
    }
    
    public void d() {
      if (NativeAd.o(this.b) != null)
        NativeAd.o(this.b).onLoggingImpression(this.b); 
      if (NativeAd.a(this.b) instanceof ImpressionListener && NativeAd.a(this.b) != NativeAd.o(this.b))
        ((ImpressionListener)NativeAd.a(this.b)).onLoggingImpression(this.b); 
    }
    
    public void e() {}
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/NativeAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */