package com.facebook.ads;

public interface RewardedVideoAdListener extends AdListener {
  void onLoggingImpression(Ad paramAd);
  
  void onRewardedVideoClosed();
  
  void onRewardedVideoCompleted();
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/RewardedVideoAdListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */