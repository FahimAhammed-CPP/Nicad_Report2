package com.facebook.ads;

public interface AdListener {
  void onAdClicked(Ad paramAd);
  
  void onAdLoaded(Ad paramAd);
  
  void onError(Ad paramAd, AdError paramAdError);
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/AdListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */