package com.facebook.ads;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import com.facebook.ads.internal.util.AdInternalSettings;
import com.facebook.ads.internal.util.h;
import com.facebook.ads.internal.util.s;
import java.util.Collection;
import java.util.HashSet;
import java.util.UUID;

public class AdSettings {
  public static final boolean DEBUG = false;
  
  static volatile boolean a;
  
  private static final String b = AdSettings.class.getSimpleName();
  
  private static final Collection<String> c = new HashSet<String>();
  
  private static final Collection<String> d = new HashSet<String>();
  
  private static String e;
  
  private static boolean f;
  
  private static boolean g;
  
  private static String h;
  
  private static boolean i;
  
  private static String j;
  
  static {
    d.add("sdk");
    d.add("google_sdk");
    d.add("vbox86p");
    d.add("vbox86tp");
    a = false;
  }
  
  private static void a(String paramString) {
    if (!a) {
      a = true;
      Log.d(b, "Test mode device hash: " + paramString);
      Log.d(b, "When testing your app with Facebook's ad units you must specify the device hashed ID to ensure the delivery of test ads, add the following code before loading an ad: AdSettings.addTestDevice(\"" + paramString + "\");");
    } 
  }
  
  public static void addTestDevice(String paramString) {
    c.add(paramString);
  }
  
  public static void addTestDevices(Collection<String> paramCollection) {
    c.addAll(paramCollection);
  }
  
  public static void clearTestDevices() {
    c.clear();
  }
  
  public static String getMediationService() {
    return h;
  }
  
  public static String getUrlPrefix() {
    return e;
  }
  
  public static boolean isChildDirected() {
    return i;
  }
  
  public static boolean isTestMode(Context paramContext) {
    boolean bool1 = true;
    boolean bool2 = bool1;
    if (!AdInternalSettings.a) {
      if (d.contains(Build.PRODUCT))
        return bool1; 
    } else {
      return bool2;
    } 
    if (j == null) {
      SharedPreferences sharedPreferences = paramContext.getSharedPreferences("FBAdPrefs", 0);
      j = sharedPreferences.getString("deviceIdHash", null);
      if (TextUtils.isEmpty(j)) {
        h.a a = h.a(paramContext.getContentResolver());
        if (!TextUtils.isEmpty(a.b)) {
          j = s.a(a.b);
        } else if (!TextUtils.isEmpty(a.a)) {
          j = s.a(a.a);
        } else {
          j = s.a(UUID.randomUUID().toString());
        } 
        sharedPreferences.edit().putString("deviceIdHash", j).apply();
      } 
    } 
    bool2 = bool1;
    if (!c.contains(j)) {
      a(j);
      bool2 = false;
    } 
    return bool2;
  }
  
  public static boolean isVideoAutoplay() {
    return f;
  }
  
  public static boolean isVideoAutoplayOnMobile() {
    return g;
  }
  
  public static void setIsChildDirected(boolean paramBoolean) {
    i = paramBoolean;
  }
  
  public static void setMediationService(String paramString) {
    h = paramString;
  }
  
  public static void setUrlPrefix(String paramString) {
    e = paramString;
  }
  
  public static void setVideoAutoplay(boolean paramBoolean) {
    f = paramBoolean;
  }
  
  public static void setVideoAutoplayOnMobile(boolean paramBoolean) {
    g = paramBoolean;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/AdSettings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */