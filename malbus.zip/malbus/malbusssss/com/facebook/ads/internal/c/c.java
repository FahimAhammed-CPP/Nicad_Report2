package com.facebook.ads.internal.c;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.Nullable;
import android.util.Log;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class c {
  private static final String a = c.class.getSimpleName();
  
  private static c b;
  
  private final Context c;
  
  private c(Context paramContext) {
    this.c = paramContext;
  }
  
  public static c a(Context paramContext) {
    if (b == null)
      synchronized (paramContext.getApplicationContext()) {
        if (b == null) {
          c c1 = new c();
          this(paramContext);
          b = c1;
        } 
        return b;
      }  
    return b;
  }
  
  private static void a(@Nullable Closeable paramCloseable) {
    if (paramCloseable != null)
      try {
        paramCloseable.close();
      } catch (IOException iOException) {} 
  }
  
  @Nullable
  private Bitmap b(String paramString) {
    Bitmap bitmap;
    try {
      FileInputStream fileInputStream = new FileInputStream();
      this(paramString.substring("file://".length()));
      Bitmap bitmap1 = BitmapFactory.decodeStream(fileInputStream, null, null);
      a(paramString, bitmap1);
      bitmap = bitmap1;
    } catch (IOException iOException) {
      Log.e(a, "Failed to copy local image into cache (url=" + bitmap + ").", iOException);
      bitmap = null;
    } 
    return bitmap;
  }
  
  @Nullable
  private Bitmap c(String paramString) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_1
    //   3: ldc 'asset:///'
    //   5: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   8: ifeq -> 128
    //   11: aload_0
    //   12: getfield c : Landroid/content/Context;
    //   15: invokevirtual getAssets : ()Landroid/content/res/AssetManager;
    //   18: aload_1
    //   19: bipush #9
    //   21: aload_1
    //   22: invokevirtual length : ()I
    //   25: invokevirtual substring : (II)Ljava/lang/String;
    //   28: invokevirtual open : (Ljava/lang/String;)Ljava/io/InputStream;
    //   31: astore_3
    //   32: aload_3
    //   33: invokestatic decodeStream : (Ljava/io/InputStream;)Landroid/graphics/Bitmap;
    //   36: astore #4
    //   38: aload #4
    //   40: astore_2
    //   41: aload_2
    //   42: astore #4
    //   44: aload_3
    //   45: ifnull -> 55
    //   48: aload_3
    //   49: invokevirtual close : ()V
    //   52: aload_2
    //   53: astore #4
    //   55: aload_0
    //   56: aload_1
    //   57: aload #4
    //   59: invokevirtual a : (Ljava/lang/String;Landroid/graphics/Bitmap;)V
    //   62: aload #4
    //   64: areturn
    //   65: astore_3
    //   66: aload_3
    //   67: invokevirtual printStackTrace : ()V
    //   70: aload_2
    //   71: astore #4
    //   73: goto -> 55
    //   76: astore_1
    //   77: aconst_null
    //   78: astore_3
    //   79: aload_2
    //   80: astore #4
    //   82: aload_3
    //   83: ifnull -> 62
    //   86: aload_3
    //   87: invokevirtual close : ()V
    //   90: aload_2
    //   91: astore #4
    //   93: goto -> 62
    //   96: astore_1
    //   97: aload_1
    //   98: invokevirtual printStackTrace : ()V
    //   101: aload_2
    //   102: astore #4
    //   104: goto -> 62
    //   107: astore_1
    //   108: aconst_null
    //   109: astore_3
    //   110: aload_3
    //   111: ifnull -> 118
    //   114: aload_3
    //   115: invokevirtual close : ()V
    //   118: aload_1
    //   119: athrow
    //   120: astore_3
    //   121: aload_3
    //   122: invokevirtual printStackTrace : ()V
    //   125: goto -> 118
    //   128: aload_0
    //   129: getfield c : Landroid/content/Context;
    //   132: invokestatic a : (Landroid/content/Context;)Lcom/facebook/ads/internal/i/a/a;
    //   135: aload_1
    //   136: aconst_null
    //   137: invokevirtual a : (Ljava/lang/String;Lcom/facebook/ads/internal/i/a/p;)Lcom/facebook/ads/internal/i/a/n;
    //   140: invokevirtual d : ()[B
    //   143: astore_3
    //   144: aload_3
    //   145: iconst_0
    //   146: aload_3
    //   147: arraylength
    //   148: invokestatic decodeByteArray : ([BII)Landroid/graphics/Bitmap;
    //   151: astore #4
    //   153: goto -> 55
    //   156: astore_1
    //   157: goto -> 110
    //   160: astore_1
    //   161: goto -> 79
    // Exception table:
    //   from	to	target	type
    //   11	32	76	java/io/IOException
    //   11	32	107	finally
    //   32	38	160	java/io/IOException
    //   32	38	156	finally
    //   48	52	65	java/io/IOException
    //   86	90	96	java/io/IOException
    //   114	118	120	java/io/IOException
  }
  
  @Nullable
  public Bitmap a(String paramString) {
    File file = new File(this.c.getCacheDir(), paramString.hashCode() + ".png");
    return !file.exists() ? (paramString.startsWith("file://") ? b(paramString) : c(paramString)) : BitmapFactory.decodeFile(file.getAbsolutePath());
  }
  
  public void a(String paramString, Bitmap paramBitmap) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aconst_null
    //   3: astore #4
    //   5: aconst_null
    //   6: astore #5
    //   8: aconst_null
    //   9: astore #6
    //   11: aconst_null
    //   12: astore #7
    //   14: new java/io/File
    //   17: dup
    //   18: aload_0
    //   19: getfield c : Landroid/content/Context;
    //   22: invokevirtual getCacheDir : ()Ljava/io/File;
    //   25: new java/lang/StringBuilder
    //   28: dup
    //   29: invokespecial <init> : ()V
    //   32: aload_1
    //   33: invokevirtual hashCode : ()I
    //   36: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   39: ldc '.png'
    //   41: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   44: invokevirtual toString : ()Ljava/lang/String;
    //   47: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   50: astore #8
    //   52: new java/io/ByteArrayOutputStream
    //   55: astore #9
    //   57: aload #9
    //   59: invokespecial <init> : ()V
    //   62: aload #6
    //   64: astore #5
    //   66: aload #9
    //   68: astore #10
    //   70: aload_2
    //   71: getstatic android/graphics/Bitmap$CompressFormat.PNG : Landroid/graphics/Bitmap$CompressFormat;
    //   74: bipush #100
    //   76: aload #9
    //   78: invokevirtual compress : (Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z
    //   81: pop
    //   82: aload #6
    //   84: astore #5
    //   86: aload #9
    //   88: astore #10
    //   90: aload #9
    //   92: invokevirtual size : ()I
    //   95: ldc 3145728
    //   97: if_icmplt -> 127
    //   100: aload #6
    //   102: astore #5
    //   104: aload #9
    //   106: astore #10
    //   108: getstatic com/facebook/ads/internal/c/c.a : Ljava/lang/String;
    //   111: ldc 'Bitmap size exceeds max size for storage'
    //   113: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   116: pop
    //   117: aload #9
    //   119: invokestatic a : (Ljava/io/Closeable;)V
    //   122: aconst_null
    //   123: invokestatic a : (Ljava/io/Closeable;)V
    //   126: return
    //   127: aload #6
    //   129: astore #5
    //   131: aload #9
    //   133: astore #10
    //   135: new java/io/FileOutputStream
    //   138: dup
    //   139: aload #8
    //   141: invokespecial <init> : (Ljava/io/File;)V
    //   144: astore_2
    //   145: aload #9
    //   147: aload_2
    //   148: invokevirtual writeTo : (Ljava/io/OutputStream;)V
    //   151: aload_2
    //   152: invokevirtual flush : ()V
    //   155: aload #9
    //   157: invokestatic a : (Ljava/io/Closeable;)V
    //   160: aload_2
    //   161: invokestatic a : (Ljava/io/Closeable;)V
    //   164: goto -> 126
    //   167: astore_2
    //   168: aconst_null
    //   169: astore_1
    //   170: aload #7
    //   172: astore #5
    //   174: getstatic com/facebook/ads/internal/c/c.a : Ljava/lang/String;
    //   177: astore #9
    //   179: new java/lang/StringBuilder
    //   182: astore #10
    //   184: aload #10
    //   186: invokespecial <init> : ()V
    //   189: aload #9
    //   191: aload #10
    //   193: ldc 'Bad output destination (file='
    //   195: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   198: aload #8
    //   200: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   203: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   206: ldc ').'
    //   208: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   211: invokevirtual toString : ()Ljava/lang/String;
    //   214: aload_2
    //   215: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   218: pop
    //   219: aload_1
    //   220: invokestatic a : (Ljava/io/Closeable;)V
    //   223: aload #5
    //   225: invokestatic a : (Ljava/io/Closeable;)V
    //   228: goto -> 126
    //   231: astore_2
    //   232: aconst_null
    //   233: astore #9
    //   235: aload_3
    //   236: astore #7
    //   238: aload #7
    //   240: astore #5
    //   242: aload #9
    //   244: astore #10
    //   246: getstatic com/facebook/ads/internal/c/c.a : Ljava/lang/String;
    //   249: astore #4
    //   251: aload #7
    //   253: astore #5
    //   255: aload #9
    //   257: astore #10
    //   259: new java/lang/StringBuilder
    //   262: astore_3
    //   263: aload #7
    //   265: astore #5
    //   267: aload #9
    //   269: astore #10
    //   271: aload_3
    //   272: invokespecial <init> : ()V
    //   275: aload #7
    //   277: astore #5
    //   279: aload #9
    //   281: astore #10
    //   283: aload #4
    //   285: aload_3
    //   286: ldc 'Unable to write bitmap to file (url='
    //   288: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   291: aload_1
    //   292: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   295: ldc ').'
    //   297: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   300: invokevirtual toString : ()Ljava/lang/String;
    //   303: aload_2
    //   304: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   307: pop
    //   308: aload #9
    //   310: invokestatic a : (Ljava/io/Closeable;)V
    //   313: aload #7
    //   315: invokestatic a : (Ljava/io/Closeable;)V
    //   318: goto -> 126
    //   321: astore_1
    //   322: aconst_null
    //   323: astore #9
    //   325: aload #4
    //   327: astore_2
    //   328: aload_2
    //   329: astore #5
    //   331: aload #9
    //   333: astore #10
    //   335: getstatic com/facebook/ads/internal/c/c.a : Ljava/lang/String;
    //   338: ldc 'Unable to write bitmap to output stream'
    //   340: aload_1
    //   341: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   344: pop
    //   345: aload #9
    //   347: invokestatic a : (Ljava/io/Closeable;)V
    //   350: aload_2
    //   351: invokestatic a : (Ljava/io/Closeable;)V
    //   354: goto -> 126
    //   357: astore_1
    //   358: aconst_null
    //   359: astore #9
    //   361: aload #9
    //   363: invokestatic a : (Ljava/io/Closeable;)V
    //   366: aload #5
    //   368: invokestatic a : (Ljava/io/Closeable;)V
    //   371: aload_1
    //   372: athrow
    //   373: astore_1
    //   374: aload #10
    //   376: astore #9
    //   378: goto -> 361
    //   381: astore_1
    //   382: aload_2
    //   383: astore #5
    //   385: goto -> 361
    //   388: astore_2
    //   389: aload_1
    //   390: astore #9
    //   392: aload_2
    //   393: astore_1
    //   394: goto -> 361
    //   397: astore_1
    //   398: aload #4
    //   400: astore_2
    //   401: goto -> 328
    //   404: astore_1
    //   405: goto -> 328
    //   408: astore_2
    //   409: aload_3
    //   410: astore #7
    //   412: goto -> 238
    //   415: astore #10
    //   417: aload_2
    //   418: astore #7
    //   420: aload #10
    //   422: astore_2
    //   423: goto -> 238
    //   426: astore_2
    //   427: aload #9
    //   429: astore_1
    //   430: aload #7
    //   432: astore #5
    //   434: goto -> 174
    //   437: astore_1
    //   438: aload_2
    //   439: astore #5
    //   441: aload_1
    //   442: astore_2
    //   443: aload #9
    //   445: astore_1
    //   446: goto -> 174
    // Exception table:
    //   from	to	target	type
    //   52	62	167	java/io/FileNotFoundException
    //   52	62	231	java/io/IOException
    //   52	62	321	java/lang/OutOfMemoryError
    //   52	62	357	finally
    //   70	82	426	java/io/FileNotFoundException
    //   70	82	408	java/io/IOException
    //   70	82	397	java/lang/OutOfMemoryError
    //   70	82	373	finally
    //   90	100	426	java/io/FileNotFoundException
    //   90	100	408	java/io/IOException
    //   90	100	397	java/lang/OutOfMemoryError
    //   90	100	373	finally
    //   108	117	426	java/io/FileNotFoundException
    //   108	117	408	java/io/IOException
    //   108	117	397	java/lang/OutOfMemoryError
    //   108	117	373	finally
    //   135	145	426	java/io/FileNotFoundException
    //   135	145	408	java/io/IOException
    //   135	145	397	java/lang/OutOfMemoryError
    //   135	145	373	finally
    //   145	155	437	java/io/FileNotFoundException
    //   145	155	415	java/io/IOException
    //   145	155	404	java/lang/OutOfMemoryError
    //   145	155	381	finally
    //   174	219	388	finally
    //   246	251	373	finally
    //   259	263	373	finally
    //   271	275	373	finally
    //   283	308	373	finally
    //   335	345	373	finally
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/c/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */