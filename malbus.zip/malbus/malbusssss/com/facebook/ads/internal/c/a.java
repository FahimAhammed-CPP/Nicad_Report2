package com.facebook.ads.internal.c;

public interface a {
  void a();
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/c/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */