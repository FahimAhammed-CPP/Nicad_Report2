package com.facebook.ads.internal.c;

import android.content.Context;
import android.os.Handler;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class b {
  private static final String a = b.class.getSimpleName();
  
  private final Handler b = new Handler();
  
  private final ExecutorService c = Executors.newFixedThreadPool(10);
  
  private final c d;
  
  private final d e;
  
  private final List<Callable<Boolean>> f;
  
  public b(Context paramContext) {
    this.d = c.a(paramContext);
    this.e = d.a(paramContext);
    this.f = new ArrayList<Callable<Boolean>>();
  }
  
  public void a(a parama) {
    ArrayList<Callable<Boolean>> arrayList = new ArrayList<Callable<Boolean>>(this.f);
    this.c.submit(new Runnable(this, arrayList, parama) {
          public void run() {
            ArrayList arrayList = new ArrayList(this.a.size());
            for (Callable<?> callable : (Iterable<Callable<?>>)this.a)
              arrayList.add(b.a(this.c).submit(callable)); 
            try {
              Iterator<Future> iterator = arrayList.iterator();
              while (iterator.hasNext())
                ((Future)iterator.next()).get(); 
              b.b(this.c).post(new Runnable(this) {
                    public void run() {
                      this.a.b.a();
                    }
                  });
              return;
            } catch (InterruptedException interruptedException) {
            
            } catch (ExecutionException executionException) {}
            Log.e(b.a(), "Exception while executing cache downloads.", executionException);
            b.b(this.c).post(new Runnable(this) {
                  public void run() {
                    this.a.b.a();
                  }
                });
          }
        });
    this.f.clear();
  }
  
  public void a(String paramString) {
    this.f.add(new a(this, paramString));
  }
  
  public void b(String paramString) {
    this.f.add(new b(this, paramString));
  }
  
  public String c(String paramString) {
    return this.e.b(paramString);
  }
  
  private class a implements Callable<Boolean> {
    private final String b;
    
    public a(b this$0, String param1String) {
      this.b = param1String;
    }
    
    public Boolean a() {
      b.c(this.a).a(this.b);
      return Boolean.valueOf(true);
    }
  }
  
  private class b implements Callable<Boolean> {
    private final String b;
    
    public b(b this$0, String param1String) {
      this.b = param1String;
    }
    
    public Boolean a() {
      b.d(this.a).a(this.b);
      return Boolean.valueOf(true);
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/c/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */