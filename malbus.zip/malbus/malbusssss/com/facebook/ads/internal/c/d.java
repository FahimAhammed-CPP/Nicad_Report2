package com.facebook.ads.internal.c;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.Log;
import com.facebook.ads.internal.i.b.f;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class d {
  private static final String a = d.class.getSimpleName();
  
  private static d b;
  
  private final Future<f> c;
  
  private d(Context paramContext) {
    this.c = Executors.newSingleThreadExecutor().submit(new Callable<f>(this, paramContext) {
          public f a() {
            return new f(this.a);
          }
        });
  }
  
  public static d a(Context paramContext) {
    if (b == null)
      synchronized (paramContext.getApplicationContext()) {
        if (b == null) {
          d d1 = new d();
          this(paramContext);
          b = d1;
        } 
        return b;
      }  
    return b;
  }
  
  @Nullable
  private f a() {
    try {
      return this.c.get(500L, TimeUnit.MILLISECONDS);
    } catch (InterruptedException interruptedException) {
    
    } catch (ExecutionException executionException) {
    
    } catch (TimeoutException null) {}
    Log.e(a, "Timed out waiting for cache server.", null);
    return null;
  }
  
  public void a(String paramString) {
    f f = a();
    if (f != null)
      f.a(paramString); 
  }
  
  @Nullable
  public String b(String paramString) {
    f f = a();
    return (f == null) ? null : f.b(paramString);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/c/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */