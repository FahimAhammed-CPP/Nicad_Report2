package com.facebook.ads.internal;

import android.text.TextUtils;
import com.facebook.ads.AdError;

public class b {
  private final AdErrorType a;
  
  private final String b;
  
  public b(int paramInt, String paramString) {
    this(AdErrorType.adErrorTypeFromCode(paramInt), paramString);
  }
  
  public b(AdErrorType paramAdErrorType, String paramString) {
    String str = paramString;
    if (TextUtils.isEmpty(paramString))
      str = paramAdErrorType.getDefaultErrorMessage(); 
    this.a = paramAdErrorType;
    this.b = str;
  }
  
  public AdErrorType a() {
    return this.a;
  }
  
  public AdError b() {
    return this.a.a() ? new AdError(this.a.getErrorCode(), this.b) : new AdError(AdErrorType.UNKNOWN_ERROR.getErrorCode(), AdErrorType.UNKNOWN_ERROR.getDefaultErrorMessage());
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */