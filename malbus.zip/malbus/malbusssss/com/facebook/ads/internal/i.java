package com.facebook.ads.internal;

import android.content.Context;
import android.os.Handler;
import com.facebook.ads.AdError;
import com.facebook.ads.AdSettings;
import com.facebook.ads.AdSize;
import com.facebook.ads.NativeAd;
import com.facebook.ads.internal.adapters.AdAdapter;
import com.facebook.ads.internal.adapters.d;
import com.facebook.ads.internal.adapters.v;
import com.facebook.ads.internal.adapters.w;
import com.facebook.ads.internal.d.a;
import com.facebook.ads.internal.f.a;
import com.facebook.ads.internal.f.d;
import com.facebook.ads.internal.f.f;
import com.facebook.ads.internal.g.f;
import com.facebook.ads.internal.g.g;
import com.facebook.ads.internal.server.AdPlacementType;
import com.facebook.ads.internal.server.a;
import com.facebook.ads.internal.server.e;
import com.facebook.ads.internal.util.al;
import com.facebook.ads.internal.util.o;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;

public class i implements a.a {
  private final Context a;
  
  private final String b;
  
  private final a c;
  
  private final e d;
  
  private final c e;
  
  private final AdSize f;
  
  private final int g;
  
  private boolean h;
  
  private final Handler i;
  
  private final Runnable j;
  
  private a k;
  
  private d l;
  
  public i(Context paramContext, String paramString, e parame, AdSize paramAdSize, c paramc, int paramInt, EnumSet<NativeAd.MediaCacheFlag> paramEnumSet) {
    this.a = paramContext;
    this.b = paramString;
    this.d = parame;
    this.f = paramAdSize;
    this.e = paramc;
    this.g = paramInt;
    this.c = new a(paramContext);
    this.c.a(this);
    this.h = true;
    this.i = new Handler();
    this.j = (Runnable)new b(this);
    a.a(paramContext).a();
  }
  
  private List<v> d() {
    d d1 = this.l;
    a a1 = d1.d();
    ArrayList<v> arrayList = new ArrayList(d1.c());
    while (a1 != null) {
      AdAdapter adAdapter = d.a(a1.a(), AdPlacementType.NATIVE);
      if (adAdapter != null && adAdapter.getPlacementType() == AdPlacementType.NATIVE) {
        HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
        hashMap.put("data", a1.b());
        hashMap.put("definition", d1.a());
        ((v)adAdapter).a(this.a, new w(this, arrayList) {
              public void a(v param1v) {
                this.a.add(param1v);
              }
              
              public void a(v param1v, AdError param1AdError) {}
              
              public void b(v param1v) {}
              
              public void c(v param1v) {}
            }(f)g.a(this.a), hashMap);
      } 
      a1 = d1.d();
    } 
    return arrayList;
  }
  
  public void a() {
    f f = new f(this.a, this.b, this.f, this.d, this.e, this.g, AdSettings.isTestMode(this.a));
    this.c.a(f);
  }
  
  public void a(b paramb) {
    if (this.h)
      this.i.postDelayed(this.j, 1800000L); 
    if (this.k != null)
      this.k.a(paramb); 
  }
  
  public void a(a parama) {
    this.k = parama;
  }
  
  public void a(e parame) {
    d d1 = parame.b();
    if (d1 == null)
      throw new IllegalStateException("no placement in response"); 
    if (this.h) {
      long l1 = d1.a().b();
      long l2 = l1;
      if (l1 == 0L)
        l2 = 1800000L; 
      this.i.postDelayed(this.j, l2);
    } 
    this.l = d1;
    List<v> list = d();
    if (this.k != null) {
      if (list.isEmpty()) {
        this.k.a(AdErrorType.NO_FILL.getAdErrorWrapper(""));
        return;
      } 
    } else {
      return;
    } 
    this.k.a(list);
  }
  
  public void b() {}
  
  public void c() {
    this.h = false;
    this.i.removeCallbacks(this.j);
  }
  
  public static interface a {
    void a(b param1b);
    
    void a(List<v> param1List);
  }
  
  private static final class b extends al<i> {
    public b(i param1i) {
      super(param1i);
    }
    
    public void run() {
      i i = (i)a();
      if (i != null) {
        if (o.a(i.a(i))) {
          i.a();
          return;
        } 
        i.c(i).postDelayed(i.b(i), 5000L);
      } 
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */