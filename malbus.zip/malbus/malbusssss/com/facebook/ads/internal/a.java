package com.facebook.ads.internal;

import android.view.View;
import com.facebook.ads.internal.adapters.AdAdapter;
import com.facebook.ads.internal.adapters.v;

public abstract class a {
  public abstract void a();
  
  public void a(View paramView) {}
  
  public abstract void a(AdAdapter paramAdAdapter);
  
  public void a(v paramv) {}
  
  public abstract void a(b paramb);
  
  public abstract void b();
  
  public void c() {}
  
  public void d() {}
  
  public void e() {}
  
  public void f() {}
  
  public void g() {}
  
  public void h() {}
  
  public void i() {}
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */