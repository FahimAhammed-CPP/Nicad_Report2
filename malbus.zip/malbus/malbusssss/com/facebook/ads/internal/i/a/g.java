package com.facebook.ads.internal.i.a;

import java.net.HttpURLConnection;
import java.util.List;
import java.util.Map;

public class g implements r {
  private void a(Map<String, List<String>> paramMap) {
    if (paramMap != null)
      for (String str : paramMap.keySet()) {
        for (String str1 : paramMap.get(str))
          a(str + ":" + str1); 
      }  
  }
  
  public void a(n paramn) {
    if (paramn != null) {
      a("=== HTTP Response ===");
      a("Receive url: " + paramn.b());
      a("Status: " + paramn.a());
      a(paramn.c());
      a("Content:\n" + paramn.e());
    } 
  }
  
  public void a(String paramString) {
    System.out.println(paramString);
  }
  
  public void a(HttpURLConnection paramHttpURLConnection, Object paramObject) {
    a("=== HTTP Request ===");
    a(paramHttpURLConnection.getRequestMethod() + " " + paramHttpURLConnection.getURL().toString());
    if (paramObject instanceof String)
      a("Content: " + (String)paramObject); 
    a(paramHttpURLConnection.getRequestProperties());
  }
  
  public boolean a() {
    return false;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/a/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */