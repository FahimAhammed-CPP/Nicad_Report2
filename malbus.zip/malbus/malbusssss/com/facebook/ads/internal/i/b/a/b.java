package com.facebook.ads.internal.i.b.a;

import com.facebook.ads.internal.i.b.a;
import com.facebook.ads.internal.i.b.l;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

public class b implements a {
  public File a;
  
  private final a b;
  
  private RandomAccessFile c;
  
  public b(File paramFile, a parama) {
    File file1;
    String str;
    if (parama == null)
      try {
        NullPointerException nullPointerException = new NullPointerException();
        this();
        throw nullPointerException;
      } catch (IOException iOException) {
        throw new l("Error using file " + paramFile + " as disc cache", iOException);
      }  
    this.b = (a)iOException;
    d.a(paramFile.getParentFile());
    boolean bool = paramFile.exists();
    if (bool) {
      file1 = paramFile;
    } else {
      file1 = paramFile.getParentFile();
      StringBuilder stringBuilder = new StringBuilder();
      this();
      file1 = new File(file1, stringBuilder.append(paramFile.getName()).append(".download").toString());
    } 
    this.a = file1;
    RandomAccessFile randomAccessFile = new RandomAccessFile();
    File file2 = this.a;
    if (bool) {
      str = "r";
    } else {
      str = "rw";
    } 
    this(file2, str);
    this.c = randomAccessFile;
  }
  
  private boolean a(File paramFile) {
    return paramFile.getName().endsWith(".download");
  }
  
  public int a() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield c : Ljava/io/RandomAccessFile;
    //   6: invokevirtual length : ()J
    //   9: lstore_1
    //   10: lload_1
    //   11: l2i
    //   12: istore_3
    //   13: aload_0
    //   14: monitorexit
    //   15: iload_3
    //   16: ireturn
    //   17: astore #4
    //   19: new com/facebook/ads/internal/i/b/l
    //   22: astore #5
    //   24: new java/lang/StringBuilder
    //   27: astore #6
    //   29: aload #6
    //   31: invokespecial <init> : ()V
    //   34: aload #5
    //   36: aload #6
    //   38: ldc 'Error reading length of file '
    //   40: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   43: aload_0
    //   44: getfield a : Ljava/io/File;
    //   47: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   50: invokevirtual toString : ()Ljava/lang/String;
    //   53: aload #4
    //   55: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   58: aload #5
    //   60: athrow
    //   61: astore #4
    //   63: aload_0
    //   64: monitorexit
    //   65: aload #4
    //   67: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	17	java/io/IOException
    //   2	10	61	finally
    //   19	61	61	finally
  }
  
  public int a(byte[] paramArrayOfbyte, long paramLong, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield c : Ljava/io/RandomAccessFile;
    //   6: lload_2
    //   7: invokevirtual seek : (J)V
    //   10: aload_0
    //   11: getfield c : Ljava/io/RandomAccessFile;
    //   14: aload_1
    //   15: iconst_0
    //   16: iload #4
    //   18: invokevirtual read : ([BII)I
    //   21: istore #5
    //   23: aload_0
    //   24: monitorexit
    //   25: iload #5
    //   27: ireturn
    //   28: astore #6
    //   30: new com/facebook/ads/internal/i/b/l
    //   33: astore #7
    //   35: aload #7
    //   37: ldc 'Error reading %d bytes with offset %d from file[%d bytes] to buffer[%d bytes]'
    //   39: iconst_4
    //   40: anewarray java/lang/Object
    //   43: dup
    //   44: iconst_0
    //   45: iload #4
    //   47: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   50: aastore
    //   51: dup
    //   52: iconst_1
    //   53: lload_2
    //   54: invokestatic valueOf : (J)Ljava/lang/Long;
    //   57: aastore
    //   58: dup
    //   59: iconst_2
    //   60: aload_0
    //   61: invokevirtual a : ()I
    //   64: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   67: aastore
    //   68: dup
    //   69: iconst_3
    //   70: aload_1
    //   71: arraylength
    //   72: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   75: aastore
    //   76: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   79: aload #6
    //   81: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   84: aload #7
    //   86: athrow
    //   87: astore_1
    //   88: aload_0
    //   89: monitorexit
    //   90: aload_1
    //   91: athrow
    // Exception table:
    //   from	to	target	type
    //   2	23	28	java/io/IOException
    //   2	23	87	finally
    //   30	87	87	finally
  }
  
  public void a(byte[] paramArrayOfbyte, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual d : ()Z
    //   6: ifeq -> 102
    //   9: new com/facebook/ads/internal/i/b/l
    //   12: astore_3
    //   13: new java/lang/StringBuilder
    //   16: astore #4
    //   18: aload #4
    //   20: invokespecial <init> : ()V
    //   23: aload_3
    //   24: aload #4
    //   26: ldc 'Error append cache: cache file '
    //   28: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   31: aload_0
    //   32: getfield a : Ljava/io/File;
    //   35: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   38: ldc ' is completed!'
    //   40: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   43: invokevirtual toString : ()Ljava/lang/String;
    //   46: invokespecial <init> : (Ljava/lang/String;)V
    //   49: aload_3
    //   50: athrow
    //   51: astore_3
    //   52: new com/facebook/ads/internal/i/b/l
    //   55: astore #4
    //   57: aload #4
    //   59: ldc 'Error writing %d bytes to %s from buffer with size %d'
    //   61: iconst_3
    //   62: anewarray java/lang/Object
    //   65: dup
    //   66: iconst_0
    //   67: iload_2
    //   68: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   71: aastore
    //   72: dup
    //   73: iconst_1
    //   74: aload_0
    //   75: getfield c : Ljava/io/RandomAccessFile;
    //   78: aastore
    //   79: dup
    //   80: iconst_2
    //   81: aload_1
    //   82: arraylength
    //   83: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   86: aastore
    //   87: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   90: aload_3
    //   91: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   94: aload #4
    //   96: athrow
    //   97: astore_1
    //   98: aload_0
    //   99: monitorexit
    //   100: aload_1
    //   101: athrow
    //   102: aload_0
    //   103: getfield c : Ljava/io/RandomAccessFile;
    //   106: aload_0
    //   107: invokevirtual a : ()I
    //   110: i2l
    //   111: invokevirtual seek : (J)V
    //   114: aload_0
    //   115: getfield c : Ljava/io/RandomAccessFile;
    //   118: aload_1
    //   119: iconst_0
    //   120: iload_2
    //   121: invokevirtual write : ([BII)V
    //   124: aload_0
    //   125: monitorexit
    //   126: return
    // Exception table:
    //   from	to	target	type
    //   2	51	51	java/io/IOException
    //   2	51	97	finally
    //   52	97	97	finally
    //   102	124	51	java/io/IOException
    //   102	124	97	finally
  }
  
  public void b() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield c : Ljava/io/RandomAccessFile;
    //   6: invokevirtual close : ()V
    //   9: aload_0
    //   10: getfield b : Lcom/facebook/ads/internal/i/b/a/a;
    //   13: aload_0
    //   14: getfield a : Ljava/io/File;
    //   17: invokeinterface a : (Ljava/io/File;)V
    //   22: aload_0
    //   23: monitorexit
    //   24: return
    //   25: astore_1
    //   26: new com/facebook/ads/internal/i/b/l
    //   29: astore_2
    //   30: new java/lang/StringBuilder
    //   33: astore_3
    //   34: aload_3
    //   35: invokespecial <init> : ()V
    //   38: aload_2
    //   39: aload_3
    //   40: ldc 'Error closing file '
    //   42: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   45: aload_0
    //   46: getfield a : Ljava/io/File;
    //   49: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   52: invokevirtual toString : ()Ljava/lang/String;
    //   55: aload_1
    //   56: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   59: aload_2
    //   60: athrow
    //   61: astore_1
    //   62: aload_0
    //   63: monitorexit
    //   64: aload_1
    //   65: athrow
    // Exception table:
    //   from	to	target	type
    //   2	22	25	java/io/IOException
    //   2	22	61	finally
    //   26	61	61	finally
  }
  
  public void c() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual d : ()Z
    //   6: istore_1
    //   7: iload_1
    //   8: ifeq -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aload_0
    //   15: invokevirtual b : ()V
    //   18: aload_0
    //   19: getfield a : Ljava/io/File;
    //   22: invokevirtual getName : ()Ljava/lang/String;
    //   25: iconst_0
    //   26: aload_0
    //   27: getfield a : Ljava/io/File;
    //   30: invokevirtual getName : ()Ljava/lang/String;
    //   33: invokevirtual length : ()I
    //   36: ldc '.download'
    //   38: invokevirtual length : ()I
    //   41: isub
    //   42: invokevirtual substring : (II)Ljava/lang/String;
    //   45: astore_2
    //   46: new java/io/File
    //   49: astore_3
    //   50: aload_3
    //   51: aload_0
    //   52: getfield a : Ljava/io/File;
    //   55: invokevirtual getParentFile : ()Ljava/io/File;
    //   58: aload_2
    //   59: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   62: aload_0
    //   63: getfield a : Ljava/io/File;
    //   66: aload_3
    //   67: invokevirtual renameTo : (Ljava/io/File;)Z
    //   70: ifne -> 129
    //   73: new com/facebook/ads/internal/i/b/l
    //   76: astore #4
    //   78: new java/lang/StringBuilder
    //   81: astore_2
    //   82: aload_2
    //   83: invokespecial <init> : ()V
    //   86: aload #4
    //   88: aload_2
    //   89: ldc 'Error renaming file '
    //   91: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   94: aload_0
    //   95: getfield a : Ljava/io/File;
    //   98: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   101: ldc ' to '
    //   103: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   106: aload_3
    //   107: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   110: ldc ' for completion!'
    //   112: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   115: invokevirtual toString : ()Ljava/lang/String;
    //   118: invokespecial <init> : (Ljava/lang/String;)V
    //   121: aload #4
    //   123: athrow
    //   124: astore_3
    //   125: aload_0
    //   126: monitorexit
    //   127: aload_3
    //   128: athrow
    //   129: aload_0
    //   130: aload_3
    //   131: putfield a : Ljava/io/File;
    //   134: new java/io/RandomAccessFile
    //   137: astore_3
    //   138: aload_3
    //   139: aload_0
    //   140: getfield a : Ljava/io/File;
    //   143: ldc 'r'
    //   145: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   148: aload_0
    //   149: aload_3
    //   150: putfield c : Ljava/io/RandomAccessFile;
    //   153: goto -> 11
    //   156: astore #4
    //   158: new com/facebook/ads/internal/i/b/l
    //   161: astore_3
    //   162: new java/lang/StringBuilder
    //   165: astore_2
    //   166: aload_2
    //   167: invokespecial <init> : ()V
    //   170: aload_3
    //   171: aload_2
    //   172: ldc 'Error opening '
    //   174: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   177: aload_0
    //   178: getfield a : Ljava/io/File;
    //   181: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   184: ldc ' as disc cache'
    //   186: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   189: invokevirtual toString : ()Ljava/lang/String;
    //   192: aload #4
    //   194: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   197: aload_3
    //   198: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	124	finally
    //   14	124	124	finally
    //   129	134	124	finally
    //   134	153	156	java/io/IOException
    //   134	153	124	finally
    //   158	199	124	finally
  }
  
  public boolean d() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_0
    //   4: getfield a : Ljava/io/File;
    //   7: invokespecial a : (Ljava/io/File;)Z
    //   10: istore_1
    //   11: iload_1
    //   12: ifne -> 21
    //   15: iconst_1
    //   16: istore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: iload_1
    //   20: ireturn
    //   21: iconst_0
    //   22: istore_1
    //   23: goto -> 17
    //   26: astore_2
    //   27: aload_0
    //   28: monitorexit
    //   29: aload_2
    //   30: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	26	finally
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */