package com.facebook.ads.internal.i.a;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;

public interface q {
  OutputStream a(HttpURLConnection paramHttpURLConnection);
  
  HttpURLConnection a(String paramString);
  
  void a(OutputStream paramOutputStream, byte[] paramArrayOfbyte);
  
  void a(HttpURLConnection paramHttpURLConnection, j paramj, String paramString);
  
  boolean a(m paramm);
  
  byte[] a(InputStream paramInputStream);
  
  InputStream b(HttpURLConnection paramHttpURLConnection);
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/a/q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */