package com.facebook.ads.internal.i.b;

import android.util.Log;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class h implements n {
  public final String a;
  
  private HttpURLConnection b;
  
  private InputStream c;
  
  private volatile int d = Integer.MIN_VALUE;
  
  private volatile String e;
  
  public h(h paramh) {
    this.a = paramh.a;
    this.e = paramh.e;
    this.d = paramh.d;
  }
  
  public h(String paramString) {
    this(paramString, m.a(paramString));
  }
  
  public h(String paramString1, String paramString2) {
    this.a = j.<String>a(paramString1);
    this.e = paramString2;
  }
  
  private int a(HttpURLConnection paramHttpURLConnection, int paramInt1, int paramInt2) {
    int i = paramHttpURLConnection.getContentLength();
    return (paramInt2 == 200) ? i : ((paramInt2 == 206) ? (i + paramInt1) : this.d);
  }
  
  private HttpURLConnection a(int paramInt1, int paramInt2) {
    String str = this.a;
    int i = 0;
    while (true) {
      String str1;
      StringBuilder stringBuilder = (new StringBuilder()).append("Open connection ");
      if (paramInt1 > 0) {
        str1 = " with offset " + paramInt1;
      } else {
        str1 = "";
      } 
      Log.d("ProxyCache", stringBuilder.append(str1).append(" to ").append(str).toString());
      HttpURLConnection httpURLConnection = (HttpURLConnection)(new URL(str)).openConnection();
      if (paramInt1 > 0)
        httpURLConnection.setRequestProperty("Range", "bytes=" + paramInt1 + "-"); 
      if (paramInt2 > 0) {
        httpURLConnection.setConnectTimeout(paramInt2);
        httpURLConnection.setReadTimeout(paramInt2);
      } 
      int j = httpURLConnection.getResponseCode();
      if (j == 301 || j == 302 || j == 303) {
        j = 1;
      } else {
        j = 0;
      } 
      int k = i;
      if (j != 0) {
        str = httpURLConnection.getHeaderField("Location");
        k = i + 1;
        httpURLConnection.disconnect();
      } 
      if (k > 5)
        throw new l("Too many redirects: " + k); 
      i = k;
      if (j == 0)
        return httpURLConnection; 
    } 
  }
  
  private void d() {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: aconst_null
    //   3: astore_2
    //   4: aconst_null
    //   5: astore_3
    //   6: aconst_null
    //   7: astore #4
    //   9: ldc 'ProxyCache'
    //   11: new java/lang/StringBuilder
    //   14: dup
    //   15: invokespecial <init> : ()V
    //   18: ldc 'Read content info from '
    //   20: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   23: aload_0
    //   24: getfield a : Ljava/lang/String;
    //   27: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   30: invokevirtual toString : ()Ljava/lang/String;
    //   33: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   36: pop
    //   37: aload_0
    //   38: iconst_0
    //   39: sipush #10000
    //   42: invokespecial a : (II)Ljava/net/HttpURLConnection;
    //   45: astore #5
    //   47: aload_2
    //   48: astore_1
    //   49: aload #5
    //   51: astore #6
    //   53: aload_3
    //   54: astore #4
    //   56: aload_0
    //   57: aload #5
    //   59: invokevirtual getContentLength : ()I
    //   62: putfield d : I
    //   65: aload_2
    //   66: astore_1
    //   67: aload #5
    //   69: astore #6
    //   71: aload_3
    //   72: astore #4
    //   74: aload_0
    //   75: aload #5
    //   77: invokevirtual getContentType : ()Ljava/lang/String;
    //   80: putfield e : Ljava/lang/String;
    //   83: aload_2
    //   84: astore_1
    //   85: aload #5
    //   87: astore #6
    //   89: aload_3
    //   90: astore #4
    //   92: aload #5
    //   94: invokevirtual getInputStream : ()Ljava/io/InputStream;
    //   97: astore_2
    //   98: aload_2
    //   99: astore_1
    //   100: aload #5
    //   102: astore #6
    //   104: aload_2
    //   105: astore #4
    //   107: new java/lang/StringBuilder
    //   110: astore_3
    //   111: aload_2
    //   112: astore_1
    //   113: aload #5
    //   115: astore #6
    //   117: aload_2
    //   118: astore #4
    //   120: aload_3
    //   121: invokespecial <init> : ()V
    //   124: aload_2
    //   125: astore_1
    //   126: aload #5
    //   128: astore #6
    //   130: aload_2
    //   131: astore #4
    //   133: ldc 'ProxyCache'
    //   135: aload_3
    //   136: ldc 'Content info for `'
    //   138: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   141: aload_0
    //   142: getfield a : Ljava/lang/String;
    //   145: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   148: ldc '`: mime: '
    //   150: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   153: aload_0
    //   154: getfield e : Ljava/lang/String;
    //   157: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   160: ldc ', content-length: '
    //   162: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   165: aload_0
    //   166: getfield d : I
    //   169: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   172: invokevirtual toString : ()Ljava/lang/String;
    //   175: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   178: pop
    //   179: aload_2
    //   180: invokestatic a : (Ljava/io/Closeable;)V
    //   183: aload #5
    //   185: ifnull -> 193
    //   188: aload #5
    //   190: invokevirtual disconnect : ()V
    //   193: return
    //   194: astore_2
    //   195: aconst_null
    //   196: astore #5
    //   198: aload #4
    //   200: astore_1
    //   201: aload #5
    //   203: astore #6
    //   205: new java/lang/StringBuilder
    //   208: astore_3
    //   209: aload #4
    //   211: astore_1
    //   212: aload #5
    //   214: astore #6
    //   216: aload_3
    //   217: invokespecial <init> : ()V
    //   220: aload #4
    //   222: astore_1
    //   223: aload #5
    //   225: astore #6
    //   227: ldc 'ProxyCache'
    //   229: aload_3
    //   230: ldc 'Error fetching info from '
    //   232: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   235: aload_0
    //   236: getfield a : Ljava/lang/String;
    //   239: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   242: invokevirtual toString : ()Ljava/lang/String;
    //   245: aload_2
    //   246: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   249: pop
    //   250: aload #4
    //   252: invokestatic a : (Ljava/io/Closeable;)V
    //   255: aload #5
    //   257: ifnull -> 193
    //   260: aload #5
    //   262: invokevirtual disconnect : ()V
    //   265: goto -> 193
    //   268: astore #5
    //   270: aconst_null
    //   271: astore #6
    //   273: aload_1
    //   274: invokestatic a : (Ljava/io/Closeable;)V
    //   277: aload #6
    //   279: ifnull -> 287
    //   282: aload #6
    //   284: invokevirtual disconnect : ()V
    //   287: aload #5
    //   289: athrow
    //   290: astore #5
    //   292: goto -> 273
    //   295: astore_2
    //   296: goto -> 198
    // Exception table:
    //   from	to	target	type
    //   37	47	194	java/io/IOException
    //   37	47	268	finally
    //   56	65	295	java/io/IOException
    //   56	65	290	finally
    //   74	83	295	java/io/IOException
    //   74	83	290	finally
    //   92	98	295	java/io/IOException
    //   92	98	290	finally
    //   107	111	295	java/io/IOException
    //   107	111	290	finally
    //   120	124	295	java/io/IOException
    //   120	124	290	finally
    //   133	179	295	java/io/IOException
    //   133	179	290	finally
    //   205	209	290	finally
    //   216	220	290	finally
    //   227	250	290	finally
  }
  
  public int a() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : I
    //   6: ldc -2147483648
    //   8: if_icmpne -> 15
    //   11: aload_0
    //   12: invokespecial d : ()V
    //   15: aload_0
    //   16: getfield d : I
    //   19: istore_1
    //   20: aload_0
    //   21: monitorexit
    //   22: iload_1
    //   23: ireturn
    //   24: astore_2
    //   25: aload_0
    //   26: monitorexit
    //   27: aload_2
    //   28: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	24	finally
    //   15	20	24	finally
  }
  
  public int a(byte[] paramArrayOfbyte) {
    if (this.c == null)
      throw new l("Error reading data from " + this.a + ": connection is absent!"); 
    try {
      return this.c.read(paramArrayOfbyte, 0, paramArrayOfbyte.length);
    } catch (InterruptedIOException interruptedIOException) {
      throw new i("Reading source " + this.a + " is interrupted", interruptedIOException);
    } catch (IOException iOException) {
      throw new l("Error reading data from " + this.a, iOException);
    } 
  }
  
  public void a(int paramInt) {
    try {
      this.b = a(paramInt, -1);
      this.e = this.b.getContentType();
      BufferedInputStream bufferedInputStream = new BufferedInputStream();
      this(this.b.getInputStream(), 8192);
      this.c = bufferedInputStream;
      this.d = a(this.b, paramInt, this.b.getResponseCode());
      return;
    } catch (IOException iOException) {
      throw new l("Error opening connection for " + this.a + " with offset " + paramInt, iOException);
    } 
  }
  
  public void b() {
    if (this.b != null)
      try {
        this.b.disconnect();
        return;
      } catch (NullPointerException nullPointerException) {
        throw new l("Error disconnecting HttpUrlConnection", nullPointerException);
      }  
  }
  
  public String c() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield e : Ljava/lang/String;
    //   6: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   9: ifeq -> 16
    //   12: aload_0
    //   13: invokespecial d : ()V
    //   16: aload_0
    //   17: getfield e : Ljava/lang/String;
    //   20: astore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_1
    //   24: areturn
    //   25: astore_1
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_1
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	25	finally
    //   16	21	25	finally
  }
  
  public String toString() {
    return "HttpUrlSource{url='" + this.a + "}";
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */