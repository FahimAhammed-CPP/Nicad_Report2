package com.facebook.ads.internal.i.b;

final class j {
  static <T> T a(T paramT) {
    if (paramT == null)
      throw new NullPointerException(); 
    return paramT;
  }
  
  static <T> T a(T paramT, String paramString) {
    if (paramT == null)
      throw new NullPointerException(paramString); 
    return paramT;
  }
  
  static void a(boolean paramBoolean, String paramString) {
    if (!paramBoolean)
      throw new IllegalArgumentException(paramString); 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */