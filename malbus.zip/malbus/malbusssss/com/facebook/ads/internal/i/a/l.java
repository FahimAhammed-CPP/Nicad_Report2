package com.facebook.ads.internal.i.a;

public abstract class l {
  protected String a = "";
  
  protected j b;
  
  protected String c;
  
  protected byte[] d;
  
  public l(String paramString, p paramp) {
    if (paramString != null)
      this.a = paramString; 
    if (paramp != null) {
      paramString = paramp.a();
      this.a += "?" + paramString;
    } 
  }
  
  public String a() {
    return this.a;
  }
  
  public j b() {
    return this.b;
  }
  
  public String c() {
    return this.c;
  }
  
  public byte[] d() {
    return this.d;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/a/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */