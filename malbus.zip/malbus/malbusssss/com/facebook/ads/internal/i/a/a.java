package com.facebook.ads.internal.i.a;

import android.os.Build;
import java.io.OutputStream;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class a {
  private static int[] f = new int[20];
  
  private static final String g = a.class.getSimpleName();
  
  protected final q a = new f(this) {
    
    };
  
  protected final d b = new e();
  
  protected r c = new g();
  
  protected int d = 2000;
  
  protected int e = 8000;
  
  private int h = 3;
  
  private Map<String, String> i = new TreeMap<String, String>();
  
  private boolean j;
  
  private Set<String> k;
  
  private Set<String> l;
  
  static {
    c();
    if (Build.VERSION.SDK_INT > 8)
      a(); 
  }
  
  public static void a() {
    if (CookieHandler.getDefault() == null)
      CookieHandler.setDefault(new CookieManager()); 
  }
  
  private static void c() {
    if (Build.VERSION.SDK_INT < 8)
      System.setProperty("http.keepAlive", "false"); 
  }
  
  private void c(HttpURLConnection paramHttpURLConnection) {
    for (String str : this.i.keySet())
      paramHttpURLConnection.setRequestProperty(str, this.i.get(str)); 
  }
  
  protected int a(int paramInt) {
    return f[paramInt + 2] * 1000;
  }
  
  protected int a(HttpURLConnection paramHttpURLConnection, byte[] paramArrayOfbyte) {
    OutputStream outputStream = null;
    try {
      OutputStream outputStream1 = this.a.a(paramHttpURLConnection);
      if (outputStream1 != null) {
        outputStream = outputStream1;
        this.a.a(outputStream1, paramArrayOfbyte);
      } 
      outputStream = outputStream1;
      return paramHttpURLConnection.getResponseCode();
    } finally {
      if (outputStream != null)
        try {
          outputStream.close();
        } catch (Exception exception) {} 
    } 
  }
  
  public a a(String paramString1, String paramString2) {
    this.i.put(paramString1, paramString2);
    return this;
  }
  
  public n a(l paraml) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: invokestatic currentTimeMillis : ()J
    //   5: lstore_3
    //   6: iload_2
    //   7: aload_0
    //   8: getfield h : I
    //   11: if_icmpge -> 230
    //   14: lload_3
    //   15: lstore #5
    //   17: aload_0
    //   18: aload_0
    //   19: iload_2
    //   20: invokevirtual a : (I)I
    //   23: invokevirtual c : (I)V
    //   26: lload_3
    //   27: lstore #5
    //   29: aload_0
    //   30: getfield c : Lcom/facebook/ads/internal/i/a/r;
    //   33: invokeinterface a : ()Z
    //   38: ifeq -> 111
    //   41: lload_3
    //   42: lstore #5
    //   44: aload_0
    //   45: getfield c : Lcom/facebook/ads/internal/i/a/r;
    //   48: astore #7
    //   50: lload_3
    //   51: lstore #5
    //   53: new java/lang/StringBuilder
    //   56: astore #8
    //   58: lload_3
    //   59: lstore #5
    //   61: aload #8
    //   63: invokespecial <init> : ()V
    //   66: lload_3
    //   67: lstore #5
    //   69: aload #7
    //   71: aload #8
    //   73: iload_2
    //   74: iconst_1
    //   75: iadd
    //   76: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   79: ldc 'of'
    //   81: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   84: aload_0
    //   85: getfield h : I
    //   88: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   91: ldc ', trying '
    //   93: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   96: aload_1
    //   97: invokevirtual a : ()Ljava/lang/String;
    //   100: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   103: invokevirtual toString : ()Ljava/lang/String;
    //   106: invokeinterface a : (Ljava/lang/String;)V
    //   111: lload_3
    //   112: lstore #5
    //   114: invokestatic currentTimeMillis : ()J
    //   117: lstore_3
    //   118: lload_3
    //   119: lstore #5
    //   121: aload_0
    //   122: aload_1
    //   123: invokevirtual a : ()Ljava/lang/String;
    //   126: aload_1
    //   127: invokevirtual b : ()Lcom/facebook/ads/internal/i/a/j;
    //   130: aload_1
    //   131: invokevirtual c : ()Ljava/lang/String;
    //   134: aload_1
    //   135: invokevirtual d : ()[B
    //   138: invokevirtual a : (Ljava/lang/String;Lcom/facebook/ads/internal/i/a/j;Ljava/lang/String;[B)Lcom/facebook/ads/internal/i/a/n;
    //   141: astore #7
    //   143: lload_3
    //   144: lstore #5
    //   146: aload #7
    //   148: ifnull -> 179
    //   151: aload #7
    //   153: astore_1
    //   154: aload_1
    //   155: areturn
    //   156: astore #7
    //   158: aload_0
    //   159: aload #7
    //   161: lload #5
    //   163: invokevirtual a : (Ljava/lang/Throwable;J)Z
    //   166: ifeq -> 188
    //   169: iload_2
    //   170: aload_0
    //   171: getfield h : I
    //   174: iconst_1
    //   175: isub
    //   176: if_icmpge -> 188
    //   179: iinc #2, 1
    //   182: lload #5
    //   184: lstore_3
    //   185: goto -> 6
    //   188: aload_0
    //   189: getfield a : Lcom/facebook/ads/internal/i/a/q;
    //   192: aload #7
    //   194: invokeinterface a : (Lcom/facebook/ads/internal/i/a/m;)Z
    //   199: ifeq -> 227
    //   202: iload_2
    //   203: aload_0
    //   204: getfield h : I
    //   207: iconst_1
    //   208: isub
    //   209: if_icmpge -> 227
    //   212: aload_0
    //   213: getfield d : I
    //   216: i2l
    //   217: invokestatic sleep : (J)V
    //   220: goto -> 179
    //   223: astore_1
    //   224: aload #7
    //   226: athrow
    //   227: aload #7
    //   229: athrow
    //   230: aconst_null
    //   231: astore_1
    //   232: goto -> 154
    // Exception table:
    //   from	to	target	type
    //   17	26	156	com/facebook/ads/internal/i/a/m
    //   29	41	156	com/facebook/ads/internal/i/a/m
    //   44	50	156	com/facebook/ads/internal/i/a/m
    //   53	58	156	com/facebook/ads/internal/i/a/m
    //   61	66	156	com/facebook/ads/internal/i/a/m
    //   69	111	156	com/facebook/ads/internal/i/a/m
    //   114	118	156	com/facebook/ads/internal/i/a/m
    //   121	143	156	com/facebook/ads/internal/i/a/m
    //   212	220	223	java/lang/InterruptedException
  }
  
  protected n a(String paramString1, j paramj, String paramString2, byte[] paramArrayOfbyte) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #5
    //   3: iconst_1
    //   4: istore #6
    //   6: aload_0
    //   7: iconst_0
    //   8: putfield j : Z
    //   11: aload_0
    //   12: aload_1
    //   13: invokevirtual a : (Ljava/lang/String;)Ljava/net/HttpURLConnection;
    //   16: astore_1
    //   17: aload_0
    //   18: aload_1
    //   19: aload_2
    //   20: aload_3
    //   21: invokevirtual a : (Ljava/net/HttpURLConnection;Lcom/facebook/ads/internal/i/a/j;Ljava/lang/String;)V
    //   24: aload_0
    //   25: aload_1
    //   26: invokespecial c : (Ljava/net/HttpURLConnection;)V
    //   29: aload_0
    //   30: getfield c : Lcom/facebook/ads/internal/i/a/r;
    //   33: invokeinterface a : ()Z
    //   38: ifeq -> 53
    //   41: aload_0
    //   42: getfield c : Lcom/facebook/ads/internal/i/a/r;
    //   45: aload_1
    //   46: aload #4
    //   48: invokeinterface a : (Ljava/net/HttpURLConnection;Ljava/lang/Object;)V
    //   53: aload_1
    //   54: invokevirtual connect : ()V
    //   57: aload_0
    //   58: iconst_1
    //   59: putfield j : Z
    //   62: aload_0
    //   63: getfield l : Ljava/util/Set;
    //   66: ifnull -> 208
    //   69: aload_0
    //   70: getfield l : Ljava/util/Set;
    //   73: invokeinterface isEmpty : ()Z
    //   78: ifne -> 208
    //   81: iconst_1
    //   82: istore #7
    //   84: aload_0
    //   85: getfield k : Ljava/util/Set;
    //   88: ifnull -> 214
    //   91: aload_0
    //   92: getfield k : Ljava/util/Set;
    //   95: invokeinterface isEmpty : ()Z
    //   100: ifne -> 214
    //   103: aload_1
    //   104: instanceof javax/net/ssl/HttpsURLConnection
    //   107: istore #8
    //   109: iload #8
    //   111: ifeq -> 139
    //   114: iload #7
    //   116: ifne -> 124
    //   119: iload #6
    //   121: ifeq -> 139
    //   124: aload_1
    //   125: checkcast javax/net/ssl/HttpsURLConnection
    //   128: aload_0
    //   129: getfield l : Ljava/util/Set;
    //   132: aload_0
    //   133: getfield k : Ljava/util/Set;
    //   136: invokestatic a : (Ljavax/net/ssl/HttpsURLConnection;Ljava/util/Set;Ljava/util/Set;)V
    //   139: aload_1
    //   140: invokevirtual getDoOutput : ()Z
    //   143: ifeq -> 159
    //   146: aload #4
    //   148: ifnull -> 159
    //   151: aload_0
    //   152: aload_1
    //   153: aload #4
    //   155: invokevirtual a : (Ljava/net/HttpURLConnection;[B)I
    //   158: pop
    //   159: aload_1
    //   160: invokevirtual getDoInput : ()Z
    //   163: ifeq -> 294
    //   166: aload_0
    //   167: aload_1
    //   168: invokevirtual a : (Ljava/net/HttpURLConnection;)Lcom/facebook/ads/internal/i/a/n;
    //   171: astore_2
    //   172: aload_0
    //   173: getfield c : Lcom/facebook/ads/internal/i/a/r;
    //   176: invokeinterface a : ()Z
    //   181: ifeq -> 194
    //   184: aload_0
    //   185: getfield c : Lcom/facebook/ads/internal/i/a/r;
    //   188: aload_2
    //   189: invokeinterface a : (Lcom/facebook/ads/internal/i/a/n;)V
    //   194: aload_2
    //   195: astore_3
    //   196: aload_1
    //   197: ifnull -> 206
    //   200: aload_1
    //   201: invokevirtual disconnect : ()V
    //   204: aload_2
    //   205: astore_3
    //   206: aload_3
    //   207: areturn
    //   208: iconst_0
    //   209: istore #7
    //   211: goto -> 84
    //   214: iconst_0
    //   215: istore #6
    //   217: goto -> 103
    //   220: astore_2
    //   221: getstatic com/facebook/ads/internal/i/a/a.g : Ljava/lang/String;
    //   224: ldc_w 'Unable to validate SSL certificates.'
    //   227: aload_2
    //   228: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   231: pop
    //   232: goto -> 139
    //   235: astore_3
    //   236: aload_0
    //   237: aload_1
    //   238: invokevirtual b : (Ljava/net/HttpURLConnection;)Lcom/facebook/ads/internal/i/a/n;
    //   241: astore_2
    //   242: aload_2
    //   243: ifnull -> 349
    //   246: aload_2
    //   247: invokevirtual a : ()I
    //   250: istore #7
    //   252: iload #7
    //   254: ifle -> 349
    //   257: aload_0
    //   258: getfield c : Lcom/facebook/ads/internal/i/a/r;
    //   261: invokeinterface a : ()Z
    //   266: ifeq -> 279
    //   269: aload_0
    //   270: getfield c : Lcom/facebook/ads/internal/i/a/r;
    //   273: aload_2
    //   274: invokeinterface a : (Lcom/facebook/ads/internal/i/a/n;)V
    //   279: aload_2
    //   280: astore_3
    //   281: aload_1
    //   282: ifnull -> 206
    //   285: aload_1
    //   286: invokevirtual disconnect : ()V
    //   289: aload_2
    //   290: astore_3
    //   291: goto -> 206
    //   294: new com/facebook/ads/internal/i/a/n
    //   297: dup
    //   298: aload_1
    //   299: aconst_null
    //   300: invokespecial <init> : (Ljava/net/HttpURLConnection;[B)V
    //   303: astore_2
    //   304: goto -> 172
    //   307: astore_3
    //   308: aload #5
    //   310: astore #4
    //   312: aload_1
    //   313: astore_2
    //   314: aload_3
    //   315: astore_1
    //   316: aload_0
    //   317: getfield c : Lcom/facebook/ads/internal/i/a/r;
    //   320: invokeinterface a : ()Z
    //   325: ifeq -> 339
    //   328: aload_0
    //   329: getfield c : Lcom/facebook/ads/internal/i/a/r;
    //   332: aload #4
    //   334: invokeinterface a : (Lcom/facebook/ads/internal/i/a/n;)V
    //   339: aload_2
    //   340: ifnull -> 347
    //   343: aload_2
    //   344: invokevirtual disconnect : ()V
    //   347: aload_1
    //   348: athrow
    //   349: new com/facebook/ads/internal/i/a/m
    //   352: astore #4
    //   354: aload #4
    //   356: aload_3
    //   357: aload_2
    //   358: invokespecial <init> : (Ljava/lang/Exception;Lcom/facebook/ads/internal/i/a/n;)V
    //   361: aload #4
    //   363: athrow
    //   364: astore #4
    //   366: aload_2
    //   367: astore_3
    //   368: aload_1
    //   369: astore_2
    //   370: aload #4
    //   372: astore_1
    //   373: aload_3
    //   374: astore #4
    //   376: goto -> 316
    //   379: astore_2
    //   380: aload_3
    //   381: invokevirtual printStackTrace : ()V
    //   384: iconst_0
    //   385: ifeq -> 396
    //   388: new java/lang/NullPointerException
    //   391: dup
    //   392: invokespecial <init> : ()V
    //   395: athrow
    //   396: new com/facebook/ads/internal/i/a/m
    //   399: astore_2
    //   400: aload_2
    //   401: aload_3
    //   402: aconst_null
    //   403: invokespecial <init> : (Ljava/lang/Exception;Lcom/facebook/ads/internal/i/a/n;)V
    //   406: aload_2
    //   407: athrow
    //   408: astore_3
    //   409: aload_1
    //   410: astore_2
    //   411: aload_3
    //   412: astore_1
    //   413: aload #5
    //   415: astore #4
    //   417: goto -> 316
    //   420: astore_2
    //   421: iconst_0
    //   422: ifeq -> 433
    //   425: new java/lang/NullPointerException
    //   428: dup
    //   429: invokespecial <init> : ()V
    //   432: athrow
    //   433: new com/facebook/ads/internal/i/a/m
    //   436: astore_2
    //   437: aload_2
    //   438: aload_3
    //   439: aconst_null
    //   440: invokespecial <init> : (Ljava/lang/Exception;Lcom/facebook/ads/internal/i/a/n;)V
    //   443: aload_2
    //   444: athrow
    //   445: astore_1
    //   446: aconst_null
    //   447: astore_2
    //   448: aload #5
    //   450: astore #4
    //   452: goto -> 316
    //   455: astore_3
    //   456: aconst_null
    //   457: astore_1
    //   458: goto -> 236
    // Exception table:
    //   from	to	target	type
    //   6	17	455	java/lang/Exception
    //   6	17	445	finally
    //   17	53	235	java/lang/Exception
    //   17	53	307	finally
    //   53	81	235	java/lang/Exception
    //   53	81	307	finally
    //   84	103	235	java/lang/Exception
    //   84	103	307	finally
    //   103	109	235	java/lang/Exception
    //   103	109	307	finally
    //   124	139	220	java/lang/Exception
    //   124	139	307	finally
    //   139	146	235	java/lang/Exception
    //   139	146	307	finally
    //   151	159	235	java/lang/Exception
    //   151	159	307	finally
    //   159	172	235	java/lang/Exception
    //   159	172	307	finally
    //   221	232	235	java/lang/Exception
    //   221	232	307	finally
    //   236	242	379	java/lang/Exception
    //   236	242	420	finally
    //   246	252	364	finally
    //   294	304	235	java/lang/Exception
    //   294	304	307	finally
    //   349	364	364	finally
    //   380	384	420	finally
    //   388	396	408	finally
    //   396	408	408	finally
    //   425	433	408	finally
    //   433	445	408	finally
  }
  
  public n a(String paramString, p paramp) {
    return b(new i(paramString, paramp));
  }
  
  protected n a(HttpURLConnection paramHttpURLConnection) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_0
    //   3: getfield a : Lcom/facebook/ads/internal/i/a/q;
    //   6: aload_1
    //   7: invokeinterface b : (Ljava/net/HttpURLConnection;)Ljava/io/InputStream;
    //   12: astore_3
    //   13: aload_3
    //   14: ifnull -> 28
    //   17: aload_0
    //   18: getfield a : Lcom/facebook/ads/internal/i/a/q;
    //   21: aload_3
    //   22: invokeinterface a : (Ljava/io/InputStream;)[B
    //   27: astore_2
    //   28: new com/facebook/ads/internal/i/a/n
    //   31: dup
    //   32: aload_1
    //   33: aload_2
    //   34: invokespecial <init> : (Ljava/net/HttpURLConnection;[B)V
    //   37: astore_1
    //   38: aload_3
    //   39: ifnull -> 46
    //   42: aload_3
    //   43: invokevirtual close : ()V
    //   46: aload_1
    //   47: areturn
    //   48: astore_1
    //   49: aconst_null
    //   50: astore_3
    //   51: aload_3
    //   52: ifnull -> 59
    //   55: aload_3
    //   56: invokevirtual close : ()V
    //   59: aload_1
    //   60: athrow
    //   61: astore_3
    //   62: goto -> 46
    //   65: astore_3
    //   66: goto -> 59
    //   69: astore_1
    //   70: goto -> 51
    // Exception table:
    //   from	to	target	type
    //   2	13	48	finally
    //   17	28	69	finally
    //   28	38	69	finally
    //   42	46	61	java/lang/Exception
    //   55	59	65	java/lang/Exception
  }
  
  protected HttpURLConnection a(String paramString) {
    try {
      new URL(paramString);
      return this.a.a(paramString);
    } catch (MalformedURLException malformedURLException) {
      throw new IllegalArgumentException(paramString + " is not a valid URL", malformedURLException);
    } 
  }
  
  protected void a(l paraml, b paramb) {
    this.b.a(this, paramb).a(paraml);
  }
  
  public void a(String paramString, p paramp, b paramb) {
    a(new k(paramString, paramp), paramb);
  }
  
  protected void a(HttpURLConnection paramHttpURLConnection, j paramj, String paramString) {
    paramHttpURLConnection.setConnectTimeout(this.d);
    paramHttpURLConnection.setReadTimeout(this.e);
    this.a.a(paramHttpURLConnection, paramj, paramString);
  }
  
  public void a(Set<String> paramSet) {
    this.l = paramSet;
  }
  
  protected boolean a(Throwable paramThrowable, long paramLong) {
    boolean bool = true;
    paramLong = System.currentTimeMillis() - paramLong + 10L;
    if (this.c.a())
      this.c.a("ELAPSED TIME = " + paramLong + ", CT = " + this.d + ", RT = " + this.e); 
    if (this.j) {
      if (paramLong < this.e)
        bool = false; 
      return bool;
    } 
    if (paramLong < this.d)
      bool = false; 
    return bool;
  }
  
  public n b(l paraml) {
    m m = null;
    try {
      n n = a(paraml.a(), paraml.b(), paraml.c(), paraml.d());
    } catch (m null) {
      this.a.a((m)exception);
      exception = m;
    } catch (Exception exception) {
      this.a.a(new m(exception, null));
      exception = m;
    } 
    return (n)exception;
  }
  
  public n b(String paramString, p paramp) {
    return b(new k(paramString, paramp));
  }
  
  protected n b(HttpURLConnection paramHttpURLConnection) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_1
    //   3: invokevirtual getErrorStream : ()Ljava/io/InputStream;
    //   6: astore_3
    //   7: aload_3
    //   8: ifnull -> 22
    //   11: aload_0
    //   12: getfield a : Lcom/facebook/ads/internal/i/a/q;
    //   15: aload_3
    //   16: invokeinterface a : (Ljava/io/InputStream;)[B
    //   21: astore_2
    //   22: new com/facebook/ads/internal/i/a/n
    //   25: dup
    //   26: aload_1
    //   27: aload_2
    //   28: invokespecial <init> : (Ljava/net/HttpURLConnection;[B)V
    //   31: astore_1
    //   32: aload_3
    //   33: ifnull -> 40
    //   36: aload_3
    //   37: invokevirtual close : ()V
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aconst_null
    //   44: astore_3
    //   45: aload_3
    //   46: ifnull -> 53
    //   49: aload_3
    //   50: invokevirtual close : ()V
    //   53: aload_1
    //   54: athrow
    //   55: astore_3
    //   56: goto -> 40
    //   59: astore_3
    //   60: goto -> 53
    //   63: astore_1
    //   64: goto -> 45
    // Exception table:
    //   from	to	target	type
    //   2	7	42	finally
    //   11	22	63	finally
    //   22	32	63	finally
    //   36	40	55	java/lang/Exception
    //   49	53	59	java/lang/Exception
  }
  
  public p b() {
    return new p();
  }
  
  public void b(int paramInt) {
    if (paramInt < 1 || paramInt > 18)
      throw new IllegalArgumentException("Maximum retries must be between 1 and 18"); 
    this.h = paramInt;
  }
  
  public void b(Set<String> paramSet) {
    this.k = paramSet;
  }
  
  public void c(int paramInt) {
    this.d = paramInt;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */