package com.facebook.ads.internal.i.b;

public class i extends l {
  public i(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */