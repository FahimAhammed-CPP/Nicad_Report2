package com.facebook.ads.internal.i.a;

public class m extends Exception {
  private static final long serialVersionUID = -2413629666163901633L;
  
  private n a;
  
  public m(Exception paramException, n paramn) {
    super(paramException);
    this.a = paramn;
  }
  
  public n a() {
    return this.a;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/a/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */