package com.facebook.ads.internal.i.a;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public abstract class f implements q {
  private final r a;
  
  public f() {
    this(new g());
  }
  
  public f(r paramr) {
    this.a = paramr;
  }
  
  public OutputStream a(HttpURLConnection paramHttpURLConnection) {
    return paramHttpURLConnection.getOutputStream();
  }
  
  public HttpURLConnection a(String paramString) {
    return (HttpURLConnection)(new URL(paramString)).openConnection();
  }
  
  public void a(OutputStream paramOutputStream, byte[] paramArrayOfbyte) {
    paramOutputStream.write(paramArrayOfbyte);
  }
  
  public void a(HttpURLConnection paramHttpURLConnection, j paramj, String paramString) {
    paramHttpURLConnection.setRequestMethod(paramj.c());
    paramHttpURLConnection.setDoOutput(paramj.b());
    paramHttpURLConnection.setDoInput(paramj.a());
    if (paramString != null)
      paramHttpURLConnection.setRequestProperty("Content-Type", paramString); 
    paramHttpURLConnection.setRequestProperty("Accept-Charset", "UTF-8");
  }
  
  public boolean a(m paramm) {
    n n = paramm.a();
    if (this.a.a()) {
      this.a.a("BasicRequestHandler.onError got");
      paramm.printStackTrace();
    } 
    return (n != null && n.a() > 0);
  }
  
  public byte[] a(InputStream paramInputStream) {
    byte[] arrayOfByte = new byte[16384];
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    while (true) {
      int i = paramInputStream.read(arrayOfByte);
      if (i != -1) {
        byteArrayOutputStream.write(arrayOfByte, 0, i);
        continue;
      } 
      byteArrayOutputStream.flush();
      return byteArrayOutputStream.toByteArray();
    } 
  }
  
  public InputStream b(HttpURLConnection paramHttpURLConnection) {
    return paramHttpURLConnection.getInputStream();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/a/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */