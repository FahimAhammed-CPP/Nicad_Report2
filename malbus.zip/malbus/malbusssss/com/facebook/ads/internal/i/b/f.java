package com.facebook.ads.internal.i.b;

import android.content.Context;
import android.os.SystemClock;
import android.util.Log;
import com.facebook.ads.internal.i.b.a.a;
import com.facebook.ads.internal.i.b.a.c;
import com.facebook.ads.internal.i.b.a.f;
import com.facebook.ads.internal.i.b.a.g;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class f {
  private final Object a = new Object();
  
  private final ExecutorService b = Executors.newFixedThreadPool(8);
  
  private final Map<String, g> c = new ConcurrentHashMap<String, g>();
  
  private final ServerSocket d;
  
  private final int e;
  
  private final Thread f;
  
  private final c g;
  
  private boolean h;
  
  public f(Context paramContext) {
    this(a.a(new a(paramContext)));
  }
  
  private f(c paramc) {
    this.g = j.<c>a(paramc);
    try {
      InetAddress inetAddress = InetAddress.getByName("127.0.0.1");
      ServerSocket serverSocket = new ServerSocket();
      this(0, 8, inetAddress);
      this.d = serverSocket;
      this.e = this.d.getLocalPort();
      CountDownLatch countDownLatch = new CountDownLatch();
      this(1);
      Thread thread = new Thread();
      e e = new e();
      this(this, countDownLatch);
      this(e);
      this.f = thread;
      this.f.start();
      countDownLatch.await();
      Log.i("ProxyCache", "Proxy cache server started. Ping it...");
      b();
      return;
    } catch (IOException iOException) {
    
    } catch (InterruptedException interruptedException) {}
    this.b.shutdown();
    throw new IllegalStateException("Error starting local proxy server", interruptedException);
  }
  
  private void a(Throwable paramThrowable) {
    Log.e("ProxyCache", "HttpProxyCacheServer error", paramThrowable);
  }
  
  private void a(Socket paramSocket) {
    try {
      d d = d.a(paramSocket.getInputStream());
      StringBuilder stringBuilder = new StringBuilder();
      this();
      Log.i("ProxyCache", stringBuilder.append("Request to cache proxy:").append(d).toString());
      String str = m.c(d.a);
      if ("ping".equals(str)) {
        b(paramSocket);
      } else {
        e(str).a(d, paramSocket);
      } 
      return;
    } catch (SocketException socketException) {
      Log.d("ProxyCache", "Closing socket... Socket is closed by client.");
      return;
    } catch (l l1) {
    
    } catch (IOException iOException) {
    
    } finally {
      c(paramSocket);
      Log.d("ProxyCache", "Opened connections: " + f());
    } 
    l l = new l();
    this("Error processing request", (Throwable)SYNTHETIC_LOCAL_VARIABLE_2);
    a(l);
    c(paramSocket);
    Log.d("ProxyCache", "Opened connections: " + f());
  }
  
  private void b() {
    int i = 300;
    for (byte b = 0;; b++) {
      if (b < 3) {
        try {
          ExecutorService executorService = this.b;
          b b1 = new b();
          this(this);
          this.h = ((Boolean)executorService.<Boolean>submit(b1).get(i, TimeUnit.MILLISECONDS)).booleanValue();
          if (this.h)
            return; 
          SystemClock.sleep(i);
          i *= 2;
          b++;
          continue;
        } catch (InterruptedException interruptedException) {
        
        } catch (ExecutionException executionException) {
        
        } catch (TimeoutException timeoutException) {}
        Log.e("ProxyCache", "Error pinging server [attempt: " + b + ", timeout: " + i + "]. ", timeoutException);
      } else {
        Log.e("ProxyCache", "Shutdown server... Error pinging server [attempts: " + b + ", max timeout: " + (i / 2) + "].");
        a();
        return;
      } 
      i *= 2;
    } 
  }
  
  private void b(Socket paramSocket) {
    OutputStream outputStream = paramSocket.getOutputStream();
    outputStream.write("HTTP/1.1 200 OK\n\n".getBytes());
    outputStream.write("ping ok".getBytes());
  }
  
  private void c(Socket paramSocket) {
    d(paramSocket);
    e(paramSocket);
    f(paramSocket);
  }
  
  private boolean c() {
    h h = new h(d("ping"));
    try {
      byte[] arrayOfByte1 = "ping ok".getBytes();
      h.a(0);
      byte[] arrayOfByte2 = new byte[arrayOfByte1.length];
      h.a(arrayOfByte2);
      boolean bool = Arrays.equals(arrayOfByte1, arrayOfByte2);
      StringBuilder stringBuilder = new StringBuilder();
      this();
      stringBuilder = stringBuilder.append("Ping response: `");
      String str = new String();
      this(arrayOfByte2);
      Log.d("ProxyCache", stringBuilder.append(str).append("`, pinged? ").append(bool).toString());
      return bool;
    } catch (l l) {
      Log.e("ProxyCache", "Error reading ping response", l);
      return false;
    } finally {
      h.b();
    } 
  }
  
  private boolean c(String paramString) {
    boolean bool = false;
    h h = new h(d(paramString));
    try {
      h.a(0);
      byte[] arrayOfByte = new byte[8192];
      while (true) {
        int i = h.a(arrayOfByte);
        if (i == -1)
          return true; 
      } 
    } catch (l l) {
      Log.e("ProxyCache", "Error reading url", l);
      return bool;
    } finally {
      h.b();
    } 
  }
  
  private String d(String paramString) {
    return String.format("http://%s:%d/%s", new Object[] { "127.0.0.1", Integer.valueOf(this.e), m.b(paramString) });
  }
  
  private void d() {
    synchronized (this.a) {
      Iterator<g> iterator = this.c.values().iterator();
      while (iterator.hasNext())
        ((g)iterator.next()).a(); 
    } 
    this.c.clear();
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_1} */
  }
  
  private void d(Socket paramSocket) {
    try {
      if (!paramSocket.isInputShutdown())
        paramSocket.shutdownInput(); 
    } catch (SocketException socketException) {
      Log.d("ProxyCache", "Releasing input stream... Socket is closed by client.");
    } catch (IOException iOException) {
      a(new l("Error closing socket input stream", iOException));
    } 
  }
  
  private g e(String paramString) {
    synchronized (this.a) {
      g g1 = this.c.get(paramString);
      g g2 = g1;
      if (g1 == null) {
        g2 = new g();
        this(paramString, this.g);
        this.c.put(paramString, g2);
      } 
      return g2;
    } 
  }
  
  private void e() {
    try {
      while (!Thread.currentThread().isInterrupted()) {
        Socket socket = this.d.accept();
        StringBuilder stringBuilder = new StringBuilder();
        this();
        Log.d("ProxyCache", stringBuilder.append("Accept new socket ").append(socket).toString());
        ExecutorService executorService = this.b;
        d d = new d();
        this(this, socket);
        executorService.submit(d);
      } 
    } catch (IOException iOException) {
      a(new l("Error during waiting connection", iOException));
    } 
  }
  
  private void e(Socket paramSocket) {
    try {
      if (paramSocket.isOutputShutdown())
        paramSocket.shutdownOutput(); 
    } catch (IOException iOException) {
      a(new l("Error closing socket output stream", iOException));
    } 
  }
  
  private int f() {
    synchronized (this.a) {
      Iterator<g> iterator = this.c.values().iterator();
      int i;
      for (i = 0; iterator.hasNext(); i = ((g)iterator.next()).b() + i);
      return i;
    } 
  }
  
  private void f(Socket paramSocket) {
    try {
      if (!paramSocket.isClosed())
        paramSocket.close(); 
    } catch (IOException iOException) {
      a(new l("Error closing socket", iOException));
    } 
  }
  
  public void a() {
    Log.i("ProxyCache", "Shutdown proxy server");
    d();
    this.f.interrupt();
    try {
      if (!this.d.isClosed())
        this.d.close(); 
    } catch (IOException iOException) {
      a(new l("Error shutting down proxy server", iOException));
    } 
  }
  
  public void a(String paramString) {
    int i = 300;
    for (byte b = 0;; b++) {
      if (b < 3) {
        try {
          ExecutorService executorService = this.b;
          c c1 = new c();
          this(this, paramString);
          if (((Boolean)executorService.<Boolean>submit(c1).get()).booleanValue())
            return; 
          SystemClock.sleep(i);
          i *= 2;
          b++;
          continue;
        } catch (InterruptedException interruptedException) {
        
        } catch (ExecutionException executionException) {}
        Log.e("ProxyCache", "Error precaching url [attempt: " + b + ", url: " + paramString + "]. ", executionException);
      } else {
        Log.e("ProxyCache", "Shutdown server... Error precaching url [attempts: " + b + ", url: " + paramString + "].");
        a();
        return;
      } 
      i *= 2;
    } 
  }
  
  public String b(String paramString) {
    if (!this.h)
      Log.e("ProxyCache", "Proxy server isn't pinged. Caching doesn't work."); 
    String str = paramString;
    if (this.h)
      str = d(paramString); 
    return str;
  }
  
  public static final class a {
    private File a;
    
    private c b;
    
    private a c;
    
    public a(Context param1Context) {
      this.a = o.a(param1Context);
      this.c = (a)new g(67108864L);
      this.b = (c)new f();
    }
    
    private c a() {
      return new c(this.a, this.b, this.c);
    }
  }
  
  private class b implements Callable<Boolean> {
    private b(f this$0) {}
    
    public Boolean a() {
      return Boolean.valueOf(f.b(this.a));
    }
  }
  
  private class c implements Callable<Boolean> {
    private final String b;
    
    public c(f this$0, String param1String) {
      this.b = param1String;
    }
    
    public Boolean a() {
      return Boolean.valueOf(f.a(this.a, this.b));
    }
  }
  
  private final class d implements Runnable {
    private final Socket b;
    
    public d(f this$0, Socket param1Socket) {
      this.b = param1Socket;
    }
    
    public void run() {
      f.a(this.a, this.b);
    }
  }
  
  private final class e implements Runnable {
    private final CountDownLatch b;
    
    public e(f this$0, CountDownLatch param1CountDownLatch) {
      this.b = param1CountDownLatch;
    }
    
    public void run() {
      this.b.countDown();
      f.a(this.a);
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */