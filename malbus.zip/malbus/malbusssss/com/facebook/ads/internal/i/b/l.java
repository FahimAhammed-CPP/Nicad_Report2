package com.facebook.ads.internal.i.b;

public class l extends Exception {
  public l(String paramString) {
    super(paramString);
  }
  
  public l(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */