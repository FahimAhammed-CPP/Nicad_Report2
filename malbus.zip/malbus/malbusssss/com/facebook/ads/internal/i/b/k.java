package com.facebook.ads.internal.i.b;

import android.util.Log;
import java.util.concurrent.atomic.AtomicInteger;

class k {
  private final n a;
  
  private final a b;
  
  private final Object c = new Object();
  
  private final Object d = new Object();
  
  private final AtomicInteger e;
  
  private volatile Thread f;
  
  private volatile boolean g;
  
  private volatile int h = -1;
  
  public k(n paramn, a parama) {
    this.a = j.<n>a(paramn);
    this.b = j.<a>a(parama);
    this.e = new AtomicInteger();
  }
  
  private void b() {
    int i = this.e.get();
    if (i >= 1) {
      this.e.set(0);
      throw new l("Error reading source " + i + " times");
    } 
  }
  
  private void b(long paramLong1, long paramLong2) {
    a(paramLong1, paramLong2);
    synchronized (this.c) {
      this.c.notifyAll();
      return;
    } 
  }
  
  private void c() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield f : Ljava/lang/Thread;
    //   6: ifnull -> 108
    //   9: aload_0
    //   10: getfield f : Ljava/lang/Thread;
    //   13: invokevirtual getState : ()Ljava/lang/Thread$State;
    //   16: getstatic java/lang/Thread$State.TERMINATED : Ljava/lang/Thread$State;
    //   19: if_acmpeq -> 108
    //   22: iconst_1
    //   23: istore_1
    //   24: aload_0
    //   25: getfield g : Z
    //   28: ifne -> 105
    //   31: aload_0
    //   32: getfield b : Lcom/facebook/ads/internal/i/b/a;
    //   35: invokeinterface d : ()Z
    //   40: ifne -> 105
    //   43: iload_1
    //   44: ifne -> 105
    //   47: new java/lang/Thread
    //   50: astore_2
    //   51: new com/facebook/ads/internal/i/b/k$a
    //   54: astore_3
    //   55: aload_3
    //   56: aload_0
    //   57: aconst_null
    //   58: invokespecial <init> : (Lcom/facebook/ads/internal/i/b/k;Lcom/facebook/ads/internal/i/b/k$1;)V
    //   61: new java/lang/StringBuilder
    //   64: astore #4
    //   66: aload #4
    //   68: invokespecial <init> : ()V
    //   71: aload_2
    //   72: aload_3
    //   73: aload #4
    //   75: ldc 'Source reader for '
    //   77: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: aload_0
    //   81: getfield a : Lcom/facebook/ads/internal/i/b/n;
    //   84: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   87: invokevirtual toString : ()Ljava/lang/String;
    //   90: invokespecial <init> : (Ljava/lang/Runnable;Ljava/lang/String;)V
    //   93: aload_0
    //   94: aload_2
    //   95: putfield f : Ljava/lang/Thread;
    //   98: aload_0
    //   99: getfield f : Ljava/lang/Thread;
    //   102: invokevirtual start : ()V
    //   105: aload_0
    //   106: monitorexit
    //   107: return
    //   108: iconst_0
    //   109: istore_1
    //   110: goto -> 24
    //   113: astore_3
    //   114: aload_0
    //   115: monitorexit
    //   116: aload_3
    //   117: athrow
    // Exception table:
    //   from	to	target	type
    //   2	22	113	finally
    //   24	43	113	finally
    //   47	105	113	finally
  }
  
  private void d() {
    synchronized (this.c) {
      this.c.wait(1000L);
      return;
    } 
  }
  
  private void e() {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: iconst_0
    //   3: istore_2
    //   4: aload_0
    //   5: getfield b : Lcom/facebook/ads/internal/i/b/a;
    //   8: invokeinterface a : ()I
    //   13: istore_3
    //   14: iload_3
    //   15: istore_2
    //   16: iload_3
    //   17: istore_1
    //   18: aload_0
    //   19: getfield a : Lcom/facebook/ads/internal/i/b/n;
    //   22: iload_3
    //   23: invokeinterface a : (I)V
    //   28: iload_3
    //   29: istore_2
    //   30: iload_3
    //   31: istore_1
    //   32: aload_0
    //   33: getfield a : Lcom/facebook/ads/internal/i/b/n;
    //   36: invokeinterface a : ()I
    //   41: istore #4
    //   43: iload_3
    //   44: istore_1
    //   45: iload_3
    //   46: istore_2
    //   47: iload #4
    //   49: istore #5
    //   51: sipush #8192
    //   54: newarray byte
    //   56: astore #6
    //   58: iload_3
    //   59: istore_1
    //   60: iload_3
    //   61: istore_2
    //   62: iload #4
    //   64: istore #5
    //   66: aload_0
    //   67: getfield a : Lcom/facebook/ads/internal/i/b/n;
    //   70: aload #6
    //   72: invokeinterface a : ([B)I
    //   77: istore #7
    //   79: iload #7
    //   81: iconst_m1
    //   82: if_icmpeq -> 261
    //   85: iload_3
    //   86: istore_1
    //   87: iload_3
    //   88: istore_2
    //   89: iload #4
    //   91: istore #5
    //   93: aload_0
    //   94: getfield d : Ljava/lang/Object;
    //   97: astore #8
    //   99: iload_3
    //   100: istore_1
    //   101: iload_3
    //   102: istore_2
    //   103: iload #4
    //   105: istore #5
    //   107: aload #8
    //   109: monitorenter
    //   110: aload_0
    //   111: invokespecial g : ()Z
    //   114: ifeq -> 134
    //   117: aload #8
    //   119: monitorexit
    //   120: aload_0
    //   121: invokespecial h : ()V
    //   124: aload_0
    //   125: iload_3
    //   126: i2l
    //   127: iload #4
    //   129: i2l
    //   130: invokespecial b : (JJ)V
    //   133: return
    //   134: aload_0
    //   135: getfield b : Lcom/facebook/ads/internal/i/b/a;
    //   138: aload #6
    //   140: iload #7
    //   142: invokeinterface a : ([BI)V
    //   147: aload #8
    //   149: monitorexit
    //   150: iload_3
    //   151: iload #7
    //   153: iadd
    //   154: istore_3
    //   155: iload_3
    //   156: i2l
    //   157: lstore #9
    //   159: iload #4
    //   161: i2l
    //   162: lstore #11
    //   164: iload_3
    //   165: istore_1
    //   166: iload_3
    //   167: istore_2
    //   168: iload #4
    //   170: istore #5
    //   172: aload_0
    //   173: lload #9
    //   175: lload #11
    //   177: invokespecial b : (JJ)V
    //   180: goto -> 58
    //   183: astore #8
    //   185: iload_1
    //   186: istore_2
    //   187: iload #4
    //   189: istore #5
    //   191: aload_0
    //   192: getfield e : Ljava/util/concurrent/atomic/AtomicInteger;
    //   195: invokevirtual incrementAndGet : ()I
    //   198: pop
    //   199: iload_1
    //   200: istore_2
    //   201: iload #4
    //   203: istore #5
    //   205: aload_0
    //   206: aload #8
    //   208: invokevirtual a : (Ljava/lang/Throwable;)V
    //   211: aload_0
    //   212: invokespecial h : ()V
    //   215: aload_0
    //   216: iload_1
    //   217: i2l
    //   218: iload #4
    //   220: i2l
    //   221: invokespecial b : (JJ)V
    //   224: goto -> 133
    //   227: astore #6
    //   229: aload #8
    //   231: monitorexit
    //   232: iload_3
    //   233: istore_1
    //   234: iload_3
    //   235: istore_2
    //   236: iload #4
    //   238: istore #5
    //   240: aload #6
    //   242: athrow
    //   243: astore #8
    //   245: aload_0
    //   246: invokespecial h : ()V
    //   249: aload_0
    //   250: iload_2
    //   251: i2l
    //   252: iload #5
    //   254: i2l
    //   255: invokespecial b : (JJ)V
    //   258: aload #8
    //   260: athrow
    //   261: iload_3
    //   262: istore_1
    //   263: iload_3
    //   264: istore_2
    //   265: iload #4
    //   267: istore #5
    //   269: aload_0
    //   270: invokespecial f : ()V
    //   273: aload_0
    //   274: invokespecial h : ()V
    //   277: aload_0
    //   278: iload_3
    //   279: i2l
    //   280: iload #4
    //   282: i2l
    //   283: invokespecial b : (JJ)V
    //   286: goto -> 133
    //   289: astore #8
    //   291: iconst_m1
    //   292: istore #5
    //   294: goto -> 245
    //   297: astore #8
    //   299: iconst_m1
    //   300: istore #4
    //   302: goto -> 185
    // Exception table:
    //   from	to	target	type
    //   4	14	297	java/lang/Throwable
    //   4	14	289	finally
    //   18	28	297	java/lang/Throwable
    //   18	28	289	finally
    //   32	43	297	java/lang/Throwable
    //   32	43	289	finally
    //   51	58	183	java/lang/Throwable
    //   51	58	243	finally
    //   66	79	183	java/lang/Throwable
    //   66	79	243	finally
    //   93	99	183	java/lang/Throwable
    //   93	99	243	finally
    //   107	110	183	java/lang/Throwable
    //   107	110	243	finally
    //   110	120	227	finally
    //   134	150	227	finally
    //   172	180	183	java/lang/Throwable
    //   172	180	243	finally
    //   191	199	243	finally
    //   205	211	243	finally
    //   229	232	227	finally
    //   240	243	183	java/lang/Throwable
    //   240	243	243	finally
    //   269	273	183	java/lang/Throwable
    //   269	273	243	finally
  }
  
  private void f() {
    synchronized (this.d) {
      if (!g() && this.b.a() == this.a.a())
        this.b.c(); 
      return;
    } 
  }
  
  private boolean g() {
    return (Thread.currentThread().isInterrupted() || this.g);
  }
  
  private void h() {
    try {
      this.a.b();
    } catch (l l) {
      a(new l("Error closing source " + this.a, l));
    } 
  }
  
  public int a(byte[] paramArrayOfbyte, long paramLong, int paramInt) {
    m.a(paramArrayOfbyte, paramLong, paramInt);
    while (!this.b.d() && this.b.a() < paramInt + paramLong && !this.g) {
      c();
      d();
      b();
    } 
    paramInt = this.b.a(paramArrayOfbyte, paramLong, paramInt);
    if (this.b.d() && this.h != 100) {
      this.h = 100;
      a(100);
    } 
    return paramInt;
  }
  
  public void a() {
    synchronized (this.d) {
      StringBuilder stringBuilder = new StringBuilder();
      this();
      Log.d("ProxyCache", stringBuilder.append("Shutdown proxy for ").append(this.a).toString());
      try {
        this.g = true;
        if (this.f != null)
          this.f.interrupt(); 
        this.b.b();
      } catch (l l) {}
      return;
    } 
  }
  
  protected void a(int paramInt) {}
  
  protected void a(long paramLong1, long paramLong2) {
    int i;
    boolean bool2;
    boolean bool1 = true;
    if (paramLong2 == 0L) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      i = 100;
    } else {
      i = (int)(100L * paramLong1 / paramLong2);
    } 
    if (i != this.h) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (paramLong2 < 0L)
      bool1 = false; 
    if (bool1 && bool2)
      a(i); 
    this.h = i;
  }
  
  protected final void a(Throwable paramThrowable) {
    if (paramThrowable instanceof i) {
      Log.d("ProxyCache", "ProxyCache is interrupted");
      return;
    } 
    Log.e("ProxyCache", "ProxyCache error", paramThrowable);
  }
  
  private class a implements Runnable {
    private a(k this$0) {}
    
    public void run() {
      k.a(this.a);
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */