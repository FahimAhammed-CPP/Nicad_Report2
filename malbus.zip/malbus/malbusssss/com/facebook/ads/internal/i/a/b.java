package com.facebook.ads.internal.i.a;

public abstract class b {
  public abstract void a(n paramn);
  
  public void a(Exception paramException) {
    paramException.printStackTrace();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */