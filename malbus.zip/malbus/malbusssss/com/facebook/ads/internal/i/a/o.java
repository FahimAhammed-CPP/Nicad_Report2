package com.facebook.ads.internal.i.a;

import android.os.Build;
import android.util.Base64;
import java.security.MessageDigest;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Set;
import javax.net.ssl.HttpsURLConnection;

public class o {
  private static String a(byte[] paramArrayOfbyte, String paramString) {
    MessageDigest messageDigest = MessageDigest.getInstance(paramString);
    messageDigest.reset();
    return Base64.encodeToString(messageDigest.digest(paramArrayOfbyte), 0);
  }
  
  public static void a(HttpsURLConnection paramHttpsURLConnection, Set<String> paramSet1, Set<String> paramSet2) {
    if (Build.VERSION.SDK_INT != 15 || !"4.0.3".equals(Build.VERSION.RELEASE))
      try {
        Certificate[] arrayOfCertificate = paramHttpsURLConnection.getServerCertificates();
        int i = arrayOfCertificate.length;
        byte b = 0;
        while (b < i) {
          X509Certificate x509Certificate = (X509Certificate)arrayOfCertificate[b];
          String str = a(x509Certificate.getEncoded(), "SHA-1");
          if (paramSet1 == null || !paramSet1.contains(str)) {
            str = a(x509Certificate.getPublicKey().getEncoded(), "SHA-1");
            if (paramSet2 == null || !paramSet2.contains(str)) {
              b++;
              continue;
            } 
          } 
          return;
        } 
        CertificateException certificateException = new CertificateException();
        this("Unable to find valid certificate or public key.");
        throw certificateException;
      } catch (Exception exception) {
        throw exception;
      }  
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/a/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */