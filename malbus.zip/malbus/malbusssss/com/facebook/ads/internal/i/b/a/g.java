package com.facebook.ads.internal.i.b.a;

import java.io.File;

public class g extends e {
  private final long a;
  
  public g(long paramLong) {
    if (paramLong <= 0L)
      throw new IllegalArgumentException("Max size must be positive number!"); 
    this.a = paramLong;
  }
  
  protected boolean a(File paramFile, long paramLong, int paramInt) {
    return (paramLong <= this.a);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/a/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */