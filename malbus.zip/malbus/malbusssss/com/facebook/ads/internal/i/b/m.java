package com.facebook.ads.internal.i.b;

import android.text.TextUtils;
import android.util.Log;
import android.webkit.MimeTypeMap;
import java.io.Closeable;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class m {
  static String a(String paramString) {
    MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
    paramString = MimeTypeMap.getFileExtensionFromUrl(paramString);
    return TextUtils.isEmpty(paramString) ? null : mimeTypeMap.getMimeTypeFromExtension(paramString);
  }
  
  private static String a(byte[] paramArrayOfbyte) {
    StringBuffer stringBuffer = new StringBuffer();
    int i = paramArrayOfbyte.length;
    for (byte b = 0; b < i; b++) {
      stringBuffer.append(String.format("%02x", new Object[] { Byte.valueOf(paramArrayOfbyte[b]) }));
    } 
    return stringBuffer.toString();
  }
  
  static void a(Closeable paramCloseable) {
    if (paramCloseable != null)
      try {
        paramCloseable.close();
      } catch (IOException iOException) {
        Log.e("ProxyCache", "Error closing resource", iOException);
      }  
  }
  
  static void a(byte[] paramArrayOfbyte, long paramLong, int paramInt) {
    boolean bool2;
    boolean bool1 = true;
    j.a(paramArrayOfbyte, "Buffer must be not null!");
    if (paramLong >= 0L) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    j.a(bool2, "Data offset must be positive!");
    if (paramInt >= 0 && paramInt <= paramArrayOfbyte.length) {
      bool2 = bool1;
    } else {
      bool2 = false;
    } 
    j.a(bool2, "Length must be in range [0..buffer.length]");
  }
  
  static String b(String paramString) {
    try {
      return URLEncoder.encode(paramString, "utf-8");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      throw new RuntimeException("Error encoding url", unsupportedEncodingException);
    } 
  }
  
  static String c(String paramString) {
    try {
      return URLDecoder.decode(paramString, "utf-8");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      throw new RuntimeException("Error decoding url", unsupportedEncodingException);
    } 
  }
  
  public static String d(String paramString) {
    try {
      return a(MessageDigest.getInstance("MD5").digest(paramString.getBytes()));
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      throw new IllegalStateException(noSuchAlgorithmException);
    } 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */