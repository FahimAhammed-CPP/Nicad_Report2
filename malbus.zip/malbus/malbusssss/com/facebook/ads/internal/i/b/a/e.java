package com.facebook.ads.internal.i.b.a;

import android.util.Log;
import java.io.File;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

abstract class e implements a {
  private final ExecutorService a = Executors.newSingleThreadExecutor();
  
  private void a(List<File> paramList) {
    long l = b(paramList);
    int i = paramList.size();
    for (File file : paramList) {
      if (!a(file, l, i)) {
        long l1 = file.length();
        if (file.delete()) {
          l -= l1;
          Log.i("ProxyCache", "Cache file " + file + " is deleted because it exceeds cache limit");
          i--;
          continue;
        } 
        Log.e("ProxyCache", "Error deleting file " + file + " for trimming cache");
      } 
    } 
  }
  
  private long b(List<File> paramList) {
    Iterator<File> iterator = paramList.iterator();
    long l;
    for (l = 0L; iterator.hasNext(); l = ((File)iterator.next()).length() + l);
    return l;
  }
  
  private void b(File paramFile) {
    d.c(paramFile);
    a(d.b(paramFile.getParentFile()));
  }
  
  public void a(File paramFile) {
    this.a.submit(new a(this, paramFile));
  }
  
  protected abstract boolean a(File paramFile, long paramLong, int paramInt);
  
  private class a implements Callable<Void> {
    private final File b;
    
    public a(e this$0, File param1File) {
      this.b = param1File;
    }
    
    public Void a() {
      e.a(this.a, this.b);
      return null;
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/a/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */