package com.facebook.ads.internal.i.b;

import com.facebook.ads.internal.i.b.a.a;
import com.facebook.ads.internal.i.b.a.c;
import java.io.File;

class c {
  public final File a;
  
  public final c b;
  
  public final a c;
  
  c(File paramFile, c paramc, a parama) {
    this.a = paramFile;
    this.b = paramc;
    this.c = parama;
  }
  
  File a(String paramString) {
    paramString = this.b.a(paramString);
    return new File(this.a, paramString);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */