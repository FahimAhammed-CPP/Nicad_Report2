package com.facebook.ads.internal.i.b.a;

public interface c {
  String a(String paramString);
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */