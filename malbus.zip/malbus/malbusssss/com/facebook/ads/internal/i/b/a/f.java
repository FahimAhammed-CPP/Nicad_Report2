package com.facebook.ads.internal.i.b.a;

import android.text.TextUtils;
import com.facebook.ads.internal.i.b.m;

public class f implements c {
  private String b(String paramString) {
    int i = paramString.lastIndexOf('.');
    int j = paramString.lastIndexOf('/');
    return (i != -1 && i > j && i + 2 + 4 > paramString.length()) ? paramString.substring(i + 1, paramString.length()) : "";
  }
  
  public String a(String paramString) {
    String str = b(paramString);
    paramString = m.d(paramString);
    if (!TextUtils.isEmpty(str))
      paramString = paramString + "." + str; 
    return paramString;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/a/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */