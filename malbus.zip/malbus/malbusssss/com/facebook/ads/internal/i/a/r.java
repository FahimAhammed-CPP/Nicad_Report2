package com.facebook.ads.internal.i.a;

import java.net.HttpURLConnection;

public interface r {
  void a(n paramn);
  
  void a(String paramString);
  
  void a(HttpURLConnection paramHttpURLConnection, Object paramObject);
  
  boolean a();
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/a/r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */