package com.facebook.ads.internal.i.a;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.List;
import java.util.Map;

public class n {
  private int a;
  
  private String b;
  
  private Map<String, List<String>> c;
  
  private byte[] d;
  
  public n(HttpURLConnection paramHttpURLConnection, byte[] paramArrayOfbyte) {
    try {
      this.a = paramHttpURLConnection.getResponseCode();
      this.b = paramHttpURLConnection.getURL().toString();
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    this.c = paramHttpURLConnection.getHeaderFields();
    this.d = paramArrayOfbyte;
  }
  
  public int a() {
    return this.a;
  }
  
  public String b() {
    return this.b;
  }
  
  public Map<String, List<String>> c() {
    return this.c;
  }
  
  public byte[] d() {
    return this.d;
  }
  
  public String e() {
    return (this.d != null) ? new String(this.d) : null;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/a/n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */