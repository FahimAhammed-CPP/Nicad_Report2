package com.facebook.ads.internal.i.b.a;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

class d {
  static void a(File paramFile) {
    if (paramFile.exists()) {
      if (!paramFile.isDirectory())
        throw new IOException("File " + paramFile + " is not directory!"); 
    } else if (!paramFile.mkdirs()) {
      throw new IOException(String.format("Directory %s can't be created", new Object[] { paramFile.getAbsolutePath() }));
    } 
  }
  
  static List<File> b(File paramFile) {
    LinkedList linkedList = new LinkedList();
    File[] arrayOfFile = paramFile.listFiles();
    List<File> list = linkedList;
    if (arrayOfFile != null) {
      list = Arrays.asList(arrayOfFile);
      Collections.sort(list, new a());
    } 
    return list;
  }
  
  static void c(File paramFile) {
    if (paramFile.exists()) {
      long l = System.currentTimeMillis();
      if (!paramFile.setLastModified(l)) {
        d(paramFile);
        if (paramFile.lastModified() < l)
          throw new IOException("Error set last modified date to " + paramFile); 
      } 
    } 
  }
  
  static void d(File paramFile) {
    long l = paramFile.length();
    if (l == 0L) {
      e(paramFile);
      return;
    } 
    RandomAccessFile randomAccessFile = new RandomAccessFile(paramFile, "rwd");
    randomAccessFile.seek(l - 1L);
    byte b = randomAccessFile.readByte();
    randomAccessFile.seek(l - 1L);
    randomAccessFile.write(b);
    randomAccessFile.close();
  }
  
  private static void e(File paramFile) {
    if (!paramFile.delete() || !paramFile.createNewFile())
      throw new IOException("Error recreate zero-size file " + paramFile); 
  }
  
  private static final class a implements Comparator<File> {
    private a() {}
    
    private int a(long param1Long1, long param1Long2) {
      return (param1Long1 < param1Long2) ? -1 : ((param1Long1 == param1Long2) ? 0 : 1);
    }
    
    public int a(File param1File1, File param1File2) {
      return a(param1File1.lastModified(), param1File2.lastModified());
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/a/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */