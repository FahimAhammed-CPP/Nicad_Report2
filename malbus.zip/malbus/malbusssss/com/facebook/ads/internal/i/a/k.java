package com.facebook.ads.internal.i.a;

public class k extends l {
  public k(String paramString, p paramp) {
    super(paramString, null);
    this.a = paramString;
    this.c = "application/x-www-form-urlencoded;charset=UTF-8";
    if (paramp != null)
      this.d = paramp.b(); 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/a/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */