package com.facebook.ads.internal.i.b;

import java.io.File;

public interface b {
  void a(File paramFile, String paramString, int paramInt);
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */