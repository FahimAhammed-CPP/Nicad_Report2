package com.facebook.ads.internal.i.b.a;

import java.io.File;

public interface a {
  void a(File paramFile);
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */