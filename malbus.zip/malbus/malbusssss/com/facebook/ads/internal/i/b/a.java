package com.facebook.ads.internal.i.b;

public interface a {
  int a();
  
  int a(byte[] paramArrayOfbyte, long paramLong, int paramInt);
  
  void a(byte[] paramArrayOfbyte, int paramInt);
  
  void b();
  
  void c();
  
  boolean d();
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */