package com.facebook.ads.internal.i.b;

import android.text.TextUtils;
import com.facebook.ads.internal.i.b.a.b;
import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.net.Socket;

class e extends k {
  private final h a;
  
  private final b b;
  
  private b c;
  
  public e(h paramh, b paramb) {
    super(paramh, (a)paramb);
    this.b = paramb;
    this.a = paramh;
  }
  
  private void a(OutputStream paramOutputStream, long paramLong) {
    byte[] arrayOfByte = new byte[8192];
    while (true) {
      int i = a(arrayOfByte, paramLong, arrayOfByte.length);
      if (i != -1) {
        paramOutputStream.write(arrayOfByte, 0, i);
        paramLong += i;
        continue;
      } 
      paramOutputStream.flush();
      return;
    } 
  }
  
  private boolean a(d paramd) {
    boolean bool;
    null = false;
    int i = this.a.a();
    if (i > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    int j = this.b.a();
    if (bool && paramd.c) {
      float f1 = (float)paramd.b;
      float f2 = j;
      return (f1 <= i * 0.2F + f2) ? true : null;
    } 
    return true;
  }
  
  private String b(d paramd) {
    boolean bool1;
    int i;
    boolean bool2;
    long l;
    boolean bool3;
    String str3;
    String str2 = this.a.c();
    if (!TextUtils.isEmpty(str2)) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (this.b.d()) {
      i = this.b.a();
    } else {
      i = this.a.a();
    } 
    if (i >= 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (paramd.c) {
      l = i - paramd.b;
    } else {
      l = i;
    } 
    if (bool2 && paramd.c) {
      bool3 = true;
    } else {
      bool3 = false;
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    if (paramd.c) {
      str3 = "HTTP/1.1 206 PARTIAL CONTENT\n";
    } else {
      str3 = "HTTP/1.1 200 OK\n";
    } 
    stringBuilder1 = stringBuilder1.append(str3).append("Accept-Ranges: bytes\n");
    if (bool2) {
      str3 = String.format("Content-Length: %d\n", new Object[] { Long.valueOf(l) });
    } else {
      str3 = "";
    } 
    StringBuilder stringBuilder2 = stringBuilder1.append(str3);
    if (bool3) {
      str1 = String.format("Content-Range: bytes %d-%d/%d\n", new Object[] { Long.valueOf(paramd.b), Integer.valueOf(i - 1), Integer.valueOf(i) });
    } else {
      str1 = "";
    } 
    stringBuilder2 = stringBuilder2.append(str1);
    if (bool1) {
      str1 = String.format("Content-Type: %s\n", new Object[] { str2 });
      return stringBuilder2.append(str1).append("\n").toString();
    } 
    String str1 = "";
    return stringBuilder2.append(str1).append("\n").toString();
  }
  
  private void b(OutputStream paramOutputStream, long paramLong) {
    try {
      h h1 = new h();
      this(this.a);
      h1.a((int)paramLong);
      byte[] arrayOfByte = new byte[8192];
      while (true) {
        int i = h1.a(arrayOfByte);
        if (i != -1) {
          paramOutputStream.write(arrayOfByte, 0, i);
          paramLong += i;
          continue;
        } 
        paramOutputStream.flush();
        return;
      } 
    } finally {
      this.a.b();
    } 
  }
  
  protected void a(int paramInt) {
    if (this.c != null)
      this.c.a(this.b.a, this.a.a, paramInt); 
  }
  
  public void a(b paramb) {
    this.c = paramb;
  }
  
  public void a(d paramd, Socket paramSocket) {
    BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(paramSocket.getOutputStream());
    bufferedOutputStream.write(b(paramd).getBytes("UTF-8"));
    long l = paramd.b;
    if (a(paramd)) {
      a(bufferedOutputStream, l);
      return;
    } 
    b(bufferedOutputStream, l);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */