package com.facebook.ads.internal.i.b;

import android.content.Context;
import android.os.Environment;
import android.util.Log;
import java.io.File;

final class o {
  public static File a(Context paramContext) {
    return new File(a(paramContext, true), "video-cache");
  }
  
  private static File a(Context paramContext, boolean paramBoolean) {
    String str;
    File file1 = null;
    try {
      str = Environment.getExternalStorageState();
    } catch (NullPointerException nullPointerException) {
      str = "";
    } 
    File file3 = file1;
    if (paramBoolean) {
      file3 = file1;
      if ("mounted".equals(str))
        file3 = b(paramContext); 
    } 
    File file2 = file3;
    if (file3 == null)
      file2 = paramContext.getCacheDir(); 
    file3 = file2;
    if (file2 == null) {
      String str1 = "/data/data/" + paramContext.getPackageName() + "/cache/";
      Log.w("ProxyCache", "Can't define system cache directory! '" + str1 + "%s' will be used.");
      file3 = new File(str1);
    } 
    return file3;
  }
  
  private static File b(Context paramContext) {
    File file2 = new File(new File(new File(new File(Environment.getExternalStorageDirectory(), "Android"), "data"), paramContext.getPackageName()), "cache");
    File file1 = file2;
    if (!file2.exists()) {
      file1 = file2;
      if (!file2.mkdirs()) {
        Log.w("ProxyCache", "Unable to create external cache directory");
        file1 = null;
      } 
    } 
    return file1;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */