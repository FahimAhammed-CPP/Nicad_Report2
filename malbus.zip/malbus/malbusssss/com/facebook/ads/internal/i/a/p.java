package com.facebook.ads.internal.i.a;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class p implements Map<String, String> {
  private Map<String, String> a = new HashMap<String, String>();
  
  public p a(Map<? extends String, ? extends String> paramMap) {
    putAll(paramMap);
    return this;
  }
  
  public String a() {
    StringBuilder stringBuilder = new StringBuilder();
    for (String str : this.a.keySet()) {
      if (stringBuilder.length() > 0)
        stringBuilder.append("&"); 
      stringBuilder.append(str);
      str = this.a.get(str);
      if (str != null) {
        stringBuilder.append("=");
        try {
          stringBuilder.append(URLEncoder.encode(str, "UTF-8"));
        } catch (UnsupportedEncodingException unsupportedEncodingException) {
          unsupportedEncodingException.printStackTrace();
        } 
      } 
    } 
    return stringBuilder.toString();
  }
  
  public String a(Object paramObject) {
    return this.a.get(paramObject);
  }
  
  public String a(String paramString1, String paramString2) {
    return this.a.put(paramString1, paramString2);
  }
  
  public String b(Object paramObject) {
    return this.a.remove(paramObject);
  }
  
  public byte[] b() {
    byte[] arrayOfByte = null;
    try {
      byte[] arrayOfByte1 = a().getBytes("UTF-8");
      arrayOfByte = arrayOfByte1;
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      unsupportedEncodingException.printStackTrace();
    } 
    return arrayOfByte;
  }
  
  public void clear() {
    this.a.clear();
  }
  
  public boolean containsKey(Object paramObject) {
    return this.a.containsKey(paramObject);
  }
  
  public boolean containsValue(Object paramObject) {
    return this.a.containsValue(paramObject);
  }
  
  public Set<Map.Entry<String, String>> entrySet() {
    return this.a.entrySet();
  }
  
  public boolean isEmpty() {
    return this.a.isEmpty();
  }
  
  public Set<String> keySet() {
    return this.a.keySet();
  }
  
  public void putAll(Map<? extends String, ? extends String> paramMap) {
    this.a.putAll(paramMap);
  }
  
  public int size() {
    return this.a.size();
  }
  
  public Collection<String> values() {
    return this.a.values();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/a/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */