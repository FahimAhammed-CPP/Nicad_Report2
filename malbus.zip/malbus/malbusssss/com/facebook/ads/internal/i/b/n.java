package com.facebook.ads.internal.i.b;

public interface n {
  int a();
  
  int a(byte[] paramArrayOfbyte);
  
  void a(int paramInt);
  
  void b();
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */