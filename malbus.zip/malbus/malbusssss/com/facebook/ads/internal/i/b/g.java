package com.facebook.ads.internal.i.b;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.facebook.ads.internal.i.b.a.b;
import java.io.File;
import java.net.Socket;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

final class g {
  private final AtomicInteger a = new AtomicInteger(0);
  
  private final String b;
  
  private volatile e c;
  
  private final List<b> d = new CopyOnWriteArrayList<b>();
  
  private final b e;
  
  private final c f;
  
  public g(String paramString, c paramc) {
    this.b = j.<String>a(paramString);
    this.f = j.<c>a(paramc);
    this.e = new a(paramString, this.d);
  }
  
  private void c() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield c : Lcom/facebook/ads/internal/i/b/e;
    //   6: ifnonnull -> 22
    //   9: aload_0
    //   10: invokespecial e : ()Lcom/facebook/ads/internal/i/b/e;
    //   13: astore_1
    //   14: aload_0
    //   15: aload_1
    //   16: putfield c : Lcom/facebook/ads/internal/i/b/e;
    //   19: aload_0
    //   20: monitorexit
    //   21: return
    //   22: aload_0
    //   23: getfield c : Lcom/facebook/ads/internal/i/b/e;
    //   26: astore_1
    //   27: goto -> 14
    //   30: astore_1
    //   31: aload_0
    //   32: monitorexit
    //   33: aload_1
    //   34: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	30	finally
    //   14	19	30	finally
    //   22	27	30	finally
  }
  
  private void d() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   6: invokevirtual decrementAndGet : ()I
    //   9: ifgt -> 24
    //   12: aload_0
    //   13: getfield c : Lcom/facebook/ads/internal/i/b/e;
    //   16: invokevirtual a : ()V
    //   19: aload_0
    //   20: aconst_null
    //   21: putfield c : Lcom/facebook/ads/internal/i/b/e;
    //   24: aload_0
    //   25: monitorexit
    //   26: return
    //   27: astore_1
    //   28: aload_0
    //   29: monitorexit
    //   30: aload_1
    //   31: athrow
    // Exception table:
    //   from	to	target	type
    //   2	24	27	finally
  }
  
  private e e() {
    e e1 = new e(new h(this.b), new b(this.f.a(this.b), this.f.c));
    e1.a(this.e);
    return e1;
  }
  
  public void a() {
    this.d.clear();
    if (this.c != null) {
      this.c.a((b)null);
      this.c.a();
      this.c = null;
    } 
    this.a.set(0);
  }
  
  public void a(d paramd, Socket paramSocket) {
    c();
    try {
      this.a.incrementAndGet();
      this.c.a(paramd, paramSocket);
      return;
    } finally {
      d();
    } 
  }
  
  public int b() {
    return this.a.get();
  }
  
  private static final class a extends Handler implements b {
    private final String a;
    
    private final List<b> b;
    
    public a(String param1String, List<b> param1List) {
      super(Looper.getMainLooper());
      this.a = param1String;
      this.b = param1List;
    }
    
    public void a(File param1File, String param1String, int param1Int) {
      Message message = obtainMessage();
      message.arg1 = param1Int;
      message.obj = param1File;
      sendMessage(message);
    }
    
    public void handleMessage(Message param1Message) {
      Iterator<b> iterator = this.b.iterator();
      while (iterator.hasNext())
        ((b)iterator.next()).a((File)param1Message.obj, this.a, param1Message.arg1); 
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */