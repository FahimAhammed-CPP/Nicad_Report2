package com.facebook.ads.internal.i.a;

public enum j {
  a(true, false),
  b(true, true);
  
  private boolean c;
  
  private boolean d;
  
  j(boolean paramBoolean1, boolean paramBoolean2) {
    this.c = paramBoolean1;
    this.d = paramBoolean2;
  }
  
  public boolean a() {
    return this.c;
  }
  
  public boolean b() {
    return this.d;
  }
  
  public String c() {
    return toString();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/a/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */