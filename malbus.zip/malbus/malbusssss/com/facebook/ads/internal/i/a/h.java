package com.facebook.ads.internal.i.a;

import android.os.AsyncTask;

public class h extends AsyncTask<l, Void, n> implements c {
  private a a;
  
  private b b;
  
  private Exception c;
  
  public h(a parama, b paramb) {
    this.a = parama;
    this.b = paramb;
  }
  
  protected n a(l... paramVarArgs) {
    if (paramVarArgs != null) {
      try {
        if (paramVarArgs.length > 0) {
          l l1 = paramVarArgs[0];
          return this.a.a(l1);
        } 
        exception = new IllegalArgumentException();
        this("DoHttpRequestTask takes exactly one argument of type HttpRequest");
        throw exception;
      } catch (Exception exception) {
        this.c = exception;
        cancel(true);
        exception = null;
      } 
      return (n)exception;
    } 
    IllegalArgumentException illegalArgumentException = new IllegalArgumentException();
    this("DoHttpRequestTask takes exactly one argument of type HttpRequest");
    throw illegalArgumentException;
  }
  
  public void a(l paraml) {
    execute((Object[])new l[] { paraml });
  }
  
  protected void a(n paramn) {
    this.b.a(paramn);
  }
  
  protected void onCancelled() {
    this.b.a(this.c);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/a/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */