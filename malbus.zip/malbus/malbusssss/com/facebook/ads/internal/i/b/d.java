package com.facebook.ads.internal.i.b;

import android.text.TextUtils;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class d {
  private static final Pattern d = Pattern.compile("[R,r]ange:[ ]?bytes=(\\d*)-");
  
  private static final Pattern e = Pattern.compile("GET /(.*) HTTP");
  
  public final String a;
  
  public final long b;
  
  public final boolean c;
  
  public d(String paramString) {
    boolean bool;
    j.a(paramString);
    long l = a(paramString);
    this.b = Math.max(0L, l);
    if (l >= 0L) {
      bool = true;
    } else {
      bool = false;
    } 
    this.c = bool;
    this.a = b(paramString);
  }
  
  private long a(String paramString) {
    Matcher matcher = d.matcher(paramString);
    return matcher.find() ? Long.parseLong(matcher.group(1)) : -1L;
  }
  
  public static d a(InputStream paramInputStream) {
    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(paramInputStream, "UTF-8"));
    StringBuilder stringBuilder = new StringBuilder();
    while (true) {
      String str = bufferedReader.readLine();
      if (!TextUtils.isEmpty(str)) {
        stringBuilder.append(str).append('\n');
        continue;
      } 
      return new d(stringBuilder.toString());
    } 
  }
  
  private String b(String paramString) {
    Matcher matcher = e.matcher(paramString);
    if (matcher.find())
      return matcher.group(1); 
    throw new IllegalArgumentException("Invalid request `" + paramString + "`: url not found!");
  }
  
  public String toString() {
    return "GetRequest{rangeOffset=" + this.b + ", partial=" + this.c + ", uri='" + this.a + '\'' + '}';
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/i/b/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */