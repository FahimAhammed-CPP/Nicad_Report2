package com.facebook.ads.internal.view.b;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdViewAttributes;
import com.facebook.ads.internal.view.j;
import com.facebook.ads.internal.view.l;

public class a extends LinearLayout {
  private l a;
  
  private int b;
  
  public a(Context paramContext, NativeAd paramNativeAd, NativeAdViewAttributes paramNativeAdViewAttributes) {
    super(paramContext);
    setOrientation(1);
    setVerticalGravity(16);
    this.a = new l(getContext(), 2);
    this.a.setMinTextSize((paramNativeAdViewAttributes.getTitleTextSize() - 2));
    this.a.setText(paramNativeAd.getAdTitle());
    j.a((TextView)this.a, paramNativeAdViewAttributes);
    this.a.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-2, -2));
    addView((View)this.a);
    if (paramNativeAd.getAdTitle() != null)
      i = Math.min(paramNativeAd.getAdTitle().length(), 21); 
    this.b = i;
    addView((View)j.a(paramContext, paramNativeAd, paramNativeAdViewAttributes));
  }
  
  public int getMinVisibleTitleCharacters() {
    return this.b;
  }
  
  public TextView getTitleTextView() {
    return (TextView)this.a;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/b/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */