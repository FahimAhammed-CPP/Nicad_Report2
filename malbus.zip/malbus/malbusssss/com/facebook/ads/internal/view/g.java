package com.facebook.ads.internal.view;

import android.support.v7.widget.RecyclerView;
import android.view.View;

public class g extends RecyclerView.ViewHolder {
  public p a;
  
  public g(p paramp) {
    super((View)paramp);
    this.a = paramp;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */