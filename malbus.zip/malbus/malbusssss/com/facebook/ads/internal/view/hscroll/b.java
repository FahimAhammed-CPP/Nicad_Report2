package com.facebook.ads.internal.view.hscroll;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;

public class b extends d implements d.a {
  private HScrollLinearLayoutManager c;
  
  private a d;
  
  private int e = -1;
  
  private int f = -1;
  
  private int g = 0;
  
  private int h = 0;
  
  public b(Context paramContext) {
    super(paramContext);
    a();
  }
  
  private void a() {
    this.c = new HScrollLinearLayoutManager(getContext(), new c(), new a());
    this.c.setOrientation(0);
    setLayoutManager((RecyclerView.LayoutManager)this.c);
    setSnapDelegate(this);
  }
  
  private void a(int paramInt1, int paramInt2) {
    if (paramInt1 != this.e || paramInt2 != this.f) {
      this.e = paramInt1;
      this.f = paramInt2;
      if (this.d != null)
        this.d.a(this.e, this.f); 
    } 
  }
  
  private int b(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield h : I
    //   4: iconst_2
    //   5: imul
    //   6: istore_2
    //   7: aload_0
    //   8: invokevirtual getMeasuredWidth : ()I
    //   11: istore_3
    //   12: aload_0
    //   13: invokevirtual getPaddingLeft : ()I
    //   16: istore #4
    //   18: aload_0
    //   19: invokevirtual getAdapter : ()Landroid/support/v7/widget/RecyclerView$Adapter;
    //   22: invokevirtual getItemCount : ()I
    //   25: istore #5
    //   27: iconst_0
    //   28: istore #6
    //   30: ldc 2147483647
    //   32: istore #7
    //   34: iload #7
    //   36: iload_1
    //   37: if_icmple -> 77
    //   40: iinc #6, 1
    //   43: iload #6
    //   45: iload #5
    //   47: if_icmplt -> 52
    //   50: iload_1
    //   51: ireturn
    //   52: iload_3
    //   53: iload #4
    //   55: isub
    //   56: iload_2
    //   57: isub
    //   58: iload #6
    //   60: iload_2
    //   61: imul
    //   62: isub
    //   63: i2f
    //   64: iload #6
    //   66: i2f
    //   67: ldc 0.333
    //   69: fadd
    //   70: fdiv
    //   71: f2i
    //   72: istore #7
    //   74: goto -> 34
    //   77: iload #7
    //   79: istore_1
    //   80: goto -> 50
  }
  
  public int a(int paramInt) {
    paramInt = Math.abs(paramInt);
    return (paramInt <= this.b) ? 0 : ((this.g == 0) ? 1 : (paramInt / this.g + 1));
  }
  
  protected void a(int paramInt, boolean paramBoolean) {
    super.a(paramInt, paramBoolean);
    a(paramInt, 0);
  }
  
  public int getChildSpacing() {
    return this.h;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    paramInt1 = Math.round(getMeasuredWidth() / 1.91F);
    switch (View.MeasureSpec.getMode(paramInt2)) {
      default:
        paramInt2 = getPaddingTop() + getPaddingBottom();
        paramInt1 = b(paramInt1 - paramInt2);
        setMeasuredDimension(getMeasuredWidth(), paramInt2 + paramInt1);
        setChildWidth(paramInt1 + this.h * 2);
        return;
      case 1073741824:
        paramInt1 = View.MeasureSpec.getSize(paramInt2);
      case -2147483648:
        break;
    } 
    paramInt1 = Math.min(View.MeasureSpec.getSize(paramInt2), paramInt1);
  }
  
  public void setAdapter(RecyclerView.Adapter paramAdapter) {
    int i;
    HScrollLinearLayoutManager hScrollLinearLayoutManager = this.c;
    if (paramAdapter == null) {
      i = -1;
    } else {
      i = paramAdapter.hashCode();
    } 
    hScrollLinearLayoutManager.a(i);
    super.setAdapter(paramAdapter);
  }
  
  public void setChildSpacing(int paramInt) {
    this.h = paramInt;
  }
  
  public void setChildWidth(int paramInt) {
    this.g = paramInt;
    int i = getMeasuredWidth();
    int j = getPaddingLeft();
    paramInt = getPaddingRight();
    this.c.b((i - j - paramInt - this.g) / 2);
    this.c.a(this.g / i);
  }
  
  public void setCurrentPosition(int paramInt) {
    a(paramInt, false);
  }
  
  public void setOnPageChangedListener(a parama) {
    this.d = parama;
  }
  
  public static interface a {
    void a(int param1Int1, int param1Int2);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/hscroll/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */