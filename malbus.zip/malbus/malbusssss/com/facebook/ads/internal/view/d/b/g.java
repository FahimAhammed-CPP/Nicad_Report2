package com.facebook.ads.internal.view.d.b;

import android.content.Context;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.facebook.ads.internal.g.q;
import com.facebook.ads.internal.g.r;
import com.facebook.ads.internal.g.s;
import com.facebook.ads.internal.view.d.a.b;
import com.facebook.ads.internal.view.d.a.c;
import com.facebook.ads.internal.view.d.a.h;
import com.facebook.ads.internal.view.d.a.i;
import com.facebook.ads.internal.view.d.a.j;
import com.facebook.ads.internal.view.d.a.k;
import com.facebook.ads.internal.view.d.a.l;
import com.facebook.ads.internal.view.d.a.m;
import com.facebook.ads.internal.view.d.c.d;
import com.facebook.ads.internal.view.m;

public class g extends m implements View.OnTouchListener {
  private final m b = new m(this) {
      public void a(l param1l) {
        this.a.setVisibility(0);
      }
    };
  
  private final i c = new i(this) {
      public void a(h param1h) {
        g.a(this.a).setChecked(true);
      }
    };
  
  private final k d = new k(this) {
      public void a(j param1j) {
        g.a(this.a).setChecked(false);
      }
    };
  
  private final c e = new c(this) {
      public void a(b param1b) {
        g.a(this.a).setChecked(true);
      }
    };
  
  private final l f;
  
  public g(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public g(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public g(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
    this.f = new l(paramContext);
    this.f.setChecked(true);
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams((int)(displayMetrics.density * 25.0F), (int)(displayMetrics.density * 25.0F));
    setVisibility(8);
    addView((View)this.f, (ViewGroup.LayoutParams)layoutParams);
    setClickable(true);
    setFocusable(true);
    setFocusableInTouchMode(true);
  }
  
  protected void a(m paramm) {
    this.f.setOnTouchListener(this);
    setOnTouchListener(this);
    r r = paramm.getEventBus();
    r.a((s)this.b);
    r.a((s)this.e);
    r.a((s)this.c);
    r.a((s)this.d);
  }
  
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent) {
    boolean bool1 = false;
    if (paramMotionEvent.getAction() != 1)
      return bool1; 
    m m1 = getVideoView();
    boolean bool2 = bool1;
    if (m1 != null) {
      if (m1.getState() == d.c || m1.getState() == d.e || m1.getState() == d.g) {
        m1.d();
        return true;
      } 
      bool2 = bool1;
      if (m1.getState() == d.d) {
        m1.e();
        bool2 = bool1;
      } 
    } 
    return bool2;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/b/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */