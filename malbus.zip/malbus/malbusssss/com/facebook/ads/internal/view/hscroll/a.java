package com.facebook.ads.internal.view.hscroll;

import android.util.SparseArray;

public class a {
  private final SparseArray<int[]> a = new SparseArray();
  
  public void a(int paramInt, int[] paramArrayOfint) {
    this.a.put(paramInt, paramArrayOfint);
  }
  
  public int[] a(int paramInt) {
    return (int[])this.a.get(paramInt);
  }
  
  public boolean b(int paramInt) {
    return (this.a.indexOfKey(paramInt) >= 0);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/hscroll/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */