package com.facebook.ads.internal.view.d.b;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Context;
import android.os.Handler;
import android.support.annotation.Nullable;
import com.facebook.ads.internal.g.q;
import com.facebook.ads.internal.g.s;
import com.facebook.ads.internal.view.d.a.h;
import com.facebook.ads.internal.view.d.a.j;
import com.facebook.ads.internal.view.d.a.q;
import com.facebook.ads.internal.view.m;

@TargetApi(12)
public abstract class d extends m {
  private final Handler b;
  
  private final boolean c;
  
  @Nullable
  private m d;
  
  private final s<h> e = new s<h>(this) {
      public Class<h> a() {
        return h.class;
      }
      
      public void a(h param1h) {
        d.a(this.a).removeCallbacksAndMessages(null);
        this.a.clearAnimation();
        this.a.setAlpha(1.0F);
        this.a.setVisibility(0);
      }
    };
  
  private final s<j> f = new s<j>(this) {
      public Class<j> a() {
        return j.class;
      }
      
      public void a(j param1j) {
        d.a(this.a).removeCallbacksAndMessages(null);
        this.a.clearAnimation();
        this.a.setAlpha(0.0F);
        this.a.setVisibility(8);
      }
    };
  
  private final s<q> g = new s<q>(this) {
      public Class<q> a() {
        return q.class;
      }
      
      public void a(q param1q) {
        if (d.b(this.a) != null && param1q.b().getAction() == 0) {
          d.a(this.a).removeCallbacksAndMessages(null);
          this.a.setVisibility(0);
          this.a.animate().alpha(1.0F).setDuration(500L).setListener((Animator.AnimatorListener)new AnimatorListenerAdapter(this) {
                public void onAnimationEnd(Animator param2Animator) {
                  d.a(this.a.a).postDelayed(new Runnable(this) {
                        public void run() {
                          this.a.a.a.animate().alpha(0.0F).setDuration(500L).setListener((Animator.AnimatorListener)new AnimatorListenerAdapter(this) {
                                public void onAnimationEnd(Animator param4Animator) {
                                  this.a.a.a.a.setVisibility(8);
                                }
                              },  );
                        }
                      },  2000L);
                }
              });
        } 
      }
    };
  
  public d(Context paramContext) {
    this(paramContext, false);
  }
  
  public d(Context paramContext, boolean paramBoolean) {
    super(paramContext);
    this.c = paramBoolean;
    this.b = new Handler();
    if (!this.c) {
      setAlpha(0.0F);
      setVisibility(8);
    } 
  }
  
  protected void a(m paramm) {
    if (!this.c) {
      paramm.getEventBus().a(this.e);
      paramm.getEventBus().a(this.f);
      paramm.getEventBus().a(this.g);
      this.d = paramm;
    } 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/b/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */