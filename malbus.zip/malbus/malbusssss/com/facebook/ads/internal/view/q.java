package com.facebook.ads.internal.view;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.facebook.ads.AudienceNetworkActivity;
import com.facebook.ads.internal.g.f;
import com.facebook.ads.internal.g.g;
import com.facebook.ads.internal.g.s;
import com.facebook.ads.internal.util.ac;
import com.facebook.ads.internal.view.d.a.b;
import com.facebook.ads.internal.view.d.a.c;
import com.facebook.ads.internal.view.d.a.d;
import com.facebook.ads.internal.view.d.a.e;
import com.facebook.ads.internal.view.d.a.f;
import com.facebook.ads.internal.view.d.a.g;
import com.facebook.ads.internal.view.d.a.h;
import com.facebook.ads.internal.view.d.a.i;
import com.facebook.ads.internal.view.d.a.j;
import com.facebook.ads.internal.view.d.a.k;
import com.facebook.ads.internal.view.d.a.o;
import com.facebook.ads.internal.view.d.b.b;
import com.facebook.ads.internal.view.d.b.m;

public class q implements d {
  private final e a = new e(this) {
      public void a(d param1d) {
        q.a(this.a).finish();
      }
    };
  
  private final k b = new k(this) {
      public void a(j param1j) {
        q.b(this.a).a("videoInterstitalEvent", (com.facebook.ads.internal.g.q)param1j);
      }
    };
  
  private final i c = new i(this) {
      public void a(h param1h) {
        q.b(this.a).a("videoInterstitalEvent", (com.facebook.ads.internal.g.q)param1h);
      }
    };
  
  private final c d = new c(this) {
      public void a(b param1b) {
        q.b(this.a).a("videoInterstitalEvent", (com.facebook.ads.internal.g.q)param1b);
      }
    };
  
  private final AudienceNetworkActivity e;
  
  private final m f;
  
  private final d.a g;
  
  private ac h;
  
  private int i;
  
  public q(AudienceNetworkActivity paramAudienceNetworkActivity, d.a parama) {
    this.e = paramAudienceNetworkActivity;
    this.f = new m((Context)paramAudienceNetworkActivity);
    this.f.a((m)new b((Context)paramAudienceNetworkActivity));
    this.f.getEventBus().a((s)this.b);
    this.f.getEventBus().a((s)this.c);
    this.f.getEventBus().a((s)this.d);
    this.f.getEventBus().a((s)this.a);
    this.g = parama;
    this.f.setIsFullScreen(true);
    this.f.setVolume(1.0F);
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -2);
    layoutParams.addRule(15);
    this.f.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    parama.a((View)this.f);
  }
  
  public void a(Intent paramIntent, Bundle paramBundle, AudienceNetworkActivity paramAudienceNetworkActivity) {
    boolean bool = paramIntent.getBooleanExtra("autoplay", false);
    String str1 = paramIntent.getStringExtra("videoURL");
    String str2 = paramIntent.getStringExtra("videoMPD");
    paramBundle = paramIntent.getBundleExtra("videoLogger");
    String str3 = paramIntent.getStringExtra("clientToken");
    String str4 = paramIntent.getStringExtra("videoReportURL");
    this.i = paramIntent.getIntExtra("videoSeekTime", 0);
    this.f.setAutoplay(bool);
    this.h = new ac((Context)paramAudienceNetworkActivity, (f)g.a(paramAudienceNetworkActivity.getApplicationContext()), this.f, str4, str3, paramBundle);
    this.f.setVideoMPD(str2);
    this.f.setVideoURI(str1);
    if (this.i > 0)
      this.f.a(this.i); 
    this.f.d();
  }
  
  public void a(Bundle paramBundle) {}
  
  public void a(View paramView) {
    this.f.setControlsAnchorView(paramView);
  }
  
  public void a(d.a parama) {}
  
  public void e() {
    this.g.a("videoInterstitalEvent", (com.facebook.ads.internal.g.q)new f());
    this.f.e();
  }
  
  public void f() {
    this.g.a("videoInterstitalEvent", (com.facebook.ads.internal.g.q)new g());
    this.f.d();
  }
  
  public void g() {
    this.g.a("videoInterstitalEvent", (com.facebook.ads.internal.g.q)new o(this.i, this.f.getCurrentPosition()));
    this.h.b(this.f.getCurrentPosition());
    this.f.g();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */