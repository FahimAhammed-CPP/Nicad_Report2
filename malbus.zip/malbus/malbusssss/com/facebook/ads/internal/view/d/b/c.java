package com.facebook.ads.internal.view.d.b;

import android.content.Context;
import android.view.View;
import android.widget.TextView;
import com.facebook.ads.internal.g.q;
import com.facebook.ads.internal.g.s;
import com.facebook.ads.internal.view.d.a.n;
import com.facebook.ads.internal.view.m;
import java.util.concurrent.TimeUnit;

public class c extends d {
  private final TextView b;
  
  private final String c;
  
  private final s<n> d = new s<n>(this) {
      public Class<n> a() {
        return n.class;
      }
      
      public void a(n param1n) {
        c.a(this.a).setText(c.a(this.a, (this.a.getVideoView().getDuration() - this.a.getVideoView().getCurrentPosition())));
      }
    };
  
  public c(Context paramContext, String paramString) {
    this(paramContext, paramString, false);
  }
  
  public c(Context paramContext, String paramString, boolean paramBoolean) {
    super(paramContext, paramBoolean);
    this.b = new TextView(paramContext);
    this.c = paramString;
    addView((View)this.b);
  }
  
  private String a(long paramLong) {
    if (paramLong <= 0L)
      return "00:00"; 
    long l = TimeUnit.MILLISECONDS.toMinutes(paramLong);
    paramLong = TimeUnit.MILLISECONDS.toSeconds(paramLong % 60000L);
    return this.c.isEmpty() ? String.format("%02d:%02d", new Object[] { Long.valueOf(l), Long.valueOf(paramLong) }) : this.c.replace("{{REMAINING_TIME}}", String.format("%02d:%02d", new Object[] { Long.valueOf(l), Long.valueOf(paramLong) }));
  }
  
  protected void a(m paramm) {
    paramm.getEventBus().a(this.d);
    super.a(paramm);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/b/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */