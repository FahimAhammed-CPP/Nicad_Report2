package com.facebook.ads.internal.view.a;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.facebook.ads.internal.util.r;
import com.facebook.ads.internal.util.t;

@TargetApi(19)
public class c extends LinearLayout {
  private TextView a;
  
  private TextView b;
  
  private Drawable c;
  
  public c(Context paramContext) {
    super(paramContext);
    a();
  }
  
  private void a() {
    float f = (getResources().getDisplayMetrics()).density;
    setOrientation(1);
    this.a = new TextView(getContext());
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
    this.a.setTextColor(-16777216);
    this.a.setTextSize(2, 20.0F);
    this.a.setEllipsize(TextUtils.TruncateAt.END);
    this.a.setSingleLine(true);
    this.a.setVisibility(8);
    addView((View)this.a, (ViewGroup.LayoutParams)layoutParams);
    this.b = new TextView(getContext());
    layoutParams = new LinearLayout.LayoutParams(-1, -2);
    this.b.setAlpha(0.5F);
    this.b.setTextColor(-16777216);
    this.b.setTextSize(2, 15.0F);
    this.b.setCompoundDrawablePadding((int)(f * 5.0F));
    this.b.setEllipsize(TextUtils.TruncateAt.END);
    this.b.setSingleLine(true);
    this.b.setVisibility(8);
    addView((View)this.b, (ViewGroup.LayoutParams)layoutParams);
  }
  
  private Drawable getPadlockDrawable() {
    if (this.c == null)
      this.c = t.b(getContext(), r.b); 
    return this.c;
  }
  
  public void setSubtitle(String paramString) {
    if (TextUtils.isEmpty(paramString)) {
      this.b.setText(null);
      this.b.setVisibility(8);
      return;
    } 
    Uri uri = Uri.parse(paramString);
    this.b.setText(uri.getHost());
    TextView textView = this.b;
    if ("https".equals(uri.getScheme())) {
      Drawable drawable = getPadlockDrawable();
    } else {
      uri = null;
    } 
    textView.setCompoundDrawablesRelativeWithIntrinsicBounds((Drawable)uri, null, null, null);
    this.b.setVisibility(0);
  }
  
  public void setTitle(String paramString) {
    if (TextUtils.isEmpty(paramString)) {
      this.a.setText(null);
      this.a.setVisibility(8);
      return;
    } 
    this.a.setText(paramString);
    this.a.setVisibility(0);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */