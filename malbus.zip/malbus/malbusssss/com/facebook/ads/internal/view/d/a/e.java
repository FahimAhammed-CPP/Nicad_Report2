package com.facebook.ads.internal.view.d.a;

import com.facebook.ads.internal.g.s;

public abstract class e extends s<d> {
  public Class<d> a() {
    return d.class;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/a/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */