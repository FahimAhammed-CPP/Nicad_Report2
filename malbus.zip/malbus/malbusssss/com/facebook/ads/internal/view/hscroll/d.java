package com.facebook.ads.internal.view.hscroll;

import android.content.Context;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MotionEvent;
import android.view.View;

public class d extends RecyclerView implements View.OnTouchListener {
  protected int a = 0;
  
  protected int b;
  
  private int c = 0;
  
  private boolean d = true;
  
  private boolean e = false;
  
  private LinearLayoutManager f;
  
  private a g;
  
  public d(Context paramContext) {
    super(paramContext);
    a(paramContext);
  }
  
  private int a(int paramInt) {
    int i = this.c - paramInt;
    paramInt = this.g.a(i);
    return (i > this.b) ? a(this.a, paramInt) : ((i < -this.b) ? b(this.a, paramInt) : this.a);
  }
  
  private int a(int paramInt1, int paramInt2) {
    return Math.min(paramInt1 + paramInt2, getItemCount() - 1);
  }
  
  private void a(Context paramContext) {
    setOnTouchListener(this);
    this.b = (int)(paramContext.getResources().getDisplayMetrics()).density * 10;
  }
  
  private int b(int paramInt1, int paramInt2) {
    return Math.max(paramInt1 - paramInt2, 0);
  }
  
  private int getItemCount() {
    return (getAdapter() == null) ? 0 : getAdapter().getItemCount();
  }
  
  protected void a(int paramInt, boolean paramBoolean) {
    if (getAdapter() != null) {
      this.a = paramInt;
      if (paramBoolean) {
        smoothScrollToPosition(paramInt);
        return;
      } 
      scrollToPosition(paramInt);
    } 
  }
  
  public int getCurrentPosition() {
    return this.a;
  }
  
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: aload_2
    //   3: invokevirtual getRawX : ()F
    //   6: f2i
    //   7: istore #4
    //   9: aload_2
    //   10: invokevirtual getActionMasked : ()I
    //   13: istore #5
    //   15: iload #5
    //   17: iconst_1
    //   18: if_icmpeq -> 40
    //   21: iload #5
    //   23: bipush #6
    //   25: if_icmpeq -> 40
    //   28: iload #5
    //   30: iconst_3
    //   31: if_icmpeq -> 40
    //   34: iload #5
    //   36: iconst_4
    //   37: if_icmpne -> 74
    //   40: aload_0
    //   41: getfield e : Z
    //   44: ifeq -> 58
    //   47: aload_0
    //   48: aload_0
    //   49: iload #4
    //   51: invokespecial a : (I)I
    //   54: iconst_1
    //   55: invokevirtual a : (IZ)V
    //   58: aload_0
    //   59: iconst_1
    //   60: putfield d : Z
    //   63: aload_0
    //   64: iconst_0
    //   65: putfield e : Z
    //   68: iconst_1
    //   69: istore #6
    //   71: iload #6
    //   73: ireturn
    //   74: iload #5
    //   76: ifeq -> 104
    //   79: iload #5
    //   81: iconst_5
    //   82: if_icmpeq -> 104
    //   85: iload_3
    //   86: istore #6
    //   88: aload_0
    //   89: getfield d : Z
    //   92: ifeq -> 71
    //   95: iload_3
    //   96: istore #6
    //   98: iload #5
    //   100: iconst_2
    //   101: if_icmpne -> 71
    //   104: aload_0
    //   105: iload #4
    //   107: putfield c : I
    //   110: aload_0
    //   111: getfield d : Z
    //   114: ifeq -> 122
    //   117: aload_0
    //   118: iconst_0
    //   119: putfield d : Z
    //   122: aload_0
    //   123: iconst_1
    //   124: putfield e : Z
    //   127: iload_3
    //   128: istore #6
    //   130: goto -> 71
  }
  
  public void setLayoutManager(RecyclerView.LayoutManager paramLayoutManager) {
    if (!(paramLayoutManager instanceof LinearLayoutManager))
      throw new IllegalArgumentException("SnapRecyclerView only supports LinearLayoutManager"); 
    super.setLayoutManager(paramLayoutManager);
    this.f = (LinearLayoutManager)paramLayoutManager;
  }
  
  public void setSnapDelegate(a parama) {
    this.g = parama;
  }
  
  public static interface a {
    int a(int param1Int);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/hscroll/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */