package com.facebook.ads.internal.view.d.b;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import android.widget.TextView;

public class j extends d {
  private final TextView b;
  
  private final Paint c;
  
  private final RectF d;
  
  public j(Context paramContext, String paramString, int paramInt) {
    super(paramContext);
    this.b = new TextView(paramContext);
    this.b.setGravity(17);
    this.b.setText(paramString);
    this.b.setTextSize(paramInt);
    this.c = new Paint();
    this.c.setStyle(Paint.Style.FILL);
    this.c.setColor(-16777216);
    this.c.setAlpha(178);
    this.d = new RectF();
    setBackgroundColor(0);
    addView((View)this.b);
  }
  
  protected void onDraw(Canvas paramCanvas) {
    this.d.set(0.0F, 0.0F, getWidth(), getHeight());
    paramCanvas.drawRoundRect(this.d, 0.0F, 0.0F, this.c);
    super.onDraw(paramCanvas);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/b/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */