package com.facebook.ads.internal.view;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;

public class p extends ImageView {
  public p(Context paramContext) {
    super(paramContext);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i;
    if (View.MeasureSpec.getMode(paramInt1) == 1073741824) {
      i = paramInt1;
    } else {
      i = paramInt2;
      if (View.MeasureSpec.getMode(paramInt2) == 1073741824) {
        paramInt1 = paramInt2;
        i = paramInt2;
      } 
    } 
    super.onMeasure(paramInt1, i);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */