package com.facebook.ads.internal.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import com.facebook.ads.AudienceNetworkActivity;
import com.facebook.ads.internal.g.q;

public interface d {
  void a(Intent paramIntent, Bundle paramBundle, AudienceNetworkActivity paramAudienceNetworkActivity);
  
  void a(Bundle paramBundle);
  
  void a(a parama);
  
  void e();
  
  void f();
  
  void g();
  
  public static interface a {
    void a(View param1View);
    
    void a(String param1String);
    
    void a(String param1String, q param1q);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */