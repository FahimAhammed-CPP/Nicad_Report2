package com.facebook.ads.internal.view.d.b;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.facebook.ads.internal.g.q;
import com.facebook.ads.internal.g.s;
import com.facebook.ads.internal.view.d.a.h;
import com.facebook.ads.internal.view.d.a.j;
import com.facebook.ads.internal.view.d.c.d;
import com.facebook.ads.internal.view.m;

public class k extends d {
  private final l b;
  
  private final s<h> c = new s<h>(this) {
      public Class<h> a() {
        return h.class;
      }
      
      public void a(h param1h) {
        k.a(this.a).setChecked(true);
      }
    };
  
  private final s<j> d = new s<j>(this) {
      public Class<j> a() {
        return j.class;
      }
      
      public void a(j param1j) {
        k.a(this.a).setChecked(false);
      }
    };
  
  private final Paint e;
  
  private final RectF f;
  
  public k(Context paramContext) {
    super(paramContext);
    this.b = new l(paramContext);
    DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams((int)(displayMetrics.density * 50.0F), (int)(displayMetrics.density * 50.0F));
    layoutParams.addRule(13);
    this.b.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    this.e = new Paint();
    this.e.setStyle(Paint.Style.FILL);
    this.e.setColor(-16777216);
    this.e.setAlpha(119);
    this.f = new RectF();
    setBackgroundColor(0);
    addView((View)this.b);
    setGravity(17);
    layoutParams = new RelativeLayout.LayoutParams((int)(displayMetrics.density * 75.0D), (int)(displayMetrics.density * 75.0D));
    layoutParams.addRule(13);
    setLayoutParams((ViewGroup.LayoutParams)layoutParams);
  }
  
  protected void a(m paramm) {
    paramm.getEventBus().a(this.c);
    paramm.getEventBus().a(this.d);
    this.b.setOnTouchListener(new View.OnTouchListener(this, paramm) {
          public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
            boolean bool1 = false;
            boolean bool2 = bool1;
            if (param1MotionEvent.getAction() == 0) {
              if (this.a.getState() == d.c) {
                this.a.d();
              } else if (this.a.getState() == d.e) {
                this.a.d();
              } else {
                bool2 = bool1;
                if (this.a.getState() == d.d) {
                  this.a.e();
                } else {
                  return bool2;
                } 
              } 
              bool2 = true;
            } 
            return bool2;
          }
        });
    super.a(paramm);
  }
  
  protected void onDraw(Canvas paramCanvas) {
    float f = (getContext().getResources().getDisplayMetrics()).density;
    this.f.set(0.0F, 0.0F, getWidth(), getHeight());
    paramCanvas.drawRoundRect(this.f, 5.0F * f, f * 5.0F, this.e);
    super.onDraw(paramCanvas);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/b/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */