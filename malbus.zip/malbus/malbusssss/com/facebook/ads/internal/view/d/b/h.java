package com.facebook.ads.internal.view.d.b;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.facebook.ads.R;
import com.facebook.ads.internal.g.q;
import com.facebook.ads.internal.g.s;
import com.facebook.ads.internal.view.d.a.n;
import com.facebook.ads.internal.view.m;
import java.util.concurrent.atomic.AtomicBoolean;

public class h extends m {
  private final a b;
  
  private final int c;
  
  private final AtomicBoolean d;
  
  private final s<n> e = new s<n>(this) {
      public Class<n> a() {
        return n.class;
      }
      
      public void a(n param1n) {
        if (!h.a(this.a).get()) {
          int i = h.b(this.a) - this.a.getVideoView().getCurrentPosition() / 1000;
          if (i > 0) {
            h.c(this.a).setText(this.a.getResources().getString(R.string.com_facebook_skip_ad_in) + ' ' + i);
            return;
          } 
          h.c(this.a).setText(this.a.getResources().getString(R.string.com_facebook_skip_ad));
          h.a(this.a).set(true);
        } 
      }
    };
  
  public h(Context paramContext, int paramInt) {
    super(paramContext);
    this.c = paramInt;
    this.d = new AtomicBoolean(false);
    this.b = new a(paramContext);
    this.b.setText(getResources().getString(R.string.com_facebook_skip_ad_in) + ' ' + paramInt);
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
    addView((View)this.b, (ViewGroup.LayoutParams)layoutParams);
  }
  
  public void a(m paramm) {
    paramm.getEventBus().a(this.e);
    this.b.setOnClickListener(new View.OnClickListener(this, paramm) {
          public void onClick(View param1View) {
            if (!h.a(this.b).get()) {
              Log.i("SkipPlugin", "User clicked skip before the ads is allowed to skip.");
              return;
            } 
            this.a.f();
          }
        });
  }
  
  public boolean a() {
    return this.d.get();
  }
  
  private static class a extends TextView {
    private final Paint a;
    
    private final Paint b;
    
    private final RectF c;
    
    public a(Context param1Context) {
      super(param1Context);
      DisplayMetrics displayMetrics = param1Context.getResources().getDisplayMetrics();
      setBackgroundColor(0);
      setTextColor(-3355444);
      setPadding((int)(displayMetrics.density * 9.0F), (int)(displayMetrics.density * 5.0F), (int)(displayMetrics.density * 9.0F), (int)(displayMetrics.density * 5.0F));
      setTextSize(18.0F);
      this.a = new Paint();
      this.a.setStyle(Paint.Style.STROKE);
      this.a.setColor(-10066330);
      this.a.setStrokeWidth(1.0F);
      this.a.setAntiAlias(true);
      this.b = new Paint();
      this.b.setStyle(Paint.Style.FILL);
      this.b.setColor(-1895825408);
      this.c = new RectF();
    }
    
    protected void onDraw(Canvas param1Canvas) {
      if (getText().length() != 0) {
        int i = getWidth();
        int j = getHeight();
        this.c.set(false, false, i, j);
        param1Canvas.drawRoundRect(this.c, 6.0F, 6.0F, this.b);
        this.c.set(2, 2, (i - 2), (j - 2));
        param1Canvas.drawRoundRect(this.c, 6.0F, 6.0F, this.a);
        super.onDraw(param1Canvas);
      } 
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/b/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */