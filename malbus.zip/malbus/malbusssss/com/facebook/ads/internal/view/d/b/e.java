package com.facebook.ads.internal.view.d.b;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.facebook.ads.R;
import com.facebook.ads.internal.g.q;
import com.facebook.ads.internal.g.r;
import com.facebook.ads.internal.util.h;
import com.facebook.ads.internal.view.d.a.a;
import com.facebook.ads.internal.view.m;

public class e extends m {
  private final Context b;
  
  private final String c;
  
  private final TextView d;
  
  private final String e;
  
  private final Paint f;
  
  private final RectF g;
  
  public e(Context paramContext, String paramString1, String paramString2) {
    super(paramContext);
    this.b = paramContext;
    this.c = paramString1;
    this.e = paramString2;
    DisplayMetrics displayMetrics = paramContext.getResources().getDisplayMetrics();
    this.d = new TextView(getContext());
    this.d.setTextColor(-3355444);
    this.d.setTextSize(16.0F);
    this.d.setPadding((int)(displayMetrics.density * 6.0F), (int)(displayMetrics.density * 4.0F), (int)(displayMetrics.density * 6.0F), (int)(displayMetrics.density * 4.0F));
    this.f = new Paint();
    this.f.setStyle(Paint.Style.FILL);
    this.f.setColor(-16777216);
    this.f.setAlpha(178);
    this.g = new RectF();
    setBackgroundColor(0);
    this.d.setText(getResources().getString(R.string.com_facebook_ads_learn_more));
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
    addView((View)this.d, (ViewGroup.LayoutParams)layoutParams);
  }
  
  protected void a(m paramm) {
    this.d.setOnClickListener(new View.OnClickListener(this, paramm) {
          public void onClick(View param1View) {
            try {
              Uri uri = Uri.parse(e.a(this.b));
              r r = this.a.getEventBus();
              a a = new a();
              this(uri);
              r.a((q)a);
              h.a(e.b(this.b), Uri.parse(e.a(this.b)), e.c(this.b));
            } catch (ActivityNotFoundException activityNotFoundException) {
              Log.e("LearnMorePlugin", "Error while opening " + e.a(this.b), (Throwable)activityNotFoundException);
            } 
          }
        });
  }
  
  protected void onDraw(Canvas paramCanvas) {
    this.g.set(0.0F, 0.0F, getWidth(), getHeight());
    paramCanvas.drawRoundRect(this.g, 0.0F, 0.0F, this.f);
    super.onDraw(paramCanvas);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/b/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */