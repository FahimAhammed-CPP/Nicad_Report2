package com.facebook.ads.internal.view.b;

import android.content.Context;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdViewAttributes;
import com.facebook.ads.internal.view.j;

public class d extends LinearLayout {
  public d(Context paramContext, NativeAd paramNativeAd, NativeAdViewAttributes paramNativeAdViewAttributes) {
    super(paramContext);
    DisplayMetrics displayMetrics = paramContext.getResources().getDisplayMetrics();
    LinearLayout linearLayout = new LinearLayout(paramContext);
    linearLayout.setOrientation(1);
    linearLayout.setGravity(17);
    linearLayout.setVerticalGravity(16);
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
    layoutParams.setMargins(Math.round(displayMetrics.density * 15.0F), Math.round(displayMetrics.density * 15.0F), Math.round(displayMetrics.density * 15.0F), Math.round(displayMetrics.density * 15.0F));
    linearLayout.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    addView((View)linearLayout);
    String str2 = paramNativeAd.getAdSubtitle();
    TextView textView2 = new TextView(getContext());
    String str1 = str2;
    if (TextUtils.isEmpty(str2))
      str1 = paramNativeAd.getAdTitle(); 
    textView2.setText(str1);
    j.a(textView2, paramNativeAdViewAttributes);
    textView2.setEllipsize(TextUtils.TruncateAt.END);
    textView2.setSingleLine(true);
    linearLayout.addView((View)textView2);
    TextView textView1 = new TextView(getContext());
    textView1.setText(paramNativeAd.getAdBody());
    j.b(textView1, paramNativeAdViewAttributes);
    textView1.setEllipsize(TextUtils.TruncateAt.END);
    textView1.setMaxLines(2);
    linearLayout.addView((View)textView1);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/b/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */