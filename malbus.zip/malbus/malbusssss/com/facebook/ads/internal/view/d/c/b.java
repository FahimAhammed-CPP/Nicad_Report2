package com.facebook.ads.internal.view.d.c;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.graphics.SurfaceTexture;
import android.media.MediaPlayer;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.MediaController;
import java.io.IOException;

@TargetApi(14)
public class b extends TextureView implements MediaPlayer.OnBufferingUpdateListener, MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener, MediaPlayer.OnInfoListener, MediaPlayer.OnPreparedListener, MediaPlayer.OnSeekCompleteListener, MediaPlayer.OnVideoSizeChangedListener, TextureView.SurfaceTextureListener, MediaController.MediaPlayerControl, c {
  private static final String o = b.class.getSimpleName();
  
  private Uri a;
  
  private e b;
  
  private Surface c;
  
  @Nullable
  private MediaPlayer d;
  
  private MediaController e;
  
  private d f = d.a;
  
  private d g = d.a;
  
  private View h;
  
  private int i = 0;
  
  private long j;
  
  private int k = 0;
  
  private int l = 0;
  
  private float m = 1.0F;
  
  private boolean n = false;
  
  private int p = 0;
  
  private boolean q = false;
  
  public b(Context paramContext) {
    super(paramContext);
  }
  
  private boolean c() {
    return (this.f == d.c || this.f == d.d || this.f == d.e || this.f == d.g);
  }
  
  private void setVideoState(d paramd) {
    if (paramd != this.f) {
      this.f = paramd;
      if (this.b != null)
        this.b.a(paramd); 
    } 
  }
  
  public void a() {
    setVideoState(d.g);
    b();
    this.i = 0;
  }
  
  public void a(boolean paramBoolean) {
    if (this.e != null)
      this.e.setVisibility(8); 
    this.q = true;
  }
  
  public void b() {
    this.g = d.a;
    if (this.d != null) {
      int i = this.d.getCurrentPosition();
      if (i > 0)
        this.i = i; 
      this.d.stop();
      this.d.reset();
      this.d.release();
      this.d = null;
      if (this.e != null) {
        this.e.hide();
        this.e.setEnabled(false);
      } 
    } 
    setVideoState(d.a);
  }
  
  public boolean canPause() {
    return (this.f != d.b);
  }
  
  public boolean canSeekBackward() {
    return true;
  }
  
  public boolean canSeekForward() {
    return true;
  }
  
  public int getAudioSessionId() {
    return (this.d != null) ? this.d.getAudioSessionId() : 0;
  }
  
  public int getBufferPercentage() {
    return 0;
  }
  
  public int getCurrentPosition() {
    int i = 0;
    if (this.d != null)
      i = this.d.getCurrentPosition(); 
    return i;
  }
  
  public int getDuration() {
    return (this.d == null) ? 0 : this.d.getDuration();
  }
  
  public long getInitialBufferTime() {
    return this.j;
  }
  
  public d getState() {
    return this.f;
  }
  
  public d getTargetState() {
    return this.g;
  }
  
  public View getView() {
    return (View)this;
  }
  
  public float getVolume() {
    return this.m;
  }
  
  public boolean isPlaying() {
    return (this.d != null && this.d.isPlaying());
  }
  
  public void onBufferingUpdate(MediaPlayer paramMediaPlayer, int paramInt) {}
  
  public void onCompletion(MediaPlayer paramMediaPlayer) {
    if (this.d != null)
      this.d.pause(); 
    setVideoState(d.g);
    seekTo(0);
    this.i = 0;
  }
  
  public boolean onError(MediaPlayer paramMediaPlayer, int paramInt1, int paramInt2) {
    setVideoState(d.h);
    b();
    return true;
  }
  
  public boolean onInfo(MediaPlayer paramMediaPlayer, int paramInt1, int paramInt2) {
    switch (paramInt1) {
      default:
        return false;
      case 701:
        setVideoState(d.f);
      case 702:
        break;
    } 
    setVideoState(d.d);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i = getDefaultSize(this.k, paramInt1);
    int j = getDefaultSize(this.l, paramInt2);
    int k = j;
    int m = i;
    if (this.k > 0) {
      k = j;
      m = i;
      if (this.l > 0) {
        i = View.MeasureSpec.getMode(paramInt1);
        paramInt1 = View.MeasureSpec.getSize(paramInt1);
        int n = View.MeasureSpec.getMode(paramInt2);
        paramInt2 = View.MeasureSpec.getSize(paramInt2);
        if (i == 1073741824 && n == 1073741824) {
          if (this.k * paramInt2 < this.l * paramInt1) {
            m = this.k * paramInt2 / this.l;
            k = paramInt2;
          } else if (this.k * paramInt2 > this.l * paramInt1) {
            k = this.l * paramInt1 / this.k;
            m = paramInt1;
          } else {
            k = paramInt2;
            m = paramInt1;
          } 
        } else if (i == 1073741824) {
          k = this.l * paramInt1 / this.k;
          if (n == Integer.MIN_VALUE && k > paramInt2) {
            k = paramInt2;
            m = paramInt1;
          } else {
            m = paramInt1;
          } 
        } else if (n == 1073741824) {
          j = this.k * paramInt2 / this.l;
          k = paramInt2;
          m = j;
          if (i == Integer.MIN_VALUE) {
            k = paramInt2;
            m = j;
            if (j > paramInt1) {
              k = paramInt2;
              m = paramInt1;
            } 
          } 
        } else {
          j = this.k;
          m = this.l;
          if (n == Integer.MIN_VALUE && m > paramInt2) {
            j = this.k * paramInt2 / this.l;
          } else {
            paramInt2 = m;
          } 
          k = paramInt2;
          m = j;
          if (i == Integer.MIN_VALUE) {
            k = paramInt2;
            m = j;
            if (j > paramInt1) {
              k = this.l * paramInt1 / this.k;
              m = paramInt1;
            } 
          } 
        } 
      } 
    } 
    setMeasuredDimension(m, k);
  }
  
  public void onPrepared(MediaPlayer paramMediaPlayer) {
    setVideoState(d.c);
    if (this.n) {
      View view;
      this.e = new MediaController(getContext());
      MediaController mediaController = this.e;
      if (this.h == null) {
        b b1 = this;
      } else {
        view = this.h;
      } 
      mediaController.setAnchorView(view);
      this.e.setMediaPlayer(this);
      this.e.setEnabled(true);
    } 
    setRequestedVolume(this.m);
    this.k = paramMediaPlayer.getVideoWidth();
    this.l = paramMediaPlayer.getVideoHeight();
    if (this.i > 0) {
      if (this.i >= this.d.getDuration())
        this.i = 0; 
      this.d.seekTo(this.i);
      this.i = 0;
    } 
    if (this.g == d.d)
      start(); 
  }
  
  public void onSeekComplete(MediaPlayer paramMediaPlayer) {
    if (this.b != null) {
      this.b.a(this.p, this.i);
      this.i = 0;
    } 
  }
  
  public void onSurfaceTextureAvailable(SurfaceTexture paramSurfaceTexture, int paramInt1, int paramInt2) {
    if (this.c == null)
      this.c = new Surface(paramSurfaceTexture); 
    if (this.d != null) {
      this.d.setSurface(this.c);
      if (this.f == d.e && this.g != d.e)
        start(); 
    } 
  }
  
  public boolean onSurfaceTextureDestroyed(SurfaceTexture paramSurfaceTexture) {
    if (this.c != null) {
      this.c.release();
      this.c = null;
    } 
    if (this.n) {
      d d2 = d.d;
      this.g = d2;
      pause();
      return true;
    } 
    d d1 = this.f;
    this.g = d1;
    pause();
    return true;
  }
  
  public void onSurfaceTextureSizeChanged(SurfaceTexture paramSurfaceTexture, int paramInt1, int paramInt2) {}
  
  public void onSurfaceTextureUpdated(SurfaceTexture paramSurfaceTexture) {}
  
  public void onVideoSizeChanged(MediaPlayer paramMediaPlayer, int paramInt1, int paramInt2) {
    this.k = paramMediaPlayer.getVideoWidth();
    this.l = paramMediaPlayer.getVideoHeight();
    if (this.k != 0 && this.l != 0)
      requestLayout(); 
  }
  
  public void pause() {
    if (this.d != null) {
      if (canPause()) {
        this.d.pause();
        if (this.f != d.g)
          setVideoState(d.e); 
      } 
      return;
    } 
    setVideoState(d.a);
  }
  
  public void seekTo(int paramInt) {
    if (this.d != null && c()) {
      if (paramInt < getDuration() && paramInt > 0) {
        this.p = getCurrentPosition();
        this.i = paramInt;
        this.d.seekTo(paramInt);
      } 
      return;
    } 
    this.i = paramInt;
  }
  
  public void setControlsAnchorView(View paramView) {
    this.h = paramView;
    paramView.setOnTouchListener(new View.OnTouchListener(this) {
          public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
            if (!b.a(this.a) && b.b(this.a) != null && param1MotionEvent.getAction() == 1) {
              if (b.b(this.a).isShowing()) {
                b.b(this.a).hide();
                return true;
              } 
              b.b(this.a).show();
            } 
            return true;
          }
        });
  }
  
  public void setFullScreen(boolean paramBoolean) {
    this.n = paramBoolean;
    if (this.n)
      setOnTouchListener(new View.OnTouchListener(this) {
            public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
              if (!b.a(this.a) && b.b(this.a) != null && param1MotionEvent.getAction() == 1) {
                if (b.b(this.a).isShowing()) {
                  b.b(this.a).hide();
                  return true;
                } 
                b.b(this.a).show();
              } 
              return true;
            }
          }); 
  }
  
  public void setRequestedVolume(float paramFloat) {
    this.m = paramFloat;
    if (this.d != null && this.f != d.b && this.f != d.a)
      this.d.setVolume(paramFloat, paramFloat); 
  }
  
  public void setVideoMPD(String paramString) {}
  
  public void setVideoStateChangeListener(e parame) {
    this.b = parame;
  }
  
  public void setup(Uri paramUri) {
    MediaPlayer mediaPlayer;
    AssetFileDescriptor assetFileDescriptor = null;
    SecurityException securityException = null;
    this.a = paramUri;
    if (this.d != null) {
      this.d.reset();
      this.d.setSurface(null);
      mediaPlayer = this.d;
    } else {
      mediaPlayer = new MediaPlayer();
    } 
    try {
      boolean bool = paramUri.getScheme().equals("asset");
      if (bool) {
        try {
          AssetFileDescriptor assetFileDescriptor1 = getContext().getAssets().openFd(paramUri.getPath().substring(1));
        } catch (SecurityException securityException2) {
        
        } catch (IOException iOException1) {
        
        } finally {
          if (iOException != null)
            try {
              iOException.close();
            } catch (IOException iOException1) {} 
        } 
        SecurityException securityException1 = securityException;
        String str = o;
        securityException1 = securityException;
        StringBuilder stringBuilder = new StringBuilder();
        securityException1 = securityException;
        this();
        securityException1 = securityException;
        Log.w(str, stringBuilder.append("Failed to open assets ").append(paramUri).toString());
        securityException1 = securityException;
        setVideoState(d.h);
        if (securityException != null)
          try {
            securityException.close();
          } catch (IOException iOException1) {} 
      } else {
        mediaPlayer.setDataSource(getContext(), paramUri);
      } 
      mediaPlayer.setLooping(false);
      mediaPlayer.setOnBufferingUpdateListener(this);
      mediaPlayer.setOnCompletionListener(this);
      mediaPlayer.setOnErrorListener(this);
      mediaPlayer.setOnInfoListener(this);
      mediaPlayer.setOnPreparedListener(this);
      mediaPlayer.setOnVideoSizeChangedListener(this);
      mediaPlayer.setOnSeekCompleteListener(this);
      mediaPlayer.prepareAsync();
      this.d = mediaPlayer;
      setVideoState(d.b);
    } catch (Exception exception) {
      setVideoState(d.h);
      mediaPlayer.release();
      Log.e(o, "Cannot prepare media player with SurfaceTexture: " + exception);
    } 
    setSurfaceTextureListener(this);
    if (isAvailable())
      onSurfaceTextureAvailable(getSurfaceTexture(), 0, 0); 
  }
  
  public void start() {
    this.g = d.d;
    if (this.f == d.d || this.f == d.c || this.f == d.e || this.f == d.g)
      if (this.d == null) {
        setup(this.a);
      } else {
        if (this.i > 0)
          this.d.seekTo(this.i); 
        this.d.start();
        setVideoState(d.d);
      }  
    if (isAvailable())
      onSurfaceTextureAvailable(getSurfaceTexture(), 0, 0); 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/c/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */