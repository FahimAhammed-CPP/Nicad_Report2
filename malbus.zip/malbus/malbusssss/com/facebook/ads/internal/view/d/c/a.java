package com.facebook.ads.internal.view.d.c;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.SurfaceTexture;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.MediaController;
import com.facebook.ads.AdSettings;
import com.facebook.ads.internal.util.c;
import com.facebook.ads.internal.util.d;
import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.LoadControl;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.extractor.ExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.trackselection.AdaptiveVideoTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelection;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.upstream.BandwidthMeter;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.upstream.TransferListener;
import com.google.android.exoplayer2.util.Util;

@TargetApi(14)
public class a extends TextureView implements TextureView.SurfaceTextureListener, c, ExoPlayer.EventListener, SimpleExoPlayer.VideoListener {
  private static final String a = a.class.getSimpleName();
  
  private Uri b;
  
  private String c;
  
  private e d;
  
  private Handler e = new Handler();
  
  private Surface f;
  
  @Nullable
  private SimpleExoPlayer g;
  
  private MediaController h;
  
  private d i = d.a;
  
  private d j = d.a;
  
  private View k;
  
  private boolean l = false;
  
  private boolean m = false;
  
  private long n;
  
  private long o;
  
  private long p;
  
  private int q;
  
  private int r;
  
  private float s = 1.0F;
  
  private int t = -1;
  
  public a(Context paramContext) {
    super(paramContext);
  }
  
  private void c() {
    DefaultBandwidthMeter defaultBandwidthMeter = new DefaultBandwidthMeter();
    AdaptiveVideoTrackSelection.Factory factory = new AdaptiveVideoTrackSelection.Factory((BandwidthMeter)defaultBandwidthMeter);
    DefaultTrackSelector defaultTrackSelector = new DefaultTrackSelector(this.e, (TrackSelection.Factory)factory);
    DefaultLoadControl defaultLoadControl = new DefaultLoadControl();
    this.g = ExoPlayerFactory.newSimpleInstance(getContext(), (TrackSelector)defaultTrackSelector, (LoadControl)defaultLoadControl);
    this.g.setVideoListener(this);
    this.g.addListener(this);
    this.g.setPlayWhenReady(false);
    if (this.m) {
      View view;
      this.h = new MediaController(getContext());
      MediaController mediaController = this.h;
      if (this.k == null) {
        a a1 = this;
      } else {
        view = this.k;
      } 
      mediaController.setAnchorView(view);
      this.h.setMediaPlayer(new MediaController.MediaPlayerControl(this) {
            public boolean canPause() {
              return true;
            }
            
            public boolean canSeekBackward() {
              return true;
            }
            
            public boolean canSeekForward() {
              return true;
            }
            
            public int getAudioSessionId() {
              return a.a(this.a).getAudioSessionId();
            }
            
            public int getBufferPercentage() {
              return a.a(this.a).getBufferedPercentage();
            }
            
            public int getCurrentPosition() {
              return this.a.getCurrentPosition();
            }
            
            public int getDuration() {
              return this.a.getDuration();
            }
            
            public boolean isPlaying() {
              return a.a(this.a).getPlayWhenReady();
            }
            
            public void pause() {
              this.a.pause();
            }
            
            public void seekTo(int param1Int) {
              this.a.seekTo(param1Int);
            }
            
            public void start() {
              this.a.start();
            }
          });
      this.h.setEnabled(true);
    } 
    if (this.c == null || this.c.length() <= 0 || AdSettings.isTestMode(getContext())) {
      DefaultDataSourceFactory defaultDataSourceFactory = new DefaultDataSourceFactory(getContext(), Util.getUserAgent(getContext(), "ads"), (TransferListener)defaultBandwidthMeter);
      DefaultExtractorsFactory defaultExtractorsFactory = new DefaultExtractorsFactory();
      ExtractorMediaSource extractorMediaSource = new ExtractorMediaSource(this.b, (DataSource.Factory)defaultDataSourceFactory, (ExtractorsFactory)defaultExtractorsFactory, null, null);
      this.g.prepare((MediaSource)extractorMediaSource);
    } 
    setVideoState(d.b);
    if (isAvailable())
      onSurfaceTextureAvailable(getSurfaceTexture(), 0, 0); 
  }
  
  private void d() {
    if (this.f != null) {
      this.f.release();
      this.f = null;
    } 
    if (this.g != null) {
      this.g.release();
      this.g = null;
    } 
    this.h = null;
    this.l = false;
    setVideoState(d.a);
  }
  
  private void setVideoState(d paramd) {
    if (paramd != this.i) {
      this.i = paramd;
      if (this.i == d.d)
        this.l = true; 
      if (this.d != null)
        this.d.a(paramd); 
    } 
  }
  
  public void a() {
    setVideoState(d.g);
  }
  
  public void a(boolean paramBoolean) {}
  
  public void b() {
    setVideoState(d.a);
  }
  
  public int getCurrentPosition() {
    return (this.g != null) ? (int)this.g.getCurrentPosition() : 0;
  }
  
  public int getDuration() {
    return (this.g == null) ? 0 : (int)this.g.getDuration();
  }
  
  public long getInitialBufferTime() {
    return this.o;
  }
  
  public d getState() {
    return this.i;
  }
  
  public d getTargetState() {
    return this.j;
  }
  
  public View getView() {
    return (View)this;
  }
  
  public float getVolume() {
    return this.s;
  }
  
  public void onLoadingChanged(boolean paramBoolean) {}
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i = getDefaultSize(this.q, paramInt1);
    int j = getDefaultSize(this.r, paramInt2);
    int k = j;
    int m = i;
    if (this.q > 0) {
      k = j;
      m = i;
      if (this.r > 0) {
        j = View.MeasureSpec.getMode(paramInt1);
        paramInt1 = View.MeasureSpec.getSize(paramInt1);
        int n = View.MeasureSpec.getMode(paramInt2);
        i = View.MeasureSpec.getSize(paramInt2);
        if (j == 1073741824 && n == 1073741824) {
          if (this.q * i < this.r * paramInt1) {
            m = this.q * i / this.r;
            k = i;
          } else if (this.q * i > this.r * paramInt1) {
            k = this.r * paramInt1 / this.q;
            m = paramInt1;
          } else {
            k = i;
            m = paramInt1;
          } 
        } else if (j == 1073741824) {
          k = this.r * paramInt1 / this.q;
          if (n == Integer.MIN_VALUE && k > i) {
            k = i;
            m = paramInt1;
          } else {
            m = paramInt1;
          } 
        } else if (n == 1073741824) {
          paramInt2 = this.q * i / this.r;
          k = i;
          m = paramInt2;
          if (j == Integer.MIN_VALUE) {
            k = i;
            m = paramInt2;
            if (paramInt2 > paramInt1) {
              k = i;
              m = paramInt1;
            } 
          } 
        } else {
          paramInt2 = this.q;
          m = this.r;
          if (n == Integer.MIN_VALUE && m > i) {
            paramInt2 = this.q * i / this.r;
          } else {
            i = m;
          } 
          k = i;
          m = paramInt2;
          if (j == Integer.MIN_VALUE) {
            k = i;
            m = paramInt2;
            if (paramInt2 > paramInt1) {
              k = this.r * paramInt1 / this.q;
              m = paramInt1;
            } 
          } 
        } 
      } 
    } 
    setMeasuredDimension(m, k);
  }
  
  public void onPlayerError(ExoPlaybackException paramExoPlaybackException) {
    setVideoState(d.h);
    paramExoPlaybackException.printStackTrace();
    d.a(c.a((Throwable)paramExoPlaybackException, "[ExoPlayer] Error during playback of ExoPlayer"));
  }
  
  public void onPlayerStateChanged(boolean paramBoolean, int paramInt) {
    switch (paramInt) {
      default:
        return;
      case 1:
        setVideoState(d.a);
      case 2:
        if (this.t >= 0) {
          paramInt = this.t;
          this.t = -1;
          this.d.a(paramInt, getCurrentPosition());
        } 
      case 3:
        if (this.n != 0L)
          this.o = System.currentTimeMillis() - this.n; 
        setRequestedVolume(this.s);
        if (this.p > 0L && this.p < this.g.getDuration()) {
          this.g.seekTo(this.p);
          this.p = 0L;
        } 
        if (this.g.getCurrentPosition() != 0L && !paramBoolean && this.l)
          setVideoState(d.e); 
        if (!paramBoolean && this.i != d.g) {
          setVideoState(d.c);
          if (this.j == d.d) {
            start();
            this.j = d.a;
          } 
        } 
      case 4:
        break;
    } 
    if (paramBoolean)
      setVideoState(d.g); 
    if (this.g != null) {
      this.g.setPlayWhenReady(false);
      if (!paramBoolean)
        this.g.seekToDefaultPosition(); 
    } 
    this.l = false;
  }
  
  public void onPositionDiscontinuity() {}
  
  public void onRenderedFirstFrame() {}
  
  public void onSurfaceTextureAvailable(SurfaceTexture paramSurfaceTexture, int paramInt1, int paramInt2) {
    this.f = new Surface(paramSurfaceTexture);
    if (this.f == null)
      this.f = new Surface(paramSurfaceTexture); 
    if (this.g != null) {
      this.g.setVideoSurface(this.f);
      if (this.i == d.e && this.j != d.e)
        start(); 
    } 
  }
  
  public boolean onSurfaceTextureDestroyed(SurfaceTexture paramSurfaceTexture) {
    if (this.f != null) {
      this.f.release();
      this.f = null;
      this.g.setVideoSurface(null);
    } 
    if (this.m) {
      d d2 = d.d;
      this.j = d2;
      pause();
      return true;
    } 
    d d1 = this.i;
    this.j = d1;
    pause();
    return true;
  }
  
  public void onSurfaceTextureSizeChanged(SurfaceTexture paramSurfaceTexture, int paramInt1, int paramInt2) {}
  
  public void onSurfaceTextureUpdated(SurfaceTexture paramSurfaceTexture) {}
  
  public void onTimelineChanged(Timeline paramTimeline, Object paramObject) {}
  
  public void onVideoSizeChanged(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.q = paramInt1;
    this.r = paramInt2;
    if (this.q != 0 && this.r != 0)
      requestLayout(); 
  }
  
  public void onVideoTracksDisabled() {}
  
  public void pause() {
    if (this.g != null) {
      this.g.setPlayWhenReady(false);
      return;
    } 
    setVideoState(d.a);
  }
  
  public void seekTo(int paramInt) {
    if (this.g != null) {
      this.t = getCurrentPosition();
      this.g.seekTo(paramInt);
      return;
    } 
    this.p = paramInt;
  }
  
  public void setControlsAnchorView(View paramView) {
    this.k = paramView;
    paramView.setOnTouchListener(new View.OnTouchListener(this) {
          public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
            if (a.b(this.a) != null && param1MotionEvent.getAction() == 1) {
              if (a.b(this.a).isShowing()) {
                a.b(this.a).hide();
                return true;
              } 
            } else {
              return true;
            } 
            a.b(this.a).show();
            return true;
          }
        });
  }
  
  public void setFullScreen(boolean paramBoolean) {
    this.m = paramBoolean;
    if (paramBoolean)
      setOnTouchListener(new View.OnTouchListener(this) {
            public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
              if (a.b(this.a) != null && param1MotionEvent.getAction() == 1) {
                if (a.b(this.a).isShowing()) {
                  a.b(this.a).hide();
                  return true;
                } 
              } else {
                return true;
              } 
              a.b(this.a).show();
              return true;
            }
          }); 
  }
  
  public void setRequestedVolume(float paramFloat) {
    this.s = paramFloat;
    if (this.g != null && this.i != d.b && this.i != d.a)
      this.g.setVolume(paramFloat); 
  }
  
  public void setVideoMPD(String paramString) {
    this.c = paramString;
  }
  
  public void setVideoStateChangeListener(e parame) {
    this.d = parame;
  }
  
  public void setup(Uri paramUri) {
    if (this.g != null && this.i != d.g)
      d(); 
    this.b = paramUri;
    setSurfaceTextureListener(this);
    c();
  }
  
  public void start() {
    Log.d("TEST", "Start");
    this.j = d.d;
    if (this.g == null) {
      setup(this.b);
      return;
    } 
    if (this.i == d.c || this.i == d.e || this.i == d.g) {
      this.g.setPlayWhenReady(true);
      setVideoState(d.d);
    } 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/c/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */