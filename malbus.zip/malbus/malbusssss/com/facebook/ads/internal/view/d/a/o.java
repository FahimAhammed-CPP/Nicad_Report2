package com.facebook.ads.internal.view.d.a;

import com.facebook.ads.internal.g.q;

public class o extends q {
  private final int a;
  
  private final int b;
  
  public o(int paramInt1, int paramInt2) {
    this.a = paramInt1;
    this.b = paramInt2;
  }
  
  public int a() {
    return this.a;
  }
  
  public int b() {
    return this.b;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/a/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */