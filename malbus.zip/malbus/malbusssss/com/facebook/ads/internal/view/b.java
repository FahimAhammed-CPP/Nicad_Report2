package com.facebook.ads.internal.view;

import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.facebook.ads.internal.util.i;

public abstract class b extends WebView {
  private static final String a = b.class.getSimpleName();
  
  private boolean b;
  
  public b(Context paramContext) {
    super(paramContext);
    d();
  }
  
  private void d() {
    setWebChromeClient(a());
    setWebViewClient(b());
    i.b(this);
    getSettings().setJavaScriptEnabled(true);
    if (Build.VERSION.SDK_INT >= 17)
      getSettings().setMediaPlaybackRequiresUserGesture(false); 
    setHorizontalScrollBarEnabled(false);
    setHorizontalScrollbarOverlay(false);
    setVerticalScrollBarEnabled(false);
    setVerticalScrollbarOverlay(false);
    if (Build.VERSION.SDK_INT >= 21)
      try {
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true);
      } catch (Exception exception) {
        Log.w(a, "Failed to initialize CookieManager.");
      }  
  }
  
  protected WebChromeClient a() {
    return new WebChromeClient();
  }
  
  protected WebViewClient b() {
    return new WebViewClient();
  }
  
  public boolean c() {
    return this.b;
  }
  
  public void destroy() {
    this.b = true;
    super.destroy();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */