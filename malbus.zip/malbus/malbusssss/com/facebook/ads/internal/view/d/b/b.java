package com.facebook.ads.internal.view.d.b;

import android.content.Context;
import android.media.AudioManager;
import android.support.annotation.Nullable;
import com.facebook.ads.internal.g.q;
import com.facebook.ads.internal.g.s;
import com.facebook.ads.internal.view.d.a.l;
import com.facebook.ads.internal.view.d.a.m;
import com.facebook.ads.internal.view.m;

public class b extends m implements AudioManager.OnAudioFocusChangeListener {
  @Nullable
  private AudioManager b;
  
  private final m c = new m(this) {
      public void a(l param1l) {
        if (b.a(this.a) == null) {
          b.a(this.a, (AudioManager)this.a.getContext().getSystemService("audio"));
          b.a(this.a).requestAudioFocus(this.a, 3, 1);
        } 
      }
    };
  
  public b(Context paramContext) {
    super(paramContext);
  }
  
  protected void a(m paramm) {
    paramm.getEventBus().a((s)this.c);
    super.a(paramm);
  }
  
  protected void finalize() {
    if (this.b != null) {
      this.b.abandonAudioFocus(this);
      this.b = null;
    } 
    super.finalize();
  }
  
  public void onAudioFocusChange(int paramInt) {
    if (getVideoView() != null && paramInt <= 0)
      getVideoView().e(); 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/b/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */