package com.facebook.ads.internal.view.d.b;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

public abstract class m extends RelativeLayout {
  private com.facebook.ads.internal.view.m b;
  
  static {
    boolean bool;
    if (!m.class.desiredAssertionStatus()) {
      bool = true;
    } else {
      bool = false;
    } 
    a = bool;
  }
  
  public m(Context paramContext) {
    super(paramContext);
  }
  
  public m(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
  }
  
  protected void a(com.facebook.ads.internal.view.m paramm) {}
  
  public void b(com.facebook.ads.internal.view.m paramm) {
    this.b = paramm;
    a(paramm);
  }
  
  protected com.facebook.ads.internal.view.m getVideoView() {
    if (!a && this.b == null)
      throw new AssertionError(); 
    return this.b;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/b/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */