package com.facebook.ads.internal.view.d.c;

public interface e {
  void a(int paramInt1, int paramInt2);
  
  void a(d paramd);
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/c/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */