package com.facebook.ads.internal.view.d.b;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Build;
import android.widget.Button;

public class l extends Button {
  private final Path a = new Path();
  
  private final Path b = new Path();
  
  private final Paint c = new Paint(this) {
    
    };
  
  private final Path d = new Path();
  
  private boolean e = false;
  
  public l(Context paramContext) {
    super(paramContext);
    setClickable(true);
    setBackgroundColor(0);
  }
  
  protected void onDraw(Canvas paramCanvas) {
    if (paramCanvas.isHardwareAccelerated() && Build.VERSION.SDK_INT < 17)
      setLayerType(1, null); 
    float f = Math.max(paramCanvas.getWidth(), paramCanvas.getHeight()) / 100.0F;
    if (this.e) {
      this.d.rewind();
      this.d.moveTo(26.5F * f, 15.5F * f);
      this.d.lineTo(26.5F * f, 84.5F * f);
      this.d.lineTo(82.5F * f, 50.5F * f);
      this.d.lineTo(26.5F * f, f * 15.5F);
      this.d.close();
      paramCanvas.drawPath(this.d, this.c);
    } else {
      this.a.rewind();
      this.a.moveTo(29.0F * f, 21.0F * f);
      this.a.lineTo(29.0F * f, 79.0F * f);
      this.a.lineTo(45.0F * f, 79.0F * f);
      this.a.lineTo(45.0F * f, 21.0F * f);
      this.a.lineTo(29.0F * f, 21.0F * f);
      this.a.close();
      this.b.rewind();
      this.b.moveTo(55.0F * f, 21.0F * f);
      this.b.lineTo(55.0F * f, 79.0F * f);
      this.b.lineTo(71.0F * f, 79.0F * f);
      this.b.lineTo(71.0F * f, 21.0F * f);
      this.b.lineTo(55.0F * f, f * 21.0F);
      this.b.close();
      paramCanvas.drawPath(this.a, this.c);
      paramCanvas.drawPath(this.b, this.c);
    } 
    super.onDraw(paramCanvas);
  }
  
  public void setChecked(boolean paramBoolean) {
    this.e = paramBoolean;
    refreshDrawableState();
    invalidate();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/b/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */