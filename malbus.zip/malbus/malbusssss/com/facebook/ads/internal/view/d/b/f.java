package com.facebook.ads.internal.view.d.b;

import android.content.Context;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.facebook.ads.internal.g.q;
import com.facebook.ads.internal.g.s;
import com.facebook.ads.internal.util.p;
import com.facebook.ads.internal.view.d.a.b;
import com.facebook.ads.internal.view.d.a.j;
import com.facebook.ads.internal.view.m;

public class f extends m {
  private final ImageView b;
  
  private final s<j> c = new s<j>(this) {
      public Class<j> a() {
        return j.class;
      }
      
      public void a(j param1j) {
        this.a.setVisibility(8);
      }
    };
  
  private final s<b> d = new s<b>(this) {
      public Class<b> a() {
        return b.class;
      }
      
      public void a(b param1b) {
        this.a.setVisibility(0);
      }
    };
  
  public f(Context paramContext) {
    super(paramContext);
    this.b = new ImageView(paramContext);
    this.b.setScaleType(ImageView.ScaleType.CENTER_CROP);
    this.b.setBackgroundColor(-16777216);
    addView((View)this.b, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
  }
  
  protected void a(m paramm) {
    paramm.getEventBus().a(this.c);
    paramm.getEventBus().a(this.d);
    super.a(paramm);
  }
  
  public void setImage(@Nullable String paramString) {
    if (paramString == null) {
      setVisibility(8);
      return;
    } 
    setVisibility(0);
    (new p(this.b)).a(new String[] { paramString });
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/b/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */