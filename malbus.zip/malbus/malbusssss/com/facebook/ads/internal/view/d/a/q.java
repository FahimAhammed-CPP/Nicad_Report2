package com.facebook.ads.internal.view.d.a;

import android.view.MotionEvent;
import android.view.View;
import com.facebook.ads.internal.g.q;

public class q extends q {
  private final View a;
  
  private final MotionEvent b;
  
  public q(View paramView, MotionEvent paramMotionEvent) {
    this.a = paramView;
    this.b = paramMotionEvent;
  }
  
  public View a() {
    return this.a;
  }
  
  public MotionEvent b() {
    return this.b;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/a/q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */