package com.facebook.ads.internal.view.a;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.net.Uri;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.facebook.ads.internal.util.r;
import com.facebook.ads.internal.util.t;
import java.util.List;

@TargetApi(19)
public class a extends LinearLayout {
  private static final int a = Color.rgb(224, 224, 224);
  
  private static final Uri b = Uri.parse("http://www.facebook.com");
  
  private static final View.OnTouchListener c = new View.OnTouchListener() {
      public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
        switch (param1MotionEvent.getAction()) {
          default:
            return false;
          case 0:
            param1View.setBackgroundColor(a.a());
          case 1:
            break;
        } 
        param1View.setBackgroundColor(0);
      }
    };
  
  private static final int d = Color.argb(34, 0, 0, 0);
  
  private ImageView e;
  
  private c f;
  
  private ImageView g;
  
  private a h;
  
  private String i;
  
  public a(Context paramContext) {
    super(paramContext);
    a(paramContext);
  }
  
  private void a(Context paramContext) {
    float f = (getResources().getDisplayMetrics()).density;
    int i = (int)(50.0F * f);
    int j = (int)(f * 4.0F);
    setBackgroundColor(-1);
    setGravity(16);
    this.e = new ImageView(paramContext);
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(i, i);
    this.e.setScaleType(ImageView.ScaleType.CENTER);
    this.e.setImageBitmap(t.a(paramContext, r.a));
    this.e.setOnTouchListener(c);
    this.e.setOnClickListener(new View.OnClickListener(this) {
          public void onClick(View param1View) {
            if (a.a(this.a) != null)
              a.a(this.a).a(); 
          }
        });
    addView((View)this.e, (ViewGroup.LayoutParams)layoutParams);
    this.f = new c(paramContext);
    layoutParams = new LinearLayout.LayoutParams(0, -2);
    layoutParams.weight = 1.0F;
    this.f.setPadding(0, j, 0, j);
    addView((View)this.f, (ViewGroup.LayoutParams)layoutParams);
    this.g = new ImageView(paramContext);
    layoutParams = new LinearLayout.LayoutParams(i, i);
    this.g.setScaleType(ImageView.ScaleType.CENTER);
    this.g.setOnTouchListener(c);
    this.g.setOnClickListener(new View.OnClickListener(this) {
          public void onClick(View param1View) {
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(a.b(this.a)));
            intent.addFlags(268435456);
            this.a.getContext().startActivity(intent);
          }
        });
    addView((View)this.g, (ViewGroup.LayoutParams)layoutParams);
    setupDefaultNativeBrowser(paramContext);
  }
  
  private void setupDefaultNativeBrowser(Context paramContext) {
    Bitmap bitmap;
    List list = paramContext.getPackageManager().queryIntentActivities(new Intent("android.intent.action.VIEW", b), 65536);
    if (list.size() == 0) {
      this.g.setVisibility(8);
      paramContext = null;
    } else if (list.size() == 1 && "com.android.chrome".equals(((ResolveInfo)list.get(0)).activityInfo.packageName)) {
      bitmap = t.a(paramContext, r.c);
    } else {
      bitmap = t.a((Context)bitmap, r.d);
    } 
    this.g.setImageBitmap(bitmap);
  }
  
  public void setListener(a parama) {
    this.h = parama;
  }
  
  public void setTitle(String paramString) {
    this.f.setTitle(paramString);
  }
  
  public void setUrl(String paramString) {
    this.i = paramString;
    this.f.setSubtitle(paramString);
    if (TextUtils.isEmpty(paramString)) {
      this.g.setEnabled(false);
      this.g.setColorFilter((ColorFilter)new PorterDuffColorFilter(a, PorterDuff.Mode.SRC_IN));
      return;
    } 
    this.g.setEnabled(true);
    this.g.setColorFilter(null);
  }
  
  public static interface a {
    void a();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */