package com.facebook.ads.internal.view.hscroll;

import android.content.Context;
import android.graphics.PointF;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.LinearSmoothScroller;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.view.View;

public class HScrollLinearLayoutManager extends LinearLayoutManager {
  private final c a;
  
  private final a b;
  
  private final Context c;
  
  private int[] d;
  
  private int e = 0;
  
  private float f = 50.0F;
  
  private a g;
  
  private int h;
  
  public HScrollLinearLayoutManager(Context paramContext, c paramc, a parama) {
    super(paramContext);
    this.c = paramContext;
    this.a = paramc;
    this.b = parama;
    this.h = -1;
    this.g = new a(this, this.c);
  }
  
  public void a(double paramDouble) {
    double d = paramDouble;
    if (paramDouble <= 0.0D)
      d = 1.0D; 
    this.f = (float)(50.0D / d);
    this.g = new a(this, this.c);
  }
  
  void a(int paramInt) {
    this.h = paramInt;
  }
  
  public void b(int paramInt) {
    this.e = paramInt;
  }
  
  public void onMeasure(RecyclerView.Recycler paramRecycler, RecyclerView.State paramState, int paramInt1, int paramInt2) {
    int[] arrayOfInt;
    int i = View.MeasureSpec.getMode(paramInt1);
    int j = View.MeasureSpec.getMode(paramInt2);
    if ((i == 1073741824 && getOrientation() == 1) || (j == 1073741824 && getOrientation() == 0)) {
      super.onMeasure(paramRecycler, paramState, paramInt1, paramInt2);
      return;
    } 
    int k = View.MeasureSpec.getSize(paramInt1);
    paramInt2 = View.MeasureSpec.getSize(paramInt2);
    if (this.b.b(this.h)) {
      arrayOfInt = this.b.a(this.h);
    } else {
      int[] arrayOfInt1 = new int[2];
      arrayOfInt1[0] = 0;
      arrayOfInt1[1] = 0;
      arrayOfInt = arrayOfInt1;
      if (paramState.getItemCount() >= 1) {
        for (paramInt1 = 0; paramInt1 < 1; paramInt1++) {
          this.d = this.a.a(paramRecycler, paramInt1, View.MeasureSpec.makeMeasureSpec(0, 0), View.MeasureSpec.makeMeasureSpec(0, 0));
          if (getOrientation() == 0) {
            arrayOfInt1[0] = arrayOfInt1[0] + this.d[0];
            if (paramInt1 == 0)
              arrayOfInt1[1] = this.d[1] + getPaddingTop() + getPaddingBottom(); 
          } else {
            arrayOfInt1[1] = arrayOfInt1[1] + this.d[1];
            if (paramInt1 == 0)
              arrayOfInt1[0] = this.d[0] + getPaddingLeft() + getPaddingRight(); 
          } 
        } 
        arrayOfInt = arrayOfInt1;
        if (this.h != -1) {
          this.b.a(this.h, arrayOfInt1);
          arrayOfInt = arrayOfInt1;
        } 
      } 
    } 
    if (i == 1073741824)
      arrayOfInt[0] = k; 
    if (j == 1073741824)
      arrayOfInt[1] = paramInt2; 
    setMeasuredDimension(arrayOfInt[0], arrayOfInt[1]);
  }
  
  public void scrollToPosition(int paramInt) {
    scrollToPositionWithOffset(paramInt, this.e);
  }
  
  public void smoothScrollToPosition(RecyclerView paramRecyclerView, RecyclerView.State paramState, int paramInt) {
    this.g.setTargetPosition(paramInt);
    startSmoothScroll((RecyclerView.SmoothScroller)this.g);
  }
  
  private class a extends LinearSmoothScroller {
    public a(HScrollLinearLayoutManager this$0, Context param1Context) {
      super(param1Context);
    }
    
    public int calculateDxToMakeVisible(View param1View, int param1Int) {
      RecyclerView.LayoutManager layoutManager = getLayoutManager();
      if (!layoutManager.canScrollHorizontally())
        return 0; 
      RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param1View.getLayoutParams();
      return calculateDtToFit(layoutManager.getDecoratedLeft(param1View) - layoutParams.leftMargin, layoutManager.getDecoratedRight(param1View) + layoutParams.rightMargin, layoutManager.getPaddingLeft(), layoutManager.getWidth() - layoutManager.getPaddingRight(), param1Int) + HScrollLinearLayoutManager.b(this.a);
    }
    
    protected float calculateSpeedPerPixel(DisplayMetrics param1DisplayMetrics) {
      return HScrollLinearLayoutManager.a(this.a) / param1DisplayMetrics.densityDpi;
    }
    
    public PointF computeScrollVectorForPosition(int param1Int) {
      return this.a.computeScrollVectorForPosition(param1Int);
    }
    
    protected int getHorizontalSnapPreference() {
      return -1;
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/hscroll/HScrollLinearLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */