package com.facebook.ads.internal.view;

import android.content.Context;
import android.widget.RelativeLayout;

public class o extends RelativeLayout {
  private int a = 0;
  
  private int b = 0;
  
  public o(Context paramContext) {
    super(paramContext);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (this.b > 0 && getMeasuredWidth() > this.b) {
      setMeasuredDimension(this.b, getMeasuredHeight());
      return;
    } 
    if (getMeasuredWidth() < this.a)
      setMeasuredDimension(this.a, getMeasuredHeight()); 
  }
  
  protected void setMaxWidth(int paramInt) {
    this.b = paramInt;
  }
  
  public void setMinWidth(int paramInt) {
    this.a = paramInt;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */