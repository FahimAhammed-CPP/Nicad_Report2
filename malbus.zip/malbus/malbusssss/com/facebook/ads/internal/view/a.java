package com.facebook.ads.internal.view;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.facebook.ads.AdChoicesView;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdView;
import com.facebook.ads.NativeAdViewAttributes;
import com.facebook.ads.internal.view.b.b;
import com.facebook.ads.internal.view.b.d;
import java.util.ArrayList;

public class a extends RelativeLayout {
  private final NativeAdViewAttributes a;
  
  private final NativeAd b;
  
  private final DisplayMetrics c;
  
  private ArrayList<View> d;
  
  public a(Context paramContext, NativeAd paramNativeAd, NativeAdView.Type paramType, NativeAdViewAttributes paramNativeAdViewAttributes) {
    super(paramContext);
    AdChoicesView adChoicesView;
    RelativeLayout.LayoutParams layoutParams1;
    setBackgroundColor(paramNativeAdViewAttributes.getBackgroundColor());
    this.a = paramNativeAdViewAttributes;
    this.b = paramNativeAd;
    this.c = paramContext.getResources().getDisplayMetrics();
    setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, Math.round(paramType.getHeight() * this.c.density)));
    o o = new o(paramContext);
    o.setMinWidth(Math.round(280.0F * this.c.density));
    o.setMaxWidth(Math.round(375.0F * this.c.density));
    RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-1, -1);
    layoutParams2.addRule(13, -1);
    o.setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
    addView((View)o);
    LinearLayout linearLayout = new LinearLayout(paramContext);
    this.d = new ArrayList<View>();
    linearLayout.setOrientation(1);
    linearLayout.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
    o.addView((View)linearLayout);
    switch (null.a[paramType.ordinal()]) {
      default:
        a((ViewGroup)linearLayout, paramType);
        paramNativeAd.registerViewForInteraction((View)this, this.d);
        adChoicesView = new AdChoicesView(getContext(), paramNativeAd, true);
        layoutParams1 = (RelativeLayout.LayoutParams)adChoicesView.getLayoutParams();
        layoutParams1.addRule(11);
        layoutParams1.setMargins(Math.round(this.c.density * 4.0F), Math.round(this.c.density * 4.0F), Math.round(this.c.density * 4.0F), Math.round(this.c.density * 4.0F));
        o.addView((View)adChoicesView);
        return;
      case 1:
        b((ViewGroup)adChoicesView);
        break;
      case 2:
        break;
    } 
    a((ViewGroup)adChoicesView);
  }
  
  private void a(ViewGroup paramViewGroup) {
    RelativeLayout relativeLayout = new RelativeLayout(getContext());
    relativeLayout.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, Math.round(this.c.density * 180.0F)));
    relativeLayout.setBackgroundColor(this.a.getBackgroundColor());
    MediaView mediaView = new MediaView(getContext());
    relativeLayout.addView((View)mediaView);
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, (int)(this.c.density * 180.0F));
    layoutParams.addRule(13, -1);
    mediaView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    mediaView.setAutoplay(this.a.getAutoplay());
    mediaView.setAutoplayOnMobile(this.a.getAutoplayOnMobile());
    mediaView.setNativeAd(this.b);
    paramViewGroup.addView((View)relativeLayout);
    this.d.add(mediaView);
  }
  
  private void a(ViewGroup paramViewGroup, NativeAdView.Type paramType) {
    b b = new b(getContext(), this.b, this.a, a(paramType), b(paramType));
    b.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, Math.round(b(paramType) * this.c.density)));
    paramViewGroup.addView((View)b);
    this.d.add(b.getIconView());
    this.d.add(b.getCallToActionView());
  }
  
  private boolean a(NativeAdView.Type paramType) {
    return (paramType == NativeAdView.Type.HEIGHT_300 || paramType == NativeAdView.Type.HEIGHT_120);
  }
  
  private int b(NativeAdView.Type paramType) {
    switch (null.a[paramType.ordinal()]) {
      default:
        return 0;
      case 3:
      case 4:
        return paramType.getHeight();
      case 2:
        return paramType.getHeight() - 180;
      case 1:
        break;
    } 
    return (paramType.getHeight() - 180) / 2;
  }
  
  private void b(ViewGroup paramViewGroup) {
    d d = new d(getContext(), this.b, this.a);
    d.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, Math.round(110.0F * this.c.density)));
    paramViewGroup.addView((View)d);
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    this.b.unregisterView();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */