package com.facebook.ads.internal.view.a;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.AttributeSet;
import android.widget.ProgressBar;

@TargetApi(19)
public class b extends ProgressBar {
  private static final int a = Color.argb(26, 0, 0, 0);
  
  private static final int b = Color.rgb(88, 144, 255);
  
  private Rect c;
  
  private Paint d;
  
  public b(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    a();
  }
  
  private void a() {
    setIndeterminate(false);
    setMax(100);
    setProgressDrawable(b());
    this.c = new Rect();
    this.d = new Paint();
    this.d.setStyle(Paint.Style.FILL);
    this.d.setColor(a);
  }
  
  private Drawable b() {
    return (Drawable)new LayerDrawable(new Drawable[] { (Drawable)new ColorDrawable(0), (Drawable)new ClipDrawable((Drawable)new ColorDrawable(b), 3, 1) });
  }
  
  protected void onDraw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: aload_0
    //   4: getfield c : Landroid/graphics/Rect;
    //   7: aload_0
    //   8: getfield d : Landroid/graphics/Paint;
    //   11: invokevirtual drawRect : (Landroid/graphics/Rect;Landroid/graphics/Paint;)V
    //   14: aload_0
    //   15: aload_1
    //   16: invokespecial onDraw : (Landroid/graphics/Canvas;)V
    //   19: aload_0
    //   20: monitorexit
    //   21: return
    //   22: astore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_1
    //   26: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	22	finally
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iload_1
    //   4: iload_2
    //   5: invokespecial onMeasure : (II)V
    //   8: aload_0
    //   9: getfield c : Landroid/graphics/Rect;
    //   12: iconst_0
    //   13: iconst_0
    //   14: aload_0
    //   15: invokevirtual getMeasuredWidth : ()I
    //   18: iconst_2
    //   19: invokevirtual set : (IIII)V
    //   22: aload_0
    //   23: monitorexit
    //   24: return
    //   25: astore_3
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_3
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   2	22	25	finally
  }
  
  public void setProgress(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iload_1
    //   3: bipush #100
    //   5: if_icmpne -> 18
    //   8: iconst_0
    //   9: istore_1
    //   10: aload_0
    //   11: iload_1
    //   12: invokespecial setProgress : (I)V
    //   15: aload_0
    //   16: monitorexit
    //   17: return
    //   18: iload_1
    //   19: iconst_5
    //   20: invokestatic max : (II)I
    //   23: istore_1
    //   24: goto -> 10
    //   27: astore_2
    //   28: aload_0
    //   29: monitorexit
    //   30: aload_2
    //   31: athrow
    // Exception table:
    //   from	to	target	type
    //   10	15	27	finally
    //   18	24	27	finally
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */