package com.facebook.ads.internal.view.b;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdViewAttributes;
import com.facebook.ads.internal.view.j;
import com.facebook.ads.internal.view.n;

public class b extends LinearLayout {
  private ImageView a;
  
  private a b;
  
  private TextView c;
  
  private LinearLayout d;
  
  public b(Context paramContext, NativeAd paramNativeAd, NativeAdViewAttributes paramNativeAdViewAttributes, boolean paramBoolean, int paramInt) {
    super(paramContext);
    DisplayMetrics displayMetrics = paramContext.getResources().getDisplayMetrics();
    setVerticalGravity(16);
    setOrientation(1);
    LinearLayout linearLayout1 = new LinearLayout(getContext());
    linearLayout1.setOrientation(1);
    linearLayout1.setGravity(16);
    LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -1);
    layoutParams2.setMargins(Math.round(15.0F * displayMetrics.density), Math.round(15.0F * displayMetrics.density), Math.round(15.0F * displayMetrics.density), Math.round(15.0F * displayMetrics.density));
    linearLayout1.setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
    addView((View)linearLayout1);
    this.d = new LinearLayout(getContext());
    layoutParams2 = new LinearLayout.LayoutParams(-1, 0);
    this.d.setOrientation(0);
    this.d.setGravity(16);
    layoutParams2.weight = 3.0F;
    this.d.setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
    linearLayout1.addView((View)this.d);
    this.a = new c(getContext());
    paramInt = a(paramBoolean, paramInt);
    layoutParams2 = new LinearLayout.LayoutParams(Math.round(paramInt * displayMetrics.density), Math.round(paramInt * displayMetrics.density));
    layoutParams2.setMargins(0, 0, Math.round(15.0F * displayMetrics.density), 0);
    this.a.setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
    NativeAd.downloadAndDisplayImage(paramNativeAd.getAdIcon(), this.a);
    this.d.addView((View)this.a);
    LinearLayout linearLayout2 = new LinearLayout(getContext());
    linearLayout2.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -1));
    linearLayout2.setOrientation(0);
    linearLayout2.setGravity(16);
    this.d.addView((View)linearLayout2);
    this.b = new a(getContext(), paramNativeAd, paramNativeAdViewAttributes);
    LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-2, -1);
    layoutParams3.setMargins(0, 0, Math.round(15.0F * displayMetrics.density), 0);
    layoutParams3.weight = 0.5F;
    this.b.setLayoutParams((ViewGroup.LayoutParams)layoutParams3);
    linearLayout2.addView((View)this.b);
    this.c = new TextView(getContext());
    this.c.setPadding(Math.round(6.0F * displayMetrics.density), Math.round(6.0F * displayMetrics.density), Math.round(6.0F * displayMetrics.density), Math.round(6.0F * displayMetrics.density));
    this.c.setText(paramNativeAd.getAdCallToAction());
    this.c.setTextColor(paramNativeAdViewAttributes.getButtonTextColor());
    this.c.setTextSize(14.0F);
    this.c.setTypeface(paramNativeAdViewAttributes.getTypeface(), 1);
    this.c.setMaxLines(2);
    this.c.setEllipsize(TextUtils.TruncateAt.END);
    this.c.setGravity(17);
    GradientDrawable gradientDrawable = new GradientDrawable();
    gradientDrawable.setColor(paramNativeAdViewAttributes.getButtonColor());
    gradientDrawable.setCornerRadius(displayMetrics.density * 5.0F);
    gradientDrawable.setStroke(1, paramNativeAdViewAttributes.getButtonBorderColor());
    this.c.setBackgroundDrawable((Drawable)gradientDrawable);
    LinearLayout.LayoutParams layoutParams1 = new LinearLayout.LayoutParams(-2, -2);
    layoutParams1.weight = 0.25F;
    this.c.setLayoutParams((ViewGroup.LayoutParams)layoutParams1);
    linearLayout2.addView((View)this.c);
    if (paramBoolean) {
      n n = new n(getContext());
      n.setText(paramNativeAd.getAdBody());
      j.b((TextView)n, paramNativeAdViewAttributes);
      n.setMinTextSize((paramNativeAdViewAttributes.getDescriptionTextSize() - 1));
      LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 0);
      layoutParams.weight = 1.0F;
      n.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
      n.setGravity(80);
      linearLayout1.addView((View)n);
    } 
  }
  
  private int a(boolean paramBoolean, int paramInt) {
    if (paramBoolean) {
      byte b2 = 1;
      double d1 = 3.0D / (b2 + 3);
      return (int)((paramInt - 30) * d1);
    } 
    byte b1 = 0;
    double d = 3.0D / (b1 + 3);
    return (int)((paramInt - 30) * d);
  }
  
  public TextView getCallToActionView() {
    return this.c;
  }
  
  public ImageView getIconView() {
    return this.a;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    TextView textView = this.b.getTitleTextView();
    if (textView.getLayout().getLineEnd(textView.getLineCount() - 1) < this.b.getMinVisibleTitleCharacters()) {
      this.d.removeView((View)this.a);
      super.onMeasure(paramInt1, paramInt2);
    } 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/b/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */