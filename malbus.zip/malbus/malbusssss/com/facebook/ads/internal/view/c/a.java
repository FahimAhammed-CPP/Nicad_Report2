package com.facebook.ads.internal.view.c;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import com.facebook.ads.internal.a.b;
import com.facebook.ads.internal.g.q;
import com.facebook.ads.internal.g.r;
import com.facebook.ads.internal.view.d.b.m;
import com.facebook.ads.internal.view.m;
import java.util.HashMap;

public class a extends m {
  private final String b;
  
  private final Paint c;
  
  private final RectF d;
  
  private final Paint e;
  
  public a(Context paramContext, String paramString1, String paramString2) {
    super(paramContext);
    this.b = paramString1;
    TextView textView = new TextView(paramContext);
    textView.setTextColor(-3355444);
    textView.setTextSize(16.0F);
    DisplayMetrics displayMetrics = paramContext.getResources().getDisplayMetrics();
    setPadding((int)(displayMetrics.density * 10.0F), (int)(displayMetrics.density * 9.0F), (int)(displayMetrics.density * 10.0F), (int)(displayMetrics.density * 9.0F));
    textView.setText(paramString2);
    addView((View)textView);
    this.c = new Paint();
    this.c.setStyle(Paint.Style.FILL);
    this.c.setColor(-16777216);
    this.c.setAlpha(178);
    this.d = new RectF();
    this.e = new Paint();
    this.e.setStyle(Paint.Style.STROKE);
    this.e.setColor(-6710887);
    this.e.setStrokeWidth(displayMetrics.density * 1.0F);
    this.e.setAntiAlias(true);
    setBackgroundColor(0);
  }
  
  protected void a(m paramm) {
    setOnClickListener(new View.OnClickListener(this, paramm) {
          public void onClick(View param1View) {
            try {
              Uri uri = Uri.parse(a.a(this.b));
              r r = this.a.getEventBus();
              com.facebook.ads.internal.view.d.a.a a2 = new com.facebook.ads.internal.view.d.a.a();
              this(uri);
              r.a((q)a2);
              Context context = this.b.getContext();
              HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
              this();
              com.facebook.ads.internal.a.a a1 = b.a(context, "", uri, hashMap);
              if (a1 != null)
                a1.b(); 
            } catch (ActivityNotFoundException activityNotFoundException) {
              Log.e(String.valueOf(a.class), "Error while opening " + a.a(this.b), (Throwable)activityNotFoundException);
            } catch (Exception exception) {
              Log.e(String.valueOf(a.class), "Error executing action", exception);
            } 
          }
        });
  }
  
  protected void onDraw(Canvas paramCanvas) {
    float f = (getContext().getResources().getDisplayMetrics()).density;
    this.d.set(0.0F, 0.0F, getWidth(), getHeight());
    paramCanvas.drawRoundRect(this.d, 0.0F, 0.0F, this.c);
    this.d.set(2.0F, 2.0F, (getWidth() - 2), (getHeight() - 2));
    paramCanvas.drawRoundRect(this.d, 6.0F * f, f * 6.0F, this.e);
    super.onDraw(paramCanvas);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/c/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */