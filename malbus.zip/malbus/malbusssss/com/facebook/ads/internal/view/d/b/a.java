package com.facebook.ads.internal.view.d.b;

import android.content.Context;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.facebook.ads.internal.util.h;
import com.facebook.ads.internal.util.r;
import com.facebook.ads.internal.util.t;

public class a extends m {
  private final a b;
  
  public a(Context paramContext, String paramString1, String paramString2, float[] paramArrayOffloat) {
    super(paramContext);
    DisplayMetrics displayMetrics = paramContext.getResources().getDisplayMetrics();
    this.b = new a(paramContext, "AdChoices", paramString1, paramString2);
    GradientDrawable gradientDrawable = new GradientDrawable();
    gradientDrawable.setColor(-16777216);
    gradientDrawable.setAlpha(178);
    gradientDrawable.setCornerRadii(new float[] { paramArrayOffloat[0] * displayMetrics.density, paramArrayOffloat[0] * displayMetrics.density, paramArrayOffloat[1] * displayMetrics.density, paramArrayOffloat[1] * displayMetrics.density, paramArrayOffloat[2] * displayMetrics.density, paramArrayOffloat[2] * displayMetrics.density, paramArrayOffloat[3] * displayMetrics.density, paramArrayOffloat[3] * displayMetrics.density });
    if (Build.VERSION.SDK_INT >= 16) {
      this.b.setBackground((Drawable)gradientDrawable);
    } else {
      this.b.setBackgroundDrawable((Drawable)gradientDrawable);
    } 
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
    layoutParams.width = Math.round(20.0F * displayMetrics.density);
    layoutParams.height = Math.round(displayMetrics.density * 18.0F);
    addView((View)this.b, (ViewGroup.LayoutParams)layoutParams);
  }
  
  private static class a extends RelativeLayout {
    private final String a;
    
    private final String b;
    
    private final String c;
    
    private final DisplayMetrics d;
    
    private ImageView e;
    
    private TextView f;
    
    private boolean g = false;
    
    public a(Context param1Context, String param1String1, String param1String2, String param1String3) {
      super(param1Context);
      this.a = param1String1;
      this.b = param1String2;
      this.c = param1String3;
      this.d = param1Context.getResources().getDisplayMetrics();
      a();
      b();
      c();
    }
    
    private void a() {
      setOnTouchListener(new View.OnTouchListener(this) {
            public boolean onTouch(View param2View, MotionEvent param2MotionEvent) {
              if (param2MotionEvent.getAction() == 0) {
                if (a.a.a(this.a)) {
                  if (!TextUtils.isEmpty(a.a.b(this.a)))
                    h.a(this.a.getContext(), Uri.parse(a.a.b(this.a)), a.a.c(this.a)); 
                } else {
                  a.a.d(this.a);
                } 
                return true;
              } 
              return false;
            }
          });
    }
    
    private void b() {
      Context context = getContext();
      this.e = new ImageView(context);
      this.e.setImageBitmap(t.a(context, r.e));
      addView((View)this.e);
      RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(Math.round(this.d.density * 16.0F), Math.round(this.d.density * 16.0F));
      layoutParams.addRule(9);
      layoutParams.addRule(15, -1);
      layoutParams.setMargins(Math.round(4.0F * this.d.density), Math.round(this.d.density * 2.0F), Math.round(this.d.density * 2.0F), Math.round(this.d.density * 2.0F));
      this.e.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    }
    
    private void c() {
      this.f = new TextView(getContext());
      addView((View)this.f);
      RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
      layoutParams.width = 0;
      layoutParams.addRule(11, this.e.getId());
      layoutParams.addRule(15, -1);
      this.f.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
      this.f.setSingleLine();
      this.f.setText(this.a);
      this.f.setTextSize(10.0F);
      this.f.setTextColor(-4341303);
    }
    
    private void d() {
      Paint paint = new Paint();
      paint.setTextSize(this.f.getTextSize());
      int i = Math.round(paint.measureText(this.a) + 4.0F * this.d.density);
      int j = getWidth();
      i += j;
      this.g = true;
      Animation animation = new Animation(this, j, i) {
          protected void applyTransformation(float param2Float, Transformation param2Transformation) {
            int i = (int)(this.a + (this.b - this.a) * param2Float);
            (this.c.getLayoutParams()).width = i;
            this.c.requestLayout();
            (a.a.e(this.c).getLayoutParams()).width = i - this.a;
            a.a.e(this.c).requestLayout();
          }
          
          public boolean willChangeBounds() {
            return true;
          }
        };
      animation.setAnimationListener(new Animation.AnimationListener(this, i, j) {
            public void onAnimationEnd(Animation param2Animation) {
              (new Handler()).postDelayed(new Runnable(this) {
                    public void run() {
                      if (a.a.a(this.a.c)) {
                        a.a.a(this.a.c, false);
                        Animation animation = new Animation(this) {
                            protected void applyTransformation(float param4Float, Transformation param4Transformation) {
                              int i = (int)(this.a.a.a + (this.a.a.b - this.a.a.a) * param4Float);
                              (this.a.a.c.getLayoutParams()).width = i;
                              this.a.a.c.requestLayout();
                              (a.a.e(this.a.a.c).getLayoutParams()).width = i - this.a.a.b;
                              a.a.e(this.a.a.c).requestLayout();
                            }
                            
                            public boolean willChangeBounds() {
                              return true;
                            }
                          };
                        animation.setDuration(300L);
                        animation.setFillAfter(true);
                        this.a.c.startAnimation(animation);
                      } 
                    }
                  }3000L);
            }
            
            public void onAnimationRepeat(Animation param2Animation) {}
            
            public void onAnimationStart(Animation param2Animation) {}
          });
      animation.setDuration(300L);
      animation.setFillAfter(true);
      startAnimation(animation);
    }
  }
  
  class null implements View.OnTouchListener {
    null(a this$0) {}
    
    public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
      if (param1MotionEvent.getAction() == 0) {
        if (a.a.a(this.a)) {
          if (!TextUtils.isEmpty(a.a.b(this.a)))
            h.a(this.a.getContext(), Uri.parse(a.a.b(this.a)), a.a.c(this.a)); 
        } else {
          a.a.d(this.a);
        } 
        return true;
      } 
      return false;
    }
  }
  
  class null extends Animation {
    null(a this$0, int param1Int1, int param1Int2) {}
    
    protected void applyTransformation(float param1Float, Transformation param1Transformation) {
      int i = (int)(this.a + (this.b - this.a) * param1Float);
      (this.c.getLayoutParams()).width = i;
      this.c.requestLayout();
      (a.a.e(this.c).getLayoutParams()).width = i - this.a;
      a.a.e(this.c).requestLayout();
    }
    
    public boolean willChangeBounds() {
      return true;
    }
  }
  
  class null implements Animation.AnimationListener {
    null(a this$0, int param1Int1, int param1Int2) {}
    
    public void onAnimationEnd(Animation param1Animation) {
      (new Handler()).postDelayed(new Runnable(this) {
            public void run() {
              if (a.a.a(this.a.c)) {
                a.a.a(this.a.c, false);
                Animation animation = new Animation(this) {
                    protected void applyTransformation(float param4Float, Transformation param4Transformation) {
                      int i = (int)(this.a.a.a + (this.a.a.b - this.a.a.a) * param4Float);
                      (this.a.a.c.getLayoutParams()).width = i;
                      this.a.a.c.requestLayout();
                      (a.a.e(this.a.a.c).getLayoutParams()).width = i - this.a.a.b;
                      a.a.e(this.a.a.c).requestLayout();
                    }
                    
                    public boolean willChangeBounds() {
                      return true;
                    }
                  };
                animation.setDuration(300L);
                animation.setFillAfter(true);
                this.a.c.startAnimation(animation);
              } 
            }
          }3000L);
    }
    
    public void onAnimationRepeat(Animation param1Animation) {}
    
    public void onAnimationStart(Animation param1Animation) {}
  }
  
  class null implements Runnable {
    public void run() {
      if (a.a.a(this.a.c)) {
        a.a.a(this.a.c, false);
        Animation animation = new Animation(this) {
            protected void applyTransformation(float param4Float, Transformation param4Transformation) {
              int i = (int)(this.a.a.a + (this.a.a.b - this.a.a.a) * param4Float);
              (this.a.a.c.getLayoutParams()).width = i;
              this.a.a.c.requestLayout();
              (a.a.e(this.a.a.c).getLayoutParams()).width = i - this.a.a.b;
              a.a.e(this.a.a.c).requestLayout();
            }
            
            public boolean willChangeBounds() {
              return true;
            }
          };
        animation.setDuration(300L);
        animation.setFillAfter(true);
        this.a.c.startAnimation(animation);
      } 
    }
  }
  
  class null extends Animation {
    protected void applyTransformation(float param1Float, Transformation param1Transformation) {
      int i = (int)(this.a.a.a + (this.a.a.b - this.a.a.a) * param1Float);
      (this.a.a.c.getLayoutParams()).width = i;
      this.a.a.c.requestLayout();
      (a.a.e(this.a.a.c).getLayoutParams()).width = i - this.a.a.b;
      a.a.e(this.a.a.c).requestLayout();
    }
    
    public boolean willChangeBounds() {
      return true;
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/b/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */