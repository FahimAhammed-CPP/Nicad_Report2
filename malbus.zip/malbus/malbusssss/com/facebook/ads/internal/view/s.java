package com.facebook.ads.internal.view;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

public class s extends View {
  private r a;
  
  public s(Context paramContext, r paramr) {
    super(paramContext);
    this.a = paramr;
    setLayoutParams(new ViewGroup.LayoutParams(0, 0));
  }
  
  public void onWindowVisibilityChanged(int paramInt) {
    if (this.a != null)
      this.a.a(paramInt); 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */