package com.facebook.ads.internal.view;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdViewAttributes;

public abstract class j {
  public static LinearLayout a(Context paramContext, NativeAd paramNativeAd, NativeAdViewAttributes paramNativeAdViewAttributes) {
    LinearLayout linearLayout = new LinearLayout(paramContext);
    n n = new n(paramContext);
    n.setText(paramNativeAd.getAdSocialContext());
    b(n, paramNativeAdViewAttributes);
    linearLayout.addView((View)n);
    return linearLayout;
  }
  
  public static void a(TextView paramTextView, NativeAdViewAttributes paramNativeAdViewAttributes) {
    paramTextView.setTextColor(paramNativeAdViewAttributes.getTitleTextColor());
    paramTextView.setTextSize(paramNativeAdViewAttributes.getTitleTextSize());
    paramTextView.setTypeface(paramNativeAdViewAttributes.getTypeface(), 1);
  }
  
  public static void b(TextView paramTextView, NativeAdViewAttributes paramNativeAdViewAttributes) {
    paramTextView.setTextColor(paramNativeAdViewAttributes.getDescriptionTextColor());
    paramTextView.setTextSize(paramNativeAdViewAttributes.getDescriptionTextSize());
    paramTextView.setTypeface(paramNativeAdViewAttributes.getTypeface());
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */