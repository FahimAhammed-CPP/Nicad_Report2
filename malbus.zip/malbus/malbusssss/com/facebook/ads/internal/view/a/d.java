package com.facebook.ads.internal.view.a;

import android.annotation.TargetApi;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.webkit.ConsoleMessage;
import android.webkit.WebBackForwardList;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.facebook.ads.internal.util.i;
import com.facebook.ads.internal.util.m;
import com.facebook.ads.internal.view.b;
import java.util.HashSet;
import java.util.Set;

@TargetApi(19)
public class d extends b {
  private static final String a = d.class.getSimpleName();
  
  private static final Set<String> b = new HashSet<String>(2);
  
  private a c;
  
  private m d;
  
  private long e = -1L;
  
  private long f = -1L;
  
  private long g = -1L;
  
  private long h = -1L;
  
  static {
    b.add("http");
    b.add("https");
  }
  
  public d(Context paramContext) {
    super(paramContext);
    f();
  }
  
  public static boolean a(String paramString) {
    return b.contains(paramString);
  }
  
  private void f() {
    getSettings().setSupportZoom(true);
    getSettings().setBuiltInZoomControls(true);
    getSettings().setDisplayZoomControls(false);
    getSettings().setLoadWithOverviewMode(true);
    getSettings().setUseWideViewPort(true);
    this.d = new m(this);
  }
  
  private void g() {
    if (this.f > -1L && this.g > -1L && this.h > -1L)
      this.d.a(false); 
  }
  
  protected WebChromeClient a() {
    return new WebChromeClient(this) {
        public boolean onConsoleMessage(ConsoleMessage param1ConsoleMessage) {
          String str = param1ConsoleMessage.message();
          if (!TextUtils.isEmpty(str) && param1ConsoleMessage.messageLevel() == ConsoleMessage.MessageLevel.LOG)
            d.b(this.a).a(str); 
          return true;
        }
        
        public void onProgressChanged(WebView param1WebView, int param1Int) {
          super.onProgressChanged(param1WebView, param1Int);
          d.b(this.a).a();
          if (d.a(this.a) != null)
            d.a(this.a).a(param1Int); 
        }
        
        public void onReceivedTitle(WebView param1WebView, String param1String) {
          super.onReceivedTitle(param1WebView, param1String);
          if (d.a(this.a) != null)
            d.a(this.a).b(param1String); 
        }
      };
  }
  
  public void a(long paramLong) {
    if (this.e < 0L)
      this.e = paramLong; 
  }
  
  protected WebViewClient b() {
    return new WebViewClient(this) {
        public void onPageFinished(WebView param1WebView, String param1String) {
          super.onPageFinished(param1WebView, param1String);
          if (d.a(this.a) != null)
            d.a(this.a).c(param1String); 
        }
        
        public void onPageStarted(WebView param1WebView, String param1String, Bitmap param1Bitmap) {
          super.onPageStarted(param1WebView, param1String, param1Bitmap);
          if (d.a(this.a) != null)
            d.a(this.a).a(param1String); 
        }
        
        public boolean shouldOverrideUrlLoading(WebView param1WebView, String param1String) {
          Uri uri = Uri.parse(param1String);
          if (!d.d().contains(uri.getScheme()))
            try {
              Intent intent = new Intent();
              this("android.intent.action.VIEW", uri);
              this.a.getContext().startActivity(intent);
              return true;
            } catch (ActivityNotFoundException activityNotFoundException) {
              Log.w(d.e(), "Activity not found to handle URI.", (Throwable)activityNotFoundException);
            } catch (Exception exception) {
              Log.e(d.e(), "Unknown exception occurred when trying to handle URI.", exception);
            }  
          return false;
        }
      };
  }
  
  public void b(long paramLong) {
    if (this.f < 0L)
      this.f = paramLong; 
    g();
  }
  
  public void b(String paramString) {
    try {
      evaluateJavascript(paramString, null);
    } catch (IllegalStateException illegalStateException) {
      loadUrl("javascript:" + paramString);
    } 
  }
  
  public void c(long paramLong) {
    if (this.h < 0L)
      this.h = paramLong; 
    g();
  }
  
  public void destroy() {
    i.a((WebView)this);
    super.destroy();
  }
  
  public long getDomContentLoadedMs() {
    return this.f;
  }
  
  public String getFirstUrl() {
    WebBackForwardList webBackForwardList = copyBackForwardList();
    return (webBackForwardList.getSize() > 0) ? webBackForwardList.getItemAtIndex(0).getUrl() : getUrl();
  }
  
  public long getLoadFinishMs() {
    return this.h;
  }
  
  public long getResponseEndMs() {
    return this.e;
  }
  
  public long getScrollReadyMs() {
    return this.g;
  }
  
  protected void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.g < 0L && computeVerticalScrollRange() > getHeight()) {
      this.g = System.currentTimeMillis();
      g();
    } 
  }
  
  public void setListener(a parama) {
    this.c = parama;
  }
  
  public static interface a {
    void a(int param1Int);
    
    void a(String param1String);
    
    void b(String param1String);
    
    void c(String param1String);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/a/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */