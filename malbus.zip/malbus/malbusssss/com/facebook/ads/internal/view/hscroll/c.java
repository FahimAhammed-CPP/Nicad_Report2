package com.facebook.ads.internal.view.hscroll;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;

public class c {
  public int[] a(RecyclerView.Recycler paramRecycler, int paramInt1, int paramInt2, int paramInt3) {
    View view = paramRecycler.getViewForPosition(paramInt1);
    int[] arrayOfInt = a(view, paramInt2, paramInt3);
    paramRecycler.recycleView(view);
    return arrayOfInt;
  }
  
  public int[] a(View paramView, int paramInt1, int paramInt2) {
    RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)paramView.getLayoutParams();
    paramView.measure(ViewGroup.getChildMeasureSpec(paramInt1, paramView.getPaddingLeft() + paramView.getPaddingRight(), layoutParams.width), ViewGroup.getChildMeasureSpec(paramInt2, paramView.getPaddingTop() + paramView.getPaddingBottom(), layoutParams.height));
    int i = paramView.getMeasuredWidth();
    paramInt1 = layoutParams.leftMargin;
    paramInt2 = layoutParams.rightMargin;
    int j = paramView.getMeasuredHeight();
    int k = layoutParams.bottomMargin;
    return new int[] { i + paramInt1 + paramInt2, layoutParams.topMargin + j + k };
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/hscroll/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */