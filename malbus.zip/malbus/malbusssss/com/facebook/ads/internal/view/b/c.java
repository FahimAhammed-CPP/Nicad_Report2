package com.facebook.ads.internal.view.b;

import android.content.Context;
import android.widget.ImageView;

public class c extends ImageView {
  public c(Context paramContext) {
    this(paramContext, 30.0F);
  }
  
  public c(Context paramContext, float paramFloat) {
    super(paramContext);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/b/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */