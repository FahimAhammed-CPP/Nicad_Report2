package com.facebook.ads.internal.view;

import android.content.Context;
import android.net.http.SslError;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.facebook.ads.internal.util.ag;
import com.facebook.ads.internal.util.h;
import com.facebook.ads.internal.util.i;
import java.util.HashMap;
import java.util.Map;

public class c extends b {
  private static final String a = c.class.getSimpleName();
  
  private final b b;
  
  private ag c;
  
  private com.facebook.ads.internal.j.a d;
  
  public c(Context paramContext, b paramb, int paramInt) {
    super(paramContext);
    this.b = paramb;
    getSettings().setSupportZoom(false);
    addJavascriptInterface(new a(this), "AdControl");
    this.c = new ag();
    this.d = new com.facebook.ads.internal.j.a((View)this, paramInt, new com.facebook.ads.internal.j.a.a(this, paramb) {
          public void a() {
            c.a(this.b).a();
            this.a.b();
          }
        });
  }
  
  protected WebChromeClient a() {
    return new WebChromeClient(this) {
        public boolean onConsoleMessage(ConsoleMessage param1ConsoleMessage) {
          return true;
        }
      };
  }
  
  public void a(int paramInt1, int paramInt2) {
    this.d.a(paramInt1);
    this.d.b(paramInt2);
  }
  
  protected WebViewClient b() {
    return new WebViewClient(this) {
        public void onReceivedSslError(WebView param1WebView, SslErrorHandler param1SslErrorHandler, SslError param1SslError) {
          param1SslErrorHandler.cancel();
        }
        
        public boolean shouldOverrideUrlLoading(WebView param1WebView, String param1String) {
          HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
          c.b(this.a).a(hashMap);
          hashMap.put("touch", h.a(this.a.getTouchData()));
          c.c(this.a).a(param1String, (Map)hashMap);
          return true;
        }
      };
  }
  
  public void destroy() {
    if (this.d != null) {
      this.d.b();
      this.d = null;
    } 
    i.a(this);
    super.destroy();
  }
  
  public Map<String, String> getTouchData() {
    return this.c.e();
  }
  
  public com.facebook.ads.internal.j.a getViewabilityChecker() {
    return this.d;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    this.c.a(paramMotionEvent, (View)this, (View)this);
    return super.onTouchEvent(paramMotionEvent);
  }
  
  protected void onWindowVisibilityChanged(int paramInt) {
    super.onWindowVisibilityChanged(paramInt);
    if (this.b != null)
      this.b.a(paramInt); 
    if (this.d != null) {
      if (paramInt == 0) {
        this.d.a();
        return;
      } 
    } else {
      return;
    } 
    if (paramInt == 8)
      this.d.b(); 
  }
  
  public class a {
    private final String b = a.class.getSimpleName();
    
    public a(c this$0) {}
    
    @JavascriptInterface
    public void alert(String param1String) {
      Log.e(this.b, param1String);
    }
    
    @JavascriptInterface
    public String getAnalogInfo() {
      return h.a(com.facebook.ads.internal.util.a.a());
    }
    
    @JavascriptInterface
    public void onPageInitialized() {
      if (!this.a.c()) {
        c.c(this.a).a();
        if (c.b(this.a) != null)
          c.b(this.a).a(); 
      } 
    }
  }
  
  public static interface b {
    void a();
    
    void a(int param1Int);
    
    void a(String param1String, Map<String, String> param1Map);
    
    void b();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */