package com.facebook.ads.internal.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class e extends LinearLayout {
  private Bitmap a;
  
  private Bitmap b;
  
  private ImageView c;
  
  private ImageView d;
  
  private ImageView e;
  
  private Bitmap f;
  
  private Bitmap g;
  
  private int h;
  
  private int i;
  
  private int j;
  
  private int k;
  
  private int l;
  
  private int m;
  
  private double n;
  
  private double o;
  
  public e(Context paramContext) {
    super(paramContext);
    d();
  }
  
  private int a(double paramDouble) {
    return (int)Math.round(getWidth() / paramDouble);
  }
  
  private void a() {
    if (getHeight() > 0 && getWidth() > 0) {
      this.o = getMeasuredWidth() / getMeasuredHeight();
      this.n = this.a.getWidth() / this.a.getHeight();
      if (this.n > this.o) {
        b();
        return;
      } 
      c();
    } 
  }
  
  private int b(double paramDouble) {
    return (int)Math.round(getHeight() * paramDouble);
  }
  
  private void b() {
    this.j = a(this.n);
    this.k = getWidth();
    this.h = (int)Math.ceil(((getHeight() - this.j) / 2.0F));
    if (this.b != null) {
      Matrix matrix = new Matrix();
      matrix.preScale(1.0F, -1.0F);
      this.i = (int)Math.floor(((getHeight() - this.j) / 2.0F));
      float f = this.a.getHeight() / this.j;
      int i = Math.min(Math.round(this.h * f), this.b.getHeight());
      if (i > 0) {
        this.f = Bitmap.createBitmap(this.b, 0, 0, this.b.getWidth(), i, matrix, true);
        this.c.setImageBitmap(this.f);
      } 
      i = Math.min(Math.round(this.i * f), this.b.getHeight());
      if (i > 0) {
        this.g = Bitmap.createBitmap(this.b, 0, this.b.getHeight() - i, this.b.getWidth(), i, matrix, true);
        this.e.setImageBitmap(this.g);
      } 
    } 
  }
  
  private void c() {
    this.k = b(this.n);
    this.j = getHeight();
    this.l = (int)Math.ceil(((getWidth() - this.k) / 2.0F));
    if (this.b != null) {
      Matrix matrix = new Matrix();
      matrix.preScale(-1.0F, 1.0F);
      this.m = (int)Math.floor(((getWidth() - this.k) / 2.0F));
      float f = this.a.getWidth() / this.k;
      int i = Math.min(Math.round(this.l * f), this.b.getWidth());
      if (i > 0) {
        this.f = Bitmap.createBitmap(this.b, 0, 0, i, this.b.getHeight(), matrix, true);
        this.c.setImageBitmap(this.f);
      } 
      i = Math.min(Math.round(this.m * f), this.b.getWidth());
      if (i > 0) {
        this.g = Bitmap.createBitmap(this.b, this.b.getWidth() - i, 0, i, this.b.getHeight(), matrix, true);
        this.e.setImageBitmap(this.g);
      } 
    } 
  }
  
  private void d() {
    getContext().getResources().getDisplayMetrics();
    setOrientation(1);
    this.c = new ImageView(getContext());
    this.c.setScaleType(ImageView.ScaleType.FIT_XY);
    addView((View)this.c);
    this.d = new ImageView(getContext());
    this.d.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -1));
    this.d.setScaleType(ImageView.ScaleType.FIT_XY);
    addView((View)this.d);
    this.e = new ImageView(getContext());
    this.e.setScaleType(ImageView.ScaleType.FIT_XY);
    addView((View)this.e);
  }
  
  private boolean e() {
    return (this.h + this.j + this.i != getMeasuredHeight() || this.l + this.k + this.m != getMeasuredWidth());
  }
  
  public void a(Bitmap paramBitmap1, Bitmap paramBitmap2) {
    if (paramBitmap2 == null) {
      this.c.setImageDrawable(null);
      this.e.setImageDrawable(null);
    } 
    if (paramBitmap1 == null) {
      this.d.setImageDrawable(null);
      return;
    } 
    this.d.setImageBitmap(Bitmap.createBitmap(paramBitmap1));
    this.a = paramBitmap1;
    this.b = paramBitmap2;
    a();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.a == null) {
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    a(this.n);
    b(this.n);
    if (this.f == null || e())
      a(); 
    if (this.n > this.o) {
      this.c.layout(paramInt1, paramInt2, paramInt3, this.h);
      this.d.layout(paramInt1, this.h + paramInt2, paramInt3, this.h + this.j);
      this.e.layout(paramInt1, this.h + paramInt2 + this.j, paramInt3, paramInt4);
      return;
    } 
    this.c.layout(paramInt1, paramInt2, this.l, paramInt4);
    this.d.layout(this.l + paramInt1, paramInt2, this.l + this.k, paramInt4);
    this.e.layout(this.l + paramInt1 + this.k, paramInt2, paramInt3, paramInt4);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */