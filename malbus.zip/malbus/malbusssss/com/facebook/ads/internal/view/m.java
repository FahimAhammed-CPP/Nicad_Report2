package com.facebook.ads.internal.view;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.facebook.ads.internal.g.q;
import com.facebook.ads.internal.g.r;
import com.facebook.ads.internal.g.s;
import com.facebook.ads.internal.h;
import com.facebook.ads.internal.util.ai;
import com.facebook.ads.internal.util.aj;
import com.facebook.ads.internal.util.x;
import com.facebook.ads.internal.view.d.a.b;
import com.facebook.ads.internal.view.d.a.d;
import com.facebook.ads.internal.view.d.a.h;
import com.facebook.ads.internal.view.d.a.j;
import com.facebook.ads.internal.view.d.a.l;
import com.facebook.ads.internal.view.d.a.n;
import com.facebook.ads.internal.view.d.a.o;
import com.facebook.ads.internal.view.d.a.p;
import com.facebook.ads.internal.view.d.a.q;
import com.facebook.ads.internal.view.d.a.r;
import com.facebook.ads.internal.view.d.a.t;
import com.facebook.ads.internal.view.d.a.u;
import com.facebook.ads.internal.view.d.b.m;
import com.facebook.ads.internal.view.d.c.a;
import com.facebook.ads.internal.view.d.c.b;
import com.facebook.ads.internal.view.d.c.c;
import com.facebook.ads.internal.view.d.c.d;
import com.facebook.ads.internal.view.d.c.e;
import java.util.ArrayList;
import java.util.List;

public class m extends RelativeLayout implements ai.a, e {
  private static final l i = new l();
  
  private static final d j = new d();
  
  private static final b k = new b();
  
  private static final n l = new n();
  
  private static final p m = new p();
  
  private static final h n = new h();
  
  private static final j o = new j();
  
  private static final r p = new r();
  
  private static final u q = new u();
  
  private static final t r = new t();
  
  private final r<s, q> a;
  
  protected final c b;
  
  private final List<m> c = new ArrayList<m>();
  
  private boolean d = false;
  
  @Deprecated
  private boolean e = false;
  
  @Deprecated
  private boolean f = false;
  
  private aj g = aj.c;
  
  private boolean h = false;
  
  private final Handler s;
  
  private final View.OnTouchListener t = new View.OnTouchListener(this) {
      public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
        m.b(this.a).a((q)new q(param1View, param1MotionEvent));
        return true;
      }
    };
  
  public m(@Nullable Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public m(@Nullable Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public m(@Nullable Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    if (h.a(getContext())) {
      this.b = (c)new a(getContext());
    } else {
      this.b = (c)new b(getContext());
    } 
    this.b.setRequestedVolume(1.0F);
    this.b.setVideoStateChangeListener(this);
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
    layoutParams.addRule(13);
    addView((View)this.b, (ViewGroup.LayoutParams)layoutParams);
    this.s = new Handler();
    this.a = new r();
    setOnTouchListener(this.t);
  }
  
  public void a(int paramInt) {
    this.b.seekTo(paramInt);
  }
  
  public void a(int paramInt1, int paramInt2) {
    this.a.a((q)new o(paramInt1, paramInt2));
  }
  
  public void a(m paramm) {
    this.c.add(paramm);
  }
  
  public void a(d paramd) {
    if (paramd == d.c) {
      this.a.a((q)i);
      if (i() && !this.d)
        d(); 
      return;
    } 
    if (paramd == d.h) {
      this.d = true;
      this.a.a((q)j);
      return;
    } 
    if (paramd == d.g) {
      this.d = true;
      this.s.removeCallbacksAndMessages(null);
      this.a.a((q)k);
      return;
    } 
    if (paramd == d.d) {
      this.a.a((q)o);
      this.s.removeCallbacksAndMessages(null);
      this.s.postDelayed(new Runnable(this) {
            public void run() {
              if (!m.a(this.a)) {
                m.b(this.a).a((q)m.j());
                m.c(this.a).postDelayed(this, 250L);
              } 
            }
          }250L);
      return;
    } 
    if (paramd == d.e) {
      this.a.a((q)n);
      this.s.removeCallbacksAndMessages(null);
    } 
  }
  
  public boolean a() {
    return i();
  }
  
  public boolean b() {
    return h.a(getContext());
  }
  
  public boolean c() {
    return this.h;
  }
  
  public void d() {
    if (this.d && this.b.getState() == d.g)
      this.d = false; 
    this.b.start();
  }
  
  public void e() {
    this.b.pause();
  }
  
  public void f() {
    getEventBus().a((q)m);
    this.b.a();
  }
  
  public void g() {
    this.b.b();
  }
  
  public int getCurrentPosition() {
    return this.b.getCurrentPosition();
  }
  
  public int getDuration() {
    return this.b.getDuration();
  }
  
  @NonNull
  public r<s, q> getEventBus() {
    return this.a;
  }
  
  public long getInitialBufferTime() {
    return this.b.getInitialBufferTime();
  }
  
  public aj getIsAutoPlayFromServer() {
    return this.g;
  }
  
  public d getState() {
    return this.b.getState();
  }
  
  public TextureView getTextureView() {
    return (TextureView)this.b;
  }
  
  public View getVideoView() {
    return this.b.getView();
  }
  
  public float getVolume() {
    return this.b.getVolume();
  }
  
  public void h() {
    this.b.a(true);
  }
  
  protected boolean i() {
    boolean bool;
    if (this.e && (!this.f || x.c(getContext()) == x.a.c)) {
      bool = true;
    } else {
      bool = false;
    } 
    if (getIsAutoPlayFromServer() != aj.c) {
      if (getIsAutoPlayFromServer() == aj.a)
        return true; 
      bool = false;
    } 
    return bool;
  }
  
  protected void onAttachedToWindow() {
    this.a.a((q)r);
    super.onAttachedToWindow();
  }
  
  protected void onDetachedFromWindow() {
    this.a.a((q)q);
    super.onDetachedFromWindow();
  }
  
  @Deprecated
  public void setAutoplay(boolean paramBoolean) {
    this.e = paramBoolean;
  }
  
  public void setControlsAnchorView(View paramView) {
    if (this.b != null)
      this.b.setControlsAnchorView(paramView); 
  }
  
  public void setIsAutoPlayFromServer(aj paramaj) {
    this.g = paramaj;
  }
  
  @Deprecated
  public void setIsAutoplayOnMobile(boolean paramBoolean) {
    this.f = paramBoolean;
  }
  
  public void setIsFullScreen(boolean paramBoolean) {
    this.h = paramBoolean;
    this.b.setFullScreen(paramBoolean);
  }
  
  public void setVideoMPD(String paramString) {
    this.b.setVideoMPD(paramString);
  }
  
  public void setVideoURI(Uri paramUri) {
    for (m m1 : this.c) {
      if (m1.getParent() == null) {
        addView((View)m1);
        m1.b(this);
      } 
    } 
    this.d = false;
    this.b.setup(paramUri);
  }
  
  public void setVideoURI(String paramString) {
    setVideoURI(Uri.parse(paramString));
  }
  
  public void setVolume(float paramFloat) {
    this.b.setRequestedVolume(paramFloat);
    getEventBus().a((q)p);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */