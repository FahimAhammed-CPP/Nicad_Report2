package com.facebook.ads.internal.view.d.a;

import com.facebook.ads.internal.g.s;

public abstract class c extends s<b> {
  public Class<b> a() {
    return b.class;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */