package com.facebook.ads.internal.view.d.b;

import android.content.Context;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import com.facebook.ads.internal.g.q;
import com.facebook.ads.internal.g.s;
import com.facebook.ads.internal.view.d.a.l;
import com.facebook.ads.internal.view.m;

public class i extends m {
  private final ProgressBar b;
  
  private final s<l> c = new s<l>(this) {
      public Class<l> a() {
        return l.class;
      }
      
      public void a(l param1l) {
        this.a.setVisibility(8);
      }
    };
  
  public i(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public i(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public i(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    paramInt = (int)TypedValue.applyDimension(1, 40.0F, getResources().getDisplayMetrics());
    this.b = new ProgressBar(getContext());
    this.b.setIndeterminate(true);
    this.b.getIndeterminateDrawable().setColorFilter(-1, PorterDuff.Mode.SRC_IN);
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(paramInt, paramInt);
    layoutParams.addRule(13);
    addView((View)this.b, (ViewGroup.LayoutParams)layoutParams);
  }
  
  protected void a(m paramm) {
    setVisibility(0);
    paramm.getEventBus().a(this.c);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/b/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */