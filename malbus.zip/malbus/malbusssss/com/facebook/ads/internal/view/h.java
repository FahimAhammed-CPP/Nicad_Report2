package com.facebook.ads.internal.view;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.facebook.ads.AudienceNetworkActivity;
import com.facebook.ads.internal.a.a;
import com.facebook.ads.internal.a.b;
import com.facebook.ads.internal.adapters.b;
import com.facebook.ads.internal.adapters.o;
import com.facebook.ads.internal.adapters.p;
import com.facebook.ads.internal.g.g;
import com.facebook.ads.internal.util.c;
import com.facebook.ads.internal.util.d;
import com.facebook.ads.internal.util.i;
import java.util.HashMap;
import java.util.Map;

public class h implements d {
  private static final String a = h.class.getSimpleName();
  
  private final d.a b;
  
  private final c c;
  
  private final p d;
  
  private o e;
  
  private long f;
  
  private long g;
  
  private c.a h;
  
  public h(AudienceNetworkActivity paramAudienceNetworkActivity, d.a parama) {
    this.b = parama;
    this.f = System.currentTimeMillis();
    this.c = new c((Context)paramAudienceNetworkActivity, new c.b(this, paramAudienceNetworkActivity) {
          public void a() {
            h.c(this.b).b();
          }
          
          public void a(int param1Int) {}
          
          public void a(String param1String, Map<String, String> param1Map) {
            Uri uri = Uri.parse(param1String);
            if ("fbad".equals(uri.getScheme()) && "close".equals(uri.getAuthority())) {
              this.a.finish();
              return;
            } 
            if ("fbad".equals(uri.getScheme()) && b.a(uri.getAuthority()))
              h.a(this.b).a("com.facebook.ads.interstitial.clicked"); 
            a a = b.a((Context)this.a, h.b(this.b).B(), uri, param1Map);
            if (a != null)
              try {
                h.a(this.b, a.a());
                h.a(this.b, System.currentTimeMillis());
                a.b();
              } catch (Exception exception) {
                Log.e(h.a(), "Error executing action", exception);
              }  
          }
          
          public void b() {
            h.c(this.b).a();
          }
        }1);
    this.c.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
    b b = new b(this) {
        public void d() {
          h.a(this.a).a("com.facebook.ads.interstitial.impression.logged");
        }
      };
    this.d = new p((Context)paramAudienceNetworkActivity, this.c, this.c.getViewabilityChecker(), b);
    this.d.c();
    parama.a((View)this.c);
  }
  
  public void a(Intent paramIntent, Bundle paramBundle, AudienceNetworkActivity paramAudienceNetworkActivity) {
    if (paramBundle != null && paramBundle.containsKey("dataModel")) {
      this.e = o.a(paramBundle.getBundle("dataModel"));
      if (this.e != null) {
        this.c.loadDataWithBaseURL(i.a(), this.e.a(), "text/html", "utf-8", null);
        this.c.a(this.e.g(), this.e.h());
      } 
      return;
    } 
    this.e = o.b(paramIntent);
    if (this.e != null) {
      this.d.a(this.e);
      this.c.loadDataWithBaseURL(i.a(), this.e.a(), "text/html", "utf-8", null);
      this.c.a(this.e.g(), this.e.h());
    } 
  }
  
  public void a(Bundle paramBundle) {
    if (this.e != null)
      paramBundle.putBundle("dataModel", this.e.i()); 
  }
  
  public void a(d.a parama) {}
  
  public void e() {
    this.c.onPause();
  }
  
  public void f() {
    if (this.g > 0L && this.h != null && this.e != null)
      d.a(c.a(this.g, this.h, this.e.f())); 
    this.c.onResume();
  }
  
  public void g() {
    if (this.e != null) {
      d.a(c.a(this.f, c.a.c, this.e.f()));
      if (!TextUtils.isEmpty(this.e.B())) {
        HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
        this.c.getViewabilityChecker().a(hashMap);
        hashMap.put("touch", com.facebook.ads.internal.util.h.a(this.c.getTouchData()));
        g.a(this.c.getContext()).f(this.e.B(), hashMap);
      } 
    } 
    i.a(this.c);
    this.c.destroy();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */