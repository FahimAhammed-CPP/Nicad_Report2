package com.facebook.ads.internal.view.d.c;

import android.net.Uri;
import android.view.View;

public interface c {
  void a();
  
  void a(boolean paramBoolean);
  
  void b();
  
  int getCurrentPosition();
  
  int getDuration();
  
  long getInitialBufferTime();
  
  d getState();
  
  d getTargetState();
  
  View getView();
  
  float getVolume();
  
  void pause();
  
  void seekTo(int paramInt);
  
  void setControlsAnchorView(View paramView);
  
  void setFullScreen(boolean paramBoolean);
  
  void setRequestedVolume(float paramFloat);
  
  void setVideoMPD(String paramString);
  
  void setVideoStateChangeListener(e parame);
  
  void setup(Uri paramUri);
  
  void start();
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/c/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */