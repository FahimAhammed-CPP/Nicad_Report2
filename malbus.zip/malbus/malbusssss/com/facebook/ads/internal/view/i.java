package com.facebook.ads.internal.view;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import com.facebook.ads.AudienceNetworkActivity;
import com.facebook.ads.InterstitialAdActivity;
import com.facebook.ads.MediaView;
import com.facebook.ads.MediaViewListener;
import com.facebook.ads.internal.adapters.aa;
import com.facebook.ads.internal.g.f;
import com.facebook.ads.internal.g.q;
import com.facebook.ads.internal.g.s;
import com.facebook.ads.internal.j.a;
import com.facebook.ads.internal.util.ac;
import com.facebook.ads.internal.util.c;
import com.facebook.ads.internal.util.d;
import com.facebook.ads.internal.view.d.a.b;
import com.facebook.ads.internal.view.d.a.c;
import com.facebook.ads.internal.view.d.a.h;
import com.facebook.ads.internal.view.d.a.i;
import com.facebook.ads.internal.view.d.a.j;
import com.facebook.ads.internal.view.d.a.k;
import com.facebook.ads.internal.view.d.a.l;
import com.facebook.ads.internal.view.d.a.m;
import com.facebook.ads.internal.view.d.b.f;
import com.facebook.ads.internal.view.d.b.g;
import com.facebook.ads.internal.view.d.b.m;
import com.facebook.ads.internal.view.d.c.d;
import java.io.Serializable;
import java.util.UUID;

public class i extends m {
  private final k c = new k(this) {
      public void a(j param1j) {
        if (i.a(this.a) != null)
          i.a(this.a).onPlay(i.b(this.a)); 
      }
    };
  
  private final i d = new i(this) {
      public void a(h param1h) {
        if (i.a(this.a) != null)
          i.a(this.a).onPause(i.b(this.a)); 
      }
    };
  
  private final m e = new m(this) {
      public void a(l param1l) {
        if (this.a.i())
          this.a.d(); 
        this.a.setOnTouchListener(new View.OnTouchListener(this) {
              public boolean onTouch(View param2View, MotionEvent param2MotionEvent) {
                if (param2MotionEvent.getAction() == 1)
                  i.c(this.a.a); 
                return true;
              }
            });
      }
    };
  
  private final c f = new c(this) {
      public void a(b param1b) {
        if (i.a(this.a) != null)
          i.a(this.a).onComplete(i.b(this.a)); 
      }
    };
  
  private final String g = UUID.randomUUID().toString();
  
  private final MediaView h;
  
  private final f i;
  
  private final a j;
  
  private final aa k;
  
  private final f l;
  
  @Nullable
  private ac m;
  
  @Nullable
  private String n;
  
  @Nullable
  private Uri o;
  
  @Nullable
  private String p;
  
  @Nullable
  private String q;
  
  @Nullable
  private MediaViewListener r;
  
  private boolean s = false;
  
  static {
    boolean bool;
    if (!i.class.desiredAssertionStatus()) {
      bool = true;
    } else {
      bool = false;
    } 
    a = bool;
  }
  
  public i(Context paramContext, MediaView paramMediaView, f paramf) {
    super(paramContext);
    this.h = paramMediaView;
    this.i = paramf;
    getEventBus().a((s)this.c);
    getEventBus().a((s)this.d);
    getEventBus().a((s)this.f);
    setAutoplay(true);
    setVolume(0.0F);
    this.l = new f(paramContext);
    a((m)this.l);
    DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
    g g = new g(paramContext);
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
    layoutParams.addRule(9);
    layoutParams.addRule(12);
    g.setPadding((int)(displayMetrics.density * 2.0F), (int)(displayMetrics.density * 25.0F), (int)(displayMetrics.density * 25.0F), (int)(displayMetrics.density * 2.0F));
    g.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    a((m)g);
    getEventBus().a((s)this.e);
    this.k = new aa(this, getContext());
    this.j = new a((View)this, 50, true, new a.a(this) {
          public void a() {
            if ((this.a.i() || this.a.b.getTargetState() == d.d) && this.a.b.getTargetState() != d.e)
              this.a.d(); 
          }
          
          public void b() {
            this.a.e();
          }
        });
    this.j.a(0);
    this.j.b(250);
  }
  
  private void a(Context paramContext, Intent paramIntent) {
    String str;
    if (!a && this.n == null)
      throw new AssertionError(); 
    if (!a && this.o == null && this.q == null)
      throw new AssertionError(); 
    ((WindowManager)paramContext.getSystemService("window")).getDefaultDisplay().getMetrics(new DisplayMetrics());
    paramIntent.putExtra("useNativeCloseButton", true);
    paramIntent.putExtra("viewType", (Serializable)AudienceNetworkActivity.Type.VIDEO);
    paramIntent.putExtra("videoURL", this.o.toString());
    if (this.p == null) {
      str = "";
    } else {
      str = this.p;
    } 
    paramIntent.putExtra("clientToken", str);
    paramIntent.putExtra("videoMPD", this.q);
    paramIntent.putExtra("videoReportURL", this.n);
    paramIntent.putExtra("predefinedOrientationKey", 13);
    paramIntent.putExtra("autoplay", a());
    paramIntent.putExtra("videoSeekTime", getCurrentPosition());
    paramIntent.putExtra("uniqueId", this.g);
    paramIntent.putExtra("videoLogger", this.m.getSaveInstanceState());
    paramIntent.addFlags(268435456);
  }
  
  private void k() {
    Context context = getContext();
    Intent intent = new Intent(context, AudienceNetworkActivity.class);
    a(context, intent);
    try {
      e();
      setVisibility(8);
      context.startActivity(intent);
    } catch (ActivityNotFoundException activityNotFoundException) {
      try {
        intent.setClass(context, InterstitialAdActivity.class);
        context.startActivity(intent);
      } catch (Exception exception) {
        d.a(c.a(exception, "Error occurred while loading fullscreen video activity."));
      } 
    } catch (Exception exception) {
      d.a(c.a(exception, "Error occurred while loading fullscreen video activity."));
    } 
  }
  
  private void l() {
    if (getVisibility() == 0 && this.s) {
      this.j.a();
      return;
    } 
    this.j.b();
  }
  
  public void a(String paramString1, @Nullable String paramString2) {
    if (this.m != null)
      this.m.a(); 
    if (paramString2 == null)
      paramString2 = ""; 
    this.m = new ac(getContext(), this.i, this, paramString1, paramString2);
    this.p = paramString2;
    this.n = paramString1;
  }
  
  public void d() {
    if (a.a((View)this, 50).a())
      super.d(); 
  }
  
  @Nullable
  public MediaViewListener getListener() {
    return this.r;
  }
  
  public MediaView getMediaView() {
    return this.h;
  }
  
  public String getUniqueId() {
    return this.g;
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.s = true;
    this.k.a();
    l();
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    this.s = false;
    this.k.b();
    l();
  }
  
  protected void onVisibilityChanged(View paramView, int paramInt) {
    l();
    super.onVisibilityChanged(paramView, paramInt);
  }
  
  public void setImage(String paramString) {
    this.l.setImage(paramString);
  }
  
  public void setListener(MediaViewListener paramMediaViewListener) {
    this.r = paramMediaViewListener;
  }
  
  public void setVideoMPD(String paramString) {
    if (!a && this.m == null)
      throw new AssertionError(); 
    this.q = paramString;
    super.setVideoMPD(paramString);
  }
  
  public void setVideoURI(Uri paramUri) {
    if (!a && this.m == null)
      throw new AssertionError(); 
    this.o = paramUri;
    super.setVideoURI(paramUri);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */