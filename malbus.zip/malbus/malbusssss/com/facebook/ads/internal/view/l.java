package com.facebook.ads.internal.view;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

public class l extends TextView {
  private int a;
  
  private float b;
  
  private float c = 8.0F;
  
  public l(Context paramContext, int paramInt) {
    super(paramContext);
    setMaxLines(paramInt);
    setEllipsize(TextUtils.TruncateAt.END);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.setMaxLines(this.a + 1);
    super.setTextSize(this.b);
    int i = paramInt3 - paramInt1;
    int j = paramInt4 - paramInt2;
    measure(View.MeasureSpec.makeMeasureSpec(i, 1073741824), View.MeasureSpec.makeMeasureSpec(j, 0));
    if (getMeasuredHeight() > j) {
      float f = this.b;
      while (f > this.c) {
        float f1 = f - 0.5F;
        super.setTextSize(f1);
        measure(View.MeasureSpec.makeMeasureSpec(i, 1073741824), 0);
        f = f1;
        if (getMeasuredHeight() <= j) {
          f = f1;
          if (getLineCount() <= this.a)
            break; 
        } 
      } 
    } 
    super.setMaxLines(this.a);
    setMeasuredDimension(i, j);
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void setMaxLines(int paramInt) {
    this.a = paramInt;
    super.setMaxLines(paramInt);
  }
  
  public void setMinTextSize(float paramFloat) {
    this.c = paramFloat;
  }
  
  public void setTextSize(float paramFloat) {
    this.b = paramFloat;
    super.setTextSize(paramFloat);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */