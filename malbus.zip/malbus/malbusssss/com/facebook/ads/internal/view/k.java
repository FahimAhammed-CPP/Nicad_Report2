package com.facebook.ads.internal.view;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import com.facebook.ads.AudienceNetworkActivity;
import com.facebook.ads.internal.g.g;
import com.facebook.ads.internal.g.q;
import com.facebook.ads.internal.g.s;
import com.facebook.ads.internal.j;
import com.facebook.ads.internal.j.a;
import com.facebook.ads.internal.util.ag;
import com.facebook.ads.internal.util.h;
import com.facebook.ads.internal.util.v;
import com.facebook.ads.internal.util.y;
import com.facebook.ads.internal.view.d.a.b;
import com.facebook.ads.internal.view.d.a.d;
import com.facebook.ads.internal.view.d.a.l;
import com.facebook.ads.internal.view.d.a.n;
import com.facebook.ads.internal.view.d.a.q;
import com.facebook.ads.internal.view.d.b.c;
import com.facebook.ads.internal.view.d.b.i;
import com.facebook.ads.internal.view.d.b.m;
import com.facebook.ads.internal.view.d.c.d;
import java.util.HashMap;
import java.util.Map;

public class k implements d {
  private a a;
  
  private m b;
  
  private v c;
  
  private ag d;
  
  private d.a e;
  
  private String f;
  
  private s<b> g;
  
  private s<d> h;
  
  private s<l> i;
  
  private s<n> j;
  
  private s<q> k;
  
  private String l;
  
  private final Context m;
  
  private String n;
  
  private String o;
  
  public k(Context paramContext, d.a parama) {
    this.m = paramContext;
    this.e = parama;
    k();
  }
  
  private void k() {
    FrameLayout.LayoutParams layoutParams1 = new FrameLayout.LayoutParams(-1, -1);
    layoutParams1.gravity = 17;
    this.b = new m(this.m);
    this.b.h();
    this.b.setAutoplay(true);
    this.b.setIsFullScreen(true);
    this.b.setLayoutParams((ViewGroup.LayoutParams)layoutParams1);
    this.b.setBackgroundColor(-16777216);
    this.k = new s<q>(this) {
        public Class<q> a() {
          return q.class;
        }
        
        public void a(q param1q) {
          k.b(this.a).a(param1q.b(), (View)k.a(this.a), param1q.a());
        }
      };
    this.g = new s<b>(this) {
        public Class<b> a() {
          return b.class;
        }
        
        public void a(b param1b) {
          if (k.c(this.a) != null)
            k.c(this.a).a(j.a.a(), (q)param1b); 
          if (k.d(this.a) != null)
            k.d(this.a).b(k.a(this.a).getCurrentPosition()); 
          this.a.i();
        }
      };
    this.h = new s<d>(this) {
        public Class<d> a() {
          return d.class;
        }
        
        public void a(d param1d) {
          if (k.c(this.a) != null)
            k.c(this.a).a(j.d.a()); 
          this.a.i();
        }
      };
    this.i = new s<l>(this) {
        public Class<l> a() {
          return l.class;
        }
        
        public void a(l param1l) {
          if (k.e(this.a) != null)
            k.e(this.a).a(); 
        }
      };
    this.j = new s<n>(this) {
        public Class<n> a() {
          return n.class;
        }
        
        public void a(n param1n) {
          if (k.a(this.a).getState() != d.b && k.d(this.a) != null)
            k.d(this.a).a(k.a(this.a).getCurrentPosition()); 
        }
      };
    this.b.getEventBus().a(this.g);
    this.b.getEventBus().a(this.h);
    this.b.getEventBus().a(this.i);
    this.b.getEventBus().a(this.j);
    this.b.getEventBus().a(this.k);
    this.b.a((m)new i(this.m));
    c c = new c(this.m, "", true);
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
    layoutParams.addRule(12);
    layoutParams.addRule(11);
    c.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    c.setBackgroundColor(-16777216);
    this.b.a((m)c);
    this.a = new a((View)this.b, 1, new a.a(this) {
          public void a() {
            if (!k.b(this.a).b()) {
              k.b(this.a).a();
              HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
              if (TextUtils.isEmpty(k.f(this.a))) {
                (new y(hashMap)).execute((Object[])new String[] { this.a.a() });
              } else {
                k.e(this.a).a(hashMap);
                hashMap.put("touch", h.a(this.a.b()));
                g.a(k.g(this.a)).b(k.f(this.a), hashMap);
              } 
              if (k.c(this.a) != null)
                k.c(this.a).a(j.f.a()); 
            } 
          }
        });
    this.a.a(250);
    this.d = new ag();
    this.e.a((View)this.b);
  }
  
  public String a() {
    return this.f;
  }
  
  public void a(Intent paramIntent, Bundle paramBundle, AudienceNetworkActivity paramAudienceNetworkActivity) {
    // Byte code:
    //   0: aload_1
    //   1: ldc 'videoURL'
    //   3: invokevirtual getStringExtra : (Ljava/lang/String;)Ljava/lang/String;
    //   6: astore_2
    //   7: aload_0
    //   8: aload_1
    //   9: ldc 'impressionReportURL'
    //   11: invokevirtual getStringExtra : (Ljava/lang/String;)Ljava/lang/String;
    //   14: putfield f : Ljava/lang/String;
    //   17: aload_0
    //   18: aload_1
    //   19: ldc 'clientToken'
    //   21: invokevirtual getStringExtra : (Ljava/lang/String;)Ljava/lang/String;
    //   24: putfield l : Ljava/lang/String;
    //   27: aload_0
    //   28: aload_1
    //   29: ldc 'closeReportURL'
    //   31: invokevirtual getStringExtra : (Ljava/lang/String;)Ljava/lang/String;
    //   34: putfield o : Ljava/lang/String;
    //   37: aload_1
    //   38: ldc 'videoTimeReportURL'
    //   40: invokevirtual getStringExtra : (Ljava/lang/String;)Ljava/lang/String;
    //   43: astore_3
    //   44: aload_1
    //   45: ldc 'videoPlayReportURL'
    //   47: invokevirtual getStringExtra : (Ljava/lang/String;)Ljava/lang/String;
    //   50: astore #4
    //   52: aload_0
    //   53: aload_1
    //   54: ldc 'contextSwitchBehavior'
    //   56: invokevirtual getStringExtra : (Ljava/lang/String;)Ljava/lang/String;
    //   59: putfield n : Ljava/lang/String;
    //   62: aload_0
    //   63: new com/facebook/ads/internal/util/v
    //   66: dup
    //   67: aload_0
    //   68: getfield m : Landroid/content/Context;
    //   71: aload_0
    //   72: getfield b : Lcom/facebook/ads/internal/view/m;
    //   75: aload_3
    //   76: aload #4
    //   78: aload_0
    //   79: getfield l : Ljava/lang/String;
    //   82: invokespecial <init> : (Landroid/content/Context;Lcom/facebook/ads/internal/util/ai$a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   85: putfield c : Lcom/facebook/ads/internal/util/v;
    //   88: aload_0
    //   89: getfield m : Landroid/content/Context;
    //   92: invokestatic a : (Landroid/content/Context;)Lcom/facebook/ads/internal/c/d;
    //   95: aload_2
    //   96: invokevirtual b : (Ljava/lang/String;)Ljava/lang/String;
    //   99: astore_3
    //   100: aload_3
    //   101: ifnull -> 113
    //   104: aload_3
    //   105: astore_1
    //   106: aload_3
    //   107: invokevirtual isEmpty : ()Z
    //   110: ifeq -> 115
    //   113: aload_2
    //   114: astore_1
    //   115: aload_1
    //   116: ifnull -> 127
    //   119: aload_0
    //   120: getfield b : Lcom/facebook/ads/internal/view/m;
    //   123: aload_1
    //   124: invokevirtual setVideoURI : (Ljava/lang/String;)V
    //   127: aload_0
    //   128: getfield b : Lcom/facebook/ads/internal/view/m;
    //   131: invokevirtual d : ()V
    //   134: return
  }
  
  public void a(Bundle paramBundle) {}
  
  public void a(d.a parama) {}
  
  public Map<String, String> b() {
    return this.d.e();
  }
  
  public void c() {
    this.b.a(1);
    this.b.d();
  }
  
  public void d() {
    this.b.e();
  }
  
  public void e() {
    d();
  }
  
  public void f() {
    if (h()) {
      if (this.n.equals("restart")) {
        c();
        return;
      } 
    } else {
      return;
    } 
    if (this.n.equals("resume")) {
      j();
      return;
    } 
    if (this.n.equals("skip")) {
      this.e.a(j.b.a(), (q)new b());
      i();
      return;
    } 
    if (this.n.equals("endvideo")) {
      this.e.a(j.c.a());
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      if (TextUtils.isEmpty(this.l)) {
        if (this.o != null)
          (new y(hashMap)).execute((Object[])new String[] { this.o }); 
      } else {
        this.a.a(hashMap);
        hashMap.put("touch", h.a(b()));
        g.a(this.m).f(this.l, hashMap);
      } 
      i();
    } 
  }
  
  public void g() {
    i();
  }
  
  public boolean h() {
    return (this.b.getState() == d.e);
  }
  
  public void i() {
    this.b.g();
    if (this.a != null)
      this.a.b(); 
  }
  
  public void j() {
    this.b.a(this.b.getCurrentPosition());
    this.b.d();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */