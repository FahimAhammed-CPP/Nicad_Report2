package com.facebook.ads.internal.view.d.a;

import com.facebook.ads.internal.g.q;

public class j extends q {}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/d/a/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */