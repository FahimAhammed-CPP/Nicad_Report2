package com.facebook.ads.internal.view;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

public class n extends TextView {
  private float a;
  
  private float b = 8.0F;
  
  public n(Context paramContext) {
    super(paramContext);
    setSingleLine();
    super.setMaxLines(1);
    this.a = getTextSize() / (paramContext.getResources().getDisplayMetrics()).density;
    setEllipsize(TextUtils.TruncateAt.END);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = paramInt3 - paramInt1;
    int j = getMeasuredHeight();
    int k = getMeasuredWidth();
    float f = this.a;
    while (true) {
      if (f >= this.b) {
        super.setTextSize(f);
        measure(0, 0);
        if (getMeasuredWidth() > i) {
          f -= 0.5F;
          continue;
        } 
      } 
      if (getMeasuredWidth() > i)
        measure(View.MeasureSpec.makeMeasureSpec(k, 1073741824), View.MeasureSpec.makeMeasureSpec(j, 1073741824)); 
      setMeasuredDimension(k, j);
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
  }
  
  public void setMaxLines(int paramInt) {}
  
  public void setMinTextSize(float paramFloat) {
    if (paramFloat <= this.a)
      this.b = paramFloat; 
  }
  
  public void setSingleLine(boolean paramBoolean) {}
  
  public void setTextSize(float paramFloat) {
    this.a = paramFloat;
    super.setTextSize(paramFloat);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */