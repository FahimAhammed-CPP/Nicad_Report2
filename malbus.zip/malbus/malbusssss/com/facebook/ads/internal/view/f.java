package com.facebook.ads.internal.view;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.RelativeLayout;
import com.facebook.ads.AudienceNetworkActivity;
import com.facebook.ads.internal.g.g;
import com.facebook.ads.internal.util.i;
import com.facebook.ads.internal.util.l;
import com.facebook.ads.internal.view.a.a;
import com.facebook.ads.internal.view.a.b;
import com.facebook.ads.internal.view.a.d;

@TargetApi(19)
public class f implements d {
  private static final String a = f.class.getSimpleName();
  
  private final AudienceNetworkActivity b;
  
  private final a c;
  
  private final d d;
  
  private final b e;
  
  private final AudienceNetworkActivity.BackButtonInterceptor f = new AudienceNetworkActivity.BackButtonInterceptor(this) {
      public boolean interceptBackButton() {
        if (f.a(this.a).canGoBack()) {
          f.a(this.a).goBack();
          return true;
        } 
        return false;
      }
    };
  
  private String g;
  
  private String h;
  
  private long i;
  
  private boolean j = true;
  
  private long k = -1L;
  
  private boolean l = true;
  
  public f(AudienceNetworkActivity paramAudienceNetworkActivity, d.a parama) {
    this.b = paramAudienceNetworkActivity;
    int i = (int)(2.0F * (paramAudienceNetworkActivity.getResources().getDisplayMetrics()).density);
    this.c = new a((Context)paramAudienceNetworkActivity);
    this.c.setId(View.generateViewId());
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -2);
    layoutParams.addRule(10);
    this.c.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    this.c.setListener(new a.a(this, paramAudienceNetworkActivity) {
          public void a() {
            this.a.finish();
          }
        });
    parama.a((View)this.c);
    this.d = new d((Context)paramAudienceNetworkActivity);
    layoutParams = new RelativeLayout.LayoutParams(-1, -2);
    layoutParams.addRule(3, this.c.getId());
    layoutParams.addRule(12);
    this.d.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    this.d.setListener(new d.a(this) {
          public void a(int param1Int) {
            if (f.c(this.a))
              f.d(this.a).setProgress(param1Int); 
          }
          
          public void a(String param1String) {
            f.a(this.a, true);
            f.b(this.a).setUrl(param1String);
          }
          
          public void b(String param1String) {
            f.b(this.a).setTitle(param1String);
          }
          
          public void c(String param1String) {
            f.d(this.a).setProgress(100);
            f.a(this.a, false);
          }
        });
    parama.a((View)this.d);
    this.e = new b((Context)paramAudienceNetworkActivity, null, 16842872);
    layoutParams = new RelativeLayout.LayoutParams(-1, i);
    layoutParams.addRule(3, this.c.getId());
    this.e.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    this.e.setProgress(0);
    parama.a((View)this.e);
    paramAudienceNetworkActivity.addBackButtonInterceptor(this.f);
  }
  
  public void a(Intent paramIntent, Bundle paramBundle, AudienceNetworkActivity paramAudienceNetworkActivity) {
    String str;
    if (this.k < 0L)
      this.k = System.currentTimeMillis(); 
    if (paramBundle == null) {
      this.g = paramIntent.getStringExtra("browserURL");
      this.h = paramIntent.getStringExtra("clientToken");
      this.i = paramIntent.getLongExtra("handlerTime", -1L);
    } else {
      this.g = paramBundle.getString("browserURL");
      this.h = paramBundle.getString("clientToken");
      this.i = paramBundle.getLong("handlerTime", -1L);
    } 
    d d1 = this.d;
    if (this.g != null) {
      str = this.g;
    } else {
      str = "about:blank";
    } 
    d1.loadUrl(str);
  }
  
  public void a(Bundle paramBundle) {
    paramBundle.putString("browserURL", this.g);
  }
  
  public void a(d.a parama) {}
  
  public void e() {
    this.d.onPause();
    if (this.l) {
      this.l = false;
      l l = (new l.a(this.d.getFirstUrl())).a(this.i).b(this.k).c(this.d.getResponseEndMs()).d(this.d.getDomContentLoadedMs()).e(this.d.getScrollReadyMs()).f(this.d.getLoadFinishMs()).g(System.currentTimeMillis()).a();
      g.a((Context)this.b).a(this.h, l);
    } 
  }
  
  public void f() {
    this.d.onResume();
  }
  
  public void g() {
    this.b.removeBackButtonInterceptor(this.f);
    i.a((WebView)this.d);
    this.d.destroy();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/view/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */