package com.facebook.ads.internal.util;

import android.app.ActivityManager;
import android.app.KeyguardManager;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.facebook.ads.AdSettings;
import com.facebook.ads.AdSize;
import com.facebook.ads.AudienceNetworkActivity;
import com.facebook.ads.InterstitialAdActivity;
import com.facebook.ads.internal.e;
import com.facebook.ads.internal.view.a.d;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import org.json.JSONException;
import org.json.JSONObject;

public class h {
  private static final Uri a = Uri.parse("content://com.facebook.katana.provider.AttributionIdProvider");
  
  private static final String b = h.class.getSimpleName();
  
  private static final Map<AdSize, e> c = new HashMap<AdSize, e>();
  
  static {
    c.put(AdSize.INTERSTITIAL, e.f);
    c.put(AdSize.RECTANGLE_HEIGHT_250, e.e);
    c.put(AdSize.BANNER_HEIGHT_90, e.d);
    c.put(AdSize.BANNER_HEIGHT_50, e.c);
  }
  
  public static final <P, PR, R> AsyncTask<P, PR, R> a(AsyncTask<P, PR, R> paramAsyncTask, P... paramVarArgs) {
    if (Build.VERSION.SDK_INT >= 11) {
      paramAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Object[])paramVarArgs);
      return paramAsyncTask;
    } 
    paramAsyncTask.execute((Object[])paramVarArgs);
    return paramAsyncTask;
  }
  
  public static e a(AdSize paramAdSize) {
    e e2 = c.get(paramAdSize);
    e e1 = e2;
    if (e2 == null)
      e1 = e.b; 
    return e1;
  }
  
  public static a a(ContentResolver paramContentResolver) {
    // Byte code:
    //   0: aload_0
    //   1: getstatic com/facebook/ads/internal/util/h.a : Landroid/net/Uri;
    //   4: iconst_3
    //   5: anewarray java/lang/String
    //   8: dup
    //   9: iconst_0
    //   10: ldc 'aid'
    //   12: aastore
    //   13: dup
    //   14: iconst_1
    //   15: ldc 'androidid'
    //   17: aastore
    //   18: dup
    //   19: iconst_2
    //   20: ldc 'limit_tracking'
    //   22: aastore
    //   23: aconst_null
    //   24: aconst_null
    //   25: aconst_null
    //   26: invokevirtual query : (Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   29: astore_1
    //   30: aload_1
    //   31: ifnull -> 45
    //   34: aload_1
    //   35: astore_0
    //   36: aload_1
    //   37: invokeinterface moveToFirst : ()Z
    //   42: ifne -> 76
    //   45: aload_1
    //   46: astore_0
    //   47: new com/facebook/ads/internal/util/h$a
    //   50: astore_2
    //   51: aload_1
    //   52: astore_0
    //   53: aload_2
    //   54: aconst_null
    //   55: aconst_null
    //   56: iconst_0
    //   57: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Z)V
    //   60: aload_2
    //   61: astore_0
    //   62: aload_1
    //   63: ifnull -> 74
    //   66: aload_1
    //   67: invokeinterface close : ()V
    //   72: aload_2
    //   73: astore_0
    //   74: aload_0
    //   75: areturn
    //   76: aload_1
    //   77: astore_0
    //   78: new com/facebook/ads/internal/util/h$a
    //   81: dup
    //   82: aload_1
    //   83: aload_1
    //   84: ldc 'aid'
    //   86: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   91: invokeinterface getString : (I)Ljava/lang/String;
    //   96: aload_1
    //   97: aload_1
    //   98: ldc 'androidid'
    //   100: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   105: invokeinterface getString : (I)Ljava/lang/String;
    //   110: aload_1
    //   111: aload_1
    //   112: ldc 'limit_tracking'
    //   114: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   119: invokeinterface getString : (I)Ljava/lang/String;
    //   124: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Boolean;
    //   127: invokevirtual booleanValue : ()Z
    //   130: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Z)V
    //   133: astore_2
    //   134: aload_2
    //   135: astore_0
    //   136: aload_1
    //   137: ifnull -> 74
    //   140: aload_1
    //   141: invokeinterface close : ()V
    //   146: aload_2
    //   147: astore_0
    //   148: goto -> 74
    //   151: astore_0
    //   152: aconst_null
    //   153: astore_1
    //   154: aload_1
    //   155: astore_0
    //   156: new com/facebook/ads/internal/util/h$a
    //   159: dup
    //   160: aconst_null
    //   161: aconst_null
    //   162: iconst_0
    //   163: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Z)V
    //   166: astore_2
    //   167: aload_2
    //   168: astore_0
    //   169: aload_1
    //   170: ifnull -> 74
    //   173: aload_1
    //   174: invokeinterface close : ()V
    //   179: aload_2
    //   180: astore_0
    //   181: goto -> 74
    //   184: astore_1
    //   185: aconst_null
    //   186: astore_0
    //   187: aload_0
    //   188: ifnull -> 197
    //   191: aload_0
    //   192: invokeinterface close : ()V
    //   197: aload_1
    //   198: athrow
    //   199: astore_1
    //   200: goto -> 187
    //   203: astore_0
    //   204: goto -> 154
    // Exception table:
    //   from	to	target	type
    //   0	30	151	java/lang/Exception
    //   0	30	184	finally
    //   36	45	203	java/lang/Exception
    //   36	45	199	finally
    //   47	51	203	java/lang/Exception
    //   47	51	199	finally
    //   53	60	203	java/lang/Exception
    //   53	60	199	finally
    //   78	134	203	java/lang/Exception
    //   78	134	199	finally
    //   156	167	199	finally
  }
  
  public static Object a(Object paramObject, Method paramMethod, Object... paramVarArgs) {
    try {
      paramObject = paramMethod.invoke(paramObject, paramVarArgs);
    } catch (Exception exception) {
      exception = null;
    } 
    return exception;
  }
  
  public static String a(double paramDouble) {
    return String.format(Locale.US, "%.3f", new Object[] { Double.valueOf(paramDouble) });
  }
  
  public static String a(long paramLong) {
    return a(paramLong / 1000.0D);
  }
  
  public static String a(InputStream paramInputStream) {
    StringWriter stringWriter = new StringWriter();
    InputStreamReader inputStreamReader = new InputStreamReader(paramInputStream);
    char[] arrayOfChar = new char[4096];
    while (true) {
      int i = inputStreamReader.read(arrayOfChar);
      if (i != -1) {
        stringWriter.write(arrayOfChar, 0, i);
        continue;
      } 
      String str = stringWriter.toString();
      stringWriter.close();
      inputStreamReader.close();
      return str;
    } 
  }
  
  public static String a(Map<String, String> paramMap) {
    JSONObject jSONObject = new JSONObject();
    if (paramMap != null)
      for (Map.Entry<String, String> entry : paramMap.entrySet()) {
        try {
          jSONObject.put((String)entry.getKey(), entry.getValue());
        } catch (JSONException jSONException) {
          jSONException.printStackTrace();
        } 
      }  
    return jSONObject.toString();
  }
  
  public static String a(JSONObject paramJSONObject, String paramString) {
    return a(paramJSONObject, paramString, (String)null);
  }
  
  public static String a(JSONObject paramJSONObject, String paramString1, String paramString2) {
    paramString1 = paramJSONObject.optString(paramString1, paramString2);
    String str = paramString1;
    if ("null".equals(paramString1))
      str = null; 
    return str;
  }
  
  public static String a(byte[] paramArrayOfbyte) {
    String str;
    try {
      ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream();
      this(paramArrayOfbyte);
      GZIPInputStream gZIPInputStream = new GZIPInputStream();
      this(byteArrayInputStream);
      str = a(gZIPInputStream);
      gZIPInputStream.close();
      byteArrayInputStream.close();
    } catch (Exception exception) {
      d.a(c.a(exception, "Error decompressing data"));
      exception.printStackTrace();
      str = "";
    } 
    return str;
  }
  
  public static Method a(Class<?> paramClass, String paramString, Class<?>... paramVarArgs) {
    try {
      Method method = paramClass.getMethod(paramString, paramVarArgs);
    } catch (NoSuchMethodException noSuchMethodException) {
      noSuchMethodException = null;
    } 
    return (Method)noSuchMethodException;
  }
  
  public static Method a(String paramString1, String paramString2, Class<?>... paramVarArgs) {
    try {
      Method method = a(Class.forName(paramString1), paramString2, paramVarArgs);
    } catch (ClassNotFoundException classNotFoundException) {
      classNotFoundException = null;
    } 
    return (Method)classNotFoundException;
  }
  
  private static void a(Context paramContext, Uri paramUri) {
    Intent intent = new Intent("android.intent.action.VIEW", paramUri);
    intent.addCategory("android.intent.category.BROWSABLE");
    intent.addFlags(268435456);
    intent.putExtra("com.android.browser.application_id", paramContext.getPackageName());
    intent.putExtra("create_new_tab", false);
    paramContext.startActivity(intent);
  }
  
  public static void a(Context paramContext, Uri paramUri, String paramString) {
    if (d.a(paramUri.getScheme()) && com.facebook.ads.internal.h.b(paramContext)) {
      b(paramContext, paramUri, paramString);
      return;
    } 
    a(paramContext, paramUri);
  }
  
  public static void a(Context paramContext, String paramString) {
    if (AdSettings.isTestMode(paramContext))
      Log.d("FBAudienceNetworkLog", paramString + " (displayed for test ads only)"); 
  }
  
  public static void a(DisplayMetrics paramDisplayMetrics, View paramView, AdSize paramAdSize) {
    int i;
    if ((int)(paramDisplayMetrics.widthPixels / paramDisplayMetrics.density) >= paramAdSize.getWidth()) {
      i = paramDisplayMetrics.widthPixels;
    } else {
      i = (int)Math.ceil((paramAdSize.getWidth() * paramDisplayMetrics.density));
    } 
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(i, (int)Math.ceil((paramAdSize.getHeight() * paramDisplayMetrics.density)));
    layoutParams.addRule(14, -1);
    paramView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
  }
  
  public static boolean a(Context paramContext) {
    boolean bool;
    try {
      ActivityManager.RunningTaskInfo runningTaskInfo = ((ActivityManager)paramContext.getSystemService("activity")).getRunningTasks(2).get(0);
      StringBuilder stringBuilder = new StringBuilder();
      this();
      String str = stringBuilder.append(runningTaskInfo.topActivity.getPackageName()).append(".UnityPlayerActivity").toString();
      if (runningTaskInfo.topActivity.getClassName() == str || b(str)) {
        bool = true;
      } else {
        bool = false;
      } 
      Boolean bool1 = Boolean.valueOf(bool);
      Log.d("IS_UNITY", Boolean.toString(bool1.booleanValue()));
      bool = bool1.booleanValue();
    } catch (Throwable throwable) {
      bool = false;
    } 
    return bool;
  }
  
  public static boolean a(String paramString1, String paramString2) {
    boolean bool;
    try {
      StringBuilder stringBuilder = new StringBuilder();
      this();
      Class.forName(stringBuilder.append(paramString1).append(".").append(paramString2).toString());
      bool = true;
    } catch (ClassNotFoundException classNotFoundException) {
      bool = false;
    } 
    return bool;
  }
  
  public static byte[] a(String paramString) {
    byte[] arrayOfByte;
    try {
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      this(paramString.length());
      GZIPOutputStream gZIPOutputStream = new GZIPOutputStream();
      this(byteArrayOutputStream);
      gZIPOutputStream.write(paramString.getBytes());
      gZIPOutputStream.close();
      arrayOfByte = byteArrayOutputStream.toByteArray();
      byteArrayOutputStream.close();
    } catch (Exception exception) {
      d.a(c.a(exception, "Error compressing data"));
      exception.printStackTrace();
      arrayOfByte = new byte[0];
    } 
    return arrayOfByte;
  }
  
  private static void b(Context paramContext, Uri paramUri, String paramString) {
    Intent intent = new Intent(paramContext, AudienceNetworkActivity.class);
    intent.addFlags(268435456);
    intent.putExtra("viewType", (Serializable)AudienceNetworkActivity.Type.BROWSER);
    intent.putExtra("browserURL", paramUri.toString());
    intent.putExtra("clientToken", paramString);
    intent.putExtra("handlerTime", System.currentTimeMillis());
    try {
      paramContext.startActivity(intent);
    } catch (ActivityNotFoundException activityNotFoundException) {
      intent.setClass(paramContext, InterstitialAdActivity.class);
    } 
  }
  
  public static boolean b(Context paramContext) {
    KeyguardManager keyguardManager = (KeyguardManager)paramContext.getSystemService("keyguard");
    return (keyguardManager != null && keyguardManager.inKeyguardRestrictedInputMode());
  }
  
  public static boolean b(String paramString) {
    boolean bool;
    try {
      Class.forName(paramString);
      bool = true;
    } catch (Throwable throwable) {
      bool = false;
    } 
    return bool;
  }
  
  public static class a {
    public String a;
    
    public String b;
    
    public boolean c;
    
    public a(String param1String1, String param1String2, boolean param1Boolean) {
      this.a = param1String1;
      this.b = param1String2;
      this.c = param1Boolean;
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */