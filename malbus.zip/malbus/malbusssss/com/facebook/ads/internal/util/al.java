package com.facebook.ads.internal.util;

import java.lang.ref.WeakReference;

public abstract class al<T> implements Runnable {
  private final WeakReference<T> a;
  
  public al(T paramT) {
    this.a = new WeakReference<T>(paramT);
  }
  
  public T a() {
    return this.a.get();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/al.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */