package com.facebook.ads.internal.util;

import com.facebook.ads.internal.f.c;
import com.facebook.ads.internal.f.f;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class e {
  private static Map<String, Long> a = new ConcurrentHashMap<String, Long>();
  
  private static Map<String, Long> b = new ConcurrentHashMap<String, Long>();
  
  private static Map<String, String> c = new ConcurrentHashMap<String, String>();
  
  private static long a(String paramString, c paramc) {
    long l1 = -1000L;
    if (a.containsKey(paramString))
      long l = ((Long)a.get(paramString)).longValue(); 
    long l2 = l1;
    switch (null.a[paramc.ordinal()]) {
      case 2:
      case 3:
        return l2;
      default:
        l2 = l1;
      case 1:
        break;
    } 
    l2 = 15000L;
  }
  
  public static void a(long paramLong, f paramf) {
    a.put(d(paramf), Long.valueOf(paramLong));
  }
  
  public static void a(String paramString, f paramf) {
    c.put(d(paramf), paramString);
  }
  
  public static boolean a(f paramf) {
    boolean bool = false;
    String str = d(paramf);
    if (b.containsKey(str)) {
      long l1 = ((Long)b.get(str)).longValue();
      long l2 = a(str, paramf.b());
      if (System.currentTimeMillis() - l1 < l2)
        return true; 
      bool = false;
    } 
    return bool;
  }
  
  public static void b(f paramf) {
    b.put(d(paramf), Long.valueOf(System.currentTimeMillis()));
  }
  
  public static String c(f paramf) {
    return c.get(d(paramf));
  }
  
  private static String d(f paramf) {
    int j;
    int i = 0;
    String str = paramf.a();
    c c = paramf.b();
    com.facebook.ads.internal.e e1 = paramf.e;
    if (paramf.c() == null) {
      j = 0;
    } else {
      j = paramf.c().getHeight();
    } 
    if (paramf.c() != null)
      i = paramf.c().getWidth(); 
    return String.format("%s:%s:%s:%d:%d:%d", new Object[] { str, c, e1, Integer.valueOf(j), Integer.valueOf(i), Integer.valueOf(paramf.d()) });
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */