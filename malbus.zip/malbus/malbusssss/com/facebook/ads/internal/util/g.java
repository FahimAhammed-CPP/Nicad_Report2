package com.facebook.ads.internal.util;

import android.content.Context;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import java.util.Collection;
import java.util.HashSet;
import org.json.JSONArray;

public class g {
  public static Collection<String> a(JSONArray paramJSONArray) {
    if (paramJSONArray == null || paramJSONArray.length() == 0)
      return null; 
    HashSet<String> hashSet = new HashSet();
    for (byte b = 0; b < paramJSONArray.length(); b++)
      hashSet.add(paramJSONArray.optString(b)); 
    return hashSet;
  }
  
  public static boolean a(Context paramContext, a parama) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_1
    //   3: invokeinterface D : ()Lcom/facebook/ads/internal/util/f;
    //   8: astore_3
    //   9: iload_2
    //   10: istore #4
    //   12: aload_3
    //   13: ifnull -> 26
    //   16: aload_3
    //   17: getstatic com/facebook/ads/internal/util/f.a : Lcom/facebook/ads/internal/util/f;
    //   20: if_acmpne -> 29
    //   23: iload_2
    //   24: istore #4
    //   26: iload #4
    //   28: ireturn
    //   29: aload_1
    //   30: invokeinterface F : ()Ljava/util/Collection;
    //   35: astore #5
    //   37: iload_2
    //   38: istore #4
    //   40: aload #5
    //   42: ifnull -> 26
    //   45: iload_2
    //   46: istore #4
    //   48: aload #5
    //   50: invokeinterface isEmpty : ()Z
    //   55: ifne -> 26
    //   58: aload #5
    //   60: invokeinterface iterator : ()Ljava/util/Iterator;
    //   65: astore #5
    //   67: aload #5
    //   69: invokeinterface hasNext : ()Z
    //   74: ifeq -> 197
    //   77: aload_0
    //   78: aload #5
    //   80: invokeinterface next : ()Ljava/lang/Object;
    //   85: checkcast java/lang/String
    //   88: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Z
    //   91: ifeq -> 67
    //   94: iconst_1
    //   95: istore #6
    //   97: aload_3
    //   98: getstatic com/facebook/ads/internal/util/f.b : Lcom/facebook/ads/internal/util/f;
    //   101: if_acmpne -> 153
    //   104: iconst_1
    //   105: istore #7
    //   107: iload_2
    //   108: istore #4
    //   110: iload #6
    //   112: iload #7
    //   114: if_icmpne -> 26
    //   117: aload_1
    //   118: invokeinterface E : ()Ljava/lang/String;
    //   123: astore_3
    //   124: aload_1
    //   125: invokeinterface B : ()Ljava/lang/String;
    //   130: astore_1
    //   131: aload_1
    //   132: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   135: ifne -> 159
    //   138: aload_0
    //   139: invokestatic a : (Landroid/content/Context;)Lcom/facebook/ads/internal/g/g;
    //   142: aload_1
    //   143: aconst_null
    //   144: invokevirtual g : (Ljava/lang/String;Ljava/util/Map;)V
    //   147: iconst_1
    //   148: istore #4
    //   150: goto -> 26
    //   153: iconst_0
    //   154: istore #7
    //   156: goto -> 107
    //   159: aload_3
    //   160: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   163: ifne -> 191
    //   166: new com/facebook/ads/internal/util/y
    //   169: dup
    //   170: invokespecial <init> : ()V
    //   173: iconst_1
    //   174: anewarray java/lang/String
    //   177: dup
    //   178: iconst_0
    //   179: aload_3
    //   180: aastore
    //   181: invokevirtual execute : ([Ljava/lang/Object;)Landroid/os/AsyncTask;
    //   184: pop
    //   185: iload_2
    //   186: istore #4
    //   188: goto -> 26
    //   191: iconst_1
    //   192: istore #4
    //   194: goto -> 26
    //   197: iconst_0
    //   198: istore #6
    //   200: goto -> 97
  }
  
  public static boolean a(Context paramContext, String paramString) {
    boolean bool = false;
    if (!TextUtils.isEmpty(paramString)) {
      PackageManager packageManager = paramContext.getPackageManager();
      try {
        packageManager.getPackageInfo(paramString, 1);
        bool = true;
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      
      } catch (RuntimeException runtimeException) {}
    } 
    return bool;
  }
  
  public static interface a {
    String B();
    
    f D();
    
    String E();
    
    Collection<String> F();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */