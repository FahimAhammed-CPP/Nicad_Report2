package com.facebook.ads.internal.util;

public enum b {
  a(0),
  b(8);
  
  int c;
  
  b(int paramInt1) {
    this.c = paramInt1;
  }
  
  public String a(String paramString) {
    return paramString + "&action=" + this.c;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */