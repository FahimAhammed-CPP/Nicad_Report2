package com.facebook.ads.internal.util;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Environment;
import android.os.StatFs;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class a {
  private static SensorManager a = null;
  
  private static Sensor b = null;
  
  private static Sensor c = null;
  
  private static volatile float[] d;
  
  private static volatile float[] e;
  
  private static Map<String, String> f = new ConcurrentHashMap<String, String>();
  
  private static String[] g = new String[] { "x", "y", "z" };
  
  public static Map<String, String> a() {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.putAll(f);
    a((Map)hashMap);
    return (Map)hashMap;
  }
  
  public static void a(Context paramContext) {
    // Byte code:
    //   0: ldc com/facebook/ads/internal/util/a
    //   2: monitorenter
    //   3: aload_0
    //   4: invokestatic b : (Landroid/content/Context;)V
    //   7: aload_0
    //   8: invokestatic c : (Landroid/content/Context;)V
    //   11: aload_0
    //   12: invokestatic d : (Landroid/content/Context;)V
    //   15: getstatic com/facebook/ads/internal/util/a.a : Landroid/hardware/SensorManager;
    //   18: ifnonnull -> 45
    //   21: aload_0
    //   22: ldc 'sensor'
    //   24: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   27: checkcast android/hardware/SensorManager
    //   30: putstatic com/facebook/ads/internal/util/a.a : Landroid/hardware/SensorManager;
    //   33: getstatic com/facebook/ads/internal/util/a.a : Landroid/hardware/SensorManager;
    //   36: astore_0
    //   37: aload_0
    //   38: ifnonnull -> 45
    //   41: ldc com/facebook/ads/internal/util/a
    //   43: monitorexit
    //   44: return
    //   45: getstatic com/facebook/ads/internal/util/a.b : Landroid/hardware/Sensor;
    //   48: ifnonnull -> 61
    //   51: getstatic com/facebook/ads/internal/util/a.a : Landroid/hardware/SensorManager;
    //   54: iconst_1
    //   55: invokevirtual getDefaultSensor : (I)Landroid/hardware/Sensor;
    //   58: putstatic com/facebook/ads/internal/util/a.b : Landroid/hardware/Sensor;
    //   61: getstatic com/facebook/ads/internal/util/a.c : Landroid/hardware/Sensor;
    //   64: ifnonnull -> 77
    //   67: getstatic com/facebook/ads/internal/util/a.a : Landroid/hardware/SensorManager;
    //   70: iconst_4
    //   71: invokevirtual getDefaultSensor : (I)Landroid/hardware/Sensor;
    //   74: putstatic com/facebook/ads/internal/util/a.c : Landroid/hardware/Sensor;
    //   77: getstatic com/facebook/ads/internal/util/a.b : Landroid/hardware/Sensor;
    //   80: ifnull -> 106
    //   83: getstatic com/facebook/ads/internal/util/a.a : Landroid/hardware/SensorManager;
    //   86: astore_1
    //   87: new com/facebook/ads/internal/util/a$a
    //   90: astore_0
    //   91: aload_0
    //   92: aconst_null
    //   93: invokespecial <init> : (Lcom/facebook/ads/internal/util/a$1;)V
    //   96: aload_1
    //   97: aload_0
    //   98: getstatic com/facebook/ads/internal/util/a.b : Landroid/hardware/Sensor;
    //   101: iconst_3
    //   102: invokevirtual registerListener : (Landroid/hardware/SensorEventListener;Landroid/hardware/Sensor;I)Z
    //   105: pop
    //   106: getstatic com/facebook/ads/internal/util/a.c : Landroid/hardware/Sensor;
    //   109: ifnull -> 41
    //   112: getstatic com/facebook/ads/internal/util/a.a : Landroid/hardware/SensorManager;
    //   115: astore_1
    //   116: new com/facebook/ads/internal/util/a$a
    //   119: astore_0
    //   120: aload_0
    //   121: aconst_null
    //   122: invokespecial <init> : (Lcom/facebook/ads/internal/util/a$1;)V
    //   125: aload_1
    //   126: aload_0
    //   127: getstatic com/facebook/ads/internal/util/a.c : Landroid/hardware/Sensor;
    //   130: iconst_3
    //   131: invokevirtual registerListener : (Landroid/hardware/SensorEventListener;Landroid/hardware/Sensor;I)Z
    //   134: pop
    //   135: goto -> 41
    //   138: astore_0
    //   139: ldc com/facebook/ads/internal/util/a
    //   141: monitorexit
    //   142: aload_0
    //   143: athrow
    // Exception table:
    //   from	to	target	type
    //   3	37	138	finally
    //   45	61	138	finally
    //   61	77	138	finally
    //   77	106	138	finally
    //   106	135	138	finally
  }
  
  public static void a(a parama) {
    // Byte code:
    //   0: ldc com/facebook/ads/internal/util/a
    //   2: monitorenter
    //   3: getstatic com/facebook/ads/internal/util/a.a : Landroid/hardware/SensorManager;
    //   6: astore_1
    //   7: aload_1
    //   8: ifnonnull -> 15
    //   11: ldc com/facebook/ads/internal/util/a
    //   13: monitorexit
    //   14: return
    //   15: getstatic com/facebook/ads/internal/util/a.a : Landroid/hardware/SensorManager;
    //   18: aload_0
    //   19: invokevirtual unregisterListener : (Landroid/hardware/SensorEventListener;)V
    //   22: goto -> 11
    //   25: astore_0
    //   26: ldc com/facebook/ads/internal/util/a
    //   28: monitorexit
    //   29: aload_0
    //   30: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	25	finally
    //   15	22	25	finally
  }
  
  private static void a(Map<String, String> paramMap) {
    byte b = 0;
    float[] arrayOfFloat1 = d;
    float[] arrayOfFloat2 = e;
    if (arrayOfFloat1 != null) {
      int i = Math.min(g.length, arrayOfFloat1.length);
      for (byte b1 = 0; b1 < i; b1++)
        paramMap.put("accelerometer_" + g[b1], String.valueOf(arrayOfFloat1[b1])); 
    } 
    if (arrayOfFloat2 != null) {
      int i = Math.min(g.length, arrayOfFloat2.length);
      for (byte b1 = b; b1 < i; b1++)
        paramMap.put("rotation_" + g[b1], String.valueOf(arrayOfFloat2[b1])); 
    } 
  }
  
  private static void b(Context paramContext) {
    ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
    ((ActivityManager)paramContext.getSystemService("activity")).getMemoryInfo(memoryInfo);
    f.put("available_memory", String.valueOf(memoryInfo.availMem));
  }
  
  private static void c(Context paramContext) {
    StatFs statFs = new StatFs(Environment.getDataDirectory().getPath());
    long l1 = statFs.getBlockSize();
    long l2 = statFs.getAvailableBlocks();
    f.put("free_space", String.valueOf(l2 * l1));
  }
  
  private static void d(Context paramContext) {
    Intent intent = paramContext.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
    if (intent != null) {
      String str;
      int i = intent.getIntExtra("level", -1);
      int j = intent.getIntExtra("scale", -1);
      int k = intent.getIntExtra("status", -1);
      if (k == 2 || k == 5) {
        k = 1;
      } else {
        k = 0;
      } 
      float f = 0.0F;
      if (j > 0)
        f = i / j * 100.0F; 
      f.put("battery", String.valueOf(f));
      Map<String, String> map = f;
      if (k != 0) {
        str = "1";
      } else {
        str = "0";
      } 
      map.put("charging", str);
    } 
  }
  
  private static class a implements SensorEventListener {
    private a() {}
    
    public void onAccuracyChanged(Sensor param1Sensor, int param1Int) {}
    
    public void onSensorChanged(SensorEvent param1SensorEvent) {
      if (param1SensorEvent.sensor == a.b()) {
        a.a(param1SensorEvent.values);
      } else if (param1SensorEvent.sensor == a.c()) {
        a.b(param1SensorEvent.values);
      } 
      a.a(this);
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */