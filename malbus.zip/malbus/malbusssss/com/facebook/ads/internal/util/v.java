package com.facebook.ads.internal.util;

import android.content.Context;
import android.support.annotation.NonNull;
import com.facebook.ads.internal.g.f;
import com.facebook.ads.internal.g.g;

public class v extends ai {
  @NonNull
  private final String a;
  
  @NonNull
  private final String b;
  
  public v(Context paramContext, ai.a parama, String paramString1, String paramString2, String paramString3) {
    super(paramContext, (f)g.a(paramContext), parama, "", paramString3);
    this.a = paramString1;
    this.b = paramString2;
  }
  
  protected String a(ai.b paramb) {
    String str1 = null;
    String str2 = str1;
    switch (null.a[paramb.ordinal()]) {
      default:
        str2 = str1;
      case 1:
        return str2;
      case 2:
        str2 = this.b;
      case 3:
        break;
    } 
    str2 = this.a;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */