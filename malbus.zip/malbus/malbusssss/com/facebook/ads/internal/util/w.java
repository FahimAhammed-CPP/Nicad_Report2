package com.facebook.ads.internal.util;

import com.facebook.ads.internal.adapters.e;

public class w {
  public static String a(e parame) {
    switch (null.a[parame.ordinal()]) {
      default:
        return "";
      case 1:
        return "AdMob";
      case 2:
        return "Flurry";
      case 3:
        return "InMobi";
      case 4:
        break;
    } 
    return "Audience Network";
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */