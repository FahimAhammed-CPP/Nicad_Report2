package com.facebook.ads.internal.util;

import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.Log;
import com.facebook.ads.internal.i.a.a;
import com.facebook.ads.internal.i.a.n;
import com.facebook.ads.internal.i.a.p;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class y extends AsyncTask<String, Void, z> {
  private static final String a = y.class.getSimpleName();
  
  private static final Set<String> b = new HashSet<String>();
  
  private Map<String, String> c;
  
  private Map<String, String> d;
  
  private n e;
  
  static {
    b.add("#");
    b.add("null");
  }
  
  public y() {
    this(null, null);
  }
  
  public y(Map<String, String> paramMap) {
    this(paramMap, null);
  }
  
  public y(Map<String, String> paramMap1, Map<String, String> paramMap2) {
    if (paramMap1 != null) {
      paramMap1 = new HashMap<String, String>(paramMap1);
    } else {
      paramMap1 = null;
    } 
    this.c = paramMap1;
    paramMap1 = map;
    if (paramMap2 != null)
      paramMap1 = new HashMap<String, String>(paramMap2); 
    this.d = paramMap1;
  }
  
  private String a(String paramString1, String paramString2, String paramString3) {
    null = paramString1;
    if (!TextUtils.isEmpty(paramString1)) {
      null = paramString1;
      if (!TextUtils.isEmpty(paramString2)) {
        if (TextUtils.isEmpty(paramString3))
          return paramString1; 
      } else {
        return null;
      } 
    } else {
      return null;
    } 
    if (paramString1.contains("?")) {
      null = "&";
    } else {
      null = "?";
    } 
    return paramString1 + null + paramString2 + "=" + URLEncoder.encode(paramString3);
  }
  
  private boolean a(String paramString) {
    boolean bool2;
    boolean bool1 = false;
    a a = x.b();
    try {
      if (this.d == null || this.d.size() == 0) {
        this.e = a.a(paramString, null);
      } else {
        p p = new p();
        this();
        p.a(this.d);
        this.e = a.b(paramString, p);
      } 
      bool2 = bool1;
      if (this.e != null) {
        bool2 = bool1;
        if (this.e.a() == 200)
          bool2 = true; 
      } 
    } catch (Exception exception) {
      Log.e(a, "Error opening url: " + paramString, exception);
      bool2 = bool1;
    } 
    return bool2;
  }
  
  private String b(String paramString) {
    try {
      String str = a(paramString, "analog", h.a(a.a()));
      paramString = str;
    } catch (Exception exception) {}
    return paramString;
  }
  
  protected z a(String... paramVarArgs) {
    String str1 = paramVarArgs[0];
    if (TextUtils.isEmpty(str1) || b.contains(str1))
      return null; 
    str1 = b(str1);
    String str2 = str1;
    if (this.c != null) {
      str2 = str1;
      if (!this.c.isEmpty()) {
        for (Map.Entry<String, String> entry : this.c.entrySet())
          str1 = a(str1, (String)entry.getKey(), (String)entry.getValue()); 
        str2 = str1;
      } 
    } 
    for (byte b = 1;; b++) {
      if (b <= 2) {
        if (a(str2))
          return new z(this.e); 
      } else {
        return null;
      } 
    } 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */