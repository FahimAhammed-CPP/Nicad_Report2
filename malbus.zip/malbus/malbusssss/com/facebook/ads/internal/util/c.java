package com.facebook.ads.internal.util;

import android.support.annotation.Nullable;
import com.facebook.ads.internal.server.AdPlacementType;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class c {
  public static String a = null;
  
  private String b;
  
  private Map<String, Object> c;
  
  private int d;
  
  private String e;
  
  public c(String paramString1, Map<String, Object> paramMap, int paramInt, String paramString2) {
    this.b = paramString1;
    this.c = paramMap;
    this.d = paramInt;
    this.e = paramString2;
  }
  
  public static c a(long paramLong, a parama, String paramString) {
    long l = System.currentTimeMillis();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("Time", String.valueOf(l - paramLong));
    hashMap.put("AdAction", String.valueOf(parama.f));
    return new c("bounceback", (Map)hashMap, (int)(l / 1000L), paramString);
  }
  
  public static c a(b paramb, AdPlacementType paramAdPlacementType, long paramLong, String paramString) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("LatencyType", String.valueOf(paramb.b));
    hashMap.put("AdPlacementType", paramAdPlacementType.toString());
    hashMap.put("Time", String.valueOf(paramLong));
    int i = (int)(System.currentTimeMillis() / 1000L);
    if (paramString == null)
      paramString = a; 
    return new c("latency", (Map)hashMap, i, paramString);
  }
  
  public static c a(@Nullable Throwable paramThrowable, @Nullable String paramString) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (paramThrowable != null) {
      hashMap.put("ex", paramThrowable.getClass().getSimpleName());
      hashMap.put("ex_msg", paramThrowable.getMessage());
    } 
    int i = (int)(System.currentTimeMillis() / 1000L);
    if (paramString == null)
      paramString = a; 
    return new c("error", (Map)hashMap, i, paramString);
  }
  
  public JSONObject a() {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("name", this.b);
      JSONObject jSONObject1 = new JSONObject();
      this(this.c);
      jSONObject.put("data", jSONObject1);
      jSONObject.put("time", this.d);
      jSONObject.put("request_id", this.e);
    } catch (JSONException jSONException) {
      jSONException.printStackTrace();
    } 
    return jSONObject;
  }
  
  public enum a {
    a(0),
    b(1),
    c(2),
    d(3),
    e(4);
    
    int f;
    
    a(int param1Int1) {
      this.f = param1Int1;
    }
  }
  
  public enum b {
    a(0);
    
    int b;
    
    b(int param1Int1) {
      this.b = param1Int1;
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */