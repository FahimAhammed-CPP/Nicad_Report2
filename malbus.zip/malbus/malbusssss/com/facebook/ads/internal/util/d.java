package com.facebook.ads.internal.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;

public class d {
  private static final List<c> a = new ArrayList<c>();
  
  public static String a() {
    List<c> list;
    JSONArray jSONArray;
    synchronized (a) {
      if (a.isEmpty())
        return ""; 
      ArrayList arrayList = new ArrayList();
      this((Collection)a);
      a.clear();
      jSONArray = new JSONArray();
      Iterator<c> iterator = arrayList.iterator();
      while (iterator.hasNext())
        jSONArray.put(((c)iterator.next()).a()); 
    } 
    return jSONArray.toString();
  }
  
  public static void a(c paramc) {
    synchronized (a) {
      a.add(paramc);
      return;
    } 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */