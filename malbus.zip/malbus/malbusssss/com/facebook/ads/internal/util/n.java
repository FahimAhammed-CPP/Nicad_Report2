package com.facebook.ads.internal.util;

import java.util.HashMap;
import java.util.Map;

public class n {
  private final String a;
  
  private final String b;
  
  public n(String paramString1, String paramString2) {
    this.a = paramString1;
    this.b = paramString2;
  }
  
  public Map<String, String> a() {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("stacktrace", this.a);
    hashMap.put("app_crashed_version", this.b);
    return (Map)hashMap;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */