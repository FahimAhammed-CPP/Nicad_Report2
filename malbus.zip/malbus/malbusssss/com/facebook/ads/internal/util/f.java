package com.facebook.ads.internal.util;

import android.text.TextUtils;
import java.util.Locale;

public enum f {
  a, b, c;
  
  public static f a(String paramString) {
    f f1;
    if (TextUtils.isEmpty(paramString))
      return a; 
    try {
      f1 = valueOf(paramString.toUpperCase(Locale.US));
    } catch (IllegalArgumentException illegalArgumentException) {
      f1 = a;
    } 
    return f1;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */