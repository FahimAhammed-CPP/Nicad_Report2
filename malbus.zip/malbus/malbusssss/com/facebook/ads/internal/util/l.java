package com.facebook.ads.internal.util;

import java.util.HashMap;
import java.util.Map;

public class l {
  public final String a;
  
  public final long b;
  
  public final long c;
  
  public final long d;
  
  public final long e;
  
  public final long f;
  
  public final long g;
  
  public final long h;
  
  private l(String paramString, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7) {
    this.a = paramString;
    this.b = paramLong1;
    this.c = paramLong2;
    this.d = paramLong3;
    this.e = paramLong4;
    this.f = paramLong5;
    this.g = paramLong6;
    this.h = paramLong7;
  }
  
  public Map<String, String> a() {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>(7);
    hashMap.put("initial_url", this.a);
    hashMap.put("handler_time_ms", String.valueOf(this.b));
    hashMap.put("load_start_ms", String.valueOf(this.c));
    hashMap.put("response_end_ms", String.valueOf(this.d));
    hashMap.put("dom_content_loaded_ms", String.valueOf(this.e));
    hashMap.put("scroll_ready_ms", String.valueOf(this.f));
    hashMap.put("load_finish_ms", String.valueOf(this.g));
    hashMap.put("session_finish_ms", String.valueOf(this.h));
    return (Map)hashMap;
  }
  
  public static class a {
    private final String a;
    
    private long b = -1L;
    
    private long c = -1L;
    
    private long d = -1L;
    
    private long e = -1L;
    
    private long f = -1L;
    
    private long g = -1L;
    
    private long h = -1L;
    
    public a(String param1String) {
      this.a = param1String;
    }
    
    public a a(long param1Long) {
      this.b = param1Long;
      return this;
    }
    
    public l a() {
      return new l(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h);
    }
    
    public a b(long param1Long) {
      this.c = param1Long;
      return this;
    }
    
    public a c(long param1Long) {
      this.d = param1Long;
      return this;
    }
    
    public a d(long param1Long) {
      this.e = param1Long;
      return this;
    }
    
    public a e(long param1Long) {
      this.f = param1Long;
      return this;
    }
    
    public a f(long param1Long) {
      this.g = param1Long;
      return this;
    }
    
    public a g(long param1Long) {
      this.h = param1Long;
      return this;
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */