package com.facebook.ads.internal.util;

import android.graphics.Rect;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;
import java.util.HashMap;
import java.util.Map;

public class ag {
  private static final String a = ag.class.getSimpleName();
  
  private boolean b;
  
  private int c = -1;
  
  private int d = -1;
  
  private long e = -1L;
  
  private int f = -1;
  
  private long g = -1L;
  
  private long h = -1L;
  
  private int i = -1;
  
  private int j = -1;
  
  private int k = -1;
  
  private int l = -1;
  
  private float m = -1.0F;
  
  private float n = -1.0F;
  
  private float o = -1.0F;
  
  public void a() {
    this.e = System.currentTimeMillis();
  }
  
  public void a(MotionEvent paramMotionEvent, View paramView1, View paramView2) {
    if (!this.b) {
      this.b = true;
      InputDevice inputDevice = paramMotionEvent.getDevice();
      if (inputDevice != null) {
        this.o = Math.min(inputDevice.getMotionRange(0).getRange(), inputDevice.getMotionRange(1).getRange());
      } else {
        this.o = Math.min(paramView1.getMeasuredWidth(), paramView1.getMeasuredHeight());
      } 
    } 
    int[] arrayOfInt2 = new int[2];
    paramView1.getLocationInWindow(arrayOfInt2);
    int[] arrayOfInt1 = new int[2];
    paramView2.getLocationInWindow(arrayOfInt1);
    switch (paramMotionEvent.getAction()) {
      default:
        return;
      case 0:
        this.c = paramView1.getWidth();
        this.d = paramView1.getHeight();
        this.f = 1;
        this.g = System.currentTimeMillis();
        this.i = (int)(paramMotionEvent.getX() + 0.5F) + arrayOfInt1[0] - arrayOfInt2[0];
        i = (int)(paramMotionEvent.getY() + 0.5F);
        this.j = arrayOfInt1[1] + i - arrayOfInt2[1];
        this.m = paramMotionEvent.getPressure();
        this.n = paramMotionEvent.getSize();
      case 2:
        this.m -= this.m / this.f;
        this.m += paramMotionEvent.getPressure() / this.f;
        this.n -= this.n / this.f;
        this.n += paramMotionEvent.getSize() / this.f;
        this.f++;
      case 1:
      case 3:
        break;
    } 
    this.h = System.currentTimeMillis();
    this.k = (int)(paramMotionEvent.getX() + 0.5F) + arrayOfInt1[0] - arrayOfInt2[0];
    int i = (int)(paramMotionEvent.getY() + 0.5F);
    this.l = arrayOfInt1[1] + i - arrayOfInt2[1];
  }
  
  public boolean a(int paramInt) {
    boolean bool1 = false;
    boolean bool2 = bool1;
    if (d()) {
      bool2 = bool1;
      if (this.k != -1) {
        bool2 = bool1;
        if (this.l != -1) {
          bool2 = bool1;
          if (this.c != -1) {
            if (this.d == -1)
              return bool1; 
          } else {
            return bool2;
          } 
        } else {
          return bool2;
        } 
      } else {
        return bool2;
      } 
    } else {
      return bool2;
    } 
    int i = this.d * paramInt / 100;
    paramInt = this.c * paramInt / 100;
    bool2 = bool1;
    if (!(new Rect(paramInt, i, this.c - paramInt, this.d - i)).contains(this.k, this.l))
      bool2 = true; 
    return bool2;
  }
  
  public boolean b() {
    return (this.e != -1L);
  }
  
  public long c() {
    return b() ? (System.currentTimeMillis() - this.e) : -1L;
  }
  
  public boolean d() {
    return this.b;
  }
  
  public Map<String, String> e() {
    long l;
    if (!this.b)
      return null; 
    String str = String.valueOf(this.n * this.o / 2.0F);
    if (this.e > 0L && this.h > this.e) {
      l = this.h - this.e;
    } else {
      l = -1L;
    } 
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>(11);
    hashMap.put("width", String.valueOf(this.c));
    hashMap.put("height", String.valueOf(this.d));
    hashMap.put("clickDelayTime", String.valueOf(l));
    hashMap.put("startTime", String.valueOf(this.g));
    hashMap.put("endTime", String.valueOf(this.h));
    hashMap.put("startX", String.valueOf(this.i));
    hashMap.put("startY", String.valueOf(this.j));
    hashMap.put("clickX", String.valueOf(this.k));
    hashMap.put("clickY", String.valueOf(this.l));
    hashMap.put("endX", String.valueOf(this.k));
    hashMap.put("endY", String.valueOf(this.l));
    hashMap.put("force", String.valueOf(this.m));
    hashMap.put("radiusX", str);
    hashMap.put("radiusY", str);
    return (Map)hashMap;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/ag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */