package com.facebook.ads.internal.util;

public class AdInternalSettings {
  public static boolean a;
  
  public static boolean b;
  
  public static void setTestMode(boolean paramBoolean) {
    a = paramBoolean;
  }
  
  public static void setVisibleAnimation(boolean paramBoolean) {
    b = paramBoolean;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/AdInternalSettings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */