package com.facebook.ads.internal.util;

import com.facebook.ads.internal.i.a.n;

public class z {
  private int a;
  
  public z(n paramn) {
    this.a = paramn.a();
  }
  
  public boolean a() {
    return (this.a == 200);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */