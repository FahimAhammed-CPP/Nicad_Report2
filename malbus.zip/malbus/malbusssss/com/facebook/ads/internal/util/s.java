package com.facebook.ads.internal.util;

import android.content.Context;
import android.support.annotation.Nullable;
import java.io.File;
import java.io.FileInputStream;
import java.security.MessageDigest;

public class s {
  @Nullable
  public static final String a(Context paramContext, String paramString) {
    try {
      String str = b((paramContext.getPackageManager().getApplicationInfo(paramString, 0)).sourceDir);
    } catch (Exception exception) {
      exception = null;
    } 
    return (String)exception;
  }
  
  @Nullable
  public static final String a(File paramFile) {
    try {
      MessageDigest messageDigest = MessageDigest.getInstance("MD5");
      byte[] arrayOfByte = new byte[1024];
      FileInputStream fileInputStream = new FileInputStream();
      this(paramFile);
      while (true) {
        int i = fileInputStream.read(arrayOfByte);
        if (i > 0)
          messageDigest.update(arrayOfByte, 0, i); 
        if (i == -1) {
          fileInputStream.close();
          return a(messageDigest.digest());
        } 
      } 
    } catch (Exception exception) {
      exception = null;
    } 
    return (String)exception;
  }
  
  @Nullable
  public static String a(String paramString) {
    try {
      paramString = a(MessageDigest.getInstance("MD5").digest(paramString.getBytes("utf-8")));
    } catch (Exception exception) {
      exception = null;
    } 
    return (String)exception;
  }
  
  private static final String a(byte[] paramArrayOfbyte) {
    StringBuilder stringBuilder = new StringBuilder();
    int i = paramArrayOfbyte.length;
    for (byte b = 0; b < i; b++)
      stringBuilder.append(Integer.toString((paramArrayOfbyte[b] & 0xFF) + 256, 16).substring(1)); 
    return stringBuilder.toString();
  }
  
  @Nullable
  public static final String b(String paramString) {
    return a(new File(paramString));
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */