package com.facebook.ads.internal.util;

import android.graphics.Bitmap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ad {
  static final int a = Runtime.getRuntime().availableProcessors();
  
  static final ExecutorService b = Executors.newFixedThreadPool(a);
  
  private static volatile boolean c = true;
  
  private final Bitmap d;
  
  private Bitmap e;
  
  private final k f;
  
  public ad(Bitmap paramBitmap) {
    this.d = paramBitmap;
    this.f = new u();
  }
  
  public Bitmap a() {
    return this.e;
  }
  
  public Bitmap a(int paramInt) {
    this.e = this.f.a(this.d, paramInt);
    return this.e;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */