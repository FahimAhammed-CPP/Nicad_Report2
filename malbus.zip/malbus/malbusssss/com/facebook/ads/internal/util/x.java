package com.facebook.ads.internal.util;

import android.annotation.TargetApi;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.text.TextUtils;
import android.webkit.WebSettings;
import com.facebook.ads.AdSettings;
import com.facebook.ads.internal.e;
import com.facebook.ads.internal.f.i;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class x {
  private static String a = null;
  
  private static final Set<String> b = new HashSet<String>(1);
  
  private static final Set<String> c = new HashSet<String>(2);
  
  static {
    b.add("1ww8E0AYsR2oX5lndk2hwp2Uosk=\n");
    c.add("toZ2GRnRjC9P5VVUdCpOrFH8lfQ=\n");
    c.add("3lKvjNsfmrn+WmfDhvr2iVh/yRs=\n");
    c.add("B08QtE4yLCdli4rptyqAEczXOeA=\n");
    c.add("XZXI6anZbdKf+taURdnyUH5ipgM=\n");
  }
  
  public static com.facebook.ads.internal.i.a.a a(Context paramContext) {
    return a(paramContext, null);
  }
  
  public static com.facebook.ads.internal.i.a.a a(Context paramContext, e parame) {
    com.facebook.ads.internal.i.a.a a = new com.facebook.ads.internal.i.a.a();
    a(paramContext, a, parame);
    return a;
  }
  
  private static String a(Context paramContext, String paramString1, String paramString2) {
    Class<?> clazz = Class.forName(paramString1);
    Constructor<?> constructor = clazz.getDeclaredConstructor(new Class[] { Context.class, Class.forName(paramString2) });
    constructor.setAccessible(true);
    Method method = clazz.getMethod("getUserAgentString", new Class[0]);
    try {
      return (String)method.invoke(constructor.newInstance(new Object[] { paramContext, null }, ), new Object[0]);
    } finally {
      constructor.setAccessible(false);
    } 
  }
  
  private static void a(Context paramContext, com.facebook.ads.internal.i.a.a parama, e parame) {
    parama.c(30000);
    parama.b(3);
    parama.a("user-agent", c(paramContext, parame) + " [FBAN/AudienceNetworkForAndroid;FBSN/" + "Android" + ";FBSV/" + i.a + ";FBAB/" + i.d + ";FBAV/" + i.f + ";FBBV/" + i.g + ";FBVS/" + "4.19.0" + ";FBLC/" + Locale.getDefault().toString() + "]");
  }
  
  public static boolean a() {
    String str = AdSettings.getUrlPrefix();
    return (!TextUtils.isEmpty(str) && str.endsWith(".sb"));
  }
  
  public static com.facebook.ads.internal.i.a.a b() {
    return a(null);
  }
  
  public static com.facebook.ads.internal.i.a.a b(Context paramContext) {
    return b(paramContext, null);
  }
  
  public static com.facebook.ads.internal.i.a.a b(Context paramContext, e parame) {
    com.facebook.ads.internal.i.a.a a = new com.facebook.ads.internal.i.a.a();
    a(paramContext, a, parame);
    if (!a()) {
      a.b(c);
      a.a(b);
    } 
    return a;
  }
  
  public static a c(Context paramContext) {
    if (paramContext.checkCallingOrSelfPermission("android.permission.ACCESS_NETWORK_STATE") != 0)
      return a.a; 
    NetworkInfo networkInfo = ((ConnectivityManager)paramContext.getSystemService("connectivity")).getActiveNetworkInfo();
    if (networkInfo == null || !networkInfo.isConnected())
      return a.b; 
    if (networkInfo.getType() == 0) {
      switch (networkInfo.getSubtype()) {
        default:
          return a.a;
        case 1:
        case 2:
        case 4:
        case 7:
        case 11:
          return a.d;
        case 3:
        case 5:
        case 6:
        case 8:
        case 9:
        case 10:
        case 12:
        case 14:
        case 15:
          return a.e;
        case 13:
          break;
      } 
      return a.f;
    } 
    return a.c;
  }
  
  private static String c(Context paramContext, e parame) {
    // Byte code:
    //   0: aload_0
    //   1: ifnonnull -> 9
    //   4: ldc 'Unknown'
    //   6: astore_0
    //   7: aload_0
    //   8: areturn
    //   9: aload_1
    //   10: getstatic com/facebook/ads/internal/e.l : Lcom/facebook/ads/internal/e;
    //   13: if_acmpeq -> 27
    //   16: aload_1
    //   17: getstatic com/facebook/ads/internal/e.j : Lcom/facebook/ads/internal/e;
    //   20: if_acmpeq -> 27
    //   23: aload_1
    //   24: ifnonnull -> 36
    //   27: ldc 'http.agent'
    //   29: invokestatic getProperty : (Ljava/lang/String;)Ljava/lang/String;
    //   32: astore_0
    //   33: goto -> 7
    //   36: getstatic com/facebook/ads/internal/util/x.a : Ljava/lang/String;
    //   39: ifnull -> 49
    //   42: getstatic com/facebook/ads/internal/util/x.a : Ljava/lang/String;
    //   45: astore_0
    //   46: goto -> 7
    //   49: ldc com/facebook/ads/internal/util/x
    //   51: monitorenter
    //   52: getstatic com/facebook/ads/internal/util/x.a : Ljava/lang/String;
    //   55: ifnull -> 74
    //   58: getstatic com/facebook/ads/internal/util/x.a : Ljava/lang/String;
    //   61: astore_0
    //   62: ldc com/facebook/ads/internal/util/x
    //   64: monitorexit
    //   65: goto -> 7
    //   68: astore_0
    //   69: ldc com/facebook/ads/internal/util/x
    //   71: monitorexit
    //   72: aload_0
    //   73: athrow
    //   74: getstatic android/os/Build$VERSION.SDK_INT : I
    //   77: istore_2
    //   78: iload_2
    //   79: bipush #17
    //   81: if_icmplt -> 104
    //   84: aload_0
    //   85: invokestatic d : (Landroid/content/Context;)Ljava/lang/String;
    //   88: putstatic com/facebook/ads/internal/util/x.a : Ljava/lang/String;
    //   91: getstatic com/facebook/ads/internal/util/x.a : Ljava/lang/String;
    //   94: astore_1
    //   95: ldc com/facebook/ads/internal/util/x
    //   97: monitorexit
    //   98: aload_1
    //   99: astore_0
    //   100: goto -> 7
    //   103: astore_1
    //   104: aload_0
    //   105: ldc_w 'android.webkit.WebSettings'
    //   108: ldc_w 'android.webkit.WebView'
    //   111: invokestatic a : (Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   114: putstatic com/facebook/ads/internal/util/x.a : Ljava/lang/String;
    //   117: ldc com/facebook/ads/internal/util/x
    //   119: monitorexit
    //   120: getstatic com/facebook/ads/internal/util/x.a : Ljava/lang/String;
    //   123: astore_0
    //   124: goto -> 7
    //   127: astore_1
    //   128: aload_0
    //   129: ldc_w 'android.webkit.WebSettingsClassic'
    //   132: ldc_w 'android.webkit.WebViewClassic'
    //   135: invokestatic a : (Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   138: putstatic com/facebook/ads/internal/util/x.a : Ljava/lang/String;
    //   141: goto -> 117
    //   144: astore_1
    //   145: new android/webkit/WebView
    //   148: astore_1
    //   149: aload_1
    //   150: aload_0
    //   151: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   154: invokespecial <init> : (Landroid/content/Context;)V
    //   157: aload_1
    //   158: invokevirtual getSettings : ()Landroid/webkit/WebSettings;
    //   161: invokevirtual getUserAgentString : ()Ljava/lang/String;
    //   164: putstatic com/facebook/ads/internal/util/x.a : Ljava/lang/String;
    //   167: aload_1
    //   168: invokevirtual destroy : ()V
    //   171: goto -> 117
    // Exception table:
    //   from	to	target	type
    //   52	65	68	finally
    //   69	72	68	finally
    //   74	78	68	finally
    //   84	95	103	java/lang/Exception
    //   84	95	68	finally
    //   95	98	68	finally
    //   104	117	127	java/lang/Exception
    //   104	117	68	finally
    //   117	120	68	finally
    //   128	141	144	java/lang/Exception
    //   128	141	68	finally
    //   145	171	68	finally
  }
  
  @TargetApi(17)
  private static String d(Context paramContext) {
    return WebSettings.getDefaultUserAgent(paramContext);
  }
  
  public enum a {
    a(0),
    b(0),
    c(1),
    d(2),
    e(3),
    f(4);
    
    public final int g;
    
    a(int param1Int1) {
      this.g = param1Int1;
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */