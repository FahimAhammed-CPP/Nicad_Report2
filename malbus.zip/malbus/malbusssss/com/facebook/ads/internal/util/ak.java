package com.facebook.ads.internal.util;

import android.content.Context;
import android.media.AudioManager;
import java.util.Map;

public class ak {
  public static float a(Context paramContext) {
    AudioManager audioManager = (AudioManager)paramContext.getSystemService("audio");
    if (audioManager != null) {
      int i = audioManager.getStreamVolume(3);
      int j = audioManager.getStreamMaxVolume(3);
      if (j > 0)
        return i * 1.0F / j; 
    } 
    return 0.0F;
  }
  
  public static void a(Map<String, String> paramMap, boolean paramBoolean1, boolean paramBoolean2) {
    String str;
    if (paramBoolean1) {
      str = "1";
    } else {
      str = "0";
    } 
    paramMap.put("autoplay", str);
    if (paramBoolean2) {
      str = "1";
    } else {
      str = "0";
    } 
    paramMap.put("inline", str);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/ak.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */