package com.facebook.ads.internal.util;

import android.graphics.Bitmap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.Callable;

class u implements k {
  private static final short[] a = new short[] { 
      512, 512, 456, 512, 328, 456, 335, 512, 405, 328, 
      271, 456, 388, 335, 292, 512, 454, 405, 364, 328, 
      298, 271, 496, 456, 420, 388, 360, 335, 312, 292, 
      273, 512, 482, 454, 428, 405, 383, 364, 345, 328, 
      312, 298, 284, 271, 259, 496, 475, 456, 437, 420, 
      404, 388, 374, 360, 347, 335, 323, 312, 302, 292, 
      282, 273, 265, 512, 497, 482, 468, 454, 441, 428, 
      417, 405, 394, 383, 373, 364, 354, 345, 337, 328, 
      320, 312, 305, 298, 291, 284, 278, 271, 265, 259, 
      507, 496, 485, 475, 465, 456, 446, 437, 428, 420, 
      412, 404, 396, 388, 381, 374, 367, 360, 354, 347, 
      341, 335, 329, 323, 318, 312, 307, 302, 297, 292, 
      287, 282, 278, 273, 269, 265, 261, 512, 505, 497, 
      489, 482, 475, 468, 461, 454, 447, 441, 435, 428, 
      422, 417, 411, 405, 399, 394, 389, 383, 378, 373, 
      368, 364, 359, 354, 350, 345, 341, 337, 332, 328, 
      324, 320, 316, 312, 309, 305, 301, 298, 294, 291, 
      287, 284, 281, 278, 274, 271, 268, 265, 262, 259, 
      257, 507, 501, 496, 491, 485, 480, 475, 470, 465, 
      460, 456, 451, 446, 442, 437, 433, 428, 424, 420, 
      416, 412, 408, 404, 400, 396, 392, 388, 385, 381, 
      377, 374, 370, 367, 363, 360, 357, 354, 350, 347, 
      344, 341, 338, 335, 332, 329, 326, 323, 320, 318, 
      315, 312, 310, 307, 304, 302, 299, 297, 294, 292, 
      289, 287, 285, 282, 280, 278, 275, 273, 271, 269, 
      267, 265, 263, 261, 259 };
  
  private static final byte[] b = new byte[] { 
      9, 11, 12, 13, 13, 14, 14, 15, 15, 15, 
      15, 16, 16, 16, 16, 17, 17, 17, 17, 17, 
      17, 17, 18, 18, 18, 18, 18, 18, 18, 18, 
      18, 19, 19, 19, 19, 19, 19, 19, 19, 19, 
      19, 19, 19, 19, 19, 20, 20, 20, 20, 20, 
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 
      20, 20, 20, 21, 21, 21, 21, 21, 21, 21, 
      21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 
      21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 
      22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 
      22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 
      22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 
      22, 22, 22, 22, 22, 22, 22, 23, 23, 23, 
      23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 
      23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 
      23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 
      23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 
      23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 
      23, 24, 24, 24, 24, 24, 24, 24, 24, 24, 
      24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 
      24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 
      24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 
      24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 
      24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 
      24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 
      24, 24, 24, 24, 24 };
  
  private static void b(int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    int i = paramInt1 - 1;
    int j = paramInt2 - 1;
    int m = paramInt3 * 2 + 1;
    short s = a[paramInt3];
    byte b = b[paramInt3];
    int[] arrayOfInt = new int[m];
    if (paramInt6 == 1) {
      paramInt6 = paramInt5 * paramInt2 / paramInt4;
      j = (paramInt5 + 1) * paramInt2 / paramInt4;
      paramInt4 = paramInt6;
      while (true) {
        if (paramInt4 < j) {
          long l1 = 0L;
          paramInt5 = paramInt1 * paramInt4;
          long l2 = 0L;
          long l3 = 0L;
          long l4 = 0L;
          long l5 = 0L;
          long l6 = 0L;
          paramInt2 = 0;
          long l7 = 0L;
          while (paramInt2 <= paramInt3) {
            arrayOfInt[paramInt2] = paramArrayOfint[paramInt5];
            l6 += ((paramArrayOfint[paramInt5] >>> 16 & 0xFF) * (paramInt2 + 1));
            l5 += ((paramArrayOfint[paramInt5] >>> 8 & 0xFF) * (paramInt2 + 1));
            l4 += ((paramArrayOfint[paramInt5] & 0xFF) * (paramInt2 + 1));
            l3 += (paramArrayOfint[paramInt5] >>> 16 & 0xFF);
            l2 += (paramArrayOfint[paramInt5] >>> 8 & 0xFF);
            l7 += (paramArrayOfint[paramInt5] & 0xFF);
            paramInt2++;
          } 
          long l8 = 0L;
          paramInt2 = 1;
          long l9 = 0L;
          while (paramInt2 <= paramInt3) {
            paramInt6 = paramInt5;
            if (paramInt2 <= i)
              paramInt6 = paramInt5 + 1; 
            arrayOfInt[paramInt2 + paramInt3] = paramArrayOfint[paramInt6];
            l6 += ((paramArrayOfint[paramInt6] >>> 16 & 0xFF) * (paramInt3 + 1 - paramInt2));
            l5 += ((paramArrayOfint[paramInt6] >>> 8 & 0xFF) * (paramInt3 + 1 - paramInt2));
            l4 += ((paramArrayOfint[paramInt6] & 0xFF) * (paramInt3 + 1 - paramInt2));
            l8 += (paramArrayOfint[paramInt6] >>> 16 & 0xFF);
            l9 += (paramArrayOfint[paramInt6] >>> 8 & 0xFF);
            l1 += (paramArrayOfint[paramInt6] & 0xFF);
            paramInt2++;
            paramInt5 = paramInt6;
          } 
          if (paramInt3 > i) {
            paramInt2 = i;
          } else {
            paramInt2 = paramInt3;
          } 
          paramInt6 = paramInt3;
          paramInt5 = 0;
          int n = paramInt2 + paramInt4 * paramInt1;
          int i1 = paramInt2;
          int i2 = paramInt4 * paramInt1;
          long l10 = l6;
          l6 = l8;
          long l11 = l9;
          long l12 = l1;
          l1 = l3;
          paramInt2 = paramInt6;
          l9 = l10;
          l3 = l5;
          l8 = l4;
          l5 = l11;
          l4 = l12;
          paramInt6 = i2;
          while (paramInt5 < paramInt1) {
            paramArrayOfint[paramInt6] = (int)((paramArrayOfint[paramInt6] & 0xFF000000) | (s * l9 >>> b & 0xFFL) << 16L | (s * l3 >>> b & 0xFFL) << 8L | s * l8 >>> b & 0xFFL);
            i2 = paramInt2 + m - paramInt3;
            int i3 = i2;
            if (i2 >= m)
              i3 = i2 - m; 
            l10 = (arrayOfInt[i3] >>> 16 & 0xFF);
            l12 = (arrayOfInt[i3] >>> 8 & 0xFF);
            l11 = (arrayOfInt[i3] & 0xFF);
            int i4 = n;
            i2 = i1;
            if (i1 < i) {
              i4 = n + 1;
              i2 = i1 + 1;
            } 
            arrayOfInt[i3] = paramArrayOfint[i4];
            l6 += (paramArrayOfint[i4] >>> 16 & 0xFF);
            l5 += (paramArrayOfint[i4] >>> 8 & 0xFF);
            l4 += (paramArrayOfint[i4] & 0xFF);
            l9 = l9 - l1 + l6;
            l3 = l3 - l2 + l5;
            l8 = l8 - l7 + l4;
            i1 = paramInt2 + 1;
            paramInt2 = i1;
            if (i1 >= m)
              paramInt2 = 0; 
            l1 = l1 - l10 + (arrayOfInt[paramInt2] >>> 16 & 0xFF);
            l2 = l2 - l12 + (arrayOfInt[paramInt2] >>> 8 & 0xFF);
            l7 = l7 - l11 + (arrayOfInt[paramInt2] & 0xFF);
            l6 -= (arrayOfInt[paramInt2] >>> 16 & 0xFF);
            l5 -= (arrayOfInt[paramInt2] >>> 8 & 0xFF);
            l4 -= (arrayOfInt[paramInt2] & 0xFF);
            paramInt5++;
            paramInt6++;
            n = i4;
            i1 = i2;
          } 
          paramInt4++;
          continue;
        } 
        return;
      } 
    } 
    if (paramInt6 == 2) {
      paramInt6 = paramInt5 * paramInt1 / paramInt4;
      int n = (paramInt5 + 1) * paramInt1 / paramInt4;
      paramInt4 = paramInt6;
      while (true) {
        if (paramInt4 < n) {
          long l10 = 0L;
          paramInt5 = 0;
          long l3 = 0L;
          long l7 = 0L;
          long l2 = 0L;
          long l1 = 0L;
          long l5 = 0L;
          long l9 = 0L;
          while (paramInt5 <= paramInt3) {
            arrayOfInt[paramInt5] = paramArrayOfint[paramInt4];
            l9 += ((paramArrayOfint[paramInt4] >>> 16 & 0xFF) * (paramInt5 + 1));
            l5 += ((paramArrayOfint[paramInt4] >>> 8 & 0xFF) * (paramInt5 + 1));
            l1 += ((paramArrayOfint[paramInt4] & 0xFF) * (paramInt5 + 1));
            l2 += (paramArrayOfint[paramInt4] >>> 16 & 0xFF);
            l7 += (paramArrayOfint[paramInt4] >>> 8 & 0xFF);
            l3 += (paramArrayOfint[paramInt4] & 0xFF);
            paramInt5++;
          } 
          long l11 = 0L;
          long l8 = 0L;
          paramInt5 = 1;
          paramInt6 = paramInt4;
          long l6 = l9;
          long l4 = l1;
          l9 = l11;
          l1 = l10;
          while (paramInt5 <= paramInt3) {
            int i5 = paramInt6;
            if (paramInt5 <= j)
              i5 = paramInt6 + paramInt1; 
            arrayOfInt[paramInt5 + paramInt3] = paramArrayOfint[i5];
            l6 += ((paramArrayOfint[i5] >>> 16 & 0xFF) * (paramInt3 + 1 - paramInt5));
            l5 += ((paramArrayOfint[i5] >>> 8 & 0xFF) * (paramInt3 + 1 - paramInt5));
            l4 += ((paramArrayOfint[i5] & 0xFF) * (paramInt3 + 1 - paramInt5));
            l8 += (paramArrayOfint[i5] >>> 16 & 0xFF);
            l9 += (paramArrayOfint[i5] >>> 8 & 0xFF);
            l1 += (paramArrayOfint[i5] & 0xFF);
            paramInt5++;
            paramInt6 = i5;
          } 
          if (paramInt3 > j) {
            paramInt5 = j;
          } else {
            paramInt5 = paramInt3;
          } 
          int i3 = paramInt5 * paramInt1 + paramInt4;
          int i1 = paramInt3;
          paramInt6 = 0;
          int i4 = paramInt5;
          int i2 = paramInt4;
          paramInt5 = i1;
          while (paramInt6 < paramInt2) {
            paramArrayOfint[i2] = (int)((paramArrayOfint[i2] & 0xFF000000) | (s * l6 >>> b & 0xFFL) << 16L | (s * l5 >>> b & 0xFFL) << 8L | s * l4 >>> b & 0xFFL);
            i1 = paramInt5 + m - paramInt3;
            i = i1;
            if (i1 >= m)
              i = i1 - m; 
            long l = (arrayOfInt[i] >>> 16 & 0xFF);
            l11 = (arrayOfInt[i] >>> 8 & 0xFF);
            l10 = (arrayOfInt[i] & 0xFF);
            int i5 = i3;
            i1 = i4;
            if (i4 < j) {
              i5 = i3 + paramInt1;
              i1 = i4 + 1;
            } 
            arrayOfInt[i] = paramArrayOfint[i5];
            l8 += (paramArrayOfint[i5] >>> 16 & 0xFF);
            l9 += (paramArrayOfint[i5] >>> 8 & 0xFF);
            l1 += (paramArrayOfint[i5] & 0xFF);
            l6 = l6 - l2 + l8;
            l5 = l5 - l7 + l9;
            l4 = l4 - l3 + l1;
            i4 = paramInt5 + 1;
            paramInt5 = i4;
            if (i4 >= m)
              paramInt5 = 0; 
            l2 = l2 - l + (arrayOfInt[paramInt5] >>> 16 & 0xFF);
            l7 = l7 - l11 + (arrayOfInt[paramInt5] >>> 8 & 0xFF);
            l3 = l3 - l10 + (arrayOfInt[paramInt5] & 0xFF);
            l8 -= (arrayOfInt[paramInt5] >>> 16 & 0xFF);
            l9 -= (arrayOfInt[paramInt5] >>> 8 & 0xFF);
            l1 -= (arrayOfInt[paramInt5] & 0xFF);
            paramInt6++;
            i2 += paramInt1;
            i3 = i5;
            i4 = i1;
          } 
          paramInt4++;
          continue;
        } 
        return;
      } 
    } 
  }
  
  public Bitmap a(Bitmap paramBitmap, float paramFloat) {
    int[] arrayOfInt;
    ArrayList<a> arrayList;
    int i = paramBitmap.getWidth();
    int j = paramBitmap.getHeight();
    try {
      arrayOfInt = new int[i * j];
      paramBitmap.getPixels(arrayOfInt, 0, i, 0, 0, i, j);
      int m = ad.a;
      arrayList = new ArrayList(m);
      ArrayList<a> arrayList1 = new ArrayList(m);
      for (byte b = 0; b < m; b++) {
        arrayList.add(new a(arrayOfInt, i, j, (int)paramFloat, m, b, 1));
        arrayList1.add(new a(arrayOfInt, i, j, (int)paramFloat, m, b, 2));
      } 
    } catch (OutOfMemoryError null) {
      return null;
    } 
    try {
      ad.b.invokeAll((Collection)arrayList);
      try {
        ad.b.invokeAll((Collection<? extends Callable<?>>)paramBitmap);
        try {
          paramBitmap = Bitmap.createBitmap(arrayOfInt, i, j, Bitmap.Config.ARGB_8888);
        } catch (OutOfMemoryError outOfMemoryError) {
          outOfMemoryError = null;
        } 
      } catch (InterruptedException null) {
        interruptedException = null;
      } 
    } catch (InterruptedException interruptedException) {
      interruptedException = null;
    } 
    return (Bitmap)interruptedException;
  }
  
  private static class a implements Callable<Void> {
    private final int[] a;
    
    private final int b;
    
    private final int c;
    
    private final int d;
    
    private final int e;
    
    private final int f;
    
    private final int g;
    
    public a(int[] param1ArrayOfint, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      this.a = param1ArrayOfint;
      this.b = param1Int1;
      this.c = param1Int2;
      this.d = param1Int3;
      this.e = param1Int4;
      this.f = param1Int5;
      this.g = param1Int6;
    }
    
    public Void a() {
      u.a(this.a, this.b, this.c, this.d, this.e, this.f, this.g);
      return null;
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */