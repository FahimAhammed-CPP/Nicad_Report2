package com.facebook.ads.internal.util;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import com.facebook.ads.internal.g.f;
import com.facebook.ads.internal.g.q;
import com.facebook.ads.internal.g.s;
import com.facebook.ads.internal.view.d.a.b;
import com.facebook.ads.internal.view.d.a.h;
import com.facebook.ads.internal.view.d.a.j;
import com.facebook.ads.internal.view.d.a.n;
import com.facebook.ads.internal.view.d.a.o;
import com.facebook.ads.internal.view.d.a.p;
import com.facebook.ads.internal.view.d.a.r;
import com.facebook.ads.internal.view.d.a.s;
import com.facebook.ads.internal.view.d.a.t;
import com.facebook.ads.internal.view.d.a.u;
import com.facebook.ads.internal.view.m;

public class ac extends ai {
  private final s a = new s(this) {
      static {
        boolean bool;
        if (!ac.class.desiredAssertionStatus()) {
          bool = true;
        } else {
          bool = false;
        } 
        a = bool;
      }
      
      public void a(r param1r) {
        if (!a && this.b == null)
          throw new AssertionError(); 
        if (this.b != null)
          this.b.e(); 
      }
    };
  
  private final s<p> b = new s<p>(this) {
      static {
        boolean bool;
        if (!ac.class.desiredAssertionStatus()) {
          bool = true;
        } else {
          bool = false;
        } 
        a = bool;
      }
      
      public Class<p> a() {
        return p.class;
      }
      
      public void a(p param1p) {
        if (!a && this.b == null)
          throw new AssertionError(); 
        if (this.b != null)
          this.b.h(); 
      }
    };
  
  private final s<h> c = new s<h>(this) {
      static {
        boolean bool;
        if (!ac.class.desiredAssertionStatus()) {
          bool = true;
        } else {
          bool = false;
        } 
        a = bool;
      }
      
      public Class<h> a() {
        return h.class;
      }
      
      public void a(h param1h) {
        if (!a && this.b == null)
          throw new AssertionError(); 
        if (this.b != null)
          this.b.i(); 
      }
    };
  
  private final s<j> d = new s<j>(this) {
      static {
        boolean bool;
        if (!ac.class.desiredAssertionStatus()) {
          bool = true;
        } else {
          bool = false;
        } 
        a = bool;
      }
      
      public Class<j> a() {
        return j.class;
      }
      
      public void a(j param1j) {
        if (!a && this.b == null)
          throw new AssertionError(); 
        if (this.b != null) {
          if (!ac.a(this.b)) {
            ac.a(this.b, true);
            return;
          } 
          this.b.j();
        } 
      }
    };
  
  private final s<n> e = new s<n>(this) {
      public Class<n> a() {
        return n.class;
      }
      
      public void a(n param1n) {
        this.a.a(ac.b(this.a).getCurrentPosition());
      }
    };
  
  private final s<b> f = new s<b>(this) {
      public Class<b> a() {
        return b.class;
      }
      
      public void a(b param1b) {
        this.a.b(ac.b(this.a).getDuration());
      }
    };
  
  private final s<o> g = new s<o>(this) {
      public Class<o> a() {
        return o.class;
      }
      
      public void a(o param1o) {
        this.a.a(param1o.a(), param1o.b());
      }
    };
  
  private final s<t> h = new s<t>(this) {
      public Class<t> a() {
        return t.class;
      }
      
      public void a(t param1t) {
        this.a.b();
      }
    };
  
  private final s<u> i = new s<u>(this) {
      public Class<u> a() {
        return u.class;
      }
      
      public void a(u param1u) {
        this.a.c();
      }
    };
  
  private final m j;
  
  private boolean k = false;
  
  public ac(Context paramContext, f paramf, m paramm, String paramString1, String paramString2) {
    super(paramContext, paramf, (ai.a)paramm, paramString1, paramString2);
    this.j = paramm;
    paramm.getEventBus().a((s)this.a);
    paramm.getEventBus().a(this.e);
    paramm.getEventBus().a(this.b);
    paramm.getEventBus().a(this.d);
    paramm.getEventBus().a(this.c);
    paramm.getEventBus().a(this.f);
    paramm.getEventBus().a(this.g);
    paramm.getEventBus().a(this.h);
    paramm.getEventBus().a(this.i);
  }
  
  public ac(Context paramContext, f paramf, m paramm, String paramString1, String paramString2, @Nullable Bundle paramBundle) {
    super(paramContext, paramf, (ai.a)paramm, paramString1, paramString2, paramBundle);
    this.j = paramm;
    paramm.getEventBus().a((s)this.a);
    paramm.getEventBus().a(this.e);
    paramm.getEventBus().a(this.b);
    paramm.getEventBus().a(this.d);
    paramm.getEventBus().a(this.c);
    paramm.getEventBus().a(this.f);
    paramm.getEventBus().a(this.h);
    paramm.getEventBus().a(this.i);
  }
  
  public void a() {
    this.j.getEventBus().b((s)this.a);
    this.j.getEventBus().b(this.e);
    this.j.getEventBus().b(this.b);
    this.j.getEventBus().b(this.d);
    this.j.getEventBus().b(this.c);
    this.j.getEventBus().b(this.f);
    this.j.getEventBus().b(this.h);
    this.j.getEventBus().b(this.i);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/ac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */