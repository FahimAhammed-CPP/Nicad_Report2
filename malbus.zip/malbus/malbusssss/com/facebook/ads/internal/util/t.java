package com.facebook.ads.internal.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Base64;

public class t {
  public static Bitmap a(Context paramContext, r paramr) {
    byte[] arrayOfByte = Base64.decode(paramr.a((paramContext.getResources().getDisplayMetrics()).density), 0);
    return BitmapFactory.decodeByteArray(arrayOfByte, 0, arrayOfByte.length);
  }
  
  public static Drawable b(Context paramContext, r paramr) {
    return (Drawable)new BitmapDrawable(paramContext.getResources(), a(paramContext, paramr));
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */