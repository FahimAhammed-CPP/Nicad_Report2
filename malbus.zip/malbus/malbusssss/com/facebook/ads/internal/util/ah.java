package com.facebook.ads.internal.util;

import java.util.Iterator;
import java.util.Set;

public class ah {
  public static String a(Set<String> paramSet, String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    Iterator<String> iterator = paramSet.iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      stringBuilder.append(paramString);
    } 
    return (stringBuilder.length() > 0) ? stringBuilder.substring(0, stringBuilder.length() - 1) : "";
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/ah.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */