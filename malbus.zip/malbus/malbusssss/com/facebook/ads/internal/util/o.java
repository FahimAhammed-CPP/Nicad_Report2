package com.facebook.ads.internal.util;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Context;
import android.os.Build;
import android.os.PowerManager;
import android.util.Log;
import android.view.Window;
import java.io.File;

public class o {
  private static final String a = o.class.getSimpleName();
  
  public static a a() {
    a a;
    try {
      boolean bool;
      if (c() || b() || a("su")) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        return a.c; 
      a = a.b;
    } catch (Throwable throwable) {
      a = a.a;
    } 
    return a;
  }
  
  public static boolean a(Context paramContext) {
    return (b(paramContext) && c(paramContext));
  }
  
  private static boolean a(String paramString) {
    boolean bool = false;
    String[] arrayOfString = System.getenv("PATH").split(":");
    int i = arrayOfString.length;
    byte b = 0;
    label20: while (true) {
      boolean bool1 = bool;
      if (b < i) {
        File file = new File(arrayOfString[b]);
        if (file.exists()) {
          if (!file.isDirectory())
            continue; 
          File[] arrayOfFile = file.listFiles();
          if (arrayOfFile != null) {
            int j = arrayOfFile.length;
            byte b1 = 0;
            while (true) {
              if (b1 < j) {
                if (arrayOfFile[b1].getName().equals(paramString))
                  return true; 
                b1++;
                continue;
              } 
              b++;
              continue label20;
            } 
            break;
          } 
          continue;
        } 
        continue;
      } 
      continue;
    } 
  }
  
  private static boolean b() {
    String str = Build.TAGS;
    return (str != null && str.contains("test-keys"));
  }
  
  public static boolean b(Context paramContext) {
    boolean bool;
    if (paramContext == null) {
      Log.v(a, "Invalid context in screen interactive check, assuming interactive.");
      return true;
    } 
    try {
      PowerManager powerManager = (PowerManager)paramContext.getSystemService("power");
      if (Build.VERSION.SDK_INT >= 20)
        return powerManager.isInteractive(); 
      bool = powerManager.isScreenOn();
    } catch (Exception exception) {
      Log.e(a, "Exception in screen interactive check, assuming interactive.", exception);
      bool = true;
    } 
    return bool;
  }
  
  private static boolean c() {
    return (new File("/system/app/Superuser.apk")).exists();
  }
  
  public static boolean c(Context paramContext) {
    boolean bool2;
    boolean bool1 = true;
    if (paramContext == null || !(paramContext instanceof Activity)) {
      Log.v(a, "Invalid Activity context in window interactive check, assuming interactive.");
      return bool1;
    } 
    try {
      Window window = ((Activity)paramContext).getWindow();
      if (window != null) {
        int i = (window.getAttributes()).flags;
        boolean bool = bool1;
        if ((0x400000 & i) == 0) {
          bool = bool1;
          if ((i & 0x80000) == 0) {
            if (!((KeyguardManager)paramContext.getSystemService("keyguard")).inKeyguardRestrictedInputMode())
              return true; 
            bool = false;
          } 
        } 
        return bool;
      } 
      Log.v(a, "Invalid window in window interactive check, assuming interactive.");
      bool2 = bool1;
    } catch (Exception exception) {
      Log.e(a, "Exception in window interactive check, assuming interactive.", exception);
      bool2 = bool1;
    } 
    return bool2;
  }
  
  public enum a {
    a(0),
    b(1),
    c(2);
    
    public final int d;
    
    a(int param1Int1) {
      this.d = param1Int1;
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */