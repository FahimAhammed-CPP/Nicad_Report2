package com.facebook.ads.internal.util;

import java.io.PrintWriter;
import java.io.StringWriter;

public class af {
  public static final String a(Throwable paramThrowable) {
    if (paramThrowable == null)
      return null; 
    StringWriter stringWriter = new StringWriter();
    PrintWriter printWriter = new PrintWriter(stringWriter);
    paramThrowable.printStackTrace(printWriter);
    printWriter.close();
    return stringWriter.toString();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/af.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */