package com.facebook.ads.internal.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ImageView;
import com.facebook.ads.internal.c.c;
import com.facebook.ads.internal.view.e;

public class p extends AsyncTask<String, Void, Bitmap[]> {
  private static final String a = p.class.getSimpleName();
  
  private final Context b;
  
  private final ImageView c;
  
  private final e d;
  
  private q e;
  
  public p(ImageView paramImageView) {
    this.b = paramImageView.getContext();
    this.d = null;
    this.c = paramImageView;
  }
  
  public p(e parame) {
    this.b = parame.getContext();
    this.d = parame;
    this.c = null;
  }
  
  public p a(q paramq) {
    this.e = paramq;
    return this;
  }
  
  protected void a(Bitmap[] paramArrayOfBitmap) {
    if (this.c != null)
      this.c.setImageBitmap(paramArrayOfBitmap[0]); 
    if (this.d != null)
      this.d.a(paramArrayOfBitmap[0], paramArrayOfBitmap[1]); 
    if (this.e != null)
      this.e.a(); 
  }
  
  public void a(String... paramVarArgs) {
    executeOnExecutor(THREAD_POOL_EXECUTOR, (Object[])paramVarArgs);
  }
  
  protected Bitmap[] b(String... paramVarArgs) {
    Bitmap bitmap;
    ad ad = null;
    String str = paramVarArgs[0];
    try {
      Bitmap bitmap1 = c.a(this.b).a(str);
      try {
        e e1 = this.d;
        ad ad1 = ad;
        Bitmap bitmap2 = bitmap1;
        if (e1 != null) {
          ad1 = ad;
          bitmap2 = bitmap1;
          if (bitmap1 != null) {
            try {
              ad1 = new ad();
              this(bitmap1);
              ad1.a(Math.round(bitmap1.getWidth() / 40.0F));
              bitmap = ad1.a();
              bitmap2 = bitmap1;
              return new Bitmap[] { bitmap2, bitmap };
            } catch (Throwable null) {
              Bitmap bitmap3 = bitmap1;
              bitmap = bitmap1;
              bitmap1 = bitmap3;
            } 
          } else {
            return new Bitmap[] { (Bitmap)throwable, bitmap };
          } 
        } else {
          return new Bitmap[] { (Bitmap)throwable, bitmap };
        } 
      } catch (Throwable null) {
        bitmap = null;
      } 
    } catch (Throwable throwable) {
      paramVarArgs = null;
      bitmap = null;
    } 
    Log.e(a, "Error downloading image: " + str, throwable);
    d.a(c.a(throwable, null));
    String[] arrayOfString = paramVarArgs;
    return new Bitmap[] { (Bitmap)arrayOfString, bitmap };
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */