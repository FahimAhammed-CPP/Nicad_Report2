package com.facebook.ads.internal.util;

import android.text.TextUtils;
import com.facebook.ads.internal.view.a.d;

public class m {
  private final d a;
  
  private boolean b = true;
  
  public m(d paramd) {
    this.a = paramd;
  }
  
  private static long a(String paramString1, String paramString2) {
    long l2;
    long l1 = -1L;
    paramString1 = paramString1.substring(paramString2.length());
    if (TextUtils.isEmpty(paramString1))
      return l1; 
    try {
      Long long_ = Long.valueOf(Long.parseLong(paramString1));
      l2 = l1;
      if (long_.longValue() >= 0L)
        l2 = long_.longValue(); 
    } catch (NumberFormatException numberFormatException) {
      l2 = l1;
    } 
    return l2;
  }
  
  public void a() {
    if (this.b) {
      if (this.a.canGoBack() || this.a.canGoForward()) {
        this.b = false;
        return;
      } 
      this.a.b("void((function() {try {  if (!window.performance || !window.performance.timing || !document ||       !document.body || document.body.scrollHeight <= 0 ||       !document.body.children || document.body.children.length < 1) {    return;  }  var nvtiming__an_t = window.performance.timing;  if (nvtiming__an_t.responseEnd > 0) {    console.log('ANNavResponseEnd:'+nvtiming__an_t.responseEnd);  }  if (nvtiming__an_t.domContentLoadedEventStart > 0) {    console.log('ANNavDomContentLoaded:' + nvtiming__an_t.domContentLoadedEventStart);  }  if (nvtiming__an_t.loadEventEnd > 0) {    console.log('ANNavLoadEventEnd:' + nvtiming__an_t.loadEventEnd);  }} catch(err) {  console.log('an_navigation_timing_error:' + err.message);}})());");
    } 
  }
  
  public void a(String paramString) {
    if (this.b) {
      if (paramString.startsWith("ANNavResponseEnd:")) {
        this.a.a(a(paramString, "ANNavResponseEnd:"));
        return;
      } 
      if (paramString.startsWith("ANNavDomContentLoaded:")) {
        this.a.b(a(paramString, "ANNavDomContentLoaded:"));
        return;
      } 
      if (paramString.startsWith("ANNavLoadEventEnd:"))
        this.a.c(a(paramString, "ANNavLoadEventEnd:")); 
    } 
  }
  
  public void a(boolean paramBoolean) {
    this.b = paramBoolean;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */