package com.facebook.ads.internal.util;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class j {
  private final String a;
  
  private final String b;
  
  private final String c;
  
  private final List<String> d;
  
  private final String e;
  
  private final String f;
  
  private j(String paramString1, String paramString2, String paramString3, List<String> paramList, String paramString4, String paramString5) {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
    this.d = paramList;
    this.e = paramString4;
    this.f = paramString5;
  }
  
  public static j a(JSONObject paramJSONObject) {
    if (paramJSONObject == null)
      return null; 
    String str1 = paramJSONObject.optString("package");
    String str2 = paramJSONObject.optString("appsite");
    String str3 = paramJSONObject.optString("appsite_url");
    JSONArray jSONArray = paramJSONObject.optJSONArray("key_hashes");
    ArrayList<String> arrayList = new ArrayList();
    if (jSONArray != null)
      for (byte b = 0; b < jSONArray.length(); b++)
        arrayList.add(jSONArray.optString(b));  
    return new j(str1, str2, str3, arrayList, paramJSONObject.optString("market_uri"), paramJSONObject.optString("fallback_url"));
  }
  
  public String a() {
    return this.a;
  }
  
  public String b() {
    return this.b;
  }
  
  public String c() {
    return this.c;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */