package com.facebook.ads.internal.util;

import android.graphics.Bitmap;

interface k {
  Bitmap a(Bitmap paramBitmap, float paramFloat);
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */