package com.facebook.ads.internal.util;

public enum aj {
  a(0),
  b(1),
  c(2);
  
  private final int d;
  
  aj(int paramInt1) {
    this.d = paramInt1;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/aj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */