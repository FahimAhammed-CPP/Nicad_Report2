package com.facebook.ads.internal.util;

import android.content.Context;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import com.facebook.ads.internal.b.c;
import com.facebook.ads.internal.g.f;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ai implements ae<Bundle> {
  private final String a;
  
  private boolean b = true;
  
  private final Context c;
  
  private final f d;
  
  private final a e;
  
  private final String f;
  
  private final com.facebook.ads.internal.b.a g;
  
  private int h = 0;
  
  private int i = 0;
  
  private final ab j;
  
  public ai(Context paramContext, f paramf, a parama, String paramString1, String paramString2) {
    this(paramContext, paramf, parama, paramString1, paramString2, null);
  }
  
  public ai(Context paramContext, f paramf, a parama, String paramString1, String paramString2, @Nullable Bundle paramBundle) {
    this.c = paramContext;
    this.d = paramf;
    this.e = parama;
    this.f = paramString1;
    this.a = paramString2;
    ArrayList<com.facebook.ads.internal.b.b> arrayList = new ArrayList();
    arrayList.add(new com.facebook.ads.internal.b.b(this, 0.5D, -1.0D, 2.0D, true, paramString2, paramf) {
          protected void a(boolean param1Boolean1, boolean param1Boolean2, c param1c) {
            if (this.g.a(ai.b.d) != null) {
              if (!this.e.isEmpty()) {
                this.f.d(this.e, ai.a(this.g, ai.b.d));
                return;
              } 
            } else {
              return;
            } 
            this.f.a(this.g.a(ai.b.d), ai.a(this.g));
          }
        });
    arrayList.add(new com.facebook.ads.internal.b.b(this, 1.0E-7D, -1.0D, 0.001D, false, paramString2, paramf) {
          protected void a(boolean param1Boolean1, boolean param1Boolean2, c param1c) {
            if (!this.e.isEmpty()) {
              this.f.d(this.e, ai.a(this.g, ai.b.i));
              return;
            } 
            String str = this.g.a(ai.b.i);
            if (str != null)
              this.f.a(str, ai.a(this.g)); 
          }
        });
    if (paramBundle != null) {
      this.g = new com.facebook.ads.internal.b.a(paramContext, (View)parama, arrayList, paramBundle.getBundle("adQualityManager"));
      this.h = paramBundle.getInt("lastProgressTimeMS");
      this.i = paramBundle.getInt("lastBoundaryTimeMS");
    } else {
      this.g = new com.facebook.ads.internal.b.a(paramContext, (View)parama, arrayList);
    } 
    this.j = new ab(new Handler(), this);
  }
  
  private Map<String, String> a() {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    boolean bool = this.e.a();
    if (!this.e.c()) {
      boolean bool2 = true;
      ak.a((Map)hashMap, bool, bool2);
      a((Map)hashMap);
      b((Map)hashMap);
      c((Map)hashMap);
      d((Map)hashMap);
      return (Map)hashMap;
    } 
    boolean bool1 = false;
    ak.a((Map)hashMap, bool, bool1);
    a((Map)hashMap);
    b((Map)hashMap);
    c((Map)hashMap);
    d((Map)hashMap);
    return (Map)hashMap;
  }
  
  private void a(int paramInt, boolean paramBoolean) {
    if (paramInt > 0.0D && paramInt >= this.h) {
      this.g.a(((paramInt - this.h) / 1000.0F), d());
      this.h = paramInt;
      if (paramInt - this.i >= 5000) {
        if (!this.a.isEmpty()) {
          this.d.d(this.a, b(b.c));
        } else if (a(b.c) != null) {
          this.d.a(a(b.c), a());
        } 
        this.i += 5000;
        this.g.a();
      } 
      if (paramBoolean) {
        if (!this.a.isEmpty()) {
          Map<String, String> map = b(b.c);
          map.put("time", String.valueOf(paramInt / 1000.0D));
          this.d.d(this.a, map);
          return;
        } 
        if (a(b.c) != null) {
          Map<String, String> map = a();
          map.put("time", String.valueOf(paramInt / 1000.0D));
          this.d.a(a(b.c), map);
        } 
      } 
    } 
  }
  
  private void a(Map<String, String> paramMap) {
    paramMap.put("exoplayer", String.valueOf(this.e.b()));
    paramMap.put("prep", Long.toString(this.e.getInitialBufferTime()));
  }
  
  private Map<String, String> b(b paramb) {
    Map<String, String> map = a();
    map.put("action", String.valueOf(paramb.j));
    return map;
  }
  
  private void b(Map<String, String> paramMap) {
    c c = this.g.b();
    c.a a2 = c.b();
    paramMap.put("vwa", String.valueOf(a2.c()));
    paramMap.put("vwm", String.valueOf(a2.b()));
    paramMap.put("vwmax", String.valueOf(a2.d()));
    paramMap.put("vtime_ms", String.valueOf(a2.f() * 1000.0D));
    paramMap.put("mcvt_ms", String.valueOf(a2.g() * 1000.0D));
    c.a a1 = c.c();
    paramMap.put("vla", String.valueOf(a1.c()));
    paramMap.put("vlm", String.valueOf(a1.b()));
    paramMap.put("vlmax", String.valueOf(a1.d()));
    paramMap.put("atime_ms", String.valueOf(a1.f() * 1000.0D));
    paramMap.put("mcat_ms", String.valueOf(a1.g() * 1000.0D));
  }
  
  private void c(Map<String, String> paramMap) {
    paramMap.put("ptime", String.valueOf(this.i / 1000.0F));
    paramMap.put("time", String.valueOf((this.i + 5000) / 1000.0F));
  }
  
  private void d(Map<String, String> paramMap) {
    Rect rect = new Rect();
    this.e.getGlobalVisibleRect(rect);
    paramMap.put("pt", String.valueOf(rect.top));
    paramMap.put("pl", String.valueOf(rect.left));
    paramMap.put("ph", String.valueOf(this.e.getMeasuredHeight()));
    paramMap.put("pw", String.valueOf(this.e.getMeasuredWidth()));
    WindowManager windowManager = (WindowManager)this.c.getSystemService("window");
    DisplayMetrics displayMetrics = new DisplayMetrics();
    windowManager.getDefaultDisplay().getMetrics(displayMetrics);
    paramMap.put("vph", String.valueOf(displayMetrics.heightPixels));
    paramMap.put("vpw", String.valueOf(displayMetrics.widthPixels));
  }
  
  protected String a(b paramb) {
    return this.f + "&action=" + paramb.j;
  }
  
  public void a(int paramInt) {
    a(paramInt, false);
  }
  
  public void a(int paramInt1, int paramInt2) {
    a(paramInt1, true);
    this.i = paramInt2;
    this.h = paramInt2;
    this.g.a();
  }
  
  public void b() {
    this.c.getContentResolver().registerContentObserver(Settings.System.CONTENT_URI, true, this.j);
  }
  
  public void b(int paramInt) {
    a(paramInt, true);
    this.i = 0;
    this.h = 0;
    this.g.a();
  }
  
  public void c() {
    this.c.getContentResolver().unregisterContentObserver(this.j);
  }
  
  protected float d() {
    return ak.a(this.c) * this.e.getVolume();
  }
  
  public void e() {
    if (d() < 0.05D) {
      if (this.b) {
        f();
        this.b = false;
      } 
      return;
    } 
    if (!this.b) {
      g();
      this.b = true;
    } 
  }
  
  public void f() {
    if (!this.a.isEmpty()) {
      this.d.d(this.a, b(b.g));
      return;
    } 
    this.d.a(a(b.g), a());
  }
  
  public void g() {
    if (!this.a.isEmpty()) {
      this.d.d(this.a, b(b.h));
      return;
    } 
    this.d.a(a(b.h), a());
  }
  
  public Bundle getSaveInstanceState() {
    Bundle bundle = new Bundle();
    bundle.putInt("lastProgressTimeMS", this.h);
    bundle.putInt("lastBoundaryTimeMS", this.i);
    bundle.putBundle("adQualityManager", this.g.getSaveInstanceState());
    return bundle;
  }
  
  public void h() {
    if (!this.a.isEmpty()) {
      this.d.d(this.a, b(b.b));
      return;
    } 
    this.d.a(a(b.b), a());
  }
  
  public void i() {
    if (!this.a.isEmpty()) {
      this.d.d(this.a, b(b.e));
      return;
    } 
    this.d.a(a(b.e), a());
  }
  
  public void j() {
    if (!this.a.isEmpty()) {
      this.d.d(this.a, b(b.f));
      return;
    } 
    this.d.a(a(b.f), a());
  }
  
  public int k() {
    return this.h;
  }
  
  public static interface a {
    boolean a();
    
    boolean b();
    
    boolean c();
    
    boolean getGlobalVisibleRect(Rect param1Rect);
    
    long getInitialBufferTime();
    
    int getMeasuredHeight();
    
    int getMeasuredWidth();
    
    float getVolume();
  }
  
  protected enum b {
    a(0),
    b(1),
    c(2),
    d(3),
    e(4),
    f(5),
    g(6),
    h(7),
    i(10);
    
    public final int j;
    
    b(int param1Int1) {
      this.j = param1Int1;
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/ai.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */