package com.facebook.ads.internal.util;

import android.annotation.TargetApi;
import android.os.Build;
import android.text.TextUtils;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.facebook.ads.AdSettings;

public class i {
  public static String a() {
    null = AdSettings.getUrlPrefix();
    return TextUtils.isEmpty(null) ? "https://www.facebook.com/" : String.format("https://www.%s.facebook.com", new Object[] { null });
  }
  
  public static void a(WebView paramWebView) {
    paramWebView.loadUrl("about:blank");
    paramWebView.clearCache(true);
  }
  
  @TargetApi(21)
  public static void b(WebView paramWebView) {
    WebSettings webSettings = paramWebView.getSettings();
    if (Build.VERSION.SDK_INT >= 21) {
      webSettings.setMixedContentMode(0);
      return;
    } 
    try {
      WebSettings.class.getMethod("setMixedContentMode", new Class[0]).invoke(webSettings, new Object[] { Integer.valueOf(0) });
    } catch (Exception exception) {}
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */