package com.facebook.ads.internal.util;

import android.database.ContentObserver;
import android.os.Handler;

class ab extends ContentObserver {
  private final ai a;
  
  public ab(Handler paramHandler, ai paramai) {
    super(paramHandler);
    this.a = paramai;
  }
  
  public boolean deliverSelfNotifications() {
    return false;
  }
  
  public void onChange(boolean paramBoolean) {
    this.a.e();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/util/ab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */