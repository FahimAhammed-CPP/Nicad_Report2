package com.facebook.ads.internal.server;

import com.facebook.ads.internal.f.d;

public class e extends d {
  public e(d paramd) {
    super(d.a.c, paramd);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/server/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */