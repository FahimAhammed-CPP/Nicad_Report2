package com.facebook.ads.internal.server;

import com.facebook.ads.internal.f.d;

public class f extends d {
  private final String a;
  
  private final int b;
  
  public f(String paramString, int paramInt, d paramd) {
    super(d.a.b, paramd);
    this.b = paramInt;
    this.a = paramString;
  }
  
  public String c() {
    return this.a;
  }
  
  public int d() {
    return this.b;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/server/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */