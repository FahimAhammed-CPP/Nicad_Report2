package com.facebook.ads.internal.server;

import android.text.TextUtils;
import com.facebook.ads.internal.f.a;
import com.facebook.ads.internal.f.d;
import com.facebook.ads.internal.f.e;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class c {
  private static c a = new c();
  
  public static c a() {
    // Byte code:
    //   0: ldc com/facebook/ads/internal/server/c
    //   2: monitorenter
    //   3: getstatic com/facebook/ads/internal/server/c.a : Lcom/facebook/ads/internal/server/c;
    //   6: astore_0
    //   7: ldc com/facebook/ads/internal/server/c
    //   9: monitorexit
    //   10: aload_0
    //   11: areturn
    //   12: astore_0
    //   13: ldc com/facebook/ads/internal/server/c
    //   15: monitorexit
    //   16: aload_0
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	12	finally
  }
  
  private e a(JSONObject paramJSONObject) {
    byte b = 0;
    JSONObject jSONObject = paramJSONObject.getJSONArray("placements").getJSONObject(0);
    d d = new d(e.a(jSONObject.getJSONObject("definition")), jSONObject.optString("feature_config"));
    if (jSONObject.has("ads")) {
      JSONArray jSONArray = jSONObject.getJSONArray("ads");
      while (b < jSONArray.length()) {
        JSONObject jSONObject1 = jSONArray.getJSONObject(b);
        d.a(new a(jSONObject1.optString("adapter"), jSONObject1.optJSONObject("data"), jSONObject1.optJSONArray("trackers")));
        b++;
      } 
    } 
    return new e(d);
  }
  
  private f b(JSONObject paramJSONObject) {
    f f;
    try {
      JSONObject jSONObject = paramJSONObject.getJSONArray("placements").getJSONObject(0);
      e e = e.a(jSONObject.getJSONObject("definition"));
      String str1 = jSONObject.optString("feature_config");
      f f1 = new f();
      String str2 = paramJSONObject.optString("message", "");
      int i = paramJSONObject.optInt("code", 0);
      d d = new d();
      this(e, str1);
      this(str2, i, d);
      f = f1;
    } catch (JSONException jSONException) {
      f = c((JSONObject)f);
    } 
    return f;
  }
  
  private f c(JSONObject paramJSONObject) {
    return new f(paramJSONObject.optString("message", ""), paramJSONObject.optInt("code", 0), null);
  }
  
  public d a(String paramString) {
    if (!TextUtils.isEmpty(paramString)) {
      JSONObject jSONObject1;
      JSONObject jSONObject2 = new JSONObject(paramString);
      paramString = jSONObject2.optString("type");
      byte b = -1;
      switch (paramString.hashCode()) {
        default:
          switch (b) {
            default:
              jSONObject1 = jSONObject2.optJSONObject("error");
              if (jSONObject1 != null)
                return c(jSONObject1); 
              break;
            case 0:
              return a(jSONObject2);
            case 1:
              break;
          } 
          return b(jSONObject2);
        case 96432:
          if (jSONObject1.equals("ads"))
            b = 0; 
        case 96784904:
          if (jSONObject1.equals("error"))
            b = 1; 
      } 
    } 
    return new d(d.a.a, null);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/server/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */