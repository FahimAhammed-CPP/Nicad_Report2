package com.facebook.ads.internal.server;

import android.content.Context;
import com.facebook.ads.internal.AdErrorType;
import com.facebook.ads.internal.b;
import com.facebook.ads.internal.f.d;
import com.facebook.ads.internal.f.f;
import com.facebook.ads.internal.f.i;
import com.facebook.ads.internal.h;
import com.facebook.ads.internal.i.a.b;
import com.facebook.ads.internal.i.a.m;
import com.facebook.ads.internal.i.a.n;
import com.facebook.ads.internal.util.aa;
import com.facebook.ads.internal.util.e;
import com.facebook.ads.internal.util.x;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import org.json.JSONException;

public class a {
  private static final aa i = new aa();
  
  private static final ThreadPoolExecutor j = (ThreadPoolExecutor)Executors.newCachedThreadPool((ThreadFactory)i);
  
  Map<String, String> a;
  
  private final Context b;
  
  private final c c;
  
  private final h d;
  
  private a e;
  
  private f f;
  
  private com.facebook.ads.internal.i.a.a g;
  
  private final String h;
  
  public a(Context paramContext) {
    this.b = paramContext.getApplicationContext();
    this.c = c.a();
    this.d = new h(this.b);
    this.h = b.a();
  }
  
  private void a(b paramb) {
    if (this.e != null)
      this.e.a(paramb); 
    a();
  }
  
  private void a(e parame) {
    if (this.e != null)
      this.e.a(parame); 
    a();
  }
  
  private void a(String paramString) {
    try {
      d = this.c.a(paramString);
      d d1 = d.b();
      if (d1 != null) {
        this.d.a(d1.b());
        e.a(d1.a().c(), this.f);
      } 
      switch (null.a[d.a().ordinal()]) {
        default:
          a(AdErrorType.UNKNOWN_RESPONSE.getAdErrorWrapper(paramString));
          return;
        case 1:
          d = d;
          if (d1 != null && d1.a().d())
            e.a(paramString, this.f); 
          a((e)d);
          return;
        case 2:
          break;
      } 
    } catch (Exception exception) {
      a(AdErrorType.PARSER_FAILURE.getAdErrorWrapper(exception.getMessage()));
      return;
    } 
    d d = d;
    String str = d.c();
    AdErrorType adErrorType = AdErrorType.adErrorTypeFromCode(d.d(), AdErrorType.ERROR_MESSAGE);
    if (str != null)
      paramString = str; 
    a(adErrorType.getAdErrorWrapper(paramString));
  }
  
  private b b() {
    return new b(this) {
        public void a(m param1m) {
          e.b(a.e(this.a));
          a.a(this.a, (com.facebook.ads.internal.i.a.a)null);
          try {
            n n = param1m.a();
            if (n != null) {
              String str = n.e();
              d d = a.f(this.a).a(str);
              if (d.a() == d.a.b) {
                f f = (f)d;
                String str1 = f.c();
                AdErrorType adErrorType = AdErrorType.adErrorTypeFromCode(f.d(), AdErrorType.ERROR_MESSAGE);
                a a1 = this.a;
                if (str1 != null)
                  str = str1; 
                a.a(a1, adErrorType.getAdErrorWrapper(str));
                return;
              } 
            } 
          } catch (JSONException jSONException) {}
          a.a(this.a, new b(AdErrorType.NETWORK_ERROR, param1m.getMessage()));
        }
        
        public void a(n param1n) {
          if (param1n != null) {
            String str = param1n.e();
            e.b(a.e(this.a));
            a.a(this.a, (com.facebook.ads.internal.i.a.a)null);
            a.a(this.a, str);
          } 
        }
        
        public void a(Exception param1Exception) {
          if (m.class.equals(param1Exception.getClass())) {
            a((m)param1Exception);
            return;
          } 
          a.a(this.a, new b(AdErrorType.NETWORK_ERROR, param1Exception.getMessage()));
        }
      };
  }
  
  public void a() {
    if (this.g != null) {
      this.g.c(1);
      this.g.b(1);
      this.g = null;
    } 
  }
  
  public void a(f paramf) {
    String str;
    a();
    if (x.c(this.b) == x.a.b) {
      a(new b(AdErrorType.NETWORK_ERROR, "No network connection"));
      return;
    } 
    this.f = paramf;
    com.facebook.ads.internal.util.a.a(this.b);
    if (e.a(paramf)) {
      str = e.c(paramf);
      if (str != null) {
        a(str);
        return;
      } 
      a(AdErrorType.LOAD_TOO_FREQUENTLY.getAdErrorWrapper(null));
      return;
    } 
    j.submit(new Runnable(this, (f)str) {
          public void run() {
            i.b(a.a(this.b));
            this.b.a = this.a.e();
            try {
              a.a(this.b, x.b(a.a(this.b), this.a.e));
              a.c(this.b).a(a.b(this.b), a.c(this.b).b().a(this.b.a), a.d(this.b));
            } catch (Exception exception) {
              a.a(this.b, AdErrorType.AD_REQUEST_FAILED.getAdErrorWrapper(exception.getMessage()));
            } 
          }
        });
  }
  
  public void a(a parama) {
    this.e = parama;
  }
  
  public static interface a {
    void a(b param1b);
    
    void a(e param1e);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/server/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */