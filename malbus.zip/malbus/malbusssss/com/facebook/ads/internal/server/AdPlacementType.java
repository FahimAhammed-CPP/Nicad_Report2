package com.facebook.ads.internal.server;

import android.text.TextUtils;
import java.util.Locale;

public enum AdPlacementType {
  BANNER,
  INSTREAM,
  INTERSTITIAL,
  NATIVE,
  REWARDED_VIDEO,
  UNKNOWN("unknown");
  
  private String a;
  
  static {
    BANNER = new AdPlacementType("BANNER", 1, "banner");
    INTERSTITIAL = new AdPlacementType("INTERSTITIAL", 2, "interstitial");
    NATIVE = new AdPlacementType("NATIVE", 3, "native");
    INSTREAM = new AdPlacementType("INSTREAM", 4, "instream");
    REWARDED_VIDEO = new AdPlacementType("REWARDED_VIDEO", 5, "rewarded_video");
    b = new AdPlacementType[] { UNKNOWN, BANNER, INTERSTITIAL, NATIVE, INSTREAM, REWARDED_VIDEO };
  }
  
  AdPlacementType(String paramString1) {
    this.a = paramString1;
  }
  
  public static AdPlacementType fromString(String paramString) {
    AdPlacementType adPlacementType;
    if (TextUtils.isEmpty(paramString))
      return UNKNOWN; 
    try {
      adPlacementType = valueOf(paramString.toUpperCase(Locale.US));
    } catch (Exception exception) {
      adPlacementType = UNKNOWN;
    } 
    return adPlacementType;
  }
  
  public String toString() {
    return this.a;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/server/AdPlacementType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */