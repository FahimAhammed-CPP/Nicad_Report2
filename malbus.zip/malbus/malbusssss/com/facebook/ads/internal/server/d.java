package com.facebook.ads.internal.server;

public class d {
  private com.facebook.ads.internal.f.d a;
  
  private a b;
  
  public d(a parama, com.facebook.ads.internal.f.d paramd) {
    this.b = parama;
    this.a = paramd;
  }
  
  public a a() {
    return this.b;
  }
  
  public com.facebook.ads.internal.f.d b() {
    return this.a;
  }
  
  public enum a {
    a, b, c;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/server/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */