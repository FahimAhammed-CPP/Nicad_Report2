package com.facebook.ads.internal.server;

import android.text.TextUtils;
import com.facebook.ads.AdSettings;

public class b {
  public static String a() {
    null = AdSettings.getUrlPrefix();
    return TextUtils.isEmpty(null) ? "https://graph.facebook.com/network_ads_common" : String.format("https://graph.%s.facebook.com/network_ads_common", new Object[] { null });
  }
  
  public static String b() {
    null = AdSettings.getUrlPrefix();
    return TextUtils.isEmpty(null) ? "https://www.facebook.com/adnw_logging/" : String.format("https://www.%s.facebook.com/adnw_logging/", new Object[] { null });
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/server/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */