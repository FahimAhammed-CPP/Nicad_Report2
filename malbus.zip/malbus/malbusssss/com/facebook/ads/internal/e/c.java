package com.facebook.ads.internal.e;

import android.content.ContentValues;
import android.database.Cursor;
import android.support.annotation.WorkerThread;
import java.util.Map;
import java.util.UUID;
import org.json.JSONObject;

public class c extends h {
  public static final b a = new b(0, "crash_id", "TEXT PRIMARY KEY");
  
  public static final b b = new b(1, "priority", "INTEGER");
  
  public static final b c = new b(2, "type", "TEXT");
  
  public static final b d = new b(3, "time", "REAL");
  
  public static final b e = new b(4, "session_time", "REAL");
  
  public static final b f = new b(5, "session_id", "TEXT");
  
  public static final b g = new b(6, "data", "TEXT");
  
  public static final b[] h = new b[] { a, b, c, d, e, f, g };
  
  private static final String i = a("crashes", h);
  
  public c(e parame) {
    super(parame);
  }
  
  public String a() {
    return "crashes";
  }
  
  String a(int paramInt, String paramString1, double paramDouble1, double paramDouble2, String paramString2, Map<String, String> paramMap) {
    String str = UUID.randomUUID().toString();
    ContentValues contentValues = new ContentValues(7);
    contentValues.put(a.b, str);
    contentValues.put(b.b, Integer.valueOf(paramInt));
    contentValues.put(c.b, paramString1);
    contentValues.put(d.b, Double.valueOf(paramDouble1));
    contentValues.put(e.b, Double.valueOf(paramDouble2));
    contentValues.put(f.b, paramString2);
    paramString2 = g.b;
    if (paramMap != null) {
      paramString1 = (new JSONObject(paramMap)).toString();
      contentValues.put(paramString2, paramString1);
      e().insertOrThrow("crashes", null, contentValues);
      return str;
    } 
    paramString1 = null;
    contentValues.put(paramString2, paramString1);
    e().insertOrThrow("crashes", null, contentValues);
    return str;
  }
  
  @WorkerThread
  public boolean a(String paramString) {
    boolean bool = true;
    if (e().delete("crashes", a.b + " = ?", new String[] { paramString }) <= 0)
      bool = false; 
    return bool;
  }
  
  public b[] b() {
    return h;
  }
  
  @WorkerThread
  Cursor c() {
    return e().rawQuery(i, null);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/e/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */