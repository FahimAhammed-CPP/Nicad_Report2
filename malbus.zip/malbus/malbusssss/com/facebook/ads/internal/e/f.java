package com.facebook.ads.internal.e;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class f extends SQLiteOpenHelper {
  private final e a;
  
  public f(Context paramContext, e parame) {
    super(paramContext, "ads.db", null, 2);
    if (parame == null)
      throw new IllegalArgumentException("AdDatabaseHelper can not be null"); 
    this.a = parame;
  }
  
  public void onCreate(SQLiteDatabase paramSQLiteDatabase) {
    h[] arrayOfH = this.a.c();
    int i = arrayOfH.length;
    for (byte b = 0; b < i; b++)
      arrayOfH[b].a(paramSQLiteDatabase); 
  }
  
  public void onDowngrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2) {
    h[] arrayOfH = this.a.c();
    paramInt2 = arrayOfH.length;
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
      h h = arrayOfH[paramInt1];
      h.b(paramSQLiteDatabase);
      h.a(paramSQLiteDatabase);
    } 
  }
  
  public void onOpen(SQLiteDatabase paramSQLiteDatabase) {
    super.onOpen(paramSQLiteDatabase);
    if (!paramSQLiteDatabase.isReadOnly())
      paramSQLiteDatabase.execSQL("PRAGMA foreign_keys = ON;"); 
  }
  
  public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2) {
    if (paramInt1 == 1 && paramInt2 == 2) {
      h h = this.a.d();
      h.b(paramSQLiteDatabase);
      h.a(paramSQLiteDatabase);
    } 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/e/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */