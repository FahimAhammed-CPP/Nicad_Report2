package com.facebook.ads.internal.e;

public abstract class a<T> {
  public void a() {}
  
  public void a(int paramInt, String paramString) {}
  
  public void a(T paramT) {}
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/e/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */