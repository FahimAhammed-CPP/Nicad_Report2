package com.facebook.ads.internal.e;

abstract class j<T> extends g<T> {}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/e/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */