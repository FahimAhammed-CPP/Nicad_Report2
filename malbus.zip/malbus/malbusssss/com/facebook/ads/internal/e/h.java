package com.facebook.ads.internal.e;

import android.database.sqlite.SQLiteDatabase;

public abstract class h {
  protected final e j;
  
  protected h(e parame) {
    this.j = parame;
  }
  
  public static String a(String paramString, b[] paramArrayOfb) {
    StringBuilder stringBuilder = new StringBuilder("SELECT ");
    for (byte b1 = 0; b1 < paramArrayOfb.length - 1; b1++) {
      stringBuilder.append((paramArrayOfb[b1]).b);
      stringBuilder.append(", ");
    } 
    stringBuilder.append((paramArrayOfb[paramArrayOfb.length - 1]).b);
    stringBuilder.append(" FROM ");
    stringBuilder.append(paramString);
    return stringBuilder.toString();
  }
  
  public static String a(String paramString, b[] paramArrayOfb, b paramb) {
    StringBuilder stringBuilder = new StringBuilder(a(paramString, paramArrayOfb));
    stringBuilder.append(" WHERE ");
    stringBuilder.append(paramb.b);
    stringBuilder.append(" = ?");
    return stringBuilder.toString();
  }
  
  private String c() {
    b[] arrayOfB = b();
    if (arrayOfB.length < 1)
      return null; 
    null = "";
    for (byte b = 0; b < arrayOfB.length - 1; b++)
      null = null + arrayOfB[b].a() + ", "; 
    return null + arrayOfB[arrayOfB.length - 1].a();
  }
  
  public abstract String a();
  
  public void a(SQLiteDatabase paramSQLiteDatabase) {
    paramSQLiteDatabase.execSQL("CREATE TABLE " + a() + " (" + c() + ")");
  }
  
  public void b(SQLiteDatabase paramSQLiteDatabase) {
    paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + a());
  }
  
  public abstract b[] b();
  
  public void d() {}
  
  protected SQLiteDatabase e() {
    return this.j.a();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/e/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */