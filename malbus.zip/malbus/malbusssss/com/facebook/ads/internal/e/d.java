package com.facebook.ads.internal.e;

import android.content.ContentValues;
import android.database.Cursor;
import android.support.annotation.WorkerThread;
import java.util.Map;
import java.util.UUID;
import org.json.JSONObject;

public class d extends h {
  public static final b a = new b(0, "event_id", "TEXT PRIMARY KEY");
  
  public static final b b = new b(1, "token_id", "TEXT REFERENCES tokens ON UPDATE CASCADE ON DELETE RESTRICT");
  
  public static final b c = new b(2, "priority", "INTEGER");
  
  public static final b d = new b(3, "type", "TEXT");
  
  public static final b e = new b(4, "time", "REAL");
  
  public static final b f = new b(5, "session_time", "REAL");
  
  public static final b g = new b(6, "session_id", "TEXT");
  
  public static final b h = new b(7, "data", "TEXT");
  
  public static final b[] i = new b[] { a, b, c, d, e, f, g, h };
  
  private static final String k = a("events", i);
  
  public d(e parame) {
    super(parame);
  }
  
  public String a() {
    return "events";
  }
  
  @WorkerThread
  String a(String paramString1, int paramInt, String paramString2, double paramDouble1, double paramDouble2, String paramString3, Map<String, String> paramMap) {
    String str = UUID.randomUUID().toString();
    ContentValues contentValues = new ContentValues(7);
    contentValues.put(a.b, str);
    contentValues.put(b.b, paramString1);
    contentValues.put(c.b, Integer.valueOf(paramInt));
    contentValues.put(d.b, paramString2);
    contentValues.put(e.b, Double.valueOf(paramDouble1));
    contentValues.put(f.b, Double.valueOf(paramDouble2));
    contentValues.put(g.b, paramString3);
    paramString2 = h.b;
    if (paramMap != null) {
      paramString1 = (new JSONObject(paramMap)).toString();
      contentValues.put(paramString2, paramString1);
      e().insertOrThrow("events", null, contentValues);
      return str;
    } 
    paramString1 = null;
    contentValues.put(paramString2, paramString1);
    e().insertOrThrow("events", null, contentValues);
    return str;
  }
  
  public boolean a(String paramString) {
    boolean bool = true;
    if (e().delete("events", a.b + " = ?", new String[] { paramString }) <= 0)
      bool = false; 
    return bool;
  }
  
  public b[] b() {
    return i;
  }
  
  @WorkerThread
  Cursor c() {
    return e().rawQuery(k, null);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/e/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */