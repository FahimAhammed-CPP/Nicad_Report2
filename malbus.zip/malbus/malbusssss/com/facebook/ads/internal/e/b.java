package com.facebook.ads.internal.e;

public class b {
  public final int a;
  
  public final String b;
  
  public final String c;
  
  public b(int paramInt, String paramString1, String paramString2) {
    this.a = paramInt;
    this.b = paramString1;
    this.c = paramString2;
  }
  
  public String a() {
    return this.b + " " + this.c;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/e/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */