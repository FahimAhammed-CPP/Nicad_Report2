package com.facebook.ads.internal.e;

abstract class g<T> {
  private a a;
  
  protected void a(a parama) {
    this.a = parama;
  }
  
  abstract T b();
  
  public a c() {
    return this.a;
  }
  
  public enum a {
    a(9000, "An unknown error has occurred."),
    b(3001, "Failed to read from database."),
    c(3002, "Failed to insert row into database."),
    d(3003, "Failed to update row in database."),
    e(3004, "Failed to delete row from database.");
    
    private final int f;
    
    private final String g;
    
    a(int param1Int1, String param1String1) {
      this.f = param1Int1;
      this.g = param1String1;
    }
    
    public int a() {
      return this.f;
    }
    
    public String b() {
      return this.g;
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/e/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */