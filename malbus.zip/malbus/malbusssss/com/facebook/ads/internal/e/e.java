package com.facebook.ads.internal.e;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.AsyncTask;
import android.os.Looper;
import android.support.annotation.WorkerThread;
import android.util.Log;
import com.facebook.ads.internal.g.d;
import com.facebook.ads.internal.util.h;

public class e {
  private static final String a = e.class.getName();
  
  private final Context b;
  
  private final i c;
  
  private final d d;
  
  private final c e;
  
  private SQLiteOpenHelper f;
  
  public e(Context paramContext) {
    this.b = paramContext;
    this.c = new i(this);
    this.d = new d(this);
    this.e = new c(this);
  }
  
  private SQLiteDatabase i() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield f : Landroid/database/sqlite/SQLiteOpenHelper;
    //   6: ifnonnull -> 27
    //   9: new com/facebook/ads/internal/e/f
    //   12: astore_1
    //   13: aload_1
    //   14: aload_0
    //   15: getfield b : Landroid/content/Context;
    //   18: aload_0
    //   19: invokespecial <init> : (Landroid/content/Context;Lcom/facebook/ads/internal/e/e;)V
    //   22: aload_0
    //   23: aload_1
    //   24: putfield f : Landroid/database/sqlite/SQLiteOpenHelper;
    //   27: aload_0
    //   28: getfield f : Landroid/database/sqlite/SQLiteOpenHelper;
    //   31: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   34: astore_1
    //   35: aload_0
    //   36: monitorexit
    //   37: aload_1
    //   38: areturn
    //   39: astore_1
    //   40: aload_0
    //   41: monitorexit
    //   42: aload_1
    //   43: athrow
    // Exception table:
    //   from	to	target	type
    //   2	27	39	finally
    //   27	35	39	finally
  }
  
  public SQLiteDatabase a() {
    if (Looper.myLooper() == Looper.getMainLooper())
      throw new IllegalStateException("Cannot call getDatabase from the UI thread!"); 
    return i();
  }
  
  public <T> AsyncTask a(g<T> paramg, a<T> parama) {
    return h.a(new AsyncTask<Void, Void, T>(this, paramg, parama) {
          private g.a d;
          
          protected T a(Void... param1VarArgs) {
            param1VarArgs = null;
            try {
              Void[] arrayOfVoid = (Void[])this.a.b();
              param1VarArgs = arrayOfVoid;
              this.d = this.a.c();
              param1VarArgs = arrayOfVoid;
            } catch (SQLiteException sQLiteException) {
              this.d = g.a.a;
            } 
            return (T)param1VarArgs;
          }
          
          protected void onPostExecute(T param1T) {
            if (this.d == null) {
              this.b.a(param1T);
            } else {
              this.b.a(this.d.a(), this.d.b());
            } 
            this.b.a();
          }
        }(Object[])new Void[0]);
  }
  
  public AsyncTask a(d paramd, a<String> parama) {
    return a(new j<String>(this, paramd) {
          public String a() {
            try {
              SQLiteDatabase sQLiteDatabase = this.b.a();
              sQLiteDatabase.beginTransaction();
              String str = e.b(this.b).a(e.a(this.b).a(this.a.d()), (this.a.a()).c, this.a.b(), this.a.e(), this.a.f(), this.a.g(), this.a.h());
              sQLiteDatabase.setTransactionSuccessful();
              sQLiteDatabase.endTransaction();
            } catch (Exception exception) {
              a(g.a.c);
              exception = null;
            } 
            return (String)exception;
          }
        }parama);
  }
  
  public String a(d paramd, boolean paramBoolean) {
    try {
      String str;
      SQLiteDatabase sQLiteDatabase = i();
      sQLiteDatabase.beginTransaction();
      if (paramBoolean) {
        str = this.e.a((paramd.a()).c, paramd.b(), paramd.e(), paramd.f(), paramd.g(), paramd.h());
      } else {
        str = this.d.a(this.c.a(str.d()), (str.a()).c, str.b(), str.e(), str.f(), str.g(), str.h());
      } 
      sQLiteDatabase.setTransactionSuccessful();
      sQLiteDatabase.endTransaction();
    } catch (Exception exception) {
      Log.e(a, "Couldn't save event to the database", exception);
      exception = null;
    } 
    return (String)exception;
  }
  
  public boolean a(String paramString) {
    return this.e.a(paramString);
  }
  
  public void b() {
    h[] arrayOfH = c();
    int j = arrayOfH.length;
    for (byte b = 0; b < j; b++)
      arrayOfH[b].d(); 
    if (this.f != null) {
      this.f.close();
      this.f = null;
    } 
  }
  
  @WorkerThread
  public boolean b(String paramString) {
    return this.d.a(paramString);
  }
  
  public h[] c() {
    return new h[] { this.c, this.d, this.e };
  }
  
  protected h d() {
    return this.e;
  }
  
  @WorkerThread
  public Cursor e() {
    return this.d.c();
  }
  
  @WorkerThread
  public Cursor f() {
    return this.c.c();
  }
  
  @WorkerThread
  public Cursor g() {
    return this.e.c();
  }
  
  @WorkerThread
  public void h() {
    this.c.f();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/e/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */