package com.facebook.ads.internal.e;

import android.database.Cursor;
import android.database.SQLException;
import android.support.annotation.WorkerThread;
import android.text.TextUtils;

public class i extends h {
  public static final b a = new b(0, "token_id", "TEXT PRIMARY KEY");
  
  public static final b b = new b(1, "token", "TEXT");
  
  public static final b[] c = new b[] { a, b };
  
  private static final String d = i.class.getSimpleName();
  
  private static final String e = a("tokens", c);
  
  private static final String f = a("tokens", c, b);
  
  private static final String g = "DELETE FROM tokens WHERE NOT EXISTS (SELECT 1 FROM events WHERE tokens." + a.b + " = " + "events" + "." + d.b.b + ")";
  
  public i(e parame) {
    super(parame);
  }
  
  public String a() {
    return "tokens";
  }
  
  @WorkerThread
  String a(String paramString) {
    Cursor cursor;
    if (TextUtils.isEmpty(paramString))
      throw new IllegalArgumentException("Invalid token."); 
    try {
      cursor = e().rawQuery(f, new String[] { paramString });
    } finally {
      paramString = null;
    } 
    if (cursor != null)
      cursor.close(); 
    throw paramString;
  }
  
  public b[] b() {
    return c;
  }
  
  @WorkerThread
  Cursor c() {
    return e().rawQuery(e, null);
  }
  
  @WorkerThread
  public void f() {
    try {
      e().execSQL(g);
    } catch (SQLException sQLException) {}
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/e/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */