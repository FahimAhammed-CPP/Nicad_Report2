package com.facebook.ads.internal.b;

import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import java.util.Arrays;
import java.util.Vector;

public class e {
  public static double a(View paramView, Context paramContext) {
    double d1 = 0.0D;
    if (!a(paramContext))
      return d1; 
    double d2 = d1;
    if (d(paramView)) {
      Rect rect = new Rect();
      d2 = d1;
      if (paramView.getGlobalVisibleRect(rect)) {
        Vector<Rect> vector = a(paramView);
        int i = a(vector);
        vector.add(rect);
        int j = a(vector);
        int k = paramView.getMeasuredHeight();
        int m = paramView.getMeasuredWidth();
        d2 = (j - i) * 1.0D / (k * m);
      } 
    } 
    return d2;
  }
  
  private static int a(Vector<Rect> paramVector) {
    int i = paramVector.size();
    int[] arrayOfInt1 = new int[i * 2];
    int[] arrayOfInt2 = new int[i * 2];
    boolean[][] arrayOfBoolean = new boolean[i * 2][i * 2];
    int j = 0;
    int k = 0;
    int m = 0;
    while (j < i) {
      Rect rect = paramVector.elementAt(j);
      int n = m + 1;
      arrayOfInt1[m] = rect.left;
      int i1 = k + 1;
      arrayOfInt2[k] = rect.bottom;
      m = n + 1;
      arrayOfInt1[n] = rect.right;
      k = i1 + 1;
      arrayOfInt2[i1] = rect.top;
      j++;
    } 
    Arrays.sort(arrayOfInt1);
    Arrays.sort(arrayOfInt2);
    for (j = 0; j < i; j++) {
      Rect rect = paramVector.elementAt(j);
      k = a(arrayOfInt1, rect.left);
      int i2 = a(arrayOfInt1, rect.right);
      int n = a(arrayOfInt2, rect.top);
      int i1 = a(arrayOfInt2, rect.bottom);
      while (++k <= i2) {
        for (m = n + 1; m <= i1; m++)
          arrayOfBoolean[k][m] = true; 
        k++;
      } 
    } 
    k = 0;
    j = 0;
    while (k < i * 2) {
      for (m = 0; m < i * 2; m++) {
        byte b;
        if (arrayOfBoolean[k][m]) {
          b = (arrayOfInt1[k] - arrayOfInt1[k - 1]) * (arrayOfInt2[m] - arrayOfInt2[m - 1]);
        } else {
          b = 0;
        } 
        j += b;
      } 
      k++;
    } 
    return j;
  }
  
  private static int a(int[] paramArrayOfint, int paramInt) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_0
    //   3: arraylength
    //   4: istore_3
    //   5: iload_2
    //   6: iload_3
    //   7: if_icmpge -> 52
    //   10: iload_3
    //   11: iload_2
    //   12: isub
    //   13: iconst_2
    //   14: idiv
    //   15: iload_2
    //   16: iadd
    //   17: istore #4
    //   19: aload_0
    //   20: iload #4
    //   22: iaload
    //   23: iload_1
    //   24: if_icmpne -> 30
    //   27: iload #4
    //   29: ireturn
    //   30: aload_0
    //   31: iload #4
    //   33: iaload
    //   34: iload_1
    //   35: if_icmple -> 44
    //   38: iload #4
    //   40: istore_3
    //   41: goto -> 5
    //   44: iload #4
    //   46: iconst_1
    //   47: iadd
    //   48: istore_2
    //   49: goto -> 41
    //   52: iconst_m1
    //   53: istore #4
    //   55: goto -> 27
  }
  
  private static Vector<Rect> a(View paramView) {
    Vector<Rect> vector = new Vector();
    if (paramView.getParent() instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView.getParent();
      for (int i = viewGroup.indexOfChild(paramView) + 1; i < viewGroup.getChildCount(); i++)
        vector.addAll(b(viewGroup.getChildAt(i))); 
      vector.addAll(a((View)viewGroup));
    } 
    return vector;
  }
  
  private static boolean a(Context paramContext) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: ifnonnull -> 10
    //   6: iconst_1
    //   7: istore_2
    //   8: iload_2
    //   9: ireturn
    //   10: iload_1
    //   11: istore_2
    //   12: aload_0
    //   13: ldc 'power'
    //   15: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   18: checkcast android/os/PowerManager
    //   21: invokevirtual isScreenOn : ()Z
    //   24: ifeq -> 8
    //   27: aload_0
    //   28: instanceof android/app/Activity
    //   31: ifeq -> 115
    //   34: aload_0
    //   35: checkcast android/app/Activity
    //   38: invokevirtual getWindow : ()Landroid/view/Window;
    //   41: astore_3
    //   42: aload_3
    //   43: ifnull -> 115
    //   46: aload_3
    //   47: invokevirtual getAttributes : ()Landroid/view/WindowManager$LayoutParams;
    //   50: getfield flags : I
    //   53: istore #4
    //   55: ldc 4194304
    //   57: iload #4
    //   59: iand
    //   60: ifne -> 71
    //   63: iload #4
    //   65: ldc 524288
    //   67: iand
    //   68: ifeq -> 103
    //   71: iconst_1
    //   72: istore #4
    //   74: aload_0
    //   75: ldc 'keyguard'
    //   77: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   80: checkcast android/app/KeyguardManager
    //   83: invokevirtual inKeyguardRestrictedInputMode : ()Z
    //   86: istore_2
    //   87: iload_2
    //   88: ifeq -> 98
    //   91: iload_1
    //   92: istore_2
    //   93: iload #4
    //   95: ifeq -> 8
    //   98: iconst_1
    //   99: istore_2
    //   100: goto -> 8
    //   103: iconst_0
    //   104: istore #4
    //   106: goto -> 74
    //   109: astore_0
    //   110: iload_1
    //   111: istore_2
    //   112: goto -> 8
    //   115: iconst_0
    //   116: istore #4
    //   118: goto -> 74
    // Exception table:
    //   from	to	target	type
    //   12	42	109	java/lang/Exception
    //   46	55	109	java/lang/Exception
    //   74	87	109	java/lang/Exception
  }
  
  private static Vector<Rect> b(View paramView) {
    Vector<Rect> vector = new Vector();
    if (paramView.isShown() && (Build.VERSION.SDK_INT < 11 || paramView.getAlpha() > 0.0F)) {
      ViewGroup viewGroup;
      if (paramView instanceof ViewGroup && c(paramView)) {
        viewGroup = (ViewGroup)paramView;
        byte b = 0;
        while (true) {
          if (b < viewGroup.getChildCount()) {
            vector.addAll(b(viewGroup.getChildAt(b)));
            b++;
            continue;
          } 
          return vector;
        } 
      } 
      Rect rect = new Rect();
      if (viewGroup.getGlobalVisibleRect(rect))
        vector.add(rect); 
    } 
    return vector;
  }
  
  private static boolean c(View paramView) {
    return (paramView.getBackground() == null || (Build.VERSION.SDK_INT >= 19 && paramView.getBackground().getAlpha() <= 0));
  }
  
  private static boolean d(View paramView) {
    boolean bool = false;
    if (paramView == null)
      return bool; 
    null = bool;
    if (paramView.isShown()) {
      null = bool;
      if (paramView.getWindowVisibility() == 0) {
        null = bool;
        if (paramView.getVisibility() == 0) {
          null = bool;
          if (paramView.getMeasuredWidth() > 0) {
            null = bool;
            if (paramView.getMeasuredHeight() > 0) {
              if (Build.VERSION.SDK_INT >= 11) {
                null = bool;
                return (paramView.getAlpha() >= 0.9F) ? true : null;
              } 
            } else {
              return null;
            } 
          } else {
            return null;
          } 
        } else {
          return null;
        } 
      } else {
        return null;
      } 
    } else {
      return null;
    } 
    return true;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/b/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */