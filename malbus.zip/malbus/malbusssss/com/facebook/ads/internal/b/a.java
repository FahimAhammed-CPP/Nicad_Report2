package com.facebook.ads.internal.b;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import com.facebook.ads.internal.util.ae;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class a implements ae<Bundle> {
  private final View a;
  
  private final List<d> b;
  
  private final Context c;
  
  private c d;
  
  public a(Context paramContext, View paramView, List<b> paramList) {
    this.c = paramContext;
    this.a = paramView;
    this.b = new ArrayList<d>(paramList.size());
    for (b b : paramList)
      this.b.add(new d(b)); 
    this.d = new c();
  }
  
  public a(Context paramContext, View paramView, List<b> paramList, Bundle paramBundle) {
    this.c = paramContext;
    this.a = paramView;
    this.b = new ArrayList<d>(paramList.size());
    ArrayList<Bundle> arrayList = paramBundle.getParcelableArrayList("TESTS");
    for (byte b = 0; b < paramList.size(); b++)
      this.b.add(new d(paramList.get(b), arrayList.get(b))); 
    this.d = (c)paramBundle.getSerializable("STATISTICS");
  }
  
  public void a() {
    this.d.a();
  }
  
  public void a(double paramDouble1, double paramDouble2) {
    if (paramDouble2 >= 0.0D)
      this.d.b(paramDouble1, paramDouble2); 
    paramDouble2 = e.a(this.a, this.c);
    this.d.a(paramDouble1, paramDouble2);
    Iterator<d> iterator = this.b.iterator();
    while (iterator.hasNext())
      ((d)iterator.next()).a(paramDouble1, paramDouble2); 
  }
  
  public c b() {
    return this.d;
  }
  
  public Bundle getSaveInstanceState() {
    Bundle bundle = new Bundle();
    bundle.putSerializable("STATISTICS", this.d);
    ArrayList<Bundle> arrayList = new ArrayList(this.b.size());
    Iterator<d> iterator = this.b.iterator();
    while (iterator.hasNext())
      arrayList.add(((d)iterator.next()).getSaveInstanceState()); 
    bundle.putParcelableArrayList("TESTS", arrayList);
    return bundle;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/b/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */