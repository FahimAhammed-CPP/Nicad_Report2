package com.facebook.ads.internal.b;

import android.os.Bundle;
import com.facebook.ads.internal.util.ae;

public class d implements ae<Bundle> {
  private c a;
  
  private final c b;
  
  private final b c;
  
  private boolean d = false;
  
  private boolean e = false;
  
  private boolean f = false;
  
  public d(b paramb) {
    this.c = paramb;
    this.b = new c(paramb.a);
    this.a = new c(paramb.a);
  }
  
  public d(b paramb, Bundle paramBundle) {
    this.c = paramb;
    this.b = (c)paramBundle.getSerializable("testStats");
    this.a = (c)paramBundle.getSerializable("viewableStats");
    this.d = paramBundle.getBoolean("ended");
    this.e = paramBundle.getBoolean("passed");
    this.f = paramBundle.getBoolean("complete");
  }
  
  private void a() {
    this.e = true;
    b();
  }
  
  private void b() {
    this.f = true;
    c();
  }
  
  private void c() {
    c c1;
    this.d = true;
    if (this.e) {
      c1 = this.a;
    } else {
      c1 = this.b;
    } 
    this.c.a(this.f, this.e, c1);
  }
  
  public void a(double paramDouble1, double paramDouble2) {
    if (!this.d) {
      this.b.a(paramDouble1, paramDouble2);
      this.a.a(paramDouble1, paramDouble2);
      paramDouble1 = this.a.b().f();
      if (this.c.d && paramDouble2 < this.c.a)
        this.a = new c(this.c.a); 
      if (this.c.b >= 0.0D && this.b.b().e() > this.c.b && paramDouble1 == 0.0D) {
        b();
        return;
      } 
      if (paramDouble1 >= this.c.c)
        a(); 
    } 
  }
  
  public Bundle getSaveInstanceState() {
    Bundle bundle = new Bundle();
    bundle.putSerializable("viewableStats", this.a);
    bundle.putSerializable("testStats", this.b);
    bundle.putBoolean("ended", this.d);
    bundle.putBoolean("passed", this.e);
    bundle.putBoolean("complete", this.f);
    return bundle;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/b/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */