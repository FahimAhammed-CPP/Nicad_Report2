package com.facebook.ads.internal.b;

public abstract class b {
  public final double a;
  
  public final double b;
  
  public final double c;
  
  public final boolean d;
  
  public b(double paramDouble1, double paramDouble2, double paramDouble3, boolean paramBoolean) {
    this.a = paramDouble1;
    this.b = paramDouble2;
    this.c = paramDouble3;
    this.d = paramBoolean;
  }
  
  protected abstract void a(boolean paramBoolean1, boolean paramBoolean2, c paramc);
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/b/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */