package com.facebook.ads.internal.b;

import java.io.Serializable;

public class c implements Serializable {
  private a a;
  
  private a b;
  
  public c() {
    this(0.5D, 0.05D);
  }
  
  public c(double paramDouble) {
    this(paramDouble, 0.05D);
  }
  
  public c(double paramDouble1, double paramDouble2) {
    this.a = new a(paramDouble1);
    this.b = new a(paramDouble2);
    a();
  }
  
  void a() {
    this.a.a();
    this.b.a();
  }
  
  void a(double paramDouble1, double paramDouble2) {
    this.a.a(paramDouble1, paramDouble2);
  }
  
  public a b() {
    return this.a;
  }
  
  void b(double paramDouble1, double paramDouble2) {
    this.b.a(paramDouble1, paramDouble2);
  }
  
  public a c() {
    return this.b;
  }
  
  public static class a implements Serializable {
    private double a;
    
    private double b;
    
    private double c;
    
    private double d;
    
    private double e;
    
    private double f;
    
    private double g;
    
    private int h;
    
    private double i;
    
    private double j;
    
    private double k;
    
    public a(double param1Double) {
      this.e = param1Double;
    }
    
    public void a() {
      this.a = 0.0D;
      this.c = 0.0D;
      this.d = 0.0D;
      this.f = 0.0D;
      this.h = 0;
      this.i = 0.0D;
      this.j = 1.0D;
      this.k = 0.0D;
    }
    
    public void a(double param1Double1, double param1Double2) {
      this.h++;
      this.i += param1Double1;
      this.c = param1Double2;
      this.k += param1Double2 * param1Double1;
      this.a = this.k / this.i;
      this.j = Math.min(this.j, param1Double2);
      this.f = Math.max(this.f, param1Double2);
      if (param1Double2 >= this.e) {
        this.d += param1Double1;
        this.b += param1Double1;
        this.g = Math.max(this.g, this.b);
        return;
      } 
      this.b = 0.0D;
    }
    
    public double b() {
      return (this.h == 0) ? 0.0D : this.j;
    }
    
    public double c() {
      return this.a;
    }
    
    public double d() {
      return this.f;
    }
    
    public double e() {
      return this.i;
    }
    
    public double f() {
      return this.d;
    }
    
    public double g() {
      return this.g;
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/b/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */