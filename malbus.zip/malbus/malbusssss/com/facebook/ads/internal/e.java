package com.facebook.ads.internal;

public enum e {
  a(0),
  b(4),
  c(5),
  d(6),
  e(7),
  f(100),
  g(101),
  h(102),
  i(103),
  j(200),
  k(400),
  l(201),
  m(300);
  
  private final int n;
  
  e(int paramInt1) {
    this.n = paramInt1;
  }
  
  public int a() {
    return this.n;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */