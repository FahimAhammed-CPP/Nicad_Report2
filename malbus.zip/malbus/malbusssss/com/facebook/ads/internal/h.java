package com.facebook.ads.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.annotation.Nullable;
import com.facebook.ads.internal.util.h;
import java.util.Iterator;
import org.json.JSONObject;

public class h {
  private static h a;
  
  private final SharedPreferences b;
  
  public h(Context paramContext) {
    this.b = paramContext.getApplicationContext().getSharedPreferences("com.facebook.ads.FEATURE_CONFIG", 0);
  }
  
  public static boolean a(Context paramContext) {
    boolean bool1 = false;
    boolean bool2 = bool1;
    if (Build.VERSION.SDK_INT >= 14) {
      bool2 = bool1;
      if (h.a("com.google.android.exoplayer", "ExoPlayer")) {
        bool2 = bool1;
        if (k(paramContext).a("adnw_enable_exoplayer", false))
          bool2 = true; 
      } 
    } 
    return bool2;
  }
  
  public static boolean b(Context paramContext) {
    boolean bool1 = false;
    boolean bool2 = bool1;
    if (Build.VERSION.SDK_INT >= 19) {
      bool2 = bool1;
      if (k(paramContext).a("adnw_enable_iab", false))
        bool2 = true; 
    } 
    return bool2;
  }
  
  public static boolean c(Context paramContext) {
    return k(paramContext).a("adnw_debug_logging", false);
  }
  
  public static long d(Context paramContext) {
    return k(paramContext).a("unified_logging_immediate_delay_ms", 500L);
  }
  
  public static long e(Context paramContext) {
    return k(paramContext).a("unified_logging_dispatch_interval_seconds", 300) * 1000L;
  }
  
  public static boolean f(Context paramContext) {
    return k(paramContext).a("video_and_endcard_autorotate", "autorotate_disabled").equals("autorotate_enabled");
  }
  
  public static int g(Context paramContext) {
    return k(paramContext).a("minimum_elapsed_time_after_impression", -1);
  }
  
  public static int h(Context paramContext) {
    return k(paramContext).a("ad_viewability_tap_margin", 0);
  }
  
  public static boolean i(Context paramContext) {
    return k(paramContext).a("visible_area_check_enabled", false);
  }
  
  public static int j(Context paramContext) {
    return k(paramContext).a("visible_area_percentage", 50);
  }
  
  private static h k(Context paramContext) {
    // Byte code:
    //   0: getstatic com/facebook/ads/internal/h.a : Lcom/facebook/ads/internal/h;
    //   3: ifnonnull -> 31
    //   6: ldc com/facebook/ads/internal/h
    //   8: monitorenter
    //   9: getstatic com/facebook/ads/internal/h.a : Lcom/facebook/ads/internal/h;
    //   12: ifnonnull -> 28
    //   15: new com/facebook/ads/internal/h
    //   18: astore_1
    //   19: aload_1
    //   20: aload_0
    //   21: invokespecial <init> : (Landroid/content/Context;)V
    //   24: aload_1
    //   25: putstatic com/facebook/ads/internal/h.a : Lcom/facebook/ads/internal/h;
    //   28: ldc com/facebook/ads/internal/h
    //   30: monitorexit
    //   31: getstatic com/facebook/ads/internal/h.a : Lcom/facebook/ads/internal/h;
    //   34: areturn
    //   35: astore_0
    //   36: ldc com/facebook/ads/internal/h
    //   38: monitorexit
    //   39: aload_0
    //   40: athrow
    // Exception table:
    //   from	to	target	type
    //   9	28	35	finally
    //   28	31	35	finally
    //   36	39	35	finally
  }
  
  public int a(String paramString, int paramInt) {
    paramString = this.b.getString(paramString, String.valueOf(paramInt));
    null = paramInt;
    if (paramString != null) {
      if (paramString.equals("null"))
        return paramInt; 
    } else {
      return null;
    } 
    return Integer.valueOf(paramString).intValue();
  }
  
  public long a(String paramString, long paramLong) {
    paramString = this.b.getString(paramString, String.valueOf(paramLong));
    null = paramLong;
    if (paramString != null) {
      if (paramString.equals("null"))
        return paramLong; 
    } else {
      return null;
    } 
    return Long.valueOf(paramString).longValue();
  }
  
  @Nullable
  public String a(String paramString1, String paramString2) {
    String str = this.b.getString(paramString1, paramString2);
    paramString1 = paramString2;
    if (str != null) {
      if (str.equals("null"))
        return paramString2; 
    } else {
      return paramString1;
    } 
    return str;
  }
  
  public void a(@Nullable String paramString) {
    if (paramString != null && !paramString.isEmpty() && !paramString.equals("[]")) {
      SharedPreferences.Editor editor = this.b.edit();
      JSONObject jSONObject = new JSONObject(paramString);
      Iterator<String> iterator = jSONObject.keys();
      while (iterator.hasNext()) {
        paramString = iterator.next();
        editor.putString(paramString, jSONObject.getString(paramString));
      } 
      editor.commit();
    } 
  }
  
  public boolean a(String paramString, boolean paramBoolean) {
    paramString = this.b.getString(paramString, String.valueOf(paramBoolean));
    null = paramBoolean;
    if (paramString != null) {
      if (paramString.equals("null"))
        return paramBoolean; 
    } else {
      return null;
    } 
    return Boolean.valueOf(paramString).booleanValue();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */