package com.facebook.ads.internal.f;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.telephony.TelephonyManager;
import com.facebook.ads.internal.f;
import com.facebook.ads.internal.util.h;

public class i {
  public static final String a;
  
  public static String b;
  
  public static String c;
  
  public static String d;
  
  public static String e;
  
  public static String f;
  
  public static int g;
  
  public static String h;
  
  public static String i;
  
  public static int j;
  
  public static String k;
  
  public static int l;
  
  public static String m;
  
  public static String n;
  
  public static String o;
  
  public static boolean p;
  
  public static String q;
  
  private static boolean r = false;
  
  static {
    a = Build.VERSION.RELEASE;
    b = "";
    c = "";
    d = "";
    e = "";
    f = "";
    g = 0;
    h = "";
    i = "";
    j = 0;
    k = "";
    l = 0;
    m = "";
    n = "";
    o = "";
    p = false;
    q = "";
  }
  
  public static void a(Context paramContext) {
    // Byte code:
    //   0: ldc com/facebook/ads/internal/f/i
    //   2: monitorenter
    //   3: getstatic com/facebook/ads/internal/f/i.r : Z
    //   6: ifne -> 17
    //   9: iconst_1
    //   10: putstatic com/facebook/ads/internal/f/i.r : Z
    //   13: aload_0
    //   14: invokestatic c : (Landroid/content/Context;)V
    //   17: aload_0
    //   18: invokestatic d : (Landroid/content/Context;)V
    //   21: ldc com/facebook/ads/internal/f/i
    //   23: monitorexit
    //   24: return
    //   25: astore_0
    //   26: ldc com/facebook/ads/internal/f/i
    //   28: monitorexit
    //   29: aload_0
    //   30: athrow
    // Exception table:
    //   from	to	target	type
    //   3	17	25	finally
    //   17	21	25	finally
  }
  
  public static void b(Context paramContext) {
    if (r)
      try {
        SharedPreferences sharedPreferences = paramContext.getSharedPreferences("SDKIDFA", 0);
        if (sharedPreferences.contains("attributionId"))
          n = sharedPreferences.getString("attributionId", ""); 
        if (sharedPreferences.contains("advertisingId")) {
          o = sharedPreferences.getString("advertisingId", "");
          p = sharedPreferences.getBoolean("limitAdTracking", p);
          q = f.c.a.name();
        } 
        try {
          h.a a = h.a(paramContext.getContentResolver());
        } catch (Exception exception2) {}
        if (exception2 != null) {
          String str = ((h.a)exception2).a;
          if (str != null)
            n = str; 
        } 
        try {
          f f = f.a(paramContext, (h.a)exception2);
        } catch (Exception exception1) {}
        if (exception1 != null) {
          String str = exception1.a();
          boolean bool = exception1.b();
          if (str != null) {
            o = str;
            p = Boolean.valueOf(bool).booleanValue();
            q = exception1.c().name();
          } 
        } 
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("attributionId", n);
        editor.putString("advertisingId", o);
        editor.putBoolean("limitAdTracking", p);
        editor.apply();
      } catch (Exception exception) {
        exception.printStackTrace();
      }  
  }
  
  private static void c(Context paramContext) {
    PackageManager packageManager = paramContext.getPackageManager();
    try {
      PackageInfo packageInfo = packageManager.getPackageInfo(paramContext.getPackageName(), 0);
      d = packageInfo.packageName;
      f = packageInfo.versionName;
      g = packageInfo.versionCode;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {}
    try {
      if (d != null && d.length() >= 0) {
        String str1 = packageManager.getInstallerPackageName(d);
        if (str1 != null && str1.length() > 0)
          h = str1; 
      } 
    } catch (Exception exception) {}
    try {
      CharSequence charSequence = packageManager.getApplicationLabel(packageManager.getApplicationInfo(paramContext.getPackageName(), 0));
      if (charSequence != null && charSequence.length() > 0)
        e = charSequence.toString(); 
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {}
    TelephonyManager telephonyManager = (TelephonyManager)paramContext.getSystemService("phone");
    if (telephonyManager != null) {
      String str1 = telephonyManager.getNetworkOperatorName();
      if (str1 != null && str1.length() > 0)
        i = str1; 
    } 
    String str = Build.MANUFACTURER;
    if (str != null && str.length() > 0)
      b = str; 
    str = Build.MODEL;
    if (str != null && str.length() > 0)
      c = Build.MODEL; 
  }
  
  private static void d(Context paramContext) {
    try {
      NetworkInfo networkInfo = ((ConnectivityManager)paramContext.getSystemService("connectivity")).getActiveNetworkInfo();
      if (networkInfo != null && networkInfo.isConnectedOrConnecting()) {
        j = networkInfo.getType();
        k = networkInfo.getTypeName();
        l = networkInfo.getSubtype();
        m = networkInfo.getSubtypeName();
      } 
    } catch (Exception exception) {}
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/f/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */