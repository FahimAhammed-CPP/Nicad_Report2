package com.facebook.ads.internal.f;

import com.facebook.ads.internal.e;

public enum c {
  a, b, c, d, e;
  
  public static c a(e parame) {
    switch (null.a[parame.ordinal()]) {
      default:
        return a;
      case 1:
        return d;
      case 2:
      case 3:
      case 4:
      case 5:
        return b;
      case 6:
      case 7:
      case 8:
      case 9:
        return c;
      case 10:
        break;
    } 
    return e;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/f/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */