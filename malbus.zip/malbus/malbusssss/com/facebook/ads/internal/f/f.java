package com.facebook.ads.internal.f;

import android.content.Context;
import com.facebook.ads.AdSettings;
import com.facebook.ads.AdSize;
import com.facebook.ads.internal.adapters.d;
import com.facebook.ads.internal.c;
import com.facebook.ads.internal.d;
import com.facebook.ads.internal.e;
import com.facebook.ads.internal.server.AdPlacementType;
import com.facebook.ads.internal.util.d;
import com.facebook.ads.internal.util.h;
import com.facebook.ads.internal.util.o;
import com.facebook.ads.internal.util.s;
import com.facebook.ads.internal.util.x;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class f {
  private static final ExecutorService g = Executors.newSingleThreadExecutor();
  
  private static String h = null;
  
  private static o.a i = o.a();
  
  protected String a;
  
  protected AdPlacementType b;
  
  protected c c;
  
  public Context d;
  
  public e e;
  
  public boolean f;
  
  private c j;
  
  private int k;
  
  private AdSize l;
  
  public f(Context paramContext, String paramString, AdSize paramAdSize, e parame, c paramc, int paramInt, boolean paramBoolean) {
    this.a = paramString;
    this.l = paramAdSize;
    this.e = parame;
    this.c = c.a(parame);
    this.j = paramc;
    this.k = paramInt;
    this.f = paramBoolean;
    a(paramContext);
  }
  
  private void a(Context paramContext) {
    this.d = paramContext;
    g.a();
    i.a(paramContext);
    g();
    g.submit(new Runnable(this, paramContext) {
          public void run() {
            if (f.f() == null)
              f.a(s.a(this.a, this.a.getPackageName())); 
          }
        });
  }
  
  private void a(Map<String, String> paramMap, String paramString1, String paramString2) {
    paramMap.put(paramString1, paramString2);
  }
  
  private static Map<String, String> b(Context paramContext) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("SDK", "android");
    hashMap.put("SDK_VERSION", "4.19.0");
    hashMap.put("LOCALE", Locale.getDefault().toString());
    float f1 = (paramContext.getResources().getDisplayMetrics()).density;
    int i = (paramContext.getResources().getDisplayMetrics()).widthPixels;
    int j = (paramContext.getResources().getDisplayMetrics()).heightPixels;
    hashMap.put("DENSITY", String.valueOf(f1));
    hashMap.put("SCREEN_WIDTH", String.valueOf((int)(i / f1)));
    hashMap.put("SCREEN_HEIGHT", String.valueOf((int)(j / f1)));
    hashMap.put("IDFA", i.o);
    if (i.p) {
      String str1 = "0";
      hashMap.put("IDFA_FLAG", str1);
      hashMap.put("ATTRIBUTION_ID", i.n);
      hashMap.put("ID_SOURCE", i.q);
      hashMap.put("OS", "Android");
      hashMap.put("OSVERS", i.a);
      hashMap.put("BUNDLE", i.d);
      hashMap.put("APPNAME", i.e);
      hashMap.put("APPVERS", i.f);
      hashMap.put("APPBUILD", String.valueOf(i.g));
      hashMap.put("CARRIER", i.i);
      hashMap.put("MAKE", i.b);
      hashMap.put("MODEL", i.c);
      hashMap.put("ROOTED", String.valueOf(i.d));
      hashMap.put("COPPA", String.valueOf(AdSettings.isChildDirected()));
      hashMap.put("INSTALLER", i.h);
      hashMap.put("SDK_CAPABILITY", d.b());
      hashMap.put("NETWORK_TYPE", String.valueOf((x.c(paramContext)).g));
      hashMap.put("REQUEST_TIME", h.a(System.currentTimeMillis()));
      hashMap.put("SESSION_TIME", h.a(g.b()));
      hashMap.put("SESSION_ID", g.c());
      return (Map)hashMap;
    } 
    String str = "1";
    hashMap.put("IDFA_FLAG", str);
    hashMap.put("ATTRIBUTION_ID", i.n);
    hashMap.put("ID_SOURCE", i.q);
    hashMap.put("OS", "Android");
    hashMap.put("OSVERS", i.a);
    hashMap.put("BUNDLE", i.d);
    hashMap.put("APPNAME", i.e);
    hashMap.put("APPVERS", i.f);
    hashMap.put("APPBUILD", String.valueOf(i.g));
    hashMap.put("CARRIER", i.i);
    hashMap.put("MAKE", i.b);
    hashMap.put("MODEL", i.c);
    hashMap.put("ROOTED", String.valueOf(i.d));
    hashMap.put("COPPA", String.valueOf(AdSettings.isChildDirected()));
    hashMap.put("INSTALLER", i.h);
    hashMap.put("SDK_CAPABILITY", d.b());
    hashMap.put("NETWORK_TYPE", String.valueOf((x.c(paramContext)).g));
    hashMap.put("REQUEST_TIME", h.a(System.currentTimeMillis()));
    hashMap.put("SESSION_TIME", h.a(g.b()));
    hashMap.put("SESSION_ID", g.c());
    return (Map)hashMap;
  }
  
  private void g() {
    if (this.c == null)
      this.c = c.a; 
    switch (null.a[this.c.ordinal()]) {
      default:
        this.b = AdPlacementType.UNKNOWN;
        return;
      case 1:
        this.b = AdPlacementType.INTERSTITIAL;
        return;
      case 2:
        this.b = AdPlacementType.BANNER;
        return;
      case 3:
        this.b = AdPlacementType.NATIVE;
        return;
      case 4:
        break;
    } 
    this.b = AdPlacementType.REWARDED_VIDEO;
  }
  
  public String a() {
    return this.a;
  }
  
  public c b() {
    return this.c;
  }
  
  public AdSize c() {
    return this.l;
  }
  
  public int d() {
    return this.k;
  }
  
  public Map<String, String> e() {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    a((Map)hashMap, "PLACEMENT_ID", this.a);
    if (this.b != AdPlacementType.UNKNOWN)
      a((Map)hashMap, "PLACEMENT_TYPE", this.b.toString().toLowerCase()); 
    for (Map.Entry<String, String> entry : b(this.d).entrySet())
      a((Map)hashMap, (String)entry.getKey(), (String)entry.getValue()); 
    if (this.l != null) {
      a((Map)hashMap, "WIDTH", String.valueOf(this.l.getWidth()));
      a((Map)hashMap, "HEIGHT", String.valueOf(this.l.getHeight()));
    } 
    a((Map)hashMap, "ADAPTERS", d.a(this.b));
    if (this.e != null)
      a((Map)hashMap, "TEMPLATE_ID", String.valueOf(this.e.a())); 
    if (this.j != null)
      a((Map)hashMap, "REQUEST_TYPE", String.valueOf(this.j.a())); 
    if (this.f)
      a((Map)hashMap, "TEST_MODE", "1"); 
    if (this.k != 0)
      a((Map)hashMap, "NUM_ADS_REQUESTED", String.valueOf(this.k)); 
    String str = AdSettings.getMediationService();
    if (str != null)
      a((Map)hashMap, "MEDIATION_SERVICE", str); 
    a((Map)hashMap, "CLIENT_EVENTS", d.a());
    if (h != null)
      a((Map)hashMap, "AFP", h); 
    a((Map)hashMap, "UNITY", String.valueOf(h.a(this.d)));
    a((Map)hashMap, "KG_RESTRICTED", String.valueOf(h.b(this.d)));
    return (Map)hashMap;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/f/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */