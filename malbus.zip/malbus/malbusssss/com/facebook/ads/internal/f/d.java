package com.facebook.ads.internal.f;

import android.support.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

public class d {
  private List<a> a = new ArrayList<a>();
  
  private int b = 0;
  
  private e c;
  
  @Nullable
  private String d;
  
  public d(e parame, @Nullable String paramString) {
    this.c = parame;
    this.d = paramString;
  }
  
  public e a() {
    return this.c;
  }
  
  public void a(a parama) {
    this.a.add(parama);
  }
  
  @Nullable
  public String b() {
    return this.d;
  }
  
  public int c() {
    return this.a.size();
  }
  
  public a d() {
    if (this.b < this.a.size()) {
      this.b++;
      return this.a.get(this.b - 1);
    } 
    return null;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/f/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */