package com.facebook.ads.internal.f;

import android.support.annotation.Nullable;
import android.text.TextUtils;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

public class a {
  private final String a;
  
  private final JSONObject b;
  
  private final Map<h, List<String>> c = new HashMap<h, List<String>>();
  
  public a(String paramString, JSONObject paramJSONObject, @Nullable JSONArray paramJSONArray) {
    this.a = paramString;
    this.b = paramJSONObject;
    if (paramJSONArray != null && paramJSONArray.length() != 0) {
      for (h h : h.values())
        this.c.put(h, new LinkedList<String>()); 
      byte b = 0;
      while (true) {
        if (b < paramJSONArray.length()) {
          try {
            JSONObject jSONObject = paramJSONArray.getJSONObject(b);
            String str2 = jSONObject.getString("type");
            String str1 = jSONObject.getString("url");
            h h = h.valueOf(str2.toUpperCase(Locale.US));
            if (h != null && !TextUtils.isEmpty(str1))
              ((List<String>)this.c.get(h)).add(str1); 
          } catch (Exception exception) {}
          b++;
          continue;
        } 
        return;
      } 
    } 
  }
  
  public String a() {
    return this.a;
  }
  
  public List<String> a(h paramh) {
    return this.c.get(paramh);
  }
  
  public JSONObject b() {
    return this.b;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/f/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */