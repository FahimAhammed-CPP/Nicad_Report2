package com.facebook.ads.internal.f;

import com.facebook.ads.internal.server.AdPlacementType;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;

public class e {
  private static final String c = e.class.getSimpleName();
  
  private static final AdPlacementType d = AdPlacementType.UNKNOWN;
  
  public int a;
  
  public int b;
  
  private AdPlacementType e;
  
  private int f;
  
  private int g;
  
  private int h;
  
  private int i;
  
  private int j;
  
  private int k;
  
  private int l;
  
  private boolean m;
  
  private List<b> n;
  
  private e(Map<String, String> paramMap) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: iconst_m1
    //   6: putfield a : I
    //   9: aload_0
    //   10: iconst_m1
    //   11: putfield b : I
    //   14: aload_0
    //   15: getstatic com/facebook/ads/internal/f/e.d : Lcom/facebook/ads/internal/server/AdPlacementType;
    //   18: putfield e : Lcom/facebook/ads/internal/server/AdPlacementType;
    //   21: aload_0
    //   22: iconst_1
    //   23: putfield f : I
    //   26: aload_0
    //   27: iconst_0
    //   28: putfield g : I
    //   31: aload_0
    //   32: iconst_0
    //   33: putfield h : I
    //   36: aload_0
    //   37: bipush #20
    //   39: putfield i : I
    //   42: aload_0
    //   43: iconst_0
    //   44: putfield j : I
    //   47: aload_0
    //   48: sipush #1000
    //   51: putfield k : I
    //   54: aload_0
    //   55: sipush #10000
    //   58: putfield l : I
    //   61: aload_0
    //   62: iconst_0
    //   63: putfield m : Z
    //   66: aload_0
    //   67: aconst_null
    //   68: putfield n : Ljava/util/List;
    //   71: aload_1
    //   72: invokeinterface entrySet : ()Ljava/util/Set;
    //   77: invokeinterface iterator : ()Ljava/util/Iterator;
    //   82: astore_1
    //   83: aload_1
    //   84: invokeinterface hasNext : ()Z
    //   89: ifeq -> 877
    //   92: aload_1
    //   93: invokeinterface next : ()Ljava/lang/Object;
    //   98: checkcast java/util/Map$Entry
    //   101: astore_2
    //   102: aload_2
    //   103: invokeinterface getKey : ()Ljava/lang/Object;
    //   108: checkcast java/lang/String
    //   111: astore_3
    //   112: aload_3
    //   113: invokevirtual hashCode : ()I
    //   116: lookupswitch default -> 224, -1899431321 -> 484, -1561601017 -> 374, -856794442 -> 452, -726276175 -> 468, -553208868 -> 389, 3575610 -> 314, 700812481 -> 329, 858630459 -> 344, 1085444827 -> 359, 1183549815 -> 436, 1503616961 -> 420, 2002133996 -> 404
    //   224: iconst_m1
    //   225: istore #4
    //   227: iload #4
    //   229: tableswitch default -> 292, 0 -> 295, 1 -> 500, 2 -> 519, 3 -> 538, 4 -> 557, 5 -> 576, 6 -> 598, 7 -> 617, 8 -> 636, 9 -> 655, 10 -> 674, 11 -> 693
    //   292: goto -> 83
    //   295: aload_0
    //   296: aload_2
    //   297: invokeinterface getValue : ()Ljava/lang/Object;
    //   302: checkcast java/lang/String
    //   305: invokestatic fromString : (Ljava/lang/String;)Lcom/facebook/ads/internal/server/AdPlacementType;
    //   308: putfield e : Lcom/facebook/ads/internal/server/AdPlacementType;
    //   311: goto -> 83
    //   314: aload_3
    //   315: ldc 'type'
    //   317: invokevirtual equals : (Ljava/lang/Object;)Z
    //   320: ifeq -> 224
    //   323: iconst_0
    //   324: istore #4
    //   326: goto -> 227
    //   329: aload_3
    //   330: ldc 'min_viewability_percentage'
    //   332: invokevirtual equals : (Ljava/lang/Object;)Z
    //   335: ifeq -> 224
    //   338: iconst_1
    //   339: istore #4
    //   341: goto -> 227
    //   344: aload_3
    //   345: ldc 'viewability_check_ticker'
    //   347: invokevirtual equals : (Ljava/lang/Object;)Z
    //   350: ifeq -> 224
    //   353: iconst_2
    //   354: istore #4
    //   356: goto -> 227
    //   359: aload_3
    //   360: ldc 'refresh'
    //   362: invokevirtual equals : (Ljava/lang/Object;)Z
    //   365: ifeq -> 224
    //   368: iconst_3
    //   369: istore #4
    //   371: goto -> 227
    //   374: aload_3
    //   375: ldc 'refresh_threshold'
    //   377: invokevirtual equals : (Ljava/lang/Object;)Z
    //   380: ifeq -> 224
    //   383: iconst_4
    //   384: istore #4
    //   386: goto -> 227
    //   389: aload_3
    //   390: ldc 'cacheable'
    //   392: invokevirtual equals : (Ljava/lang/Object;)Z
    //   395: ifeq -> 224
    //   398: iconst_5
    //   399: istore #4
    //   401: goto -> 227
    //   404: aload_3
    //   405: ldc 'placement_width'
    //   407: invokevirtual equals : (Ljava/lang/Object;)Z
    //   410: ifeq -> 224
    //   413: bipush #6
    //   415: istore #4
    //   417: goto -> 227
    //   420: aload_3
    //   421: ldc 'placement_height'
    //   423: invokevirtual equals : (Ljava/lang/Object;)Z
    //   426: ifeq -> 224
    //   429: bipush #7
    //   431: istore #4
    //   433: goto -> 227
    //   436: aload_3
    //   437: ldc 'viewability_check_initial_delay'
    //   439: invokevirtual equals : (Ljava/lang/Object;)Z
    //   442: ifeq -> 224
    //   445: bipush #8
    //   447: istore #4
    //   449: goto -> 227
    //   452: aload_3
    //   453: ldc 'viewability_check_interval'
    //   455: invokevirtual equals : (Ljava/lang/Object;)Z
    //   458: ifeq -> 224
    //   461: bipush #9
    //   463: istore #4
    //   465: goto -> 227
    //   468: aload_3
    //   469: ldc 'request_timeout'
    //   471: invokevirtual equals : (Ljava/lang/Object;)Z
    //   474: ifeq -> 224
    //   477: bipush #10
    //   479: istore #4
    //   481: goto -> 227
    //   484: aload_3
    //   485: ldc 'conv_tracking_data'
    //   487: invokevirtual equals : (Ljava/lang/Object;)Z
    //   490: ifeq -> 224
    //   493: bipush #11
    //   495: istore #4
    //   497: goto -> 227
    //   500: aload_0
    //   501: aload_2
    //   502: invokeinterface getValue : ()Ljava/lang/Object;
    //   507: checkcast java/lang/String
    //   510: invokestatic parseInt : (Ljava/lang/String;)I
    //   513: putfield f : I
    //   516: goto -> 83
    //   519: aload_0
    //   520: aload_2
    //   521: invokeinterface getValue : ()Ljava/lang/Object;
    //   526: checkcast java/lang/String
    //   529: invokestatic parseInt : (Ljava/lang/String;)I
    //   532: putfield g : I
    //   535: goto -> 83
    //   538: aload_0
    //   539: aload_2
    //   540: invokeinterface getValue : ()Ljava/lang/Object;
    //   545: checkcast java/lang/String
    //   548: invokestatic parseInt : (Ljava/lang/String;)I
    //   551: putfield h : I
    //   554: goto -> 83
    //   557: aload_0
    //   558: aload_2
    //   559: invokeinterface getValue : ()Ljava/lang/Object;
    //   564: checkcast java/lang/String
    //   567: invokestatic parseInt : (Ljava/lang/String;)I
    //   570: putfield i : I
    //   573: goto -> 83
    //   576: aload_0
    //   577: aload_2
    //   578: invokeinterface getValue : ()Ljava/lang/Object;
    //   583: checkcast java/lang/String
    //   586: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Boolean;
    //   589: invokevirtual booleanValue : ()Z
    //   592: putfield m : Z
    //   595: goto -> 83
    //   598: aload_0
    //   599: aload_2
    //   600: invokeinterface getValue : ()Ljava/lang/Object;
    //   605: checkcast java/lang/String
    //   608: invokestatic parseInt : (Ljava/lang/String;)I
    //   611: putfield a : I
    //   614: goto -> 83
    //   617: aload_0
    //   618: aload_2
    //   619: invokeinterface getValue : ()Ljava/lang/Object;
    //   624: checkcast java/lang/String
    //   627: invokestatic parseInt : (Ljava/lang/String;)I
    //   630: putfield b : I
    //   633: goto -> 83
    //   636: aload_0
    //   637: aload_2
    //   638: invokeinterface getValue : ()Ljava/lang/Object;
    //   643: checkcast java/lang/String
    //   646: invokestatic parseInt : (Ljava/lang/String;)I
    //   649: putfield j : I
    //   652: goto -> 83
    //   655: aload_0
    //   656: aload_2
    //   657: invokeinterface getValue : ()Ljava/lang/Object;
    //   662: checkcast java/lang/String
    //   665: invokestatic parseInt : (Ljava/lang/String;)I
    //   668: putfield k : I
    //   671: goto -> 83
    //   674: aload_0
    //   675: aload_2
    //   676: invokeinterface getValue : ()Ljava/lang/Object;
    //   681: checkcast java/lang/String
    //   684: invokestatic parseInt : (Ljava/lang/String;)I
    //   687: putfield l : I
    //   690: goto -> 83
    //   693: aload_0
    //   694: aload_2
    //   695: invokeinterface getValue : ()Ljava/lang/Object;
    //   700: checkcast java/lang/String
    //   703: invokestatic a : (Ljava/lang/String;)Ljava/util/List;
    //   706: putfield n : Ljava/util/List;
    //   709: invokestatic getInstance : ()Landroid/webkit/CookieManager;
    //   712: astore_2
    //   713: aload_2
    //   714: invokevirtual acceptCookie : ()Z
    //   717: istore #5
    //   719: aload_2
    //   720: iconst_1
    //   721: invokevirtual setAcceptCookie : (Z)V
    //   724: aload_0
    //   725: getfield n : Ljava/util/List;
    //   728: invokeinterface iterator : ()Ljava/util/Iterator;
    //   733: astore #6
    //   735: aload #6
    //   737: invokeinterface hasNext : ()Z
    //   742: ifeq -> 854
    //   745: aload #6
    //   747: invokeinterface next : ()Ljava/lang/Object;
    //   752: checkcast com/facebook/ads/internal/f/b
    //   755: astore_3
    //   756: aload_3
    //   757: invokevirtual b : ()Z
    //   760: ifeq -> 735
    //   763: new java/lang/StringBuilder
    //   766: astore #7
    //   768: aload #7
    //   770: invokespecial <init> : ()V
    //   773: aload #7
    //   775: aload_3
    //   776: getfield b : Ljava/lang/String;
    //   779: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   782: ldc '='
    //   784: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   787: aload_3
    //   788: getfield c : Ljava/lang/String;
    //   791: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   794: ldc ';Domain='
    //   796: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   799: aload_3
    //   800: getfield a : Ljava/lang/String;
    //   803: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   806: ldc ';Expires='
    //   808: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   811: aload_3
    //   812: invokevirtual a : ()Ljava/lang/String;
    //   815: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   818: ldc ';path=/'
    //   820: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   823: invokevirtual toString : ()Ljava/lang/String;
    //   826: astore #7
    //   828: aload_2
    //   829: aload_3
    //   830: getfield a : Ljava/lang/String;
    //   833: aload #7
    //   835: invokevirtual setCookie : (Ljava/lang/String;Ljava/lang/String;)V
    //   838: goto -> 735
    //   841: astore_3
    //   842: getstatic com/facebook/ads/internal/f/e.c : Ljava/lang/String;
    //   845: ldc 'Failed to set cookie.'
    //   847: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   850: pop
    //   851: goto -> 83
    //   854: getstatic android/os/Build$VERSION.SDK_INT : I
    //   857: bipush #21
    //   859: if_icmpge -> 868
    //   862: invokestatic getInstance : ()Landroid/webkit/CookieSyncManager;
    //   865: invokevirtual startSync : ()V
    //   868: aload_2
    //   869: iload #5
    //   871: invokevirtual setAcceptCookie : (Z)V
    //   874: goto -> 83
    //   877: return
    // Exception table:
    //   from	to	target	type
    //   709	735	841	java/lang/Exception
    //   735	838	841	java/lang/Exception
    //   854	868	841	java/lang/Exception
    //   868	874	841	java/lang/Exception
  }
  
  public static e a(JSONObject paramJSONObject) {
    if (paramJSONObject == null)
      return null; 
    Iterator<String> iterator = paramJSONObject.keys();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    while (iterator.hasNext()) {
      String str = iterator.next();
      hashMap.put(str, String.valueOf(paramJSONObject.opt(str)));
    } 
    return new e((Map)hashMap);
  }
  
  public AdPlacementType a() {
    return this.e;
  }
  
  public long b() {
    return (this.h * 1000);
  }
  
  public long c() {
    return (this.i * 1000);
  }
  
  public boolean d() {
    return this.m;
  }
  
  public int e() {
    return this.f;
  }
  
  public int f() {
    return this.g;
  }
  
  public int g() {
    return this.j;
  }
  
  public int h() {
    return this.k;
  }
  
  public int i() {
    return this.l;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/f/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */