package com.facebook.ads.internal.f;

import java.util.UUID;

public class g {
  private static final String a = g.class.getSimpleName();
  
  private static volatile boolean b = false;
  
  private static double c;
  
  private static String d;
  
  public static void a() {
    if (!b)
      synchronized (a) {
        if (!b) {
          b = true;
          c = System.currentTimeMillis() / 1000.0D;
          d = UUID.randomUUID().toString();
        } 
        return;
      }  
  }
  
  public static double b() {
    return c;
  }
  
  public static String c() {
    return d;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/f/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */