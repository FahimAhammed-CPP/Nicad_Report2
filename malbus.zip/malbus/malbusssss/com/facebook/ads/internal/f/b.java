package com.facebook.ads.internal.f;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class b {
  public String a;
  
  public String b;
  
  public String c;
  
  public Date d;
  
  public boolean e;
  
  public b(String paramString1, String paramString2, String paramString3, Date paramDate) {
    boolean bool;
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
    this.d = paramDate;
    if (paramString2 != null && paramString3 != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.e = bool;
  }
  
  public b(JSONObject paramJSONObject) {
    this(paramJSONObject.optString("url"), paramJSONObject.optString("key"), paramJSONObject.optString("value"), new Date(paramJSONObject.optLong("expiration") * 1000L));
  }
  
  public static List<b> a(String paramString) {
    if (paramString == null)
      return null; 
    try {
      JSONArray jSONArray2 = new JSONArray();
      this(paramString);
      JSONArray jSONArray1 = jSONArray2;
      if (jSONArray1 == null)
        return null; 
    } catch (JSONException jSONException) {
      jSONException = null;
      if (jSONException == null)
        return null; 
    } 
    ArrayList<b> arrayList = new ArrayList();
    for (byte b1 = 0; b1 < paramString.length(); b1++) {
      try {
        JSONObject jSONObject = paramString.getJSONObject(b1);
      } catch (JSONException jSONException) {
        jSONException = null;
      } 
      if (jSONException != null) {
        b b2 = new b((JSONObject)jSONException);
        if (b2 != null)
          arrayList.add(b2); 
      } 
    } 
    return arrayList;
  }
  
  public String a() {
    Date date1 = this.d;
    Date date2 = date1;
    if (date1 == null) {
      date2 = new Date();
      date2.setTime(date2.getTime() + 3600000L);
    } 
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE, dd-MMM-yyyy HH:mm:ss zzz");
    simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
    return simpleDateFormat.format(date2);
  }
  
  public boolean b() {
    return (this.b != null && this.c != null && this.a != null);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/f/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */