package com.facebook.ads.internal;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

public class g extends View {
  private Paint a;
  
  private Paint b;
  
  private Paint c;
  
  private int d;
  
  private boolean e;
  
  public g(Context paramContext) {
    this(paramContext, 60, true);
  }
  
  public g(Context paramContext, int paramInt, boolean paramBoolean) {
    super(paramContext);
    this.d = paramInt;
    this.e = paramBoolean;
    if (paramBoolean) {
      this.a = new Paint();
      this.a.setColor(-3355444);
      this.a.setStyle(Paint.Style.STROKE);
      this.a.setStrokeWidth(3.0F);
      this.a.setAntiAlias(true);
      this.b = new Paint();
      this.b.setColor(-1287371708);
      this.b.setStyle(Paint.Style.FILL);
      this.b.setAntiAlias(true);
      this.c = new Paint();
      this.c.setColor(-1);
      this.c.setStyle(Paint.Style.STROKE);
      this.c.setStrokeWidth(6.0F);
      this.c.setAntiAlias(true);
    } 
    a();
  }
  
  private void a() {
    DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
    int i = (int)(this.d * displayMetrics.density);
    float f = this.d;
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(i, (int)(displayMetrics.density * f));
    layoutParams.addRule(10);
    layoutParams.addRule(11);
    setLayoutParams((ViewGroup.LayoutParams)layoutParams);
  }
  
  protected void onDraw(Canvas paramCanvas) {
    if (this.e) {
      if (paramCanvas.isHardwareAccelerated() && Build.VERSION.SDK_INT < 17)
        setLayerType(1, null); 
      int i = Math.min(paramCanvas.getWidth(), paramCanvas.getHeight());
      int j = i / 2;
      int k = i / 2;
      int m = j * 2 / 3;
      paramCanvas.drawCircle(j, k, m, this.a);
      paramCanvas.drawCircle(j, k, (m - 2), this.b);
      m = i / 3;
      i /= 3;
      paramCanvas.drawLine(m, i, (m * 2), (i * 2), this.c);
      paramCanvas.drawLine((m * 2), i, m, (i * 2), this.c);
    } 
    super.onDraw(paramCanvas);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */