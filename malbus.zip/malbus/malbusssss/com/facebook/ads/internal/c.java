package com.facebook.ads.internal;

public enum c {
  a(0),
  b(1);
  
  private final int c;
  
  c(int paramInt1) {
    this.c = paramInt1;
  }
  
  public int a() {
    return this.c;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */