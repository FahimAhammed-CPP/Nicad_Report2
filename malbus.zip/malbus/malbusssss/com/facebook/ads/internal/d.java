package com.facebook.ads.internal;

import org.json.JSONArray;

public enum d {
  a(0),
  b(1),
  c(2),
  d(3),
  e(4),
  f(5),
  g(6),
  h(7),
  i(8),
  j(9),
  k(10),
  l(11),
  m(16),
  n(17);
  
  public static final d[] o;
  
  private static final String q;
  
  private final int p;
  
  static {
    o = new d[] { d, e, f, h, l, m, n };
    JSONArray jSONArray = new JSONArray();
    d[] arrayOfD = o;
    int i = arrayOfD.length;
    while (b < i) {
      jSONArray.put(arrayOfD[b].a());
      b++;
    } 
    q = jSONArray.toString();
  }
  
  d(int paramInt1) {
    this.p = paramInt1;
  }
  
  public static String b() {
    return q;
  }
  
  public int a() {
    return this.p;
  }
  
  public String toString() {
    return String.valueOf(this.p);
  }
  
  static {
    byte b = 0;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */