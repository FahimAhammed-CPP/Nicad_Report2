package com.facebook.ads.internal.g;

import com.facebook.ads.internal.util.l;

public class a extends d {
  public a(String paramString1, double paramDouble, String paramString2, l paraml) {
    super(paramString1, paramDouble, paramString2, paraml.a());
  }
  
  public h a() {
    return h.b;
  }
  
  public String b() {
    return "browser_session";
  }
  
  public boolean c() {
    return false;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/g/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */