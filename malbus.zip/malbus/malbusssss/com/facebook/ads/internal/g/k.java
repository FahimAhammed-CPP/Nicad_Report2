package com.facebook.ads.internal.g;

import android.content.Context;
import java.util.Map;

public class k extends d {
  public k(Context paramContext, String paramString1, double paramDouble, String paramString2, Map<String, String> paramMap) {
    super(paramContext, paramString1, paramDouble, paramString2, paramMap);
  }
  
  public h a() {
    return h.a;
  }
  
  public String b() {
    return "open_link";
  }
  
  public boolean c() {
    return true;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/g/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */