package com.facebook.ads.internal.g;

public class c extends d {
  public h a() {
    return h.b;
  }
  
  public String b() {
    return "error";
  }
  
  public boolean c() {
    return false;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/g/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */