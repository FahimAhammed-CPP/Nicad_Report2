package com.facebook.ads.internal.g;

import android.support.annotation.Nullable;
import java.lang.ref.WeakReference;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;

public class r<T extends s, E extends q> {
  private final Map<Class<E>, List<WeakReference<T>>> a = new HashMap<Class<E>, List<WeakReference<T>>>();
  
  private final Queue<E> b = new ArrayDeque<E>();
  
  private void a(List<WeakReference<T>> paramList) {
    if (paramList != null) {
      int i = 0;
      int j;
      for (j = 0; i < paramList.size(); j = k) {
        WeakReference<T> weakReference = paramList.get(i);
        int k = j;
        if (weakReference.get() != null) {
          paramList.set(j, weakReference);
          k = j + 1;
        } 
        i++;
      } 
      for (i = paramList.size() - 1; i >= j; i--)
        paramList.remove(i); 
    } 
  }
  
  private void b(E paramE) {
    if (this.a != null) {
      List<WeakReference<T>> list = this.a.get(paramE.getClass());
      if (list != null) {
        a(list);
        if (!list.isEmpty()) {
          Iterator<?> iterator = (new ArrayList(list)).iterator();
          while (true) {
            if (iterator.hasNext()) {
              s<E> s = ((WeakReference<s>)iterator.next()).get();
              if (s != null && s.b(paramE))
                s.a(paramE); 
              continue;
            } 
            return;
          } 
        } 
      } 
    } 
  }
  
  public void a(E paramE) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield b : Ljava/util/Queue;
    //   6: invokeinterface isEmpty : ()Z
    //   11: ifeq -> 71
    //   14: aload_0
    //   15: getfield b : Ljava/util/Queue;
    //   18: aload_1
    //   19: invokeinterface add : (Ljava/lang/Object;)Z
    //   24: pop
    //   25: aload_0
    //   26: getfield b : Ljava/util/Queue;
    //   29: invokeinterface isEmpty : ()Z
    //   34: ifne -> 82
    //   37: aload_0
    //   38: aload_0
    //   39: getfield b : Ljava/util/Queue;
    //   42: invokeinterface peek : ()Ljava/lang/Object;
    //   47: checkcast com/facebook/ads/internal/g/q
    //   50: invokespecial b : (Lcom/facebook/ads/internal/g/q;)V
    //   53: aload_0
    //   54: getfield b : Ljava/util/Queue;
    //   57: invokeinterface remove : ()Ljava/lang/Object;
    //   62: pop
    //   63: goto -> 25
    //   66: astore_1
    //   67: aload_0
    //   68: monitorexit
    //   69: aload_1
    //   70: athrow
    //   71: aload_0
    //   72: getfield b : Ljava/util/Queue;
    //   75: aload_1
    //   76: invokeinterface add : (Ljava/lang/Object;)Z
    //   81: pop
    //   82: aload_0
    //   83: monitorexit
    //   84: return
    // Exception table:
    //   from	to	target	type
    //   2	25	66	finally
    //   25	63	66	finally
    //   71	82	66	finally
  }
  
  public boolean a(T paramT) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnonnull -> 12
    //   6: iconst_0
    //   7: istore_2
    //   8: aload_0
    //   9: monitorexit
    //   10: iload_2
    //   11: ireturn
    //   12: aload_1
    //   13: invokevirtual a : ()Ljava/lang/Class;
    //   16: astore_3
    //   17: aload_0
    //   18: getfield a : Ljava/util/Map;
    //   21: aload_3
    //   22: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   27: ifnonnull -> 53
    //   30: new java/util/ArrayList
    //   33: astore #4
    //   35: aload #4
    //   37: invokespecial <init> : ()V
    //   40: aload_0
    //   41: getfield a : Ljava/util/Map;
    //   44: aload_3
    //   45: aload #4
    //   47: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   52: pop
    //   53: aload_0
    //   54: getfield a : Ljava/util/Map;
    //   57: aload_3
    //   58: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   63: checkcast java/util/List
    //   66: astore_3
    //   67: aload_0
    //   68: aload_3
    //   69: invokespecial a : (Ljava/util/List;)V
    //   72: aload_3
    //   73: invokeinterface size : ()I
    //   78: istore #5
    //   80: iconst_0
    //   81: istore #6
    //   83: iload #6
    //   85: iload #5
    //   87: if_icmpge -> 119
    //   90: aload_3
    //   91: iload #6
    //   93: invokeinterface get : (I)Ljava/lang/Object;
    //   98: checkcast java/lang/ref/WeakReference
    //   101: invokevirtual get : ()Ljava/lang/Object;
    //   104: aload_1
    //   105: if_acmpne -> 113
    //   108: iconst_0
    //   109: istore_2
    //   110: goto -> 8
    //   113: iinc #6, 1
    //   116: goto -> 83
    //   119: new java/lang/ref/WeakReference
    //   122: astore #4
    //   124: aload #4
    //   126: aload_1
    //   127: invokespecial <init> : (Ljava/lang/Object;)V
    //   130: aload_3
    //   131: aload #4
    //   133: invokeinterface add : (Ljava/lang/Object;)Z
    //   138: istore_2
    //   139: goto -> 8
    //   142: astore_1
    //   143: aload_0
    //   144: monitorexit
    //   145: aload_1
    //   146: athrow
    // Exception table:
    //   from	to	target	type
    //   12	53	142	finally
    //   53	80	142	finally
    //   90	108	142	finally
    //   119	139	142	finally
  }
  
  public boolean b(@Nullable T paramT) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnonnull -> 12
    //   6: iconst_0
    //   7: istore_2
    //   8: aload_0
    //   9: monitorexit
    //   10: iload_2
    //   11: ireturn
    //   12: aload_0
    //   13: getfield a : Ljava/util/Map;
    //   16: aload_1
    //   17: invokevirtual a : ()Ljava/lang/Class;
    //   20: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   25: checkcast java/util/List
    //   28: astore_3
    //   29: aload_3
    //   30: ifnonnull -> 38
    //   33: iconst_0
    //   34: istore_2
    //   35: goto -> 8
    //   38: aload_3
    //   39: invokeinterface size : ()I
    //   44: istore #4
    //   46: iconst_0
    //   47: istore #5
    //   49: iload #5
    //   51: iload #4
    //   53: if_icmpge -> 99
    //   56: aload_3
    //   57: iload #5
    //   59: invokeinterface get : (I)Ljava/lang/Object;
    //   64: checkcast java/lang/ref/WeakReference
    //   67: invokevirtual get : ()Ljava/lang/Object;
    //   70: aload_1
    //   71: if_acmpne -> 93
    //   74: aload_3
    //   75: iload #5
    //   77: invokeinterface get : (I)Ljava/lang/Object;
    //   82: checkcast java/lang/ref/WeakReference
    //   85: invokevirtual clear : ()V
    //   88: iconst_1
    //   89: istore_2
    //   90: goto -> 8
    //   93: iinc #5, 1
    //   96: goto -> 49
    //   99: iconst_0
    //   100: istore_2
    //   101: goto -> 8
    //   104: astore_1
    //   105: aload_0
    //   106: monitorexit
    //   107: aload_1
    //   108: athrow
    // Exception table:
    //   from	to	target	type
    //   12	29	104	finally
    //   38	46	104	finally
    //   56	88	104	finally
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/g/r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */