package com.facebook.ads.internal.g;

import android.content.Context;
import android.database.Cursor;
import android.text.TextUtils;
import android.util.Log;
import com.facebook.ads.internal.d.a;
import com.facebook.ads.internal.e.a;
import com.facebook.ads.internal.e.c;
import com.facebook.ads.internal.e.d;
import com.facebook.ads.internal.e.e;
import com.facebook.ads.internal.e.i;
import com.facebook.ads.internal.h;
import com.facebook.ads.internal.util.h;
import com.facebook.ads.internal.util.l;
import com.facebook.ads.internal.util.y;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class g implements e.a, f {
  private static final String a = g.class.getSimpleName();
  
  private static g b;
  
  private static double c;
  
  private static String d;
  
  private final e e;
  
  private final e f;
  
  private final Context g;
  
  protected g(Context paramContext) {
    this.f = new e(paramContext);
    this.e = new e(paramContext, this);
    this.e.a(false);
    this.g = paramContext;
    a.a(paramContext).a();
  }
  
  public static g a(Context paramContext) {
    if (b == null)
      synchronized (paramContext.getApplicationContext()) {
        if (b == null) {
          g g1 = new g();
          this(paramContext);
          b = g1;
          com.facebook.ads.internal.f.g.a();
          c = com.facebook.ads.internal.f.g.b();
          d = com.facebook.ads.internal.f.g.c();
        } 
        return b;
      }  
    return b;
  }
  
  private JSONObject a(Cursor paramCursor) {
    JSONObject jSONObject = new JSONObject();
    while (paramCursor.moveToNext())
      jSONObject.put(paramCursor.getString(i.a.a), paramCursor.getString(i.b.a)); 
    return jSONObject;
  }
  
  private void a(d paramd) {
    this.f.a(paramd, new a<String>(this, paramd) {
          public void a(int param1Int, String param1String) {
            super.a(param1Int, param1String);
            if (!(this.a instanceof c))
              this.b.b(param1String); 
          }
          
          public void a(String param1String) {
            super.a(param1String);
            g.a(this.b).a(this.a.i());
          }
        });
  }
  
  private void a(JSONObject paramJSONObject, String paramString, boolean paramBoolean) {
    int i = 0;
    if (paramBoolean)
      i = paramJSONObject.optInt("dbtype", 0); 
    if (i == 0) {
      this.f.b(paramString);
      return;
    } 
    this.f.a(paramString);
  }
  
  private JSONArray b(Cursor paramCursor) {
    JSONArray jSONArray = new JSONArray();
    while (paramCursor.moveToNext()) {
      JSONObject jSONObject2;
      JSONObject jSONObject1 = new JSONObject();
      jSONObject1.put("id", paramCursor.getString(d.a.a));
      jSONObject1.put("token_id", paramCursor.getString(d.b.a));
      jSONObject1.put("type", paramCursor.getString(d.d.a));
      jSONObject1.put("time", h.a(paramCursor.getDouble(d.e.a)));
      jSONObject1.put("session_time", h.a(paramCursor.getDouble(d.f.a)));
      jSONObject1.put("session_id", paramCursor.getString(d.g.a));
      String str = paramCursor.getString(d.h.a);
      if (str != null) {
        jSONObject2 = new JSONObject(str);
      } else {
        jSONObject2 = new JSONObject();
      } 
      jSONObject1.put("data", jSONObject2);
      jSONArray.put(jSONObject1);
    } 
    return jSONArray;
  }
  
  private JSONArray c(Cursor paramCursor) {
    JSONArray jSONArray = new JSONArray();
    while (paramCursor.moveToNext()) {
      JSONObject jSONObject2;
      JSONObject jSONObject1 = new JSONObject();
      jSONObject1.put("id", paramCursor.getString(c.a.a));
      jSONObject1.put("type", paramCursor.getString(c.c.a));
      jSONObject1.put("time", h.a(paramCursor.getDouble(c.d.a)));
      jSONObject1.put("session_time", h.a(paramCursor.getDouble(c.e.a)));
      jSONObject1.put("session_id", paramCursor.getString(c.f.a));
      String str = paramCursor.getString(c.g.a);
      if (str != null) {
        jSONObject2 = new JSONObject(str);
      } else {
        jSONObject2 = new JSONObject();
      } 
      jSONObject1.put("data", jSONObject2);
      jSONArray.put(jSONObject1);
    } 
    return jSONArray;
  }
  
  public JSONObject a() {
    Cursor cursor1;
    Cursor cursor2;
    Cursor cursor3;
    Cursor cursor4;
    Exception exception;
    JSONObject jSONObject = null;
    try {
      null = this.f.f();
      try {
      
      } catch (JSONException jSONException) {
      
      } finally {
        cursor3 = null;
        cursor4 = cursor1;
        if (null != null)
          null.close(); 
        if (cursor3 != null)
          cursor3.close(); 
        if (cursor4 != null)
          cursor4.close(); 
      } 
      return null;
    } catch (JSONException null) {
      Cursor cursor = null;
      null = null;
      cursor3 = null;
      return null;
    } finally {
      exception = null;
      cursor3 = null;
      cursor2 = null;
    } 
    if (cursor2 != null)
      cursor2.close(); 
    if (cursor3 != null)
      cursor3.close(); 
    if (cursor4 != null)
      cursor4.close(); 
    throw exception;
  }
  
  public void a(String paramString) {
    (new y()).execute((Object[])new String[] { paramString });
  }
  
  public void a(String paramString, l paraml) {
    a(new a(paramString, c, d, paraml));
  }
  
  public void a(String paramString, Map<String, String> paramMap) {
    (new y(paramMap)).execute((Object[])new String[] { paramString });
  }
  
  public void a(String paramString1, Map<String, String> paramMap, String paramString2, h paramh) {
    a(new l(this.g, paramString1, c, d, paramMap, paramString2, paramh));
  }
  
  public void a(String paramString, Map<String, String> paramMap1, Map<String, String> paramMap2) {
    (new y(paramMap1, paramMap2)).execute((Object[])new String[] { paramString });
  }
  
  public boolean a(JSONArray paramJSONArray) {
    boolean bool = h.c(this.g);
    byte b = 0;
    boolean bool1;
    for (bool1 = true; b < paramJSONArray.length(); bool1 = bool2) {
      boolean bool2;
      try {
        JSONObject jSONObject = paramJSONArray.getJSONObject(b);
        String str = jSONObject.getString("id");
        int i = jSONObject.getInt("code");
        if (i == 1) {
          a(jSONObject, str, bool);
          bool2 = bool1;
        } else if (i >= 1000 && i < 2000) {
          bool2 = false;
        } else {
          bool2 = bool1;
          if (i >= 2000) {
            bool2 = bool1;
            if (i < 3000) {
              a(jSONObject, str, bool);
              bool2 = bool1;
            } 
          } 
        } 
      } catch (JSONException jSONException) {
        bool2 = bool1;
      } 
      b++;
    } 
    return bool1;
  }
  
  public void b() {
    this.f.h();
    this.f.b();
  }
  
  public void b(String paramString) {
    Log.e(a, "AdEventManager error: " + paramString);
  }
  
  public void b(String paramString, Map<String, String> paramMap) {
    if (!TextUtils.isEmpty(paramString))
      a(new i(this.g, paramString, c, d, paramMap)); 
  }
  
  public void c(String paramString, Map<String, String> paramMap) {
    if (!TextUtils.isEmpty(paramString))
      a(new k(this.g, paramString, c, d, paramMap)); 
  }
  
  public void d(String paramString, Map<String, String> paramMap) {
    if (!TextUtils.isEmpty(paramString))
      a(new o(this.g, paramString, c, d, paramMap)); 
  }
  
  public void e(String paramString, Map<String, String> paramMap) {
    if (!TextUtils.isEmpty(paramString))
      a(new m(paramString, c, d, paramMap)); 
  }
  
  public void f(String paramString, Map<String, String> paramMap) {
    if (!TextUtils.isEmpty(paramString))
      a(new b(this.g, paramString, c, d, paramMap)); 
  }
  
  public void g(String paramString, Map<String, String> paramMap) {
    if (!TextUtils.isEmpty(paramString))
      a(new j(this.g, paramString, c, d, paramMap)); 
  }
  
  public void h(String paramString, Map<String, String> paramMap) {
    if (!TextUtils.isEmpty(paramString))
      a(new n(this.g, paramString, c, d, paramMap)); 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/g/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */