package com.facebook.ads.internal.g;

import android.content.Context;
import java.util.Map;

public class l extends d {
  protected String f;
  
  protected h g;
  
  public l(Context paramContext, String paramString1, double paramDouble, String paramString2, Map<String, String> paramMap, String paramString3, h paramh) {
    super(paramContext, paramString1, paramDouble, paramString2, paramMap);
    this.f = paramString3;
    this.g = paramh;
  }
  
  public h a() {
    return this.g;
  }
  
  public String b() {
    return this.f;
  }
  
  public boolean c() {
    return true;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/g/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */