package com.facebook.ads.internal.g;

public enum h {
  a(0),
  b(1);
  
  public final int c;
  
  h(int paramInt1) {
    this.c = paramInt1;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/g/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */