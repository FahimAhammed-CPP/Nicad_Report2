package com.facebook.ads.internal.g;

public abstract class s<T extends q> {
  public abstract Class<T> a();
  
  public abstract void a(T paramT);
  
  public boolean b(T paramT) {
    return true;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/g/s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */