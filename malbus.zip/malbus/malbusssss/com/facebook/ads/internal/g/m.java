package com.facebook.ads.internal.g;

import java.util.Map;

public class m extends d {
  public m(String paramString1, double paramDouble, String paramString2, Map<String, String> paramMap) {
    super(paramString1, paramDouble, paramString2, paramMap);
  }
  
  public h a() {
    return h.b;
  }
  
  public String b() {
    return "native_view";
  }
  
  public boolean c() {
    return false;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/g/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */