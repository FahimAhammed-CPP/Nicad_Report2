package com.facebook.ads.internal.g;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.WorkerThread;
import android.text.TextUtils;
import com.facebook.ads.internal.h;
import com.facebook.ads.internal.i.a.n;
import com.facebook.ads.internal.i.a.p;
import com.facebook.ads.internal.server.b;
import com.facebook.ads.internal.util.x;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.json.JSONArray;
import org.json.JSONObject;

public class e {
  private static final String a = e.class.getSimpleName();
  
  private static final String b = b.b();
  
  private final a c;
  
  private final ThreadPoolExecutor d;
  
  private final ConnectivityManager e;
  
  private final com.facebook.ads.internal.i.a.a f;
  
  private final Handler g;
  
  private final long h;
  
  private final long i;
  
  private final Runnable j = new Runnable(this) {
      public void run() {
        e.a(this.a, false);
        if (e.a(this.a).getQueue().isEmpty())
          (new AsyncTask<Void, Void, Void>(this) {
              protected Void a(Void... param2VarArgs) {
                e.b(this.a.a);
                if (e.c(this.a.a) > 0L)
                  try {
                    Thread.sleep(e.c(this.a.a));
                  } catch (InterruptedException interruptedException) {} 
                e.d(this.a.a);
                return null;
              }
            }).executeOnExecutor(e.a(this.a), (Object[])new Void[0]); 
      }
    };
  
  private volatile boolean k;
  
  private int l;
  
  private long m;
  
  public e(Context paramContext, a parama) {
    this.c = parama;
    this.d = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>());
    this.e = (ConnectivityManager)paramContext.getSystemService("connectivity");
    this.f = x.b(paramContext);
    this.g = new Handler(Looper.getMainLooper());
    this.h = h.d(paramContext);
    this.i = h.e(paramContext);
  }
  
  private void a() {
    if (this.l >= 3) {
      c();
      a(false);
      return;
    } 
    if (this.l == 1) {
      this.m = 2000L;
    } else {
      this.m *= 2L;
    } 
    a(true);
  }
  
  private void a(long paramLong) {
    this.g.postDelayed(this.j, paramLong);
  }
  
  @WorkerThread
  private void b() {
    try {
      NetworkInfo networkInfo = this.e.getActiveNetworkInfo();
      if (networkInfo == null || !networkInfo.isConnectedOrConnecting()) {
        a(this.i);
        return;
      } 
      JSONObject jSONObject = this.c.a();
      if (jSONObject == null) {
        c();
        return;
      } 
    } catch (Exception exception) {
      a();
      return;
    } 
    p p = new p();
    this();
    p.a("payload", exception.toString());
    n n = this.f.b(b, p);
    if (n != null) {
      String str = n.e();
    } else {
      exception = null;
    } 
    if (TextUtils.isEmpty((CharSequence)exception)) {
      a();
      return;
    } 
    if (n.a() != 200) {
      a();
      return;
    } 
    a a1 = this.c;
    JSONArray jSONArray = new JSONArray();
    this((String)exception);
    if (!a1.a(jSONArray)) {
      a();
      return;
    } 
    c();
  }
  
  private void c() {
    this.l = 0;
    this.m = 0L;
    if (this.d.getQueue().size() == 0)
      this.c.b(); 
  }
  
  public void a(boolean paramBoolean) {
    if (paramBoolean || !this.k) {
      long l;
      this.k = true;
      this.g.removeCallbacks(this.j);
      if (paramBoolean) {
        l = this.h;
      } else {
        l = this.i;
      } 
      a(l);
    } 
  }
  
  static interface a {
    JSONObject a();
    
    boolean a(JSONArray param1JSONArray);
    
    void b();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/g/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */