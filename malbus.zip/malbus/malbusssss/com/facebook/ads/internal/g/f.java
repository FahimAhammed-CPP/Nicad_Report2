package com.facebook.ads.internal.g;

import java.util.Map;

public interface f {
  void a(String paramString);
  
  void a(String paramString, Map<String, String> paramMap);
  
  void a(String paramString, Map<String, String> paramMap1, Map<String, String> paramMap2);
  
  void b(String paramString, Map<String, String> paramMap);
  
  void c(String paramString, Map<String, String> paramMap);
  
  void d(String paramString, Map<String, String> paramMap);
  
  void e(String paramString, Map<String, String> paramMap);
  
  void f(String paramString, Map<String, String> paramMap);
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/g/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */