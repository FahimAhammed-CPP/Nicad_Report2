package com.facebook.ads.internal.g;

import com.facebook.ads.internal.util.n;

public class p extends d {
  public p(double paramDouble, String paramString, n paramn) {
    super(null, paramDouble, paramString, paramn.a());
  }
  
  public h a() {
    return h.b;
  }
  
  public String b() {
    return "debug_crash_report";
  }
  
  public boolean c() {
    return true;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/g/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */