package com.facebook.ads.internal.g;

import android.content.Context;
import com.facebook.ads.internal.util.a;
import com.facebook.ads.internal.util.h;
import java.util.HashMap;
import java.util.Map;

public abstract class d {
  protected final String a;
  
  protected final double b;
  
  protected final double c;
  
  protected final String d;
  
  protected final Map<String, String> e;
  
  public d(Context paramContext, String paramString1, double paramDouble, String paramString2, Map<String, String> paramMap) {
    this.a = paramString1;
    this.b = System.currentTimeMillis() / 1000.0D;
    this.c = paramDouble;
    this.d = paramString2;
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (paramMap != null && !paramMap.isEmpty())
      hashMap.putAll(paramMap); 
    if (c())
      hashMap.put("analog", h.a(a.a())); 
    if (paramContext != null)
      hashMap.put("kgr", String.valueOf(h.b(paramContext))); 
    this.e = a((Map)hashMap);
  }
  
  public d(String paramString1, double paramDouble, String paramString2, Map<String, String> paramMap) {
    this(null, paramString1, paramDouble, paramString2, paramMap);
  }
  
  private static Map<String, String> a(Map<String, String> paramMap) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (Map.Entry<String, String> entry : paramMap.entrySet()) {
      String str1 = (String)entry.getKey();
      String str2 = (String)entry.getValue();
      if (str2 != null)
        hashMap.put(str1, str2); 
    } 
    return (Map)hashMap;
  }
  
  public abstract h a();
  
  public abstract String b();
  
  public abstract boolean c();
  
  public String d() {
    return this.a;
  }
  
  public double e() {
    return this.b;
  }
  
  public double f() {
    return this.c;
  }
  
  public String g() {
    return this.d;
  }
  
  public Map<String, String> h() {
    return this.e;
  }
  
  public final boolean i() {
    return (a() == h.a);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/g/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */