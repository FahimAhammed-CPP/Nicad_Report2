package com.facebook.ads.internal.h;

import com.facebook.ads.internal.adapters.e;

public class a {
  private static final String[] a = new String[] { "com.flurry.android.FlurryAgent", "com.flurry.android.ads.FlurryAdErrorType", "com.flurry.android.ads.FlurryAdNative", "com.flurry.android.ads.FlurryAdNativeAsset", "com.flurry.android.ads.FlurryAdNativeListener" };
  
  private static final String[] b = new String[] { "com.inmobi.ads.InMobiNative", "com.inmobi.sdk.InMobiSdk" };
  
  private static final String[] c = new String[] { "com.google.android.gms.ads.formats.NativeAdView" };
  
  public static boolean a(e parame) {
    switch (null.a[parame.ordinal()]) {
      default:
        return false;
      case 1:
        return true;
      case 2:
        return a(a);
      case 3:
        return a(b);
      case 4:
        break;
    } 
    return a(c);
  }
  
  private static boolean a(String paramString) {
    boolean bool;
    try {
      Class.forName(paramString);
      bool = true;
    } catch (Throwable throwable) {
      bool = false;
    } 
    return bool;
  }
  
  private static boolean a(String[] paramArrayOfString) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: ifnonnull -> 10
    //   6: iload_1
    //   7: istore_2
    //   8: iload_2
    //   9: ireturn
    //   10: aload_0
    //   11: arraylength
    //   12: istore_3
    //   13: iconst_0
    //   14: istore #4
    //   16: iload #4
    //   18: iload_3
    //   19: if_icmpge -> 40
    //   22: iload_1
    //   23: istore_2
    //   24: aload_0
    //   25: iload #4
    //   27: aaload
    //   28: invokestatic a : (Ljava/lang/String;)Z
    //   31: ifeq -> 8
    //   34: iinc #4, 1
    //   37: goto -> 16
    //   40: iconst_1
    //   41: istore_2
    //   42: goto -> 8
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/h/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */