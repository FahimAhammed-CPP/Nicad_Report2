package com.facebook.ads.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.facebook.ads.internal.util.h;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import java.lang.reflect.Method;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.atomic.AtomicBoolean;

public class f {
  public static final String a = f.class.getSimpleName();
  
  private final String b;
  
  private final boolean c;
  
  private final c d;
  
  private f(String paramString, boolean paramBoolean, c paramc) {
    this.b = paramString;
    this.c = paramBoolean;
    this.d = paramc;
  }
  
  private static f a(Context paramContext) {
    try {
      AdvertisingIdClient.Info info = AdvertisingIdClient.getAdvertisingIdInfo(paramContext);
      if (info != null) {
        f f1 = new f();
        this(info.getId(), info.isLimitAdTrackingEnabled(), c.c);
        return f1;
      } 
    } catch (Throwable throwable) {}
    return null;
  }
  
  public static f a(Context paramContext, h.a parama) {
    // Byte code:
    //   0: invokestatic myLooper : ()Landroid/os/Looper;
    //   3: invokestatic getMainLooper : ()Landroid/os/Looper;
    //   6: if_acmpne -> 19
    //   9: new java/lang/IllegalStateException
    //   12: dup
    //   13: ldc 'Cannot get advertising info on main thread.'
    //   15: invokespecial <init> : (Ljava/lang/String;)V
    //   18: athrow
    //   19: aload_1
    //   20: ifnull -> 54
    //   23: aload_1
    //   24: getfield b : Ljava/lang/String;
    //   27: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   30: ifne -> 54
    //   33: new com/facebook/ads/internal/f
    //   36: dup
    //   37: aload_1
    //   38: getfield b : Ljava/lang/String;
    //   41: aload_1
    //   42: getfield c : Z
    //   45: getstatic com/facebook/ads/internal/f$c.b : Lcom/facebook/ads/internal/f$c;
    //   48: invokespecial <init> : (Ljava/lang/String;ZLcom/facebook/ads/internal/f$c;)V
    //   51: astore_2
    //   52: aload_2
    //   53: areturn
    //   54: aload_0
    //   55: invokestatic a : (Landroid/content/Context;)Lcom/facebook/ads/internal/f;
    //   58: astore_2
    //   59: aload_2
    //   60: ifnull -> 75
    //   63: aload_2
    //   64: astore_1
    //   65: aload_2
    //   66: invokevirtual a : ()Ljava/lang/String;
    //   69: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   72: ifeq -> 80
    //   75: aload_0
    //   76: invokestatic b : (Landroid/content/Context;)Lcom/facebook/ads/internal/f;
    //   79: astore_1
    //   80: aload_1
    //   81: ifnull -> 96
    //   84: aload_1
    //   85: astore_2
    //   86: aload_1
    //   87: invokevirtual a : ()Ljava/lang/String;
    //   90: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   93: ifeq -> 52
    //   96: aload_0
    //   97: invokestatic c : (Landroid/content/Context;)Lcom/facebook/ads/internal/f;
    //   100: astore_2
    //   101: goto -> 52
  }
  
  private static f b(Context paramContext) {
    Method method2 = h.a("com.google.android.gms.common.GooglePlayServicesUtil", "isGooglePlayServicesAvailable", new Class[] { Context.class });
    if (method2 == null)
      return null; 
    Object object = h.a(null, method2, new Object[] { paramContext });
    if (object == null || ((Integer)object).intValue() != 0)
      return null; 
    object = h.a("com.google.android.gms.ads.identifier.AdvertisingIdClient", "getAdvertisingIdInfo", new Class[] { Context.class });
    if (object == null)
      return null; 
    object = h.a(null, (Method)object, new Object[] { paramContext });
    if (object == null)
      return null; 
    Method method1 = h.a(object.getClass(), "getId", new Class[0]);
    Method method3 = h.a(object.getClass(), "isLimitAdTrackingEnabled", new Class[0]);
    return (method1 == null || method3 == null) ? null : new f((String)h.a(object, method1, new Object[0]), ((Boolean)h.a(object, method3, new Object[0])).booleanValue(), c.d);
  }
  
  private static f c(Context paramContext) {
    b b = new b();
    Intent intent = new Intent("com.google.android.gms.ads.identifier.service.START");
    intent.setPackage("com.google.android.gms");
    if (paramContext.bindService(intent, b, 1))
      try {
        a a = new a();
        this(b.a());
        f f1 = new f();
        this(a.a(), a.b(), c.e);
        return f1;
      } catch (Exception exception) {
        return null;
      } finally {
        paramContext.unbindService(b);
      }  
    return null;
  }
  
  public String a() {
    return this.b;
  }
  
  public boolean b() {
    return this.c;
  }
  
  public c c() {
    return this.d;
  }
  
  private static final class a implements IInterface {
    private IBinder a;
    
    a(IBinder param1IBinder) {
      this.a = param1IBinder;
    }
    
    public String a() {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
        this.a.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readString();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public IBinder asBinder() {
      return this.a;
    }
    
    public boolean b() {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
        parcel1.writeInt(1);
        this.a.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i == 0)
          bool = false; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
  
  private static final class b implements ServiceConnection {
    private AtomicBoolean a = new AtomicBoolean(false);
    
    private final BlockingQueue<IBinder> b = new LinkedBlockingDeque<IBinder>();
    
    private b() {}
    
    public IBinder a() {
      if (this.a.compareAndSet(true, true))
        throw new IllegalStateException("Binder already consumed"); 
      return this.b.take();
    }
    
    public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
      try {
        this.b.put(param1IBinder);
      } catch (InterruptedException interruptedException) {}
    }
    
    public void onServiceDisconnected(ComponentName param1ComponentName) {}
  }
  
  public enum c {
    a, b, c, d, e;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */