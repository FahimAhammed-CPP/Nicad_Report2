package com.facebook.ads.internal;

public enum j {
  a("com.facebook.ads.rewarded_video.completed"),
  b("com.facebook.ads.rewarded_video.completed.without.reward"),
  c("com.facebook.ads.rewarded_video.error"),
  d("com.facebook.ads.rewarded_video.error"),
  e("com.facebook.ads.rewarded_video.ad_click"),
  f("com.facebook.ads.rewarded_video.ad_impression"),
  g("com.facebook.ads.rewarded_video.closed"),
  h("com.facebook.ads.rewarded_video.server_reward_success"),
  i("com.facebook.ads.rewarded_video.server_reward_failed");
  
  private String j;
  
  j(String paramString1) {
    this.j = paramString1;
  }
  
  public String a() {
    return this.j;
  }
  
  public String a(String paramString) {
    return this.j + ":" + paramString;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */