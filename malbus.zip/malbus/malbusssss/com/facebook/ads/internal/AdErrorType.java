package com.facebook.ads.internal;

import com.facebook.ads.AdError;

public enum AdErrorType {
  AD_REQUEST_FAILED,
  AD_REQUEST_TIMEOUT,
  DISABLED_APP,
  ERROR_MESSAGE,
  INTERNAL_ERROR,
  LOAD_TOO_FREQUENTLY,
  NETWORK_ERROR,
  NO_AD_PLACEMENT,
  NO_FILL,
  PARSER_FAILURE,
  SERVER_ERROR,
  START_BEFORE_INIT,
  UNKNOWN_ERROR(-1, "unknown error", false),
  UNKNOWN_RESPONSE(-1, "unknown error", false);
  
  private final int a;
  
  private final String b;
  
  private final boolean c;
  
  static {
    NETWORK_ERROR = new AdErrorType("NETWORK_ERROR", 1, 1000, "Network Error", true);
    NO_FILL = new AdErrorType("NO_FILL", 2, 1001, "No Fill", true);
    LOAD_TOO_FREQUENTLY = new AdErrorType("LOAD_TOO_FREQUENTLY", 3, 1002, "Ad was re-loaded too frequently", true);
    DISABLED_APP = new AdErrorType("DISABLED_APP", 4, 1005, "App is disabled from making ad requests", true);
    SERVER_ERROR = new AdErrorType("SERVER_ERROR", 5, 2000, "Server Error", true);
    INTERNAL_ERROR = new AdErrorType("INTERNAL_ERROR", 6, 2001, "Internal Error", true);
    START_BEFORE_INIT = new AdErrorType("START_BEFORE_INIT", 7, 2004, "initAd must be called before startAd", true);
    AD_REQUEST_FAILED = new AdErrorType("AD_REQUEST_FAILED", 8, 1111, "Facebook Ads SDK request for ads failed", false);
    AD_REQUEST_TIMEOUT = new AdErrorType("AD_REQUEST_TIMEOUT", 9, 1112, "Facebook Ads SDK request for ads timed out", false);
    PARSER_FAILURE = new AdErrorType("PARSER_FAILURE", 10, 1201, "Failed to parse Facebook Ads SDK delivery response", false);
    UNKNOWN_RESPONSE = new AdErrorType("UNKNOWN_RESPONSE", 11, 1202, "Unknown Facebook Ads SDK delivery response type", false);
    ERROR_MESSAGE = new AdErrorType("ERROR_MESSAGE", 12, 1203, "Facebook Ads SDK delivery response Error message", true);
    NO_AD_PLACEMENT = new AdErrorType("NO_AD_PLACEMENT", 13, 1302, "Facebook Ads SDK returned no ad placements", false);
    d = new AdErrorType[] { 
        UNKNOWN_ERROR, NETWORK_ERROR, NO_FILL, LOAD_TOO_FREQUENTLY, DISABLED_APP, SERVER_ERROR, INTERNAL_ERROR, START_BEFORE_INIT, AD_REQUEST_FAILED, AD_REQUEST_TIMEOUT, 
        PARSER_FAILURE, UNKNOWN_RESPONSE, ERROR_MESSAGE, NO_AD_PLACEMENT };
  }
  
  AdErrorType(int paramInt1, String paramString1, boolean paramBoolean) {
    this.a = paramInt1;
    this.b = paramString1;
    this.c = paramBoolean;
  }
  
  public static AdErrorType adErrorTypeFromCode(int paramInt) {
    return adErrorTypeFromCode(paramInt, UNKNOWN_ERROR);
  }
  
  public static AdErrorType adErrorTypeFromCode(int paramInt, AdErrorType paramAdErrorType) {
    AdErrorType[] arrayOfAdErrorType = values();
    int i = arrayOfAdErrorType.length;
    byte b = 0;
    while (true) {
      AdErrorType adErrorType = paramAdErrorType;
      if (b < i) {
        adErrorType = arrayOfAdErrorType[b];
        if (adErrorType.getErrorCode() != paramInt) {
          b++;
          continue;
        } 
      } 
      return adErrorType;
    } 
  }
  
  boolean a() {
    return this.c;
  }
  
  public AdError getAdError(String paramString) {
    return (new b(this, paramString)).b();
  }
  
  public b getAdErrorWrapper(String paramString) {
    return new b(this, paramString);
  }
  
  public String getDefaultErrorMessage() {
    return this.b;
  }
  
  public int getErrorCode() {
    return this.a;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/AdErrorType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */