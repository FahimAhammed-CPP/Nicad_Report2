package com.facebook.ads.internal.j;

public enum c {
  a(0),
  b(1),
  c(2),
  d(3),
  e(4),
  f(5),
  g(6),
  h(7),
  i(8),
  j(9),
  k(10),
  l(11),
  m(12),
  n(13),
  o(14),
  p(15);
  
  private final int q;
  
  c(int paramInt1) {
    this.q = paramInt1;
  }
  
  public int a() {
    return this.q;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/j/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */