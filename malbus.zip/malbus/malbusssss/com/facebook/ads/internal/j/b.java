package com.facebook.ads.internal.j;

public class b {
  private c a;
  
  private float b;
  
  public b(c paramc) {
    this(paramc, 0.0F);
  }
  
  public b(c paramc, float paramFloat) {
    this.a = paramc;
    this.b = paramFloat;
  }
  
  public boolean a() {
    return (this.a == c.b);
  }
  
  public int b() {
    return this.a.a();
  }
  
  public float c() {
    return this.b;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/j/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */