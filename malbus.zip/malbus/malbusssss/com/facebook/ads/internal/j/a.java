package com.facebook.ads.internal.j;

import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.View;
import com.facebook.ads.internal.h;
import com.facebook.ads.internal.util.al;
import com.facebook.ads.internal.util.h;
import com.facebook.ads.internal.util.o;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

public class a {
  private static final String a = a.class.getSimpleName();
  
  private final View b;
  
  private final int c;
  
  private final int d;
  
  private final a e;
  
  private final Handler f = new Handler();
  
  private final Runnable g = (Runnable)new b(this);
  
  private final boolean h;
  
  private int i = 0;
  
  private int j = 1000;
  
  private boolean k = true;
  
  private b l = new b(c.a);
  
  private Map<String, Integer> m = new HashMap<String, Integer>();
  
  private long n = 0L;
  
  private int o = 0;
  
  public a(View paramView, int paramInt1, int paramInt2, boolean paramBoolean, a parama) {
    this.b = paramView;
    this.c = paramInt1;
    this.e = parama;
    this.h = paramBoolean;
    paramInt1 = paramInt2;
    if (paramInt2 < 0)
      paramInt1 = 0; 
    this.d = paramInt1;
  }
  
  public a(View paramView, int paramInt, a parama) {
    this(paramView, paramInt, 0, false, parama);
  }
  
  public a(View paramView, int paramInt, boolean paramBoolean, a parama) {
    this(paramView, paramInt, 0, paramBoolean, parama);
  }
  
  public static b a(View paramView, int paramInt) {
    Context context;
    float f;
    if (paramView == null) {
      a(paramView, false, "adView is null.");
      return new b(c.c);
    } 
    if (paramView.getParent() == null) {
      a(paramView, false, "adView has no parent.");
      return new b(c.d);
    } 
    if (paramView.getWindowVisibility() != 0) {
      a(paramView, false, "adView window is not set to VISIBLE.");
      return new b(c.e);
    } 
    if (paramView.getVisibility() != 0) {
      a(paramView, false, "adView is not set to VISIBLE.");
      return new b(c.f);
    } 
    if (paramView.getMeasuredWidth() <= 0 || paramView.getMeasuredHeight() <= 0) {
      a(paramView, false, "adView has invisible dimensions (w=" + paramView.getMeasuredWidth() + ", h=" + paramView.getMeasuredHeight());
      return new b(c.g);
    } 
    if (Build.VERSION.SDK_INT >= 11 && paramView.getAlpha() < 0.9F) {
      a(paramView, false, "adView is too transparent.");
      return new b(c.h);
    } 
    int i = paramView.getWidth();
    int j = paramView.getHeight();
    int[] arrayOfInt = new int[2];
    try {
      paramView.getLocationOnScreen(arrayOfInt);
      context = paramView.getContext();
      DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
      Rect rect = new Rect(0, 0, displayMetrics.widthPixels, displayMetrics.heightPixels);
      float f1 = 0.0F;
      if (rect.intersect(arrayOfInt[0], arrayOfInt[1], arrayOfInt[0] + i, arrayOfInt[1] + j))
        f1 = (rect.width() * rect.height()) * 1.0F / (i * j); 
      boolean bool = h.i(context);
      int k = h.j(context);
      if (bool) {
        f1 *= 100.0F;
        f = f1;
        if (f1 < k) {
          a(paramView, false, String.format("adView visible area is too small [%.2f%% visible, current threshold %d%%]", new Object[] { Float.valueOf(f1), Integer.valueOf(k) }));
          return new b(c.n, f1);
        } 
      } else {
        if (arrayOfInt[0] < 0 || displayMetrics.widthPixels - arrayOfInt[0] < i) {
          a(paramView, false, "adView is not fully on screen horizontally.");
          return new b(c.j, f1);
        } 
        paramInt = (int)(j * (100.0D - paramInt) / 100.0D);
        if (arrayOfInt[1] < 0 && Math.abs(arrayOfInt[1]) > paramInt) {
          a(paramView, false, "adView is not visible from the top.");
          return new b(c.k, f1);
        } 
        f = f1;
        if (j + arrayOfInt[1] - displayMetrics.heightPixels > paramInt) {
          a(paramView, false, "adView is not visible from the bottom.");
          return new b(c.l, f1);
        } 
      } 
    } catch (NullPointerException nullPointerException) {
      a(paramView, false, "Cannot get location on screen.");
      return new b(c.g);
    } 
    if (!o.b(context)) {
      a(paramView, false, "Screen is not interactive.");
      return new b(c.m, f);
    } 
    if (!o.c(context)) {
      a(paramView, false, "Keyguard is obstructing view.");
      return new b(c.p, f);
    } 
    a(paramView, true, "adView is visible.");
    return new b(c.b, f);
  }
  
  private static void a(View paramView, boolean paramBoolean, String paramString) {}
  
  public void a() {
    this.f.postDelayed(this.g, this.i);
    this.k = false;
    this.o = 0;
  }
  
  public void a(int paramInt) {
    this.i = paramInt;
  }
  
  public void a(Map<String, String> paramMap) {
    paramMap.put("vrc", String.valueOf(this.l.b()));
    paramMap.put("vp", String.valueOf(this.l.c()));
    paramMap.put("vh", (new JSONObject(this.m)).toString());
    paramMap.put("vt", h.a(this.n));
  }
  
  public void b() {
    this.f.removeCallbacks(this.g);
    this.k = true;
    this.o = 0;
  }
  
  public void b(int paramInt) {
    this.j = paramInt;
  }
  
  public static abstract class a {
    public abstract void a();
    
    public void b() {}
  }
  
  private static final class b extends al<a> {
    public b(a param1a) {
      super(param1a);
    }
    
    public void run() {
      int i = 0;
      a a = (a)a();
      if (a == null)
        return; 
      View view = a.a(a);
      a.a a1 = a.b(a);
      if (view != null && a1 != null) {
        boolean bool1;
        boolean bool2;
        b b1 = a.a(view, a.c(a));
        if (b1.a()) {
          a.d(a);
        } else {
          a.a(a, 0);
        } 
        if (a.e(a) > a.f(a)) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (a.g(a) != null && a.g(a).a()) {
          bool2 = true;
        } else {
          bool2 = false;
        } 
        if (bool1 || !b1.a())
          a.a(a, b1); 
        synchronized (String.valueOf(b1.b())) {
          if (a.h(a).containsKey(null))
            i = ((Integer)a.h(a).get(null)).intValue(); 
          a.h(a).put(null, Integer.valueOf(i + 1));
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{com/facebook/ads/internal/j/a}, name=null} */
          if (bool1 && !bool2) {
            a.a(a, System.currentTimeMillis());
            a1.a();
            if (a.i(a)) {
              if (!a.j(a))
                a.m(a).postDelayed(a.k(a), a.l(a)); 
              return;
            } 
            return;
          } 
        } 
        if (!bool1 && bool2)
          a1.b(); 
      } else {
        return;
      } 
      if (!a.j(a))
        a.m(a).postDelayed(a.k(a), a.l(a)); 
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/j/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */