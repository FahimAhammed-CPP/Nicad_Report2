package com.facebook.ads.internal;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import com.facebook.ads.AdError;
import com.facebook.ads.AdSettings;
import com.facebook.ads.AdSize;
import com.facebook.ads.internal.adapters.AdAdapter;
import com.facebook.ads.internal.adapters.BannerAdapter;
import com.facebook.ads.internal.adapters.BannerAdapterListener;
import com.facebook.ads.internal.adapters.InterstitialAdapter;
import com.facebook.ads.internal.adapters.InterstitialAdapterListener;
import com.facebook.ads.internal.adapters.d;
import com.facebook.ads.internal.adapters.r;
import com.facebook.ads.internal.adapters.t;
import com.facebook.ads.internal.adapters.v;
import com.facebook.ads.internal.adapters.w;
import com.facebook.ads.internal.adapters.x;
import com.facebook.ads.internal.adapters.y;
import com.facebook.ads.internal.d.a;
import com.facebook.ads.internal.f.a;
import com.facebook.ads.internal.f.d;
import com.facebook.ads.internal.f.e;
import com.facebook.ads.internal.f.f;
import com.facebook.ads.internal.f.h;
import com.facebook.ads.internal.g.f;
import com.facebook.ads.internal.g.g;
import com.facebook.ads.internal.server.AdPlacementType;
import com.facebook.ads.internal.server.a;
import com.facebook.ads.internal.server.e;
import com.facebook.ads.internal.util.al;
import com.facebook.ads.internal.util.c;
import com.facebook.ads.internal.util.d;
import com.facebook.ads.internal.util.h;
import com.facebook.ads.internal.util.w;
import com.facebook.ads.internal.util.y;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class DisplayAdController implements a.a {
  private static final String b = DisplayAdController.class.getSimpleName();
  
  private static final Handler h = new Handler(Looper.getMainLooper());
  
  private static boolean i = false;
  
  protected a a;
  
  private final Context c;
  
  private final String d;
  
  private final AdPlacementType e;
  
  private final a f;
  
  private final Handler g = new Handler();
  
  private final Runnable j;
  
  private final Runnable k;
  
  private volatile boolean l;
  
  private boolean m;
  
  private volatile boolean n;
  
  private AdAdapter o;
  
  private AdAdapter p;
  
  private View q;
  
  private d r;
  
  private f s;
  
  private e t;
  
  private c u;
  
  private AdSize v;
  
  private int w;
  
  private final c x;
  
  private boolean y;
  
  private final f z;
  
  public DisplayAdController(Context paramContext, String paramString, e parame, AdPlacementType paramAdPlacementType, AdSize paramAdSize, c paramc, int paramInt, boolean paramBoolean) {
    this.c = paramContext;
    this.d = paramString;
    this.t = parame;
    this.e = paramAdPlacementType;
    this.v = paramAdSize;
    this.u = paramc;
    this.w = paramInt;
    this.x = new c();
    this.f = new a(paramContext);
    this.f.a(this);
    this.j = (Runnable)new a(this);
    this.k = (Runnable)new b(this);
    this.m = paramBoolean;
    j();
    try {
      CookieManager.getInstance();
      if (Build.VERSION.SDK_INT < 21)
        CookieSyncManager.createInstance(paramContext); 
    } catch (Exception exception) {
      Log.w(b, "Failed to initialize CookieManager.");
    } 
    a.a(paramContext).a();
    this.z = (f)g.a(paramContext);
  }
  
  private Map<String, String> a(long paramLong) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("delay", String.valueOf(System.currentTimeMillis() - paramLong));
    return (Map)hashMap;
  }
  
  private void a(AdAdapter paramAdAdapter) {
    if (paramAdAdapter != null)
      paramAdAdapter.onDestroy(); 
  }
  
  private void a(BannerAdapter paramBannerAdapter, d paramd, Map<String, Object> paramMap) {
    Runnable runnable = new Runnable(this, paramBannerAdapter) {
        public void run() {
          DisplayAdController.b(this.b, (AdAdapter)this.a);
          DisplayAdController.c(this.b);
        }
      };
    this.g.postDelayed(runnable, paramd.a().i());
    paramBannerAdapter.loadBannerAd(this.c, this.v, new BannerAdapterListener(this, runnable) {
          public void onBannerAdClicked(BannerAdapter param1BannerAdapter) {
            this.b.a.a();
          }
          
          public void onBannerAdExpanded(BannerAdapter param1BannerAdapter) {
            DisplayAdController.i(this.b);
          }
          
          public void onBannerAdLoaded(BannerAdapter param1BannerAdapter, View param1View) {
            if (param1BannerAdapter == DisplayAdController.e(this.b)) {
              DisplayAdController.f(this.b).removeCallbacks(this.a);
              AdAdapter adAdapter = DisplayAdController.g(this.b);
              DisplayAdController.a(this.b, (AdAdapter)param1BannerAdapter);
              DisplayAdController.a(this.b, param1View);
              if (!DisplayAdController.h(this.b)) {
                this.b.a.a((AdAdapter)param1BannerAdapter);
                return;
              } 
              this.b.a.a(param1View);
              DisplayAdController.b(this.b, adAdapter);
              DisplayAdController.b(this.b);
            } 
          }
          
          public void onBannerAdMinimized(BannerAdapter param1BannerAdapter) {
            DisplayAdController.b(this.b);
          }
          
          public void onBannerError(BannerAdapter param1BannerAdapter, AdError param1AdError) {
            if (param1BannerAdapter == DisplayAdController.e(this.b)) {
              DisplayAdController.f(this.b).removeCallbacks(this.a);
              DisplayAdController.b(this.b, (AdAdapter)param1BannerAdapter);
              DisplayAdController.c(this.b);
            } 
          }
          
          public void onBannerLoggingImpression(BannerAdapter param1BannerAdapter) {
            this.b.a.b();
          }
        }paramMap);
  }
  
  private void a(InterstitialAdapter paramInterstitialAdapter, d paramd, Map<String, Object> paramMap) {
    Runnable runnable = new Runnable(this, paramInterstitialAdapter) {
        public void run() {
          DisplayAdController.b(this.b, (AdAdapter)this.a);
          DisplayAdController.c(this.b);
        }
      };
    this.g.postDelayed(runnable, paramd.a().i());
    paramInterstitialAdapter.loadInterstitialAd(this.c, new InterstitialAdapterListener(this, runnable) {
          public void onInterstitialAdClicked(InterstitialAdapter param1InterstitialAdapter, String param1String, boolean param1Boolean) {
            boolean bool;
            this.b.a.a();
            if (!TextUtils.isEmpty(param1String)) {
              bool = true;
            } else {
              bool = false;
            } 
            if (param1Boolean && bool) {
              Intent intent = new Intent("android.intent.action.VIEW");
              if (!((DisplayAdController.j(this.b)).d instanceof android.app.Activity))
                intent.addFlags(268435456); 
              intent.setData(Uri.parse(param1String));
              (DisplayAdController.j(this.b)).d.startActivity(intent);
            } 
          }
          
          public void onInterstitialAdDismissed(InterstitialAdapter param1InterstitialAdapter) {
            this.b.a.e();
          }
          
          public void onInterstitialAdDisplayed(InterstitialAdapter param1InterstitialAdapter) {
            this.b.a.d();
          }
          
          public void onInterstitialAdLoaded(InterstitialAdapter param1InterstitialAdapter) {
            if (param1InterstitialAdapter == DisplayAdController.e(this.b)) {
              DisplayAdController.f(this.b).removeCallbacks(this.a);
              DisplayAdController.a(this.b, (AdAdapter)param1InterstitialAdapter);
              this.b.a.a((AdAdapter)param1InterstitialAdapter);
              DisplayAdController.b(this.b);
            } 
          }
          
          public void onInterstitialError(InterstitialAdapter param1InterstitialAdapter, AdError param1AdError) {
            if (param1InterstitialAdapter == DisplayAdController.e(this.b)) {
              DisplayAdController.f(this.b).removeCallbacks(this.a);
              DisplayAdController.b(this.b, (AdAdapter)param1InterstitialAdapter);
              DisplayAdController.c(this.b);
              this.b.a.a(new b(param1AdError.getErrorCode(), param1AdError.getErrorMessage()));
            } 
          }
          
          public void onInterstitialLoggingImpression(InterstitialAdapter param1InterstitialAdapter) {
            this.b.a.b();
          }
        }paramMap, this.z);
  }
  
  private void a(r paramr, d paramd, Map<String, Object> paramMap) {
    paramr.a(this.c, new com.facebook.ads.a.a(this) {
          public void a(r param1r) {
            DisplayAdController.a(this.a, (AdAdapter)param1r);
            this.a.a.a((AdAdapter)param1r);
          }
          
          public void a(r param1r, View param1View) {
            this.a.a.a(param1View);
          }
          
          public void a(r param1r, AdError param1AdError) {
            this.a.a.a(new b(param1AdError.getErrorCode(), param1AdError.getErrorMessage()));
          }
          
          public void b(r param1r) {
            this.a.a.a();
          }
          
          public void c(r param1r) {
            this.a.a.b();
          }
          
          public void d(r param1r) {
            this.a.a.c();
          }
        }paramMap, this.z);
  }
  
  private void a(v paramv, d paramd, a parama, Map<String, Object> paramMap) {
    long l = System.currentTimeMillis();
    Runnable runnable = new Runnable(this, paramv, l, parama) {
        public void run() {
          DisplayAdController.b(this.d, (AdAdapter)this.a);
          if (this.a instanceof t)
            h.a(DisplayAdController.k(this.d), w.a(((t)this.a).D()) + " Failed. Ad request timed out"); 
          Map<String, String> map = DisplayAdController.a(this.d, this.b);
          map.put("error", "-1");
          map.put("msg", "timeout");
          DisplayAdController.a(this.d, this.c.a(h.a), map);
          DisplayAdController.c(this.d);
        }
      };
    this.g.postDelayed(runnable, paramd.a().i());
    paramv.a(this.c, new w(this, runnable, l, parama) {
          boolean a = false;
          
          boolean b = false;
          
          boolean c = false;
          
          public void a(v param1v) {
            if (param1v == DisplayAdController.e(this.g)) {
              DisplayAdController.f(this.g).removeCallbacks(this.d);
              DisplayAdController.a(this.g, (AdAdapter)param1v);
              this.g.a.a((AdAdapter)param1v);
              if (!this.a) {
                this.a = true;
                Map map = DisplayAdController.a(this.g, this.e);
                DisplayAdController.a(this.g, this.f.a(h.a), map);
              } 
            } 
          }
          
          public void a(v param1v, AdError param1AdError) {
            if (param1v == DisplayAdController.e(this.g)) {
              DisplayAdController.f(this.g).removeCallbacks(this.d);
              DisplayAdController.b(this.g, (AdAdapter)param1v);
              if (!this.a) {
                this.a = true;
                Map<String, String> map = DisplayAdController.a(this.g, this.e);
                map.put("error", String.valueOf(param1AdError.getErrorCode()));
                map.put("msg", String.valueOf(param1AdError.getErrorMessage()));
                DisplayAdController.a(this.g, this.f.a(h.a), map);
              } 
              DisplayAdController.c(this.g);
            } 
          }
          
          public void b(v param1v) {
            if (!this.b) {
              this.b = true;
              DisplayAdController.a(this.g, this.f.a(h.b), (Map)null);
            } 
          }
          
          public void c(v param1v) {
            if (!this.c) {
              this.c = true;
              DisplayAdController.a(this.g, this.f.a(h.c), (Map)null);
            } 
            if (this.g.a != null)
              this.g.a.a(); 
          }
        }this.z, paramMap);
  }
  
  private void a(x paramx, d paramd, Map<String, Object> paramMap) {
    paramx.a(this.c, new y(this) {
          public void a() {
            this.a.a.g();
          }
          
          public void a(x param1x) {
            DisplayAdController.a(this.a, (AdAdapter)param1x);
            this.a.a.a((AdAdapter)param1x);
          }
          
          public void a(x param1x, AdError param1AdError) {
            this.a.a.a(new b(AdErrorType.INTERNAL_ERROR, null));
            DisplayAdController.b(this.a, (AdAdapter)param1x);
            DisplayAdController.c(this.a);
          }
          
          public void b(x param1x) {
            this.a.a.a();
          }
          
          public void c(x param1x) {
            this.a.a.b();
          }
          
          public void d(x param1x) {
            this.a.a.f();
          }
          
          public void e(x param1x) {
            this.a.a.h();
          }
          
          public void f(x param1x) {
            this.a.a.i();
          }
        }paramMap);
  }
  
  private void a(List<String> paramList, Map<String, String> paramMap) {
    if (paramList != null && !paramList.isEmpty()) {
      Iterator<String> iterator = paramList.iterator();
      while (true) {
        if (iterator.hasNext()) {
          String str = iterator.next();
          (new y(paramMap)).execute((Object[])new String[] { str });
          continue;
        } 
        return;
      } 
    } 
  }
  
  private void j() {
    if (!this.m) {
      IntentFilter intentFilter = new IntentFilter("android.intent.action.SCREEN_ON");
      intentFilter.addAction("android.intent.action.SCREEN_OFF");
      this.c.registerReceiver(this.x, intentFilter);
      this.y = true;
    } 
  }
  
  private void k() {
    if (this.y)
      try {
        this.c.unregisterReceiver(this.x);
        this.y = false;
      } catch (Exception exception) {
        d.a(c.a(exception, "Error unregistering screen state receiever"));
      }  
  }
  
  private AdPlacementType l() {
    return (this.e != null) ? this.e : ((this.v == null) ? AdPlacementType.NATIVE : ((this.v == AdSize.INTERSTITIAL) ? AdPlacementType.INTERSTITIAL : AdPlacementType.BANNER));
  }
  
  private void m() {
    this.s = new f(this.c, this.d, this.v, this.t, this.u, this.w, AdSettings.isTestMode(this.c));
    this.f.a(this.s);
  }
  
  private void n() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic com/facebook/ads/internal/DisplayAdController.h : Landroid/os/Handler;
    //   5: astore_1
    //   6: new com/facebook/ads/internal/DisplayAdController$5
    //   9: astore_2
    //   10: aload_2
    //   11: aload_0
    //   12: invokespecial <init> : (Lcom/facebook/ads/internal/DisplayAdController;)V
    //   15: aload_1
    //   16: aload_2
    //   17: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   20: pop
    //   21: aload_0
    //   22: monitorexit
    //   23: return
    //   24: astore_2
    //   25: aload_0
    //   26: monitorexit
    //   27: aload_2
    //   28: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	24	finally
  }
  
  private void o() {
    b b;
    this.o = null;
    d d1 = this.r;
    a a1 = d1.d();
    if (a1 == null) {
      this.a.a(AdErrorType.NO_FILL.getAdErrorWrapper(""));
      p();
      return;
    } 
    String str = a1.a();
    AdAdapter adAdapter = d.a(str, d1.a().a());
    if (adAdapter == null) {
      Log.e(b, "Adapter does not exist: " + str);
      n();
      return;
    } 
    if (l() != adAdapter.getPlacementType()) {
      this.a.a(AdErrorType.INTERNAL_ERROR.getAdErrorWrapper(""));
      return;
    } 
    this.o = adAdapter;
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    e e1 = d1.a();
    hashMap.put("data", a1.b());
    hashMap.put("definition", e1);
    if (this.s == null) {
      b = AdErrorType.UNKNOWN_ERROR.getAdErrorWrapper("environment is empty");
      this.a.a(b);
      return;
    } 
    switch (null.a[b.getPlacementType().ordinal()]) {
      default:
        Log.e(b, "attempt unexpected adapter type");
        return;
      case 2:
        a((BannerAdapter)b, d1, (Map)hashMap);
        return;
      case 1:
        a((InterstitialAdapter)b, d1, (Map)hashMap);
        return;
      case 3:
        a((v)b, d1, a1, (Map)hashMap);
        return;
      case 4:
        a((r)b, d1, (Map)hashMap);
        return;
      case 5:
        break;
    } 
    hashMap.put("placement_id", this.d);
    a((x)b, d1, (Map)hashMap);
  }
  
  private void p() {
    // Byte code:
    //   0: aload_0
    //   1: getfield m : Z
    //   4: ifne -> 14
    //   7: aload_0
    //   8: getfield l : Z
    //   11: ifeq -> 15
    //   14: return
    //   15: getstatic com/facebook/ads/internal/DisplayAdController$4.a : [I
    //   18: aload_0
    //   19: invokespecial l : ()Lcom/facebook/ads/internal/server/AdPlacementType;
    //   22: invokevirtual ordinal : ()I
    //   25: iaload
    //   26: tableswitch default -> 48, 1 -> 51, 2 -> 114
    //   48: goto -> 14
    //   51: aload_0
    //   52: getfield c : Landroid/content/Context;
    //   55: invokestatic a : (Landroid/content/Context;)Z
    //   58: ifne -> 76
    //   61: aload_0
    //   62: getfield g : Landroid/os/Handler;
    //   65: aload_0
    //   66: getfield k : Ljava/lang/Runnable;
    //   69: ldc2_w 1000
    //   72: invokevirtual postDelayed : (Ljava/lang/Runnable;J)Z
    //   75: pop
    //   76: aload_0
    //   77: getfield r : Lcom/facebook/ads/internal/f/d;
    //   80: ifnonnull -> 180
    //   83: ldc2_w 30000
    //   86: lstore_1
    //   87: lload_1
    //   88: lconst_0
    //   89: lcmp
    //   90: ifle -> 14
    //   93: aload_0
    //   94: getfield g : Landroid/os/Handler;
    //   97: aload_0
    //   98: getfield j : Ljava/lang/Runnable;
    //   101: lload_1
    //   102: invokevirtual postDelayed : (Ljava/lang/Runnable;J)Z
    //   105: pop
    //   106: aload_0
    //   107: iconst_1
    //   108: putfield l : Z
    //   111: goto -> 14
    //   114: aload_0
    //   115: getfield r : Lcom/facebook/ads/internal/f/d;
    //   118: ifnonnull -> 166
    //   121: iconst_1
    //   122: istore_3
    //   123: aload_0
    //   124: getfield q : Landroid/view/View;
    //   127: iload_3
    //   128: invokestatic a : (Landroid/view/View;I)Lcom/facebook/ads/internal/j/b;
    //   131: invokevirtual a : ()Z
    //   134: istore #4
    //   136: aload_0
    //   137: getfield q : Landroid/view/View;
    //   140: ifnull -> 76
    //   143: iload #4
    //   145: ifne -> 76
    //   148: aload_0
    //   149: getfield g : Landroid/os/Handler;
    //   152: aload_0
    //   153: getfield k : Ljava/lang/Runnable;
    //   156: ldc2_w 1000
    //   159: invokevirtual postDelayed : (Ljava/lang/Runnable;J)Z
    //   162: pop
    //   163: goto -> 14
    //   166: aload_0
    //   167: getfield r : Lcom/facebook/ads/internal/f/d;
    //   170: invokevirtual a : ()Lcom/facebook/ads/internal/f/e;
    //   173: invokevirtual e : ()I
    //   176: istore_3
    //   177: goto -> 123
    //   180: aload_0
    //   181: getfield r : Lcom/facebook/ads/internal/f/d;
    //   184: invokevirtual a : ()Lcom/facebook/ads/internal/f/e;
    //   187: invokevirtual b : ()J
    //   190: lstore_1
    //   191: goto -> 87
  }
  
  private void q() {
    if (this.l) {
      this.g.removeCallbacks(this.j);
      this.l = false;
    } 
  }
  
  private Handler r() {
    return !s() ? this.g : h;
  }
  
  private static boolean s() {
    // Byte code:
    //   0: ldc com/facebook/ads/internal/DisplayAdController
    //   2: monitorenter
    //   3: getstatic com/facebook/ads/internal/DisplayAdController.i : Z
    //   6: istore_0
    //   7: ldc com/facebook/ads/internal/DisplayAdController
    //   9: monitorexit
    //   10: iload_0
    //   11: ireturn
    //   12: astore_1
    //   13: ldc com/facebook/ads/internal/DisplayAdController
    //   15: monitorexit
    //   16: aload_1
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	12	finally
  }
  
  protected static void setMainThreadForced(boolean paramBoolean) {
    // Byte code:
    //   0: ldc com/facebook/ads/internal/DisplayAdController
    //   2: monitorenter
    //   3: getstatic com/facebook/ads/internal/DisplayAdController.b : Ljava/lang/String;
    //   6: astore_1
    //   7: new java/lang/StringBuilder
    //   10: astore_2
    //   11: aload_2
    //   12: invokespecial <init> : ()V
    //   15: aload_1
    //   16: aload_2
    //   17: ldc_w 'DisplayAdController changed main thread forced from '
    //   20: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   23: getstatic com/facebook/ads/internal/DisplayAdController.i : Z
    //   26: invokevirtual append : (Z)Ljava/lang/StringBuilder;
    //   29: ldc_w ' to '
    //   32: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   35: iload_0
    //   36: invokevirtual append : (Z)Ljava/lang/StringBuilder;
    //   39: invokevirtual toString : ()Ljava/lang/String;
    //   42: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   45: pop
    //   46: iload_0
    //   47: putstatic com/facebook/ads/internal/DisplayAdController.i : Z
    //   50: ldc com/facebook/ads/internal/DisplayAdController
    //   52: monitorexit
    //   53: return
    //   54: astore_1
    //   55: ldc com/facebook/ads/internal/DisplayAdController
    //   57: monitorexit
    //   58: aload_1
    //   59: athrow
    // Exception table:
    //   from	to	target	type
    //   3	50	54	finally
  }
  
  public e a() {
    return (this.r == null) ? null : this.r.a();
  }
  
  public void a(a parama) {
    this.a = parama;
  }
  
  public void a(b paramb) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial r : ()Landroid/os/Handler;
    //   6: astore_2
    //   7: new com/facebook/ads/internal/DisplayAdController$3
    //   10: astore_3
    //   11: aload_3
    //   12: aload_0
    //   13: aload_1
    //   14: invokespecial <init> : (Lcom/facebook/ads/internal/DisplayAdController;Lcom/facebook/ads/internal/b;)V
    //   17: aload_2
    //   18: aload_3
    //   19: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   22: pop
    //   23: aload_0
    //   24: monitorexit
    //   25: return
    //   26: astore_1
    //   27: aload_0
    //   28: monitorexit
    //   29: aload_1
    //   30: athrow
    // Exception table:
    //   from	to	target	type
    //   2	23	26	finally
  }
  
  public void a(e parame) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial r : ()Landroid/os/Handler;
    //   6: astore_2
    //   7: new com/facebook/ads/internal/DisplayAdController$1
    //   10: astore_3
    //   11: aload_3
    //   12: aload_0
    //   13: aload_1
    //   14: invokespecial <init> : (Lcom/facebook/ads/internal/DisplayAdController;Lcom/facebook/ads/internal/server/e;)V
    //   17: aload_2
    //   18: aload_3
    //   19: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   22: pop
    //   23: aload_0
    //   24: monitorexit
    //   25: return
    //   26: astore_1
    //   27: aload_0
    //   28: monitorexit
    //   29: aload_1
    //   30: athrow
    // Exception table:
    //   from	to	target	type
    //   2	23	26	finally
  }
  
  public void b() {
    m();
  }
  
  public void c() {
    v v;
    if (this.p == null)
      throw new IllegalStateException("no adapter ready to start"); 
    if (this.n)
      throw new IllegalStateException("ad already started"); 
    this.n = true;
    AdPlacementType adPlacementType = this.p.getPlacementType();
    switch (null.a[adPlacementType.ordinal()]) {
      default:
        Log.e(b, "start unexpected adapter type");
        return;
      case 1:
        ((InterstitialAdapter)this.p).show();
        return;
      case 2:
        if (this.q != null) {
          this.a.a(this.q);
          p();
        } 
        return;
      case 3:
        v = (v)this.p;
        if (!v.b())
          throw new IllegalStateException("ad is not ready or already displayed"); 
        this.a.a(v);
        return;
      case 4:
        ((r)this.p).d();
        return;
      case 5:
        break;
    } 
    ((x)this.p).b();
  }
  
  public void d() {
    k();
    if (this.n) {
      q();
      a(this.p);
      this.q = null;
      this.n = false;
    } 
  }
  
  public void e() {
    if (this.n)
      q(); 
  }
  
  public void f() {
    if (this.n)
      p(); 
  }
  
  public void g() {
    q();
    m();
  }
  
  public void h() {
    this.m = true;
    q();
  }
  
  public AdAdapter i() {
    return this.p;
  }
  
  private static final class a extends al<DisplayAdController> {
    public a(DisplayAdController param1DisplayAdController) {
      super(param1DisplayAdController);
    }
    
    public void run() {
      DisplayAdController displayAdController = (DisplayAdController)a();
      if (displayAdController != null) {
        DisplayAdController.a(displayAdController, false);
        DisplayAdController.a(displayAdController);
      } 
    }
  }
  
  private static final class b extends al<DisplayAdController> {
    public b(DisplayAdController param1DisplayAdController) {
      super(param1DisplayAdController);
    }
    
    public void run() {
      DisplayAdController displayAdController = (DisplayAdController)a();
      if (displayAdController != null)
        DisplayAdController.b(displayAdController); 
    }
  }
  
  private class c extends BroadcastReceiver {
    private c(DisplayAdController this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      String str = param1Intent.getAction();
      if ("android.intent.action.SCREEN_OFF".equals(str)) {
        DisplayAdController.i(this.a);
        return;
      } 
      if ("android.intent.action.SCREEN_ON".equals(str))
        DisplayAdController.b(this.a); 
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/DisplayAdController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */