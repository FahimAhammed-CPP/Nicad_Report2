package com.facebook.ads.internal.a;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import com.facebook.ads.internal.g.g;
import com.facebook.ads.internal.g.h;
import com.facebook.ads.internal.util.c;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class e extends a {
  private static final String a = e.class.getSimpleName();
  
  private final Context b;
  
  private final String c;
  
  private final Uri d;
  
  private final Map<String, String> e;
  
  public e(Context paramContext, String paramString, Uri paramUri, Map<String, String> paramMap) {
    this.b = paramContext;
    this.c = paramString;
    this.d = paramUri;
    this.e = paramMap;
  }
  
  public c.a a() {
    return null;
  }
  
  public void b() {
    g g = g.a(this.b);
    if (!TextUtils.isEmpty(this.d.getQueryParameter("data")))
      try {
        JSONObject jSONObject = new JSONObject();
        this(this.d.getQueryParameter("data"));
        Iterator<String> iterator = jSONObject.keys();
        while (iterator.hasNext()) {
          String str1 = iterator.next();
          this.e.put(str1, jSONObject.getString(str1));
        } 
      } catch (JSONException jSONException) {
        g.b("Unable to parse data in passthrough event.");
      }  
    h h2 = h.a;
    String str = this.d.getQueryParameter("priority");
    h h1 = h2;
    if (!TextUtils.isEmpty(str))
      try {
        h1 = h.values()[Integer.valueOf(str).intValue()];
      } catch (Exception exception) {
        h1 = h2;
      }  
    g.a(this.c, this.e, this.d.getQueryParameter("type"), h1);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/a/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */