package com.facebook.ads.internal.a;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import com.facebook.ads.internal.g.g;
import com.facebook.ads.internal.util.c;
import com.facebook.ads.internal.util.h;
import com.facebook.ads.internal.util.y;
import java.util.Map;

public abstract class a {
  public abstract c.a a();
  
  protected void a(Context paramContext, String paramString, Uri paramUri, Map<String, String> paramMap) {
    g g;
    if (!TextUtils.isEmpty(paramString)) {
      g = g.a(paramContext);
      if (this instanceof c) {
        g.h(paramString, paramMap);
      } else {
        g.c(paramString, paramMap);
      } 
    } else {
      paramString = g.getQueryParameter("native_click_report_url");
      if (!TextUtils.isEmpty(paramString)) {
        (new y(paramMap)).execute((Object[])new String[] { paramString });
      } else {
        return;
      } 
    } 
    h.a(paramContext, "Click logged");
  }
  
  public abstract void b();
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */