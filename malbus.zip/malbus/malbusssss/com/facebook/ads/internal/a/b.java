package com.facebook.ads.internal.a;

import android.content.Context;
import android.net.Uri;
import java.util.Map;

public class b {
  public static a a(Context paramContext, String paramString, Uri paramUri, Map<String, String> paramMap) {
    String str1 = paramUri.getAuthority();
    String str2 = paramUri.getQueryParameter("video_url");
    byte b1 = -1;
    switch (str1.hashCode()) {
      default:
        switch (b1) {
          default:
            return new f(paramContext, paramString, paramUri);
          case 0:
            return (str2 != null) ? null : new c(paramContext, paramString, paramUri, paramMap);
          case 1:
            return new d(paramContext, paramString, paramUri, paramMap);
          case 2:
            break;
        } 
        break;
      case 109770977:
        if (str1.equals("store"))
          b1 = 0; 
      case 1546100943:
        if (str1.equals("open_link"))
          b1 = 1; 
      case -1458789996:
        if (str1.equals("passthrough"))
          b1 = 2; 
    } 
    return new e(paramContext, paramString, paramUri, paramMap);
  }
  
  public static boolean a(String paramString) {
    return ("store".equalsIgnoreCase(paramString) || "open_link".equalsIgnoreCase(paramString));
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */