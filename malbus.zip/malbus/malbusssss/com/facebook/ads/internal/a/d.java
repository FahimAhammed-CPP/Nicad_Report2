package com.facebook.ads.internal.a;

import android.content.Context;
import android.net.Uri;
import android.util.Log;
import com.facebook.ads.internal.util.c;
import com.facebook.ads.internal.util.h;
import java.util.Map;

public class d extends a {
  private static final String a = d.class.getSimpleName();
  
  private final Context b;
  
  private final String c;
  
  private final Uri d;
  
  private final Map<String, String> e;
  
  public d(Context paramContext, String paramString, Uri paramUri, Map<String, String> paramMap) {
    this.b = paramContext;
    this.c = paramString;
    this.d = paramUri;
    this.e = paramMap;
  }
  
  public c.a a() {
    return c.a.b;
  }
  
  public void b() {
    a(this.b, this.c, this.d, this.e);
    try {
      h.a(this.b, Uri.parse(this.d.getQueryParameter("link")), this.c);
    } catch (Exception exception) {
      Log.d(a, "Failed to open link url: " + this.d.toString(), exception);
    } 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/a/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */