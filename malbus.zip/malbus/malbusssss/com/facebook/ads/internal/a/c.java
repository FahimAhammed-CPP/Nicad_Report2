package com.facebook.ads.internal.a;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import com.facebook.ads.internal.util.g;
import com.facebook.ads.internal.util.h;
import com.facebook.ads.internal.util.j;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class c extends a {
  private static final String a = c.class.getSimpleName();
  
  private final Context b;
  
  private final String c;
  
  private final Uri d;
  
  private final Map<String, String> e;
  
  public c(Context paramContext, String paramString, Uri paramUri, Map<String, String> paramMap) {
    this.b = paramContext;
    this.c = paramString;
    this.d = paramUri;
    this.e = paramMap;
  }
  
  private Intent a(j paramj) {
    Intent intent = new Intent("android.intent.action.VIEW");
    intent.addFlags(268435456);
    if (!TextUtils.isEmpty(paramj.a()) && !TextUtils.isEmpty(paramj.b()))
      intent.setComponent(new ComponentName(paramj.a(), paramj.b())); 
    if (!TextUtils.isEmpty(paramj.c()))
      intent.setData(Uri.parse(paramj.c())); 
    return intent;
  }
  
  private Intent b(j paramj) {
    if (TextUtils.isEmpty(paramj.a()))
      return null; 
    if (!g.a(this.b, paramj.a()))
      return null; 
    String str = paramj.c();
    if (!TextUtils.isEmpty(str) && (str.startsWith("tel:") || str.startsWith("telprompt:")))
      return new Intent("android.intent.action.CALL", Uri.parse(str)); 
    PackageManager packageManager = this.b.getPackageManager();
    if (TextUtils.isEmpty(paramj.b()) && TextUtils.isEmpty(str))
      return packageManager.getLaunchIntentForPackage(paramj.a()); 
    Intent intent = a(paramj);
    List list = packageManager.queryIntentActivities(intent, 65536);
    if (intent.getComponent() == null)
      for (ResolveInfo resolveInfo : list) {
        if (resolveInfo.activityInfo.packageName.equals(paramj.a())) {
          intent.setComponent(new ComponentName(resolveInfo.activityInfo.packageName, resolveInfo.activityInfo.name));
          break;
        } 
      }  
    return (list.isEmpty() || intent.getComponent() == null) ? null : intent;
  }
  
  private List<j> f() {
    ArrayList<j> arrayList1;
    String str = this.d.getQueryParameter("appsite_data");
    if (TextUtils.isEmpty(str) || "[]".equals(str))
      return null; 
    ArrayList<j> arrayList2 = new ArrayList();
    try {
      JSONObject jSONObject = new JSONObject();
      this(str);
      JSONArray jSONArray = jSONObject.optJSONArray("android");
      arrayList1 = arrayList2;
      if (jSONArray != null) {
        byte b = 0;
        while (true) {
          j j;
          arrayList1 = arrayList2;
          if (b < jSONArray.length()) {
            j = j.a(jSONArray.optJSONObject(b));
            if (j != null)
              arrayList2.add(j); 
            b++;
            continue;
          } 
          return (List<j>)j;
        } 
      } 
    } catch (JSONException jSONException) {
      Log.w(a, "Error parsing appsite_data", (Throwable)jSONException);
      arrayList1 = arrayList2;
    } 
    return arrayList1;
  }
  
  public com.facebook.ads.internal.util.c.a a() {
    return com.facebook.ads.internal.util.c.a.a;
  }
  
  public void b() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield b : Landroid/content/Context;
    //   5: aload_0
    //   6: getfield c : Ljava/lang/String;
    //   9: aload_0
    //   10: getfield d : Landroid/net/Uri;
    //   13: aload_0
    //   14: getfield e : Ljava/util/Map;
    //   17: invokevirtual a : (Landroid/content/Context;Ljava/lang/String;Landroid/net/Uri;Ljava/util/Map;)V
    //   20: aload_0
    //   21: invokevirtual d : ()Ljava/util/List;
    //   24: astore_1
    //   25: aload_1
    //   26: ifnull -> 78
    //   29: aload_1
    //   30: invokeinterface iterator : ()Ljava/util/Iterator;
    //   35: astore_1
    //   36: aload_1
    //   37: invokeinterface hasNext : ()Z
    //   42: ifeq -> 78
    //   45: aload_1
    //   46: invokeinterface next : ()Ljava/lang/Object;
    //   51: checkcast android/content/Intent
    //   54: astore_2
    //   55: aload_0
    //   56: getfield b : Landroid/content/Context;
    //   59: aload_2
    //   60: invokevirtual startActivity : (Landroid/content/Intent;)V
    //   63: return
    //   64: astore_2
    //   65: getstatic com/facebook/ads/internal/a/c.a : Ljava/lang/String;
    //   68: ldc 'Failed to open app intent, falling back'
    //   70: aload_2
    //   71: invokestatic d : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   74: pop
    //   75: goto -> 36
    //   78: aload_0
    //   79: invokevirtual e : ()V
    //   82: goto -> 63
    // Exception table:
    //   from	to	target	type
    //   55	63	64	java/lang/Exception
  }
  
  protected Uri c() {
    String str = this.d.getQueryParameter("store_url");
    return !TextUtils.isEmpty(str) ? Uri.parse(str) : Uri.parse(String.format("market://details?id=%s", new Object[] { this.d.getQueryParameter("store_id") }));
  }
  
  protected List<Intent> d() {
    List<j> list = f();
    ArrayList<Intent> arrayList = new ArrayList();
    if (list != null) {
      Iterator<j> iterator = list.iterator();
      while (iterator.hasNext()) {
        Intent intent = b(iterator.next());
        if (intent != null)
          arrayList.add(intent); 
      } 
    } 
    return arrayList;
  }
  
  public void e() {
    try {
      h.a(this.b, c(), this.c);
    } catch (Exception exception) {
      Log.d(a, "Failed to open market url: " + this.d.toString(), exception);
      String str = this.d.getQueryParameter("store_url_web_fallback");
    } 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */