package com.facebook.ads.internal.a;

import android.content.Context;
import android.net.Uri;
import android.util.Log;
import com.facebook.ads.internal.util.c;
import com.facebook.ads.internal.util.h;

public class f extends a {
  private static final String a = f.class.getSimpleName();
  
  private final Context b;
  
  private final String c;
  
  private final Uri d;
  
  public f(Context paramContext, String paramString, Uri paramUri) {
    this.b = paramContext;
    this.c = paramString;
    this.d = paramUri;
  }
  
  public c.a a() {
    return c.a.b;
  }
  
  public void b() {
    try {
      Log.w("REDIRECTACTION: ", this.d.toString());
      h.a(this.b, this.d, this.c);
    } catch (Exception exception) {
      Log.d(a, "Failed to open link url: " + this.d.toString(), exception);
    } 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/a/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */