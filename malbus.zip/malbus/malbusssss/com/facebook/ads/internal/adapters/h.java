package com.facebook.ads.internal.adapters;

import android.content.Context;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import com.facebook.ads.AdError;
import com.facebook.ads.AdSize;
import com.facebook.ads.internal.a.a;
import com.facebook.ads.internal.a.b;
import com.facebook.ads.internal.f.e;
import com.facebook.ads.internal.util.c;
import com.facebook.ads.internal.util.d;
import com.facebook.ads.internal.util.g;
import com.facebook.ads.internal.util.i;
import com.facebook.ads.internal.view.b;
import com.facebook.ads.internal.view.c;
import java.util.Map;
import org.json.JSONObject;

public class h extends BannerAdapter {
  private static final String a = h.class.getSimpleName();
  
  private c b;
  
  private p c;
  
  private BannerAdapterListener d;
  
  private Map<String, Object> e;
  
  private Context f;
  
  private long g;
  
  private c.a h;
  
  private void a(e parame) {
    this.g = 0L;
    this.h = null;
    o o = o.a((JSONObject)this.e.get("data"));
    if (g.a(this.f, o)) {
      this.d.onBannerError(this, AdError.NO_FILL);
      return;
    } 
    this.b = new c(this.f, new c.b(this, o) {
          public void a() {
            h.c(this.b).b();
          }
          
          public void a(int param1Int) {
            if (param1Int == 0 && h.d(this.b) > 0L && h.e(this.b) != null) {
              d.a(c.a(h.d(this.b), h.e(this.b), this.a.f()));
              h.a(this.b, 0L);
              h.a(this.b, (c.a)null);
            } 
          }
          
          public void a(String param1String, Map<String, String> param1Map) {
            Uri uri = Uri.parse(param1String);
            if ("fbad".equals(uri.getScheme()) && b.a(uri.getAuthority()) && h.a(this.b) != null)
              h.a(this.b).onBannerAdClicked(this.b); 
            a a = b.a(h.b(this.b), this.a.B(), uri, param1Map);
            if (a != null)
              try {
                h.a(this.b, a.a());
                h.a(this.b, System.currentTimeMillis());
                a.b();
              } catch (Exception exception) {
                Log.e(h.a(), "Error executing action", exception);
              }  
          }
          
          public void b() {
            if (h.c(this.b) != null)
              h.c(this.b).a(); 
          }
        }parame.e());
    this.b.a(parame.g(), parame.h());
    b b = new b(this) {
        public void d() {
          if (h.a(this.a) != null)
            h.a(this.a).onBannerLoggingImpression(this.a); 
        }
      };
    this.c = new p(this.f, (b)this.b, this.b.getViewabilityChecker(), b);
    this.c.a(o);
    this.b.loadDataWithBaseURL(i.a(), o.a(), "text/html", "utf-8", null);
    if (this.d != null)
      this.d.onBannerAdLoaded(this, (View)this.b); 
  }
  
  public void loadBannerAd(Context paramContext, AdSize paramAdSize, BannerAdapterListener paramBannerAdapterListener, Map<String, Object> paramMap) {
    this.f = paramContext;
    this.d = paramBannerAdapterListener;
    this.e = paramMap;
    a((e)paramMap.get("definition"));
  }
  
  public void onDestroy() {
    if (this.b != null) {
      i.a((WebView)this.b);
      this.b.destroy();
      this.b = null;
    } 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */