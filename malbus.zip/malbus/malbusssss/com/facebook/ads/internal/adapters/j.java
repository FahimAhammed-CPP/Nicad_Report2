package com.facebook.ads.internal.adapters;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.WindowManager;
import com.facebook.ads.AdError;
import com.facebook.ads.AudienceNetworkActivity;
import com.facebook.ads.InterstitialAdActivity;
import com.facebook.ads.internal.g.f;
import com.facebook.ads.internal.util.g;
import com.facebook.ads.internal.view.d;
import java.io.Serializable;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import org.json.JSONObject;

public class j extends InterstitialAdapter {
  private static final ConcurrentMap<String, d> a = new ConcurrentHashMap<String, d>();
  
  private final String b = UUID.randomUUID().toString();
  
  private Context c;
  
  private s d;
  
  private InterstitialAdapterListener e;
  
  private boolean f = false;
  
  private o g;
  
  private a h;
  
  public static d a(String paramString) {
    return a.get(paramString);
  }
  
  private int b() {
    null = ((WindowManager)this.c.getSystemService("window")).getDefaultDisplay().getRotation();
    if (this.h == a.a)
      return -1; 
    if (this.h == a.c) {
      switch (null) {
        default:
          return 0;
        case 2:
        case 3:
          break;
      } 
      return 8;
    } 
    switch (null) {
      default:
        return 1;
      case 2:
        break;
    } 
    return 9;
  }
  
  public void loadInterstitialAd(Context paramContext, InterstitialAdapterListener paramInterstitialAdapterListener, Map<String, Object> paramMap, f paramf) {
    Map<String, String> map;
    this.c = paramContext;
    this.e = paramInterstitialAdapterListener;
    JSONObject jSONObject = (JSONObject)paramMap.get("data");
    if (jSONObject.has("markup")) {
      this.g = o.a(jSONObject);
      if (g.a(paramContext, this.g)) {
        paramInterstitialAdapterListener.onInterstitialError(this, AdError.NO_FILL);
        return;
      } 
      this.d = new s(paramContext, this.b, this, this.e);
      this.d.a();
      map = this.g.e();
      if (map.containsKey("orientation"))
        this.h = a.a(Integer.parseInt(map.get("orientation"))); 
      this.f = true;
      if (this.e != null)
        this.e.onInterstitialAdLoaded(this); 
      return;
    } 
    k k = new k();
    k.a((Context)map, new com.facebook.ads.a.a(this, k) {
          public void a(r param1r) {
            j.a(this.b, true);
            if (j.a(this.b) != null)
              j.a(this.b).onInterstitialAdLoaded(this.b); 
          }
          
          public void a(r param1r, View param1View) {
            j.a(this.b, this.a.h());
            j.a().put(j.b(this.b), this.a);
          }
          
          public void a(r param1r, AdError param1AdError) {
            j.a(this.b).onInterstitialError(this.b, param1AdError);
          }
          
          public void b(r param1r) {
            j.a(this.b).onInterstitialAdClicked(this.b, "", true);
          }
          
          public void c(r param1r) {
            j.a(this.b).onInterstitialLoggingImpression(this.b);
            j.a(this.b).onInterstitialAdDisplayed(this.b);
          }
          
          public void d(r param1r) {
            j.a().remove(j.b(this.b));
            j.a(this.b).onInterstitialAdDismissed(this.b);
          }
        }paramMap, paramf);
  }
  
  public void onDestroy() {
    if (this.d != null)
      this.d.b(); 
  }
  
  public boolean show() {
    boolean bool;
    if (!this.f) {
      if (this.e != null)
        this.e.onInterstitialError(this, AdError.INTERNAL_ERROR); 
      return false;
    } 
    Intent intent = new Intent(this.c, AudienceNetworkActivity.class);
    intent.putExtra("predefinedOrientationKey", b());
    intent.putExtra("uniqueId", this.b);
    if (a.containsKey(this.b)) {
      intent.putExtra("viewType", (Serializable)AudienceNetworkActivity.Type.NATIVE);
    } else {
      intent.putExtra("viewType", (Serializable)AudienceNetworkActivity.Type.DISPLAY);
      this.g.a(intent);
    } 
    intent.addFlags(268435456);
    try {
      this.c.startActivity(intent);
      bool = true;
    } catch (ActivityNotFoundException activityNotFoundException) {
      intent.setClass(this.c, InterstitialAdActivity.class);
      this.c.startActivity(intent);
    } 
    return bool;
  }
  
  public enum a {
    a, b, c;
    
    public static a a(int param1Int) {
      return (param1Int == 2) ? c : b;
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */