package com.facebook.ads.internal.adapters;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import com.facebook.ads.AdError;
import com.facebook.ads.AdNetwork;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdViewAttributes;
import com.facebook.ads.internal.g.f;
import com.facebook.ads.internal.util.aj;
import com.facebook.ads.internal.util.h;
import com.facebook.ads.internal.util.w;
import com.inmobi.ads.InMobiAdRequestStatus;
import com.inmobi.ads.InMobiNative;
import com.inmobi.sdk.InMobiSdk;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;

public class q extends v implements t {
  private w a;
  
  private InMobiNative b;
  
  private boolean c;
  
  private View d;
  
  private String e;
  
  private String f;
  
  private String g;
  
  private NativeAd.Rating h;
  
  private NativeAd.Image i;
  
  private NativeAd.Image j;
  
  public List<NativeAd> A() {
    return null;
  }
  
  public String B() {
    return null;
  }
  
  public AdNetwork C() {
    return AdNetwork.INMOBI;
  }
  
  public e D() {
    return e.d;
  }
  
  public void a() {
    if (b()) {
      InMobiNative inMobiNative = this.b;
      InMobiNative.unbind(this.d);
    } 
    this.d = null;
  }
  
  public void a(int paramInt) {}
  
  public void a(Context paramContext, w paramw, f paramf, Map<String, Object> paramMap) {
    h.a(paramContext, w.a(D()) + " Loading");
    JSONObject jSONObject = (JSONObject)paramMap.get("data");
    String str = jSONObject.optString("account_id");
    Long long_ = Long.valueOf(jSONObject.optLong("placement_id"));
    if (TextUtils.isEmpty(str) || long_ == null) {
      paramw.a(this, AdError.MEDIATION_ERROR);
      return;
    } 
    this.a = paramw;
    InMobiSdk.init(paramContext, str);
    InMobiNative.NativeAdListener nativeAdListener = new InMobiNative.NativeAdListener(this, paramContext) {
        public void onAdDismissed(InMobiNative param1InMobiNative) {}
        
        public void onAdDisplayed(InMobiNative param1InMobiNative) {}
        
        public void onAdLoadFailed(InMobiNative param1InMobiNative, InMobiAdRequestStatus param1InMobiAdRequestStatus) {
          h.a(this.a, w.a(this.b.D()) + " Failed with InMobi error: " + param1InMobiAdRequestStatus.getMessage());
          if (q.c(this.b) != null)
            q.c(this.b).a(this.b, new AdError(3001, param1InMobiAdRequestStatus.getMessage())); 
        }
        
        public void onAdLoadSucceeded(InMobiNative param1InMobiNative) {
          try {
            JSONObject jSONObject1 = new JSONObject();
            this((String)param1InMobiNative.getAdContent());
            q.a(this.b, jSONObject1.optString("title"));
            q.b(this.b, jSONObject1.optString("description"));
            q.c(this.b, jSONObject1.optString("cta"));
            JSONObject jSONObject2 = jSONObject1.optJSONObject("icon");
            if (jSONObject2 != null) {
              int i = jSONObject2.optInt("width");
              int j = jSONObject2.optInt("height");
              String str1 = jSONObject2.optString("url");
              q q1 = this.b;
              NativeAd.Image image = new NativeAd.Image();
              this(str1, i, j);
              q.a(q1, image);
            } 
            jSONObject2 = jSONObject1.optJSONObject("screenshots");
            if (jSONObject2 != null) {
              int j = jSONObject2.optInt("width");
              int i = jSONObject2.optInt("height");
              String str1 = jSONObject2.optString("url");
              q q1 = this.b;
              NativeAd.Image image = new NativeAd.Image();
              this(str1, j, i);
              q.b(q1, image);
            } 
            String str = jSONObject1.optString("rating");
            try {
              double d = Double.parseDouble(str);
              q q1 = this.b;
              NativeAd.Rating rating = new NativeAd.Rating();
              this(d, 5.0D);
              q.a(q1, rating);
            } catch (Exception exception) {}
            q.a(this.b, true);
            if (q.a(this.b) != null) {
              q.b(this.b);
              InMobiNative.bind(q.a(this.b), param1InMobiNative);
            } 
            if (q.c(this.b) != null) {
              Context context = this.a;
              StringBuilder stringBuilder = new StringBuilder();
              this();
              h.a(context, stringBuilder.append(w.a(this.b.D())).append(" Loaded").toString());
              q.c(this.b).a(this.b);
            } 
          } catch (Exception exception) {}
        }
        
        public void onUserLeftApplication(InMobiNative param1InMobiNative) {}
      };
    this.b = new InMobiNative(long_.longValue(), nativeAdListener);
    this.b.load();
  }
  
  public void a(View paramView, List<View> paramList) {
    this.d = paramView;
    if (b()) {
      InMobiNative inMobiNative = this.b;
      InMobiNative.bind(this.d, this.b);
    } 
  }
  
  public void a(Map<String, String> paramMap) {
    this.a.b(this);
  }
  
  public void b(Map<String, String> paramMap) {
    if (b()) {
      this.a.c(this);
      this.b.reportAdClickAndOpenLandingPage(null);
    } 
  }
  
  public boolean b() {
    return (this.b != null && this.c);
  }
  
  public boolean c() {
    return false;
  }
  
  public boolean d() {
    return false;
  }
  
  public boolean e() {
    return false;
  }
  
  public boolean f() {
    return false;
  }
  
  public boolean g() {
    return true;
  }
  
  public int h() {
    return 0;
  }
  
  public int i() {
    return 0;
  }
  
  public int j() {
    return 0;
  }
  
  public NativeAd.Image k() {
    return this.i;
  }
  
  public NativeAd.Image l() {
    return this.j;
  }
  
  public NativeAdViewAttributes m() {
    return null;
  }
  
  public String n() {
    return this.e;
  }
  
  public String o() {
    return null;
  }
  
  public void onDestroy() {
    a();
    this.b = null;
    this.a = null;
  }
  
  public String p() {
    return this.f;
  }
  
  public String q() {
    return this.g;
  }
  
  public String r() {
    return null;
  }
  
  public NativeAd.Rating s() {
    return null;
  }
  
  public NativeAd.Image t() {
    return null;
  }
  
  public String u() {
    return null;
  }
  
  public String v() {
    return "Ad";
  }
  
  public String w() {
    return null;
  }
  
  public String x() {
    return null;
  }
  
  public aj y() {
    return aj.c;
  }
  
  public String z() {
    return null;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */