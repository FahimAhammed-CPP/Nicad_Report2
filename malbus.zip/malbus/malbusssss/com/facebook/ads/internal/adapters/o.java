package com.facebook.ads.internal.adapters;

import android.content.Intent;
import android.os.Bundle;
import com.facebook.ads.internal.util.f;
import com.facebook.ads.internal.util.g;
import com.facebook.ads.internal.util.h;
import java.util.Collection;
import java.util.Map;
import org.json.JSONObject;

public class o implements g.a {
  private final String a;
  
  private final String b;
  
  private final String c;
  
  private final f d;
  
  private final String e;
  
  private final Collection<String> f;
  
  private final Map<String, String> g;
  
  private final String h;
  
  private final int i;
  
  private final int j;
  
  private final int k;
  
  private final String l;
  
  private o(String paramString1, String paramString2, String paramString3, f paramf, String paramString4, Collection<String> paramCollection, Map<String, String> paramMap, String paramString5, int paramInt1, int paramInt2, int paramInt3, String paramString6) {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
    this.d = paramf;
    this.e = paramString4;
    this.f = paramCollection;
    this.g = paramMap;
    this.h = paramString5;
    this.i = paramInt1;
    this.j = paramInt2;
    this.k = paramInt3;
    this.l = paramString6;
  }
  
  public static o a(Bundle paramBundle) {
    String str2 = paramBundle.getString("markup");
    String str3 = paramBundle.getString("native_impression_report_url");
    String str4 = paramBundle.getString("request_id");
    int i = paramBundle.getInt("viewability_check_initial_delay");
    int j = paramBundle.getInt("viewability_check_interval");
    int k = paramBundle.getInt("skip_after_seconds", 0);
    String str1 = paramBundle.getString("ct");
    return new o(str2, null, str3, f.a, "", null, null, str4, i, j, k, str1);
  }
  
  public static o a(JSONObject paramJSONObject) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: iconst_0
    //   3: istore_2
    //   4: aload_0
    //   5: ifnonnull -> 12
    //   8: aload_1
    //   9: astore_0
    //   10: aload_0
    //   11: areturn
    //   12: aload_0
    //   13: ldc 'markup'
    //   15: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   18: astore_3
    //   19: aload_0
    //   20: ldc 'activation_command'
    //   22: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   25: astore #4
    //   27: aload_0
    //   28: ldc 'native_impression_report_url'
    //   30: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   33: astore #5
    //   35: aload_0
    //   36: ldc 'request_id'
    //   38: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   41: astore #6
    //   43: aload_0
    //   44: ldc 'ct'
    //   46: invokestatic a : (Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;
    //   49: astore #7
    //   51: aload_0
    //   52: ldc 'invalidation_behavior'
    //   54: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   57: invokestatic a : (Ljava/lang/String;)Lcom/facebook/ads/internal/util/f;
    //   60: astore #8
    //   62: aload_0
    //   63: ldc 'invalidation_report_url'
    //   65: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   68: astore #9
    //   70: new org/json/JSONArray
    //   73: astore_1
    //   74: aload_1
    //   75: aload_0
    //   76: ldc 'detection_strings'
    //   78: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   81: invokespecial <init> : (Ljava/lang/String;)V
    //   84: aload_1
    //   85: invokestatic a : (Lorg/json/JSONArray;)Ljava/util/Collection;
    //   88: astore_1
    //   89: aload_0
    //   90: ldc 'metadata'
    //   92: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   95: astore #10
    //   97: new java/util/HashMap
    //   100: dup
    //   101: invokespecial <init> : ()V
    //   104: astore #11
    //   106: aload #10
    //   108: ifnull -> 167
    //   111: aload #10
    //   113: invokevirtual keys : ()Ljava/util/Iterator;
    //   116: astore_0
    //   117: aload_0
    //   118: invokeinterface hasNext : ()Z
    //   123: ifeq -> 167
    //   126: aload_0
    //   127: invokeinterface next : ()Ljava/lang/Object;
    //   132: checkcast java/lang/String
    //   135: astore #12
    //   137: aload #11
    //   139: aload #12
    //   141: aload #10
    //   143: aload #12
    //   145: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   148: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   153: pop
    //   154: goto -> 117
    //   157: astore_1
    //   158: aload_1
    //   159: invokevirtual printStackTrace : ()V
    //   162: aconst_null
    //   163: astore_1
    //   164: goto -> 84
    //   167: sipush #1000
    //   170: istore #13
    //   172: aload #11
    //   174: ldc 'viewability_check_initial_delay'
    //   176: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   181: ifeq -> 290
    //   184: aload #11
    //   186: ldc 'viewability_check_initial_delay'
    //   188: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   193: checkcast java/lang/String
    //   196: invokestatic parseInt : (Ljava/lang/String;)I
    //   199: istore #14
    //   201: aload #11
    //   203: ldc 'viewability_check_interval'
    //   205: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   210: ifeq -> 230
    //   213: aload #11
    //   215: ldc 'viewability_check_interval'
    //   217: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   222: checkcast java/lang/String
    //   225: invokestatic parseInt : (Ljava/lang/String;)I
    //   228: istore #13
    //   230: aload #11
    //   232: ldc 'skip_after_seconds'
    //   234: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   239: ifeq -> 258
    //   242: aload #11
    //   244: ldc 'skip_after_seconds'
    //   246: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   251: checkcast java/lang/String
    //   254: invokestatic parseInt : (Ljava/lang/String;)I
    //   257: istore_2
    //   258: new com/facebook/ads/internal/adapters/o
    //   261: dup
    //   262: aload_3
    //   263: aload #4
    //   265: aload #5
    //   267: aload #8
    //   269: aload #9
    //   271: aload_1
    //   272: aload #11
    //   274: aload #6
    //   276: iload #14
    //   278: iload #13
    //   280: iload_2
    //   281: aload #7
    //   283: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/ads/internal/util/f;Ljava/lang/String;Ljava/util/Collection;Ljava/util/Map;Ljava/lang/String;IIILjava/lang/String;)V
    //   286: astore_0
    //   287: goto -> 10
    //   290: iconst_0
    //   291: istore #14
    //   293: goto -> 201
    // Exception table:
    //   from	to	target	type
    //   70	84	157	org/json/JSONException
  }
  
  public static o b(Intent paramIntent) {
    String str2 = h.a(paramIntent.getByteArrayExtra("markup"));
    String str3 = paramIntent.getStringExtra("activation_command");
    String str4 = paramIntent.getStringExtra("native_impression_report_url");
    String str5 = paramIntent.getStringExtra("request_id");
    int i = paramIntent.getIntExtra("viewability_check_initial_delay", 0);
    int j = paramIntent.getIntExtra("viewability_check_interval", 1000);
    int k = paramIntent.getIntExtra("skipAfterSeconds", 0);
    String str1 = paramIntent.getStringExtra("ct");
    return new o(str2, str3, str4, f.a, "", null, null, str5, i, j, k, str1);
  }
  
  public String B() {
    return this.l;
  }
  
  public f D() {
    return this.d;
  }
  
  public String E() {
    return this.e;
  }
  
  public Collection<String> F() {
    return this.f;
  }
  
  public String a() {
    return this.a;
  }
  
  public void a(Intent paramIntent) {
    paramIntent.putExtra("markup", h.a(this.a));
    paramIntent.putExtra("activation_command", this.b);
    paramIntent.putExtra("native_impression_report_url", this.c);
    paramIntent.putExtra("request_id", this.h);
    paramIntent.putExtra("viewability_check_initial_delay", this.i);
    paramIntent.putExtra("viewability_check_interval", this.j);
    paramIntent.putExtra("skipAfterSeconds", this.k);
    paramIntent.putExtra("ct", this.l);
  }
  
  public String b() {
    return this.b;
  }
  
  public String c() {
    return this.c;
  }
  
  public String d() {
    return "facebookAd.sendImpression();";
  }
  
  public Map<String, String> e() {
    return this.g;
  }
  
  public String f() {
    return this.h;
  }
  
  public int g() {
    return this.i;
  }
  
  public int h() {
    return this.j;
  }
  
  public Bundle i() {
    Bundle bundle = new Bundle();
    bundle.putString("markup", this.a);
    bundle.putString("native_impression_report_url", this.c);
    bundle.putString("request_id", this.h);
    bundle.putInt("viewability_check_initial_delay", this.i);
    bundle.putInt("viewability_check_interval", this.j);
    bundle.putInt("skip_after_seconds", this.k);
    bundle.putString("ct", this.l);
    return bundle;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */