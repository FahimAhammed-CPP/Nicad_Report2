package com.facebook.ads.internal.adapters;

import android.view.View;
import com.facebook.ads.AdError;

public interface BannerAdapterListener {
  void onBannerAdClicked(BannerAdapter paramBannerAdapter);
  
  void onBannerAdExpanded(BannerAdapter paramBannerAdapter);
  
  void onBannerAdLoaded(BannerAdapter paramBannerAdapter, View paramView);
  
  void onBannerAdMinimized(BannerAdapter paramBannerAdapter);
  
  void onBannerError(BannerAdapter paramBannerAdapter, AdError paramAdError);
  
  void onBannerLoggingImpression(BannerAdapter paramBannerAdapter);
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/BannerAdapterListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */