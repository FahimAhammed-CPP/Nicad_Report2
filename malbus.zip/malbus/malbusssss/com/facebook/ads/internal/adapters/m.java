package com.facebook.ads.internal.adapters;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.content.LocalBroadcastManager;
import com.facebook.ads.AdError;
import com.facebook.ads.AdSettings;
import com.facebook.ads.AudienceNetworkActivity;
import com.facebook.ads.internal.h;
import java.io.Serializable;
import java.util.Map;
import java.util.UUID;
import org.json.JSONObject;

public class m extends x {
  private y b;
  
  private Context c;
  
  private boolean d = false;
  
  private String e = UUID.randomUUID().toString();
  
  private String f;
  
  private String g;
  
  private String h;
  
  private String i;
  
  private String j;
  
  private String k;
  
  private String l;
  
  private String m;
  
  private String n;
  
  private String o;
  
  private z p;
  
  private void c() {
    LocalBroadcastManager.getInstance(this.c).registerReceiver(this.p, this.p.a());
  }
  
  private void d() {
    if (this.p != null)
      try {
        LocalBroadcastManager.getInstance(this.c).unregisterReceiver(this.p);
      } catch (Exception exception) {} 
  }
  
  private String e() {
    if (this.a != null) {
      String str = AdSettings.getUrlPrefix();
      if (str == null || str.isEmpty()) {
        str = "https://www.facebook.com/audience_network/server_side_reward";
      } else {
        str = String.format("https://www.%s.facebook.com/audience_network/server_side_reward", new Object[] { str });
      } 
      Uri uri = Uri.parse(str);
      Uri.Builder builder = new Uri.Builder();
      builder.scheme(uri.getScheme());
      builder.authority(uri.getAuthority());
      builder.path(uri.getPath());
      builder.query(uri.getQuery());
      builder.fragment(uri.getFragment());
      builder.appendQueryParameter("puid", this.a.getUserID());
      builder.appendQueryParameter("pc", this.a.getCurrency());
      builder.appendQueryParameter("ptid", this.e);
      builder.appendQueryParameter("appid", this.m);
      return builder.build().toString();
    } 
    return null;
  }
  
  private String f() {
    return this.n;
  }
  
  public String a() {
    return this.f;
  }
  
  public void a(Context paramContext, y paramy, Map<String, Object> paramMap) {
    this.b = paramy;
    this.c = paramContext;
    this.d = false;
    JSONObject jSONObject = (JSONObject)paramMap.get("data");
    this.f = jSONObject.optString("video_url");
    if (this.f == null || this.f.isEmpty()) {
      this.b.a(this, AdError.INTERNAL_ERROR);
      return;
    } 
    this.g = jSONObject.optString("video_play_report_url");
    this.h = jSONObject.optString("video_time_report_url");
    this.i = jSONObject.optString("impression_report_url");
    this.j = jSONObject.optString("close_report_url");
    this.o = jSONObject.optString("ct");
    this.k = jSONObject.optString("end_card_markup");
    this.l = jSONObject.optString("activation_command");
    this.n = jSONObject.optString("context_switch", "endvideo");
    String str = (String)paramMap.get("placement_id");
    if (str != null) {
      this.m = str.split("_")[0];
    } else {
      this.m = "";
    } 
    this.p = new z(this.e, this, paramy);
    c();
    this.d = true;
    this.b.a(this);
  }
  
  public boolean b() {
    if (!this.d)
      return false; 
    Intent intent = new Intent(this.c, AudienceNetworkActivity.class);
    intent.putExtra("viewType", (Serializable)AudienceNetworkActivity.Type.REWARDED_VIDEO);
    intent.putExtra("videoURL", this.f);
    intent.putExtra("videoTimeReportURL", this.h);
    intent.putExtra("videoPlayReportURL", this.g);
    if (!h.f(this.c))
      intent.putExtra("predefinedOrientationKey", 6); 
    intent.putExtra("facebookRewardedVideoEndCardActivationCommand", this.l);
    intent.putExtra("impressionReportURL", this.i);
    intent.putExtra("uniqueId", this.e);
    intent.putExtra("facebookRewardedVideoEndCardMarkup", this.k);
    intent.putExtra("closeReportURL", this.j);
    intent.putExtra("clientToken", this.o);
    intent.putExtra("rewardServerURL", e());
    intent.putExtra("contextSwitchBehavior", f());
    if (!(this.c instanceof android.app.Activity))
      intent.setFlags(intent.getFlags() | 0x10000000); 
    this.c.startActivity(intent);
    return true;
  }
  
  public void onDestroy() {
    d();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */