package com.facebook.ads.internal.adapters;

import android.content.Context;
import android.os.Bundle;
import com.facebook.ads.a.a;
import com.facebook.ads.internal.g.f;
import com.facebook.ads.internal.server.AdPlacementType;
import com.facebook.ads.internal.util.ae;
import java.util.Map;

public abstract class r implements AdAdapter, ae<Bundle> {
  public abstract void a(Context paramContext, a parama, Map<String, Object> paramMap, f paramf);
  
  public abstract boolean d();
  
  public AdPlacementType getPlacementType() {
    return AdPlacementType.INSTREAM;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */