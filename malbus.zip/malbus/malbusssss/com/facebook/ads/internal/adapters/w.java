package com.facebook.ads.internal.adapters;

import com.facebook.ads.AdError;

public interface w {
  void a(v paramv);
  
  void a(v paramv, AdError paramAdError);
  
  void b(v paramv);
  
  void c(v paramv);
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */