package com.facebook.ads.internal.adapters;

import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.internal.util.p;
import com.facebook.ads.internal.util.q;
import com.facebook.ads.internal.view.g;
import com.facebook.ads.internal.view.hscroll.b;
import com.facebook.ads.internal.view.p;
import java.util.List;

public class g extends RecyclerView.Adapter<g> {
  private static final int a = Color.argb(51, 0, 0, 0);
  
  private final List<NativeAd> b;
  
  private final int c;
  
  private final int d;
  
  public g(b paramb, List<NativeAd> paramList) {
    float f = (paramb.getContext().getResources().getDisplayMetrics()).density;
    this.b = paramList;
    this.c = Math.round(f * 1.0F);
    this.d = paramb.getChildSpacing();
  }
  
  public g a(ViewGroup paramViewGroup, int paramInt) {
    p p = new p(paramViewGroup.getContext());
    p.setScaleType(ImageView.ScaleType.CENTER_CROP);
    return new g(p);
  }
  
  public void a(g paramg, int paramInt) {
    int i;
    int j;
    ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(-2, -1);
    if (paramInt == 0) {
      i = this.d * 2;
    } else {
      i = this.d;
    } 
    if (paramInt >= this.b.size() - 1) {
      j = this.d * 2;
    } else {
      j = this.d;
    } 
    marginLayoutParams.setMargins(i, 0, j, 0);
    paramg.a.setBackgroundColor(0);
    paramg.a.setImageDrawable(null);
    paramg.a.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams);
    paramg.a.setPadding(this.c, this.c, this.c, this.c);
    NativeAd nativeAd = this.b.get(paramInt);
    nativeAd.registerViewForInteraction((View)paramg.a);
    NativeAd.Image image = nativeAd.getAdCoverImage();
    if (image != null) {
      p p = new p((ImageView)paramg.a);
      p.a(new q(this, paramg) {
            public void a() {
              this.a.a.setBackgroundColor(g.a());
            }
          });
      p.a(new String[] { image.getUrl() });
    } 
  }
  
  public int getItemCount() {
    return this.b.size();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */