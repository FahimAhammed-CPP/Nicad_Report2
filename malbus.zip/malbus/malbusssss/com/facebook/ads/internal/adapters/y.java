package com.facebook.ads.internal.adapters;

import com.facebook.ads.AdError;

public interface y {
  void a();
  
  void a(x paramx);
  
  void a(x paramx, AdError paramAdError);
  
  void b(x paramx);
  
  void c(x paramx);
  
  void d(x paramx);
  
  void e(x paramx);
  
  void f(x paramx);
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */