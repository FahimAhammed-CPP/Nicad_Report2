package com.facebook.ads.internal.adapters;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.facebook.ads.AdError;
import com.facebook.ads.a.a;
import com.facebook.ads.internal.g.f;
import com.facebook.ads.internal.g.q;
import com.facebook.ads.internal.g.s;
import com.facebook.ads.internal.util.ac;
import com.facebook.ads.internal.util.ae;
import com.facebook.ads.internal.util.ai;
import com.facebook.ads.internal.util.b;
import com.facebook.ads.internal.view.d.a.a;
import com.facebook.ads.internal.view.d.a.b;
import com.facebook.ads.internal.view.d.a.d;
import com.facebook.ads.internal.view.d.a.l;
import com.facebook.ads.internal.view.d.b.a;
import com.facebook.ads.internal.view.d.b.b;
import com.facebook.ads.internal.view.d.b.c;
import com.facebook.ads.internal.view.d.b.e;
import com.facebook.ads.internal.view.d.b.h;
import com.facebook.ads.internal.view.d.b.k;
import com.facebook.ads.internal.view.d.b.m;
import com.facebook.ads.internal.view.m;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class i extends r implements ae<Bundle> {
  @Nullable
  protected m a;
  
  @Nullable
  protected JSONObject b;
  
  @Nullable
  protected Context c;
  
  private final s<b> e = new s<b>(this) {
      public Class<b> a() {
        return b.class;
      }
      
      public void a(b param1b) {
        i.a(this.a).d(this.a);
      }
    };
  
  private final s<l> f = new s<l>(this) {
      public Class<l> a() {
        return l.class;
      }
      
      public void a(l param1l) {
        i.a(this.a, true);
        i.a(this.a).a(this.a);
      }
    };
  
  private final s<d> g = new s<d>(this) {
      public Class<d> a() {
        return d.class;
      }
      
      public void a(d param1d) {
        i.a(this.a).a(this.a, AdError.INTERNAL_ERROR);
      }
    };
  
  private final s<a> h = new s<a>(this) {
      public Class<a> a() {
        return a.class;
      }
      
      public void a(a param1a) {
        if (i.a(this.a) != null)
          i.a(this.a).b(this.a); 
        if (i.b(this.a) != null) {
          if (i.c(this.a) != null) {
            i.b(this.a).c(i.c(this.a), new HashMap<Object, Object>());
            return;
          } 
        } else {
          return;
        } 
        i.b(this.a).a(b.a.a(i.d(this.a)));
      }
    };
  
  @Nullable
  private a i;
  
  @Nullable
  private f j;
  
  @Nullable
  private String k;
  
  private boolean l = false;
  
  @Nullable
  private String m;
  
  @Nullable
  private String n;
  
  @Nullable
  private String o;
  
  @Nullable
  private ai p;
  
  @Nullable
  private String q;
  
  static {
    boolean bool;
    if (!i.class.desiredAssertionStatus()) {
      bool = true;
    } else {
      bool = false;
    } 
    d = bool;
  }
  
  private void a(Context paramContext, a parama, JSONObject paramJSONObject, f paramf, @Nullable Bundle paramBundle) {
    this.c = paramContext;
    this.i = parama;
    this.j = paramf;
    this.b = paramJSONObject;
    this.l = false;
    JSONObject jSONObject2 = paramJSONObject.getJSONObject("video");
    JSONObject jSONObject1 = paramJSONObject.getJSONObject("trackers");
    this.q = paramJSONObject.optString("ct");
    this.k = jSONObject2.getString("videoURL");
    this.m = jSONObject1.getString("nativeImpression");
    this.n = jSONObject1.getString("impression");
    this.o = jSONObject1.getString("click");
    this.a = new m(paramContext);
    a();
    this.a.getEventBus().a(this.e);
    this.a.getEventBus().a(this.g);
    this.a.getEventBus().a(this.f);
    this.a.getEventBus().a(this.h);
    if (paramBundle != null) {
      this.p = (ai)new ac(paramContext, paramf, this.a, jSONObject1.getString("video"), this.q, paramBundle.getBundle("logger"));
    } else {
      this.p = (ai)new ac(paramContext, paramf, this.a, jSONObject1.getString("video"), this.q);
    } 
    this.i.a(this, (View)this.a);
    this.a.setVideoURI(this.k);
  }
  
  protected void a() {
    if (!d && this.c == null)
      throw new AssertionError(); 
    if (!d && this.b == null)
      throw new AssertionError(); 
    JSONObject jSONObject = this.b.getJSONObject("video");
    this.a.a((m)new com.facebook.ads.internal.view.d.b.i(this.c));
    this.a.a((m)new k(this.c));
    this.a.a((m)new b(this.c));
    String str = b();
    if (str != null) {
      c c = new c(this.c, str, true);
      RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
      layoutParams.addRule(12);
      layoutParams.addRule(9);
      c.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
      this.a.a((m)c);
    } 
    if (jSONObject.has("destinationURL") && !jSONObject.isNull("destinationURL")) {
      String str1 = jSONObject.getString("destinationURL");
      if (!TextUtils.isEmpty(str1)) {
        e e = new e(this.c, str1, "");
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(10);
        layoutParams.addRule(11);
        e.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        this.a.a((m)e);
      } 
    } 
    a a1 = new a(this.c, "http://m.facebook.com/ads/ad_choices", "", new float[] { 0.0F, 0.0F, 8.0F, 0.0F });
    this.a.a((m)a1);
    int j = c();
    if (j > 0) {
      h h = new h(this.c, j);
      RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
      layoutParams.addRule(12);
      layoutParams.addRule(11);
      h.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
      h.setPadding(0, 0, 0, 30);
      this.a.a((m)h);
    } 
  }
  
  public final void a(Context paramContext, a parama, f paramf, Bundle paramBundle) {
    try {
      JSONObject jSONObject = new JSONObject();
      this(paramBundle.getString("ad_response"));
      a(paramContext, parama, jSONObject, paramf, paramBundle);
    } catch (JSONException jSONException) {
      parama.a(this, AdError.INTERNAL_ERROR);
    } 
  }
  
  public final void a(Context paramContext, a parama, Map<String, Object> paramMap, f paramf) {
    try {
      a(paramContext, parama, (JSONObject)paramMap.get("data"), paramf, null);
    } catch (JSONException jSONException) {
      parama.a(this, AdError.INTERNAL_ERROR);
    } 
  }
  
  protected String b() {
    String str2;
    String str1 = null;
    if (!d && this.b == null)
      throw new AssertionError(); 
    try {
      JSONObject jSONObject = this.b.getJSONObject("capabilities");
      str2 = str1;
      if (jSONObject.has("countdown")) {
        if (jSONObject.isNull("countdown"))
          return str1; 
      } else {
        return str2;
      } 
      jSONObject = jSONObject.getJSONObject("countdown");
      str2 = str1;
      if (jSONObject.has("format"))
        str2 = jSONObject.optString("format"); 
    } catch (Exception exception) {
      Log.w(String.valueOf(i.class), "Invalid JSON", exception);
      str2 = str1;
    } 
    return str2;
  }
  
  protected int c() {
    byte b2;
    byte b1 = -1;
    if (!d && this.b == null)
      throw new AssertionError(); 
    try {
      JSONObject jSONObject = this.b.getJSONObject("capabilities");
      b2 = b1;
      if (jSONObject.has("skipButton")) {
        if (jSONObject.isNull("skipButton"))
          return b1; 
      } else {
        return b2;
      } 
      jSONObject = jSONObject.getJSONObject("skipButton");
      b2 = b1;
      if (jSONObject.has("skippableSeconds"))
        b2 = jSONObject.getInt("skippableSeconds"); 
    } catch (Exception exception) {
      Log.w(String.valueOf(i.class), "Invalid JSON", exception);
      b2 = b1;
    } 
    return b2;
  }
  
  public boolean d() {
    if (!this.l || this.a == null)
      return false; 
    if (this.p.k() > 0) {
      this.a.a(this.p.k());
      this.a.d();
    } else {
      this.a.d();
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      int j = c();
      if (j > 0)
        hashMap.put("skippable_seconds", String.valueOf(j)); 
      if (this.q != null) {
        this.j.b(this.q, hashMap);
      } else {
        this.j.a(this.m, hashMap);
        this.j.a(this.n);
      } 
      if (this.i != null)
        this.i.c(this); 
    } 
    return true;
  }
  
  public Bundle getSaveInstanceState() {
    if (this.p == null || this.b == null)
      return null; 
    Bundle bundle = new Bundle();
    bundle.putBundle("logger", this.p.getSaveInstanceState());
    bundle.putString("ad_response", this.b.toString());
    return bundle;
  }
  
  public void onDestroy() {
    this.a.g();
    this.i = null;
    this.j = null;
    this.k = null;
    this.l = false;
    this.m = null;
    this.n = null;
    this.o = null;
    this.a = null;
    this.p = null;
    this.b = null;
    this.c = null;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */