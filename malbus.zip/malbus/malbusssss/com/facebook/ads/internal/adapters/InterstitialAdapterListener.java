package com.facebook.ads.internal.adapters;

import com.facebook.ads.AdError;

public interface InterstitialAdapterListener {
  void onInterstitialAdClicked(InterstitialAdapter paramInterstitialAdapter, String paramString, boolean paramBoolean);
  
  void onInterstitialAdDismissed(InterstitialAdapter paramInterstitialAdapter);
  
  void onInterstitialAdDisplayed(InterstitialAdapter paramInterstitialAdapter);
  
  void onInterstitialAdLoaded(InterstitialAdapter paramInterstitialAdapter);
  
  void onInterstitialError(InterstitialAdapter paramInterstitialAdapter, AdError paramAdError);
  
  void onInterstitialLoggingImpression(InterstitialAdapter paramInterstitialAdapter);
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/InterstitialAdapterListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */