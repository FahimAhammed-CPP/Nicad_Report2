package com.facebook.ads.internal.adapters;

import android.content.Context;
import com.facebook.ads.RewardData;
import com.facebook.ads.internal.server.AdPlacementType;
import java.util.Map;

public abstract class x implements AdAdapter {
  protected RewardData a;
  
  public abstract String a();
  
  public abstract void a(Context paramContext, y paramy, Map<String, Object> paramMap);
  
  public void a(RewardData paramRewardData) {
    this.a = paramRewardData;
  }
  
  public abstract boolean b();
  
  public AdPlacementType getPlacementType() {
    return AdPlacementType.REWARDED_VIDEO;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */