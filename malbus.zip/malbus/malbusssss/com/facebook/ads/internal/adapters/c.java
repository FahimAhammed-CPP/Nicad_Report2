package com.facebook.ads.internal.adapters;

import android.content.Context;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import com.facebook.ads.AdError;
import com.facebook.ads.AdNetwork;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdViewAttributes;
import com.facebook.ads.internal.g.f;
import com.facebook.ads.internal.util.aj;
import com.facebook.ads.internal.util.h;
import com.facebook.ads.internal.util.w;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.formats.NativeAd;
import com.google.android.gms.ads.formats.NativeAdView;
import com.google.android.gms.ads.formats.NativeAppInstallAd;
import com.google.android.gms.ads.formats.NativeAppInstallAdView;
import com.google.android.gms.ads.formats.NativeContentAd;
import com.google.android.gms.ads.formats.NativeContentAdView;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class c extends v implements t {
  private static final String a = c.class.getSimpleName();
  
  private View b;
  
  private NativeAd c;
  
  private w d;
  
  private NativeAdView e;
  
  private View f;
  
  private boolean g;
  
  private Uri h;
  
  private Uri i;
  
  private String j;
  
  private String k;
  
  private String l;
  
  private String m;
  
  private void a(View paramView) {
    if (paramView != null) {
      ViewGroup viewGroup = (ViewGroup)paramView.getParent();
      if (viewGroup != null)
        viewGroup.removeView(paramView); 
    } 
  }
  
  public List<NativeAd> A() {
    return null;
  }
  
  public String B() {
    return null;
  }
  
  public AdNetwork C() {
    return AdNetwork.ADMOB;
  }
  
  public e D() {
    return e.c;
  }
  
  public void a() {
    a(this.f);
    this.f = null;
    if (this.b != null) {
      ViewGroup viewGroup = (ViewGroup)this.b.getParent();
      if (viewGroup instanceof NativeContentAdView || viewGroup instanceof NativeAppInstallAdView) {
        ViewGroup viewGroup1 = (ViewGroup)viewGroup.getParent();
        if (viewGroup1 != null) {
          int i = viewGroup1.indexOfChild((View)viewGroup);
          a(this.b);
          a((View)viewGroup);
          viewGroup1.addView(this.b, i);
        } 
      } 
      this.b = null;
    } 
    this.e = null;
  }
  
  public void a(int paramInt) {}
  
  public void a(Context paramContext, w paramw, f paramf, Map<String, Object> paramMap) {
    // Byte code:
    //   0: aload_1
    //   1: new java/lang/StringBuilder
    //   4: dup
    //   5: invokespecial <init> : ()V
    //   8: aload_0
    //   9: invokevirtual D : ()Lcom/facebook/ads/internal/adapters/e;
    //   12: invokestatic a : (Lcom/facebook/ads/internal/adapters/e;)Ljava/lang/String;
    //   15: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   18: ldc ' Loading'
    //   20: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   23: invokevirtual toString : ()Ljava/lang/String;
    //   26: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)V
    //   29: aload #4
    //   31: ldc 'data'
    //   33: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   38: checkcast org/json/JSONObject
    //   41: astore #4
    //   43: aload #4
    //   45: ldc 'ad_unit_id'
    //   47: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   50: astore_3
    //   51: aload #4
    //   53: ldc 'creative_types'
    //   55: invokevirtual optJSONArray : (Ljava/lang/String;)Lorg/json/JSONArray;
    //   58: astore #4
    //   60: aload #4
    //   62: ifnull -> 295
    //   65: aload #4
    //   67: invokevirtual length : ()I
    //   70: istore #5
    //   72: iconst_0
    //   73: istore #6
    //   75: iconst_0
    //   76: istore #7
    //   78: iconst_0
    //   79: istore #8
    //   81: iload #7
    //   83: istore #9
    //   85: iload #8
    //   87: istore #10
    //   89: iload #6
    //   91: iload #5
    //   93: if_icmpge -> 301
    //   96: aload #4
    //   98: iload #6
    //   100: invokevirtual getString : (I)Ljava/lang/String;
    //   103: astore #11
    //   105: iload #7
    //   107: istore #10
    //   109: iload #8
    //   111: istore #9
    //   113: aload #11
    //   115: ifnull -> 184
    //   118: iconst_m1
    //   119: istore #10
    //   121: aload #11
    //   123: invokevirtual hashCode : ()I
    //   126: lookupswitch default -> 152, 704091517 -> 198, 883765328 -> 214
    //   152: iload #10
    //   154: tableswitch default -> 176, 0 -> 234, 1 -> 244
    //   176: iload #8
    //   178: istore #9
    //   180: iload #7
    //   182: istore #10
    //   184: iinc #6, 1
    //   187: iload #10
    //   189: istore #7
    //   191: iload #9
    //   193: istore #8
    //   195: goto -> 81
    //   198: aload #11
    //   200: ldc 'app_install'
    //   202: invokevirtual equals : (Ljava/lang/Object;)Z
    //   205: ifeq -> 152
    //   208: iconst_0
    //   209: istore #10
    //   211: goto -> 152
    //   214: aload #11
    //   216: ldc 'page_post'
    //   218: invokevirtual equals : (Ljava/lang/Object;)Z
    //   221: istore #12
    //   223: iload #12
    //   225: ifeq -> 152
    //   228: iconst_1
    //   229: istore #10
    //   231: goto -> 152
    //   234: iconst_1
    //   235: istore #9
    //   237: iload #7
    //   239: istore #10
    //   241: goto -> 184
    //   244: iconst_1
    //   245: istore #10
    //   247: iload #8
    //   249: istore #9
    //   251: goto -> 184
    //   254: astore_3
    //   255: aload_1
    //   256: new java/lang/StringBuilder
    //   259: dup
    //   260: invokespecial <init> : ()V
    //   263: aload_0
    //   264: invokevirtual D : ()Lcom/facebook/ads/internal/adapters/e;
    //   267: invokestatic a : (Lcom/facebook/ads/internal/adapters/e;)Ljava/lang/String;
    //   270: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   273: ldc ' AN server error'
    //   275: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   278: invokevirtual toString : ()Ljava/lang/String;
    //   281: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)V
    //   284: aload_2
    //   285: aload_0
    //   286: getstatic com/facebook/ads/AdError.SERVER_ERROR : Lcom/facebook/ads/AdError;
    //   289: invokeinterface a : (Lcom/facebook/ads/internal/adapters/v;Lcom/facebook/ads/AdError;)V
    //   294: return
    //   295: iconst_0
    //   296: istore #9
    //   298: iconst_0
    //   299: istore #10
    //   301: aload_3
    //   302: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   305: ifne -> 318
    //   308: iload #10
    //   310: ifne -> 360
    //   313: iload #9
    //   315: ifne -> 360
    //   318: aload_1
    //   319: new java/lang/StringBuilder
    //   322: dup
    //   323: invokespecial <init> : ()V
    //   326: aload_0
    //   327: invokevirtual D : ()Lcom/facebook/ads/internal/adapters/e;
    //   330: invokestatic a : (Lcom/facebook/ads/internal/adapters/e;)Ljava/lang/String;
    //   333: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   336: ldc ' AN server error'
    //   338: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   341: invokevirtual toString : ()Ljava/lang/String;
    //   344: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)V
    //   347: aload_2
    //   348: aload_0
    //   349: getstatic com/facebook/ads/AdError.SERVER_ERROR : Lcom/facebook/ads/AdError;
    //   352: invokeinterface a : (Lcom/facebook/ads/internal/adapters/v;Lcom/facebook/ads/AdError;)V
    //   357: goto -> 294
    //   360: aload_0
    //   361: aload_2
    //   362: putfield d : Lcom/facebook/ads/internal/adapters/w;
    //   365: new com/google/android/gms/ads/AdLoader$Builder
    //   368: dup
    //   369: aload_1
    //   370: aload_3
    //   371: invokespecial <init> : (Landroid/content/Context;Ljava/lang/String;)V
    //   374: astore_2
    //   375: iload #10
    //   377: ifeq -> 394
    //   380: aload_2
    //   381: new com/facebook/ads/internal/adapters/c$1
    //   384: dup
    //   385: aload_0
    //   386: aload_1
    //   387: invokespecial <init> : (Lcom/facebook/ads/internal/adapters/c;Landroid/content/Context;)V
    //   390: invokevirtual forAppInstallAd : (Lcom/google/android/gms/ads/formats/NativeAppInstallAd$OnAppInstallAdLoadedListener;)Lcom/google/android/gms/ads/AdLoader$Builder;
    //   393: pop
    //   394: iload #9
    //   396: ifeq -> 413
    //   399: aload_2
    //   400: new com/facebook/ads/internal/adapters/c$2
    //   403: dup
    //   404: aload_0
    //   405: aload_1
    //   406: invokespecial <init> : (Lcom/facebook/ads/internal/adapters/c;Landroid/content/Context;)V
    //   409: invokevirtual forContentAd : (Lcom/google/android/gms/ads/formats/NativeContentAd$OnContentAdLoadedListener;)Lcom/google/android/gms/ads/AdLoader$Builder;
    //   412: pop
    //   413: aload_2
    //   414: new com/facebook/ads/internal/adapters/c$3
    //   417: dup
    //   418: aload_0
    //   419: aload_1
    //   420: invokespecial <init> : (Lcom/facebook/ads/internal/adapters/c;Landroid/content/Context;)V
    //   423: invokevirtual withAdListener : (Lcom/google/android/gms/ads/AdListener;)Lcom/google/android/gms/ads/AdLoader$Builder;
    //   426: new com/google/android/gms/ads/formats/NativeAdOptions$Builder
    //   429: dup
    //   430: invokespecial <init> : ()V
    //   433: iconst_1
    //   434: invokevirtual setReturnUrlsForImageAssets : (Z)Lcom/google/android/gms/ads/formats/NativeAdOptions$Builder;
    //   437: invokevirtual build : ()Lcom/google/android/gms/ads/formats/NativeAdOptions;
    //   440: invokevirtual withNativeAdOptions : (Lcom/google/android/gms/ads/formats/NativeAdOptions;)Lcom/google/android/gms/ads/AdLoader$Builder;
    //   443: invokevirtual build : ()Lcom/google/android/gms/ads/AdLoader;
    //   446: new com/google/android/gms/ads/AdRequest$Builder
    //   449: dup
    //   450: invokespecial <init> : ()V
    //   453: invokevirtual build : ()Lcom/google/android/gms/ads/AdRequest;
    //   456: invokevirtual loadAd : (Lcom/google/android/gms/ads/AdRequest;)V
    //   459: goto -> 294
    // Exception table:
    //   from	to	target	type
    //   96	105	254	org/json/JSONException
    //   121	152	254	org/json/JSONException
    //   198	208	254	org/json/JSONException
    //   214	223	254	org/json/JSONException
  }
  
  public void a(View paramView, List<View> paramList) {
    this.b = paramView;
    if (b() && paramView != null) {
      int i = -1;
      ViewGroup viewGroup = null;
      while (true) {
        ViewGroup viewGroup1 = (ViewGroup)paramView.getParent();
        if (viewGroup1 == null) {
          Log.e(a, "View must have valid parent for AdMob registration, skipping registration. Impressions and clicks will not be logged.");
          // Byte code: goto -> 16
        } 
        if (viewGroup1 instanceof NativeAdView) {
          ViewGroup viewGroup2 = (ViewGroup)viewGroup1.getParent();
          if (viewGroup2 == null) {
            Log.e(a, "View must have valid parent for AdMob registration, skipping registration. Impressions and clicks will not be logged.");
            // Byte code: goto -> 16
          } 
          int j = viewGroup2.indexOfChild((View)viewGroup1);
          viewGroup1.removeView(paramView);
          viewGroup2.removeView((View)viewGroup1);
          viewGroup2.addView(paramView, j);
        } else {
          i = viewGroup1.indexOfChild(paramView);
          viewGroup = viewGroup1;
        } 
        if (viewGroup != null) {
          NativeAppInstallAdView nativeAppInstallAdView;
          if (this.c instanceof NativeContentAd) {
            NativeContentAdView nativeContentAdView = new NativeContentAdView(paramView.getContext());
          } else {
            nativeAppInstallAdView = new NativeAppInstallAdView(paramView.getContext());
          } 
          if (paramView instanceof ViewGroup)
            nativeAppInstallAdView.setLayoutParams(paramView.getLayoutParams()); 
          a(paramView);
          nativeAppInstallAdView.addView(paramView);
          viewGroup.removeView((View)nativeAppInstallAdView);
          viewGroup.addView((View)nativeAppInstallAdView, i);
          this.e = (NativeAdView)nativeAppInstallAdView;
          this.e.setNativeAd(this.c);
          this.f = new View(paramView.getContext());
          this.e.addView(this.f);
          this.f.setVisibility(8);
          if (this.e instanceof NativeContentAdView) {
            ((NativeContentAdView)this.e).setCallToActionView(this.f);
          } else if (this.e instanceof NativeAppInstallAdView) {
            ((NativeAppInstallAdView)this.e).setCallToActionView(this.f);
          } 
          View.OnClickListener onClickListener = new View.OnClickListener(this) {
              public void onClick(View param1View) {
                c.b(this.a).performClick();
              }
            };
          Iterator<View> iterator = paramList.iterator();
          while (true) {
            if (iterator.hasNext()) {
              ((View)iterator.next()).setOnClickListener(onClickListener);
              continue;
            } 
            return;
          } 
          break;
        } 
      } 
    } 
  }
  
  public void a(Map<String, String> paramMap) {
    if (b() && this.d != null)
      this.d.b(this); 
  }
  
  public void b(Map<String, String> paramMap) {}
  
  public boolean b() {
    return (this.g && this.c != null);
  }
  
  public boolean c() {
    return false;
  }
  
  public boolean d() {
    return false;
  }
  
  public boolean e() {
    return false;
  }
  
  public boolean f() {
    return false;
  }
  
  public boolean g() {
    return false;
  }
  
  public int h() {
    return 0;
  }
  
  public int i() {
    return 0;
  }
  
  public int j() {
    return 0;
  }
  
  public NativeAd.Image k() {
    return (b() && this.i != null) ? new NativeAd.Image(this.i.toString(), 50, 50) : null;
  }
  
  public NativeAd.Image l() {
    return (b() && this.h != null) ? new NativeAd.Image(this.h.toString(), 1200, 600) : null;
  }
  
  public NativeAdViewAttributes m() {
    return null;
  }
  
  public String n() {
    return this.j;
  }
  
  public String o() {
    return null;
  }
  
  public void onDestroy() {
    a();
    this.d = null;
    this.c = null;
    this.g = false;
    this.h = null;
    this.i = null;
    this.j = null;
    this.k = null;
    this.l = null;
    this.m = null;
  }
  
  public String p() {
    return this.k;
  }
  
  public String q() {
    return this.l;
  }
  
  public String r() {
    return this.m;
  }
  
  public NativeAd.Rating s() {
    return null;
  }
  
  public NativeAd.Image t() {
    return null;
  }
  
  public String u() {
    return null;
  }
  
  public String v() {
    return null;
  }
  
  public String w() {
    return null;
  }
  
  public String x() {
    return null;
  }
  
  public aj y() {
    return aj.c;
  }
  
  public String z() {
    return null;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */