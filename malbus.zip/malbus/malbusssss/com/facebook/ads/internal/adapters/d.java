package com.facebook.ads.internal.adapters;

import com.facebook.ads.internal.server.AdPlacementType;
import com.facebook.ads.internal.util.ah;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class d {
  private static final Set<f> a;
  
  private static final Map<AdPlacementType, String> b;
  
  static {
    // Byte code:
    //   0: new java/util/HashSet
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: putstatic com/facebook/ads/internal/adapters/d.a : Ljava/util/Set;
    //   10: new java/util/concurrent/ConcurrentHashMap
    //   13: dup
    //   14: invokespecial <init> : ()V
    //   17: putstatic com/facebook/ads/internal/adapters/d.b : Ljava/util/Map;
    //   20: invokestatic a : ()Ljava/util/List;
    //   23: invokeinterface iterator : ()Ljava/util/Iterator;
    //   28: astore_0
    //   29: aload_0
    //   30: invokeinterface hasNext : ()Z
    //   35: ifeq -> 176
    //   38: aload_0
    //   39: invokeinterface next : ()Ljava/lang/Object;
    //   44: checkcast com/facebook/ads/internal/adapters/f
    //   47: astore_1
    //   48: getstatic com/facebook/ads/internal/adapters/d$1.a : [I
    //   51: aload_1
    //   52: getfield l : Lcom/facebook/ads/internal/server/AdPlacementType;
    //   55: invokevirtual ordinal : ()I
    //   58: iaload
    //   59: tableswitch default -> 92, 1 -> 146, 2 -> 152, 3 -> 158, 4 -> 164, 5 -> 170
    //   92: aconst_null
    //   93: astore_2
    //   94: aload_2
    //   95: ifnull -> 29
    //   98: aload_1
    //   99: getfield i : Ljava/lang/Class;
    //   102: astore_3
    //   103: aload_3
    //   104: astore #4
    //   106: aload_3
    //   107: ifnonnull -> 119
    //   110: aload_1
    //   111: getfield j : Ljava/lang/String;
    //   114: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   117: astore #4
    //   119: aload #4
    //   121: ifnull -> 29
    //   124: aload_2
    //   125: aload #4
    //   127: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
    //   130: ifeq -> 29
    //   133: getstatic com/facebook/ads/internal/adapters/d.a : Ljava/util/Set;
    //   136: aload_1
    //   137: invokeinterface add : (Ljava/lang/Object;)Z
    //   142: pop
    //   143: goto -> 29
    //   146: ldc com/facebook/ads/internal/adapters/BannerAdapter
    //   148: astore_2
    //   149: goto -> 94
    //   152: ldc com/facebook/ads/internal/adapters/InterstitialAdapter
    //   154: astore_2
    //   155: goto -> 94
    //   158: ldc com/facebook/ads/internal/adapters/v
    //   160: astore_2
    //   161: goto -> 94
    //   164: ldc com/facebook/ads/internal/adapters/r
    //   166: astore_2
    //   167: goto -> 94
    //   170: ldc com/facebook/ads/internal/adapters/x
    //   172: astore_2
    //   173: goto -> 94
    //   176: return
    //   177: astore #4
    //   179: aload_3
    //   180: astore #4
    //   182: goto -> 119
    // Exception table:
    //   from	to	target	type
    //   110	119	177	java/lang/ClassNotFoundException
  }
  
  public static AdAdapter a(e parame, AdPlacementType paramAdPlacementType) {
    try {
      f f = b(parame, paramAdPlacementType);
      if (f != null && a.contains(f)) {
        Class<?> clazz2 = f.i;
        Class<?> clazz1 = clazz2;
        if (clazz2 == null)
          clazz1 = Class.forName(f.j); 
        return (AdAdapter)clazz1.newInstance();
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return null;
  }
  
  public static AdAdapter a(String paramString, AdPlacementType paramAdPlacementType) {
    return a(e.a(paramString), paramAdPlacementType);
  }
  
  public static String a(AdPlacementType paramAdPlacementType) {
    if (b.containsKey(paramAdPlacementType))
      return b.get(paramAdPlacementType); 
    HashSet<String> hashSet = new HashSet();
    for (f f : a) {
      if (f.l == paramAdPlacementType)
        hashSet.add(f.k.toString()); 
    } 
    String str = ah.a(hashSet, ",");
    b.put(paramAdPlacementType, str);
    return str;
  }
  
  private static f b(e parame, AdPlacementType paramAdPlacementType) {
    // Byte code:
    //   0: getstatic com/facebook/ads/internal/adapters/d.a : Ljava/util/Set;
    //   3: invokeinterface iterator : ()Ljava/util/Iterator;
    //   8: astore_2
    //   9: aload_2
    //   10: invokeinterface hasNext : ()Z
    //   15: ifeq -> 48
    //   18: aload_2
    //   19: invokeinterface next : ()Ljava/lang/Object;
    //   24: checkcast com/facebook/ads/internal/adapters/f
    //   27: astore_3
    //   28: aload_3
    //   29: getfield k : Lcom/facebook/ads/internal/adapters/e;
    //   32: aload_0
    //   33: if_acmpne -> 9
    //   36: aload_3
    //   37: getfield l : Lcom/facebook/ads/internal/server/AdPlacementType;
    //   40: aload_1
    //   41: if_acmpne -> 9
    //   44: aload_3
    //   45: astore_0
    //   46: aload_0
    //   47: areturn
    //   48: aconst_null
    //   49: astore_0
    //   50: goto -> 46
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */