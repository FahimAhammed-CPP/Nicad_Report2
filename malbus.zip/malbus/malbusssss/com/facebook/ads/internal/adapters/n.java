package com.facebook.ads.internal.adapters;

import android.content.Context;
import android.view.View;
import com.facebook.ads.AdError;
import com.facebook.ads.AdNetwork;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdViewAttributes;
import com.facebook.ads.internal.g.f;
import com.facebook.ads.internal.util.aj;
import com.facebook.ads.internal.util.h;
import com.facebook.ads.internal.util.w;
import com.flurry.android.ads.FlurryAdErrorType;
import com.flurry.android.ads.FlurryAdNative;
import com.flurry.android.ads.FlurryAdNativeAsset;
import com.flurry.android.ads.FlurryAdNativeListener;
import java.util.List;
import java.util.Map;

public class n extends v implements t {
  private static volatile boolean a;
  
  private w b;
  
  private FlurryAdNative c;
  
  private boolean d;
  
  private String e;
  
  private String f;
  
  private String g;
  
  private String h;
  
  private String i;
  
  private NativeAd.Image j;
  
  private NativeAd.Image k;
  
  private NativeAd.Image l;
  
  public List<NativeAd> A() {
    return null;
  }
  
  public String B() {
    return null;
  }
  
  public AdNetwork C() {
    return AdNetwork.FLURRY;
  }
  
  public e D() {
    return e.e;
  }
  
  public void a() {
    if (this.c != null)
      this.c.removeTrackingView(); 
  }
  
  public void a(int paramInt) {}
  
  public void a(Context paramContext, w paramw, f paramf, Map<String, Object> paramMap) {
    // Byte code:
    //   0: aload #4
    //   2: ldc 'data'
    //   4: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   9: checkcast org/json/JSONObject
    //   12: astore #4
    //   14: aload #4
    //   16: ldc 'api_key'
    //   18: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   21: astore_3
    //   22: aload #4
    //   24: ldc 'placement_id'
    //   26: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   29: astore #4
    //   31: ldc com/facebook/ads/internal/adapters/n
    //   33: monitorenter
    //   34: getstatic com/facebook/ads/internal/adapters/n.a : Z
    //   37: ifne -> 87
    //   40: new java/lang/StringBuilder
    //   43: astore #5
    //   45: aload #5
    //   47: invokespecial <init> : ()V
    //   50: aload_1
    //   51: aload #5
    //   53: aload_0
    //   54: invokevirtual D : ()Lcom/facebook/ads/internal/adapters/e;
    //   57: invokestatic a : (Lcom/facebook/ads/internal/adapters/e;)Ljava/lang/String;
    //   60: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   63: ldc ' Initializing'
    //   65: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   68: invokevirtual toString : ()Ljava/lang/String;
    //   71: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)V
    //   74: iconst_1
    //   75: invokestatic setLogEnabled : (Z)V
    //   78: aload_1
    //   79: aload_3
    //   80: invokestatic init : (Landroid/content/Context;Ljava/lang/String;)V
    //   83: iconst_1
    //   84: putstatic com/facebook/ads/internal/adapters/n.a : Z
    //   87: ldc com/facebook/ads/internal/adapters/n
    //   89: monitorexit
    //   90: aload_1
    //   91: new java/lang/StringBuilder
    //   94: dup
    //   95: invokespecial <init> : ()V
    //   98: aload_0
    //   99: invokevirtual D : ()Lcom/facebook/ads/internal/adapters/e;
    //   102: invokestatic a : (Lcom/facebook/ads/internal/adapters/e;)Ljava/lang/String;
    //   105: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   108: ldc ' Loading'
    //   110: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   113: invokevirtual toString : ()Ljava/lang/String;
    //   116: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)V
    //   119: aload_0
    //   120: aload_2
    //   121: putfield b : Lcom/facebook/ads/internal/adapters/w;
    //   124: aload_0
    //   125: new com/flurry/android/ads/FlurryAdNative
    //   128: dup
    //   129: aload_1
    //   130: aload #4
    //   132: invokespecial <init> : (Landroid/content/Context;Ljava/lang/String;)V
    //   135: putfield c : Lcom/flurry/android/ads/FlurryAdNative;
    //   138: aload_0
    //   139: getfield c : Lcom/flurry/android/ads/FlurryAdNative;
    //   142: new com/facebook/ads/internal/adapters/n$1
    //   145: dup
    //   146: aload_0
    //   147: aload_1
    //   148: invokespecial <init> : (Lcom/facebook/ads/internal/adapters/n;Landroid/content/Context;)V
    //   151: invokevirtual setListener : (Lcom/flurry/android/ads/FlurryAdNativeListener;)V
    //   154: aload_0
    //   155: getfield c : Lcom/flurry/android/ads/FlurryAdNative;
    //   158: invokevirtual fetchAd : ()V
    //   161: return
    //   162: astore_1
    //   163: ldc com/facebook/ads/internal/adapters/n
    //   165: monitorexit
    //   166: aload_1
    //   167: athrow
    // Exception table:
    //   from	to	target	type
    //   34	87	162	finally
    //   87	90	162	finally
    //   163	166	162	finally
  }
  
  public void a(View paramView, List<View> paramList) {
    if (this.c != null)
      this.c.setTrackingView(paramView); 
  }
  
  public void a(Map<String, String> paramMap) {}
  
  public void b(Map<String, String> paramMap) {}
  
  public boolean b() {
    return this.d;
  }
  
  public boolean c() {
    return false;
  }
  
  public boolean d() {
    return false;
  }
  
  public boolean e() {
    return false;
  }
  
  public boolean f() {
    return false;
  }
  
  public boolean g() {
    return true;
  }
  
  public int h() {
    return 0;
  }
  
  public int i() {
    return 0;
  }
  
  public int j() {
    return 0;
  }
  
  public NativeAd.Image k() {
    return this.j;
  }
  
  public NativeAd.Image l() {
    return this.k;
  }
  
  public NativeAdViewAttributes m() {
    return null;
  }
  
  public String n() {
    return this.e;
  }
  
  public String o() {
    return this.g;
  }
  
  public void onDestroy() {
    a();
    this.b = null;
    if (this.c != null) {
      this.c.destroy();
      this.c = null;
    } 
  }
  
  public String p() {
    return this.f;
  }
  
  public String q() {
    return this.h;
  }
  
  public String r() {
    return this.i;
  }
  
  public NativeAd.Rating s() {
    return null;
  }
  
  public NativeAd.Image t() {
    return this.l;
  }
  
  public String u() {
    return null;
  }
  
  public String v() {
    return "Ad";
  }
  
  public String w() {
    return null;
  }
  
  public String x() {
    return null;
  }
  
  public aj y() {
    return aj.c;
  }
  
  public String z() {
    return null;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */