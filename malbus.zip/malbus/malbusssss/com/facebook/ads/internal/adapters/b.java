package com.facebook.ads.internal.adapters;

public abstract class b {
  public boolean a() {
    return false;
  }
  
  public boolean b() {
    return false;
  }
  
  public String c() {
    return null;
  }
  
  public void d() {}
  
  public void e() {}
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */