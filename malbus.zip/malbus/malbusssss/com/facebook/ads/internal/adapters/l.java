package com.facebook.ads.internal.adapters;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import com.facebook.ads.AdError;
import com.facebook.ads.AdNetwork;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdViewAttributes;
import com.facebook.ads.internal.a.a;
import com.facebook.ads.internal.a.b;
import com.facebook.ads.internal.g.f;
import com.facebook.ads.internal.util.aj;
import com.facebook.ads.internal.util.c;
import com.facebook.ads.internal.util.d;
import com.facebook.ads.internal.util.f;
import com.facebook.ads.internal.util.g;
import com.facebook.ads.internal.util.h;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class l extends v implements g.a {
  private static final String a = l.class.getSimpleName();
  
  private String A;
  
  private String B;
  
  private aj C;
  
  private String D;
  
  private NativeAd.Image E;
  
  private String F;
  
  private String G;
  
  private NativeAdViewAttributes H;
  
  private List<NativeAd> I;
  
  private int J;
  
  private int K;
  
  private String L;
  
  private boolean M;
  
  private boolean N;
  
  private boolean O;
  
  private boolean P;
  
  private boolean Q;
  
  private long R = 0L;
  
  private c.a S = null;
  
  @Nullable
  private f T;
  
  private Context b;
  
  private w c;
  
  private Uri d;
  
  private String e;
  
  private String f;
  
  private String g;
  
  private String h;
  
  private String i;
  
  private NativeAd.Image j;
  
  private NativeAd.Image k;
  
  private NativeAd.Rating l;
  
  private String m;
  
  private String n;
  
  private String o;
  
  private String p;
  
  private f q;
  
  private String r;
  
  private Collection<String> s;
  
  private boolean t;
  
  private boolean u;
  
  private boolean v;
  
  private int w;
  
  private int x;
  
  private int y;
  
  private int z;
  
  private boolean G() {
    return (this.e != null && this.e.length() > 0 && this.h != null && this.h.length() > 0 && (this.j != null || this.M) && this.k != null);
  }
  
  private void H() {
    if (!this.Q) {
      if (this.T != null)
        this.T.a(this.p); 
      this.Q = true;
    } 
  }
  
  private void a(Context paramContext, JSONObject paramJSONObject, String paramString, int paramInt1, int paramInt2) {
    this.M = true;
    this.b = paramContext;
    this.J = paramInt1;
    this.K = paramInt2;
    a(paramJSONObject, paramString);
  }
  
  private void a(Map<String, String> paramMap1, Map<String, String> paramMap2) {
    try {
      paramMap1 = c(paramMap1);
      Handler handler = new Handler();
      this();
      Runnable runnable = new Runnable() {
          public void run() {
            if (TextUtils.isEmpty(l.a(this.c))) {
              if (l.b(this.c) != null)
                l.b(this.c).a(l.c(this.c), this.a, this.b); 
              return;
            } 
            HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
            hashMap.putAll(this.a);
            hashMap.putAll(this.b);
            if (l.b(this.c) != null)
              l.b(this.c).e(l.a(this.c), hashMap); 
          }
        };
      super(this, paramMap2, paramMap1);
      handler.postDelayed(runnable, (this.w * 1000));
    } catch (Exception exception) {}
  }
  
  private void a(JSONObject paramJSONObject, String paramString) {
    JSONException jSONException = null;
    byte b = 0;
    if (this.N)
      throw new IllegalStateException("Adapter already loaded data"); 
    if (paramJSONObject != null) {
      NativeAdViewAttributes nativeAdViewAttributes;
      h.a(this.b, "Audience Network Loaded");
      this.L = paramString;
      this.d = Uri.parse(h.a(paramJSONObject, "fbad_command"));
      this.e = h.a(paramJSONObject, "title");
      this.f = h.a(paramJSONObject, "subtitle");
      this.g = h.a(paramJSONObject, "body");
      this.h = h.a(paramJSONObject, "call_to_action");
      this.i = h.a(paramJSONObject, "social_context");
      this.j = NativeAd.Image.fromJSONObject(paramJSONObject.optJSONObject("icon"));
      this.k = NativeAd.Image.fromJSONObject(paramJSONObject.optJSONObject("image"));
      this.l = NativeAd.Rating.fromJSONObject(paramJSONObject.optJSONObject("star_rating"));
      this.m = h.a(paramJSONObject, "impression_report_url");
      this.n = h.a(paramJSONObject, "native_view_report_url");
      this.o = h.a(paramJSONObject, "click_report_url");
      this.p = h.a(paramJSONObject, "used_report_url");
      this.t = paramJSONObject.optBoolean("manual_imp");
      this.u = paramJSONObject.optBoolean("enable_view_log");
      this.v = paramJSONObject.optBoolean("enable_snapshot_log");
      this.w = paramJSONObject.optInt("snapshot_log_delay_second", 4);
      this.x = paramJSONObject.optInt("snapshot_compress_quality", 0);
      this.y = paramJSONObject.optInt("viewability_check_initial_delay", 0);
      this.z = paramJSONObject.optInt("viewability_check_interval", 1000);
      JSONObject jSONObject1 = paramJSONObject.optJSONObject("ad_choices_icon");
      JSONObject jSONObject2 = paramJSONObject.optJSONObject("native_ui_config");
      if (jSONObject2 == null) {
        jSONObject2 = null;
      } else {
        nativeAdViewAttributes = new NativeAdViewAttributes(jSONObject2);
      } 
      this.H = nativeAdViewAttributes;
      if (jSONObject1 != null)
        this.E = NativeAd.Image.fromJSONObject(jSONObject1); 
      this.F = h.a(paramJSONObject, "ad_choices_link_url");
      this.G = h.a(paramJSONObject, "request_id");
      this.q = f.a(paramJSONObject.optString("invalidation_behavior"));
      this.r = h.a(paramJSONObject, "invalidation_report_url");
      try {
        JSONArray jSONArray = new JSONArray();
        this(paramJSONObject.optString("detection_strings"));
      } catch (JSONException jSONException1) {
        jSONException1.printStackTrace();
        jSONException1 = jSONException;
      } 
      this.s = g.a((JSONArray)jSONException1);
      this.A = h.a(paramJSONObject, "video_url");
      this.B = h.a(paramJSONObject, "video_mpd");
      if (!paramJSONObject.has("video_autoplay_enabled")) {
        this.C = aj.c;
      } else {
        aj aj1;
        if (paramJSONObject.optBoolean("video_autoplay_enabled")) {
          aj1 = aj.a;
        } else {
          aj1 = aj.b;
        } 
        this.C = aj1;
      } 
      this.D = h.a(paramJSONObject, "video_report_url");
      try {
        JSONArray jSONArray = paramJSONObject.optJSONArray("carousel");
        if (jSONArray != null && jSONArray.length() > 0) {
          int i = jSONArray.length();
          ArrayList<NativeAd> arrayList = new ArrayList();
          this(i);
          while (b < i) {
            l l1 = new l();
            this();
            l1.a(this.b, jSONArray.getJSONObject(b), paramString, b, i);
            NativeAd nativeAd = new NativeAd();
            this(this.b, l1, null);
            arrayList.add(nativeAd);
            b++;
          } 
          this.I = arrayList;
        } 
      } catch (JSONException jSONException2) {
        Log.e(a, "Unable to parse carousel data.", (Throwable)jSONException2);
      } 
    } 
  }
  
  private Map<String, String> c(Map<String, String> paramMap) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (paramMap.containsKey("view"))
      hashMap.put("view", paramMap.get("view")); 
    if (paramMap.containsKey("snapshot"))
      hashMap.put("snapshot", paramMap.get("snapshot")); 
    return (Map)hashMap;
  }
  
  public List<NativeAd> A() {
    return !b() ? null : this.I;
  }
  
  public String B() {
    return this.L;
  }
  
  public AdNetwork C() {
    return AdNetwork.AN;
  }
  
  public f D() {
    return this.q;
  }
  
  public String E() {
    return this.r;
  }
  
  public Collection<String> F() {
    return this.s;
  }
  
  public void a() {}
  
  public void a(int paramInt) {
    if (b() && paramInt == 0 && this.R > 0L && this.S != null) {
      d.a(c.a(this.R, this.S, this.G));
      this.R = 0L;
      this.S = null;
    } 
  }
  
  public void a(Context paramContext, w paramw, f paramf, Map<String, Object> paramMap) {
    this.b = paramContext;
    this.c = paramw;
    this.T = paramf;
    JSONObject jSONObject = (JSONObject)paramMap.get("data");
    a(jSONObject, h.a(jSONObject, "ct"));
    if (g.a(paramContext, this)) {
      paramw.a(this, AdError.NO_FILL);
      return;
    } 
    if (paramw != null)
      paramw.a(this); 
    c.a = this.G;
  }
  
  public void a(View paramView, List<View> paramList) {}
  
  public void a(Map<String, String> paramMap) {
    if (b() && !this.P) {
      if (this.c != null)
        this.c.b(this); 
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      if (paramMap != null)
        hashMap.putAll(paramMap); 
      if (!TextUtils.isEmpty(B())) {
        if (this.M) {
          hashMap.put("cardind", String.valueOf(this.J));
          hashMap.put("cardcnt", String.valueOf(this.K));
        } 
        if (this.T != null)
          this.T.b(B(), hashMap); 
      } else if (this.T != null) {
        this.T.a(this.m);
      } 
      if (e() || d())
        a(paramMap, (Map)hashMap); 
      this.P = true;
    } 
  }
  
  public void b(Map<String, String> paramMap) {
    if (b()) {
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      if (paramMap != null)
        hashMap.putAll(paramMap); 
      if (TextUtils.isEmpty(this.L))
        this.T.a(this.o, hashMap); 
      h.a(this.b, "Click logged");
      if (this.c != null)
        this.c.c(this); 
      if (this.M) {
        hashMap.put("cardind", String.valueOf(this.J));
        hashMap.put("cardcnt", String.valueOf(this.K));
      } 
      a a1 = b.a(this.b, this.L, this.d, hashMap);
      if (a1 != null)
        try {
          this.R = System.currentTimeMillis();
          this.S = a1.a();
          a1.b();
        } catch (Exception exception) {
          Log.e(a, "Error executing action", exception);
        }  
    } 
  }
  
  public boolean b() {
    return (this.N && this.O);
  }
  
  public boolean c() {
    return (b() && this.t);
  }
  
  public boolean d() {
    return (b() && this.v);
  }
  
  public boolean e() {
    return (b() && this.u);
  }
  
  public boolean f() {
    return (b() && this.H != null);
  }
  
  public boolean g() {
    return true;
  }
  
  public int h() {
    return (this.x < 0 || this.x > 100) ? 0 : this.x;
  }
  
  public int i() {
    return this.y;
  }
  
  public int j() {
    return this.z;
  }
  
  public NativeAd.Image k() {
    return !b() ? null : this.j;
  }
  
  public NativeAd.Image l() {
    return !b() ? null : this.k;
  }
  
  public NativeAdViewAttributes m() {
    return !b() ? null : this.H;
  }
  
  public String n() {
    if (!b())
      return null; 
    H();
    return this.e;
  }
  
  public String o() {
    if (!b())
      return null; 
    H();
    return this.f;
  }
  
  public void onDestroy() {}
  
  public String p() {
    if (!b())
      return null; 
    H();
    return this.g;
  }
  
  public String q() {
    if (!b())
      return null; 
    H();
    return this.h;
  }
  
  public String r() {
    if (!b())
      return null; 
    H();
    return this.i;
  }
  
  public NativeAd.Rating s() {
    if (!b())
      return null; 
    H();
    return this.l;
  }
  
  public NativeAd.Image t() {
    return !b() ? null : this.E;
  }
  
  public String u() {
    return !b() ? null : this.F;
  }
  
  public String v() {
    return !b() ? null : "AdChoices";
  }
  
  public String w() {
    return !b() ? null : this.A;
  }
  
  public String x() {
    return !b() ? null : this.B;
  }
  
  public aj y() {
    return !b() ? aj.c : this.C;
  }
  
  public String z() {
    return this.D;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */