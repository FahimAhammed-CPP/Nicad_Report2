package com.facebook.ads.internal.adapters;

import com.facebook.ads.internal.server.AdPlacementType;
import java.util.List;

public enum f {
  a(h.class, e.b, AdPlacementType.BANNER),
  b(j.class, e.b, AdPlacementType.INTERSTITIAL),
  c(c.class, e.c, AdPlacementType.NATIVE),
  d(l.class, e.b, AdPlacementType.NATIVE),
  e(i.class, e.b, AdPlacementType.INSTREAM),
  f(m.class, e.b, AdPlacementType.REWARDED_VIDEO),
  g(q.class, e.d, AdPlacementType.NATIVE),
  h(n.class, e.e, AdPlacementType.NATIVE);
  
  private static List<f> m;
  
  public Class<?> i;
  
  public String j;
  
  public e k;
  
  public AdPlacementType l;
  
  f(Class<?> paramClass, e parame, AdPlacementType paramAdPlacementType) {
    this.i = paramClass;
    this.k = parame;
    this.l = paramAdPlacementType;
  }
  
  public static List<f> a() {
    // Byte code:
    //   0: getstatic com/facebook/ads/internal/adapters/f.m : Ljava/util/List;
    //   3: ifnonnull -> 147
    //   6: ldc com/facebook/ads/internal/adapters/f
    //   8: monitorenter
    //   9: new java/util/ArrayList
    //   12: astore_0
    //   13: aload_0
    //   14: invokespecial <init> : ()V
    //   17: aload_0
    //   18: putstatic com/facebook/ads/internal/adapters/f.m : Ljava/util/List;
    //   21: getstatic com/facebook/ads/internal/adapters/f.m : Ljava/util/List;
    //   24: getstatic com/facebook/ads/internal/adapters/f.a : Lcom/facebook/ads/internal/adapters/f;
    //   27: invokeinterface add : (Ljava/lang/Object;)Z
    //   32: pop
    //   33: getstatic com/facebook/ads/internal/adapters/f.m : Ljava/util/List;
    //   36: getstatic com/facebook/ads/internal/adapters/f.b : Lcom/facebook/ads/internal/adapters/f;
    //   39: invokeinterface add : (Ljava/lang/Object;)Z
    //   44: pop
    //   45: getstatic com/facebook/ads/internal/adapters/f.m : Ljava/util/List;
    //   48: getstatic com/facebook/ads/internal/adapters/f.d : Lcom/facebook/ads/internal/adapters/f;
    //   51: invokeinterface add : (Ljava/lang/Object;)Z
    //   56: pop
    //   57: getstatic com/facebook/ads/internal/adapters/f.m : Ljava/util/List;
    //   60: getstatic com/facebook/ads/internal/adapters/f.e : Lcom/facebook/ads/internal/adapters/f;
    //   63: invokeinterface add : (Ljava/lang/Object;)Z
    //   68: pop
    //   69: getstatic com/facebook/ads/internal/adapters/f.m : Ljava/util/List;
    //   72: getstatic com/facebook/ads/internal/adapters/f.f : Lcom/facebook/ads/internal/adapters/f;
    //   75: invokeinterface add : (Ljava/lang/Object;)Z
    //   80: pop
    //   81: getstatic com/facebook/ads/internal/adapters/e.e : Lcom/facebook/ads/internal/adapters/e;
    //   84: invokestatic a : (Lcom/facebook/ads/internal/adapters/e;)Z
    //   87: ifeq -> 102
    //   90: getstatic com/facebook/ads/internal/adapters/f.m : Ljava/util/List;
    //   93: getstatic com/facebook/ads/internal/adapters/f.h : Lcom/facebook/ads/internal/adapters/f;
    //   96: invokeinterface add : (Ljava/lang/Object;)Z
    //   101: pop
    //   102: getstatic com/facebook/ads/internal/adapters/e.d : Lcom/facebook/ads/internal/adapters/e;
    //   105: invokestatic a : (Lcom/facebook/ads/internal/adapters/e;)Z
    //   108: ifeq -> 123
    //   111: getstatic com/facebook/ads/internal/adapters/f.m : Ljava/util/List;
    //   114: getstatic com/facebook/ads/internal/adapters/f.g : Lcom/facebook/ads/internal/adapters/f;
    //   117: invokeinterface add : (Ljava/lang/Object;)Z
    //   122: pop
    //   123: getstatic com/facebook/ads/internal/adapters/e.c : Lcom/facebook/ads/internal/adapters/e;
    //   126: invokestatic a : (Lcom/facebook/ads/internal/adapters/e;)Z
    //   129: ifeq -> 144
    //   132: getstatic com/facebook/ads/internal/adapters/f.m : Ljava/util/List;
    //   135: getstatic com/facebook/ads/internal/adapters/f.c : Lcom/facebook/ads/internal/adapters/f;
    //   138: invokeinterface add : (Ljava/lang/Object;)Z
    //   143: pop
    //   144: ldc com/facebook/ads/internal/adapters/f
    //   146: monitorexit
    //   147: getstatic com/facebook/ads/internal/adapters/f.m : Ljava/util/List;
    //   150: areturn
    //   151: astore_0
    //   152: ldc com/facebook/ads/internal/adapters/f
    //   154: monitorexit
    //   155: aload_0
    //   156: athrow
    // Exception table:
    //   from	to	target	type
    //   9	102	151	finally
    //   102	123	151	finally
    //   123	144	151	finally
    //   144	147	151	finally
    //   152	155	151	finally
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */