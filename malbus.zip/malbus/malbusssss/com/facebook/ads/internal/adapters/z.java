package com.facebook.ads.internal.adapters;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import com.facebook.ads.AdError;
import com.facebook.ads.internal.j;

public class z extends BroadcastReceiver {
  private String a;
  
  private y b;
  
  private x c;
  
  public z(String paramString, x paramx, y paramy) {
    this.c = paramx;
    this.b = paramy;
    this.a = paramString;
  }
  
  public IntentFilter a() {
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction(j.a.a(this.a));
    intentFilter.addAction(j.d.a(this.a));
    intentFilter.addAction(j.e.a(this.a));
    intentFilter.addAction(j.f.a(this.a));
    intentFilter.addAction(j.g.a(this.a));
    intentFilter.addAction(j.h.a(this.a));
    intentFilter.addAction(j.i.a(this.a));
    return intentFilter;
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    String str = paramIntent.getAction();
    if (j.a.a(this.a).equals(str)) {
      this.b.d(this.c);
      return;
    } 
    if (j.d.a(this.a).equals(str)) {
      this.b.a(this.c, AdError.INTERNAL_ERROR);
      return;
    } 
    if (j.e.a(this.a).equals(str)) {
      this.b.b(this.c);
      return;
    } 
    if (j.f.a(this.a).equals(str)) {
      this.b.c(this.c);
      return;
    } 
    if (j.g.a(this.a).equals(str)) {
      this.b.a();
      return;
    } 
    if (j.i.a(this.a).equals(str)) {
      this.b.e(this.c);
      return;
    } 
    if (j.h.a(this.a).equals(str))
      this.b.f(this.c); 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */