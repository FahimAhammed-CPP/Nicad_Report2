package com.facebook.ads.internal.adapters;

import android.text.TextUtils;
import java.util.Locale;

public enum e {
  a, b, c, d, e;
  
  public static e a(String paramString) {
    e e1;
    if (TextUtils.isEmpty(paramString))
      return a; 
    try {
      e1 = Enum.<e>valueOf(e.class, paramString.toUpperCase(Locale.getDefault()));
    } catch (Exception exception) {
      e1 = a;
    } 
    return e1;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */