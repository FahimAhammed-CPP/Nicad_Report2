package com.facebook.ads.internal.adapters;

import android.content.Context;
import com.facebook.ads.internal.util.h;
import java.util.HashMap;
import java.util.Map;

public abstract class a {
  protected final b a;
  
  protected final com.facebook.ads.internal.j.a b;
  
  private final Context c;
  
  private boolean d;
  
  public a(Context paramContext, b paramb, com.facebook.ads.internal.j.a parama) {
    this.c = paramContext;
    this.a = paramb;
    this.b = parama;
  }
  
  public final void a() {
    if (!this.d) {
      if (this.a != null)
        this.a.d(); 
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      if (this.b != null)
        this.b.a(hashMap); 
      a((Map)hashMap);
      this.d = true;
      h.a(this.c, "Impression logged");
      if (this.a != null)
        this.a.e(); 
    } 
  }
  
  protected abstract void a(Map<String, String> paramMap);
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */