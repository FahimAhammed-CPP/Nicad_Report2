package com.facebook.ads.internal.adapters;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.facebook.ads.AudienceNetworkActivity;
import com.facebook.ads.internal.g.q;
import com.facebook.ads.internal.g.s;
import com.facebook.ads.internal.view.c.a;
import com.facebook.ads.internal.view.d;
import com.facebook.ads.internal.view.d.a.b;
import com.facebook.ads.internal.view.d.b.a;
import com.facebook.ads.internal.view.d.b.c;
import com.facebook.ads.internal.view.d.b.h;
import com.facebook.ads.internal.view.d.b.i;
import com.facebook.ads.internal.view.d.b.j;
import com.facebook.ads.internal.view.d.b.m;
import org.json.JSONObject;

public class k extends i implements d {
  private final s<b> f = new s<b>(this) {
      public Class<b> a() {
        return b.class;
      }
      
      public void a(b param1b) {
        if (k.a(this.a) != null)
          k.a(this.a).finish(); 
      }
    };
  
  @Nullable
  private d.a g;
  
  @Nullable
  private Activity h;
  
  @Nullable
  private h i;
  
  private AudienceNetworkActivity.BackButtonInterceptor j = new AudienceNetworkActivity.BackButtonInterceptor(this) {
      public boolean interceptBackButton() {
        boolean bool1 = false;
        boolean bool2 = bool1;
        if (k.b(this.a) != null) {
          bool2 = bool1;
          if (!k.b(this.a).a())
            bool2 = true; 
        } 
        return bool2;
      }
    };
  
  private j.a k = j.a.a;
  
  private a l;
  
  private j m;
  
  private j n;
  
  @Nullable
  private c o;
  
  static {
    boolean bool;
    if (!k.class.desiredAssertionStatus()) {
      bool = true;
    } else {
      bool = false;
    } 
    e = bool;
  }
  
  private void a(int paramInt) {
    float f = (this.c.getResources().getDisplayMetrics()).density;
    int m = this.a.getVideoView().getId();
    if (paramInt == 1) {
      RelativeLayout.LayoutParams layoutParams1 = new RelativeLayout.LayoutParams(-2, -2);
      layoutParams1.topMargin = (int)(-54.0F * f);
      layoutParams1.addRule(3, m);
      layoutParams1.addRule(11);
      this.i.setLayoutParams((ViewGroup.LayoutParams)layoutParams1);
      this.i.setPadding(0, 0, 0, 48);
      if (this.l != null) {
        layoutParams1 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams1.topMargin = (int)(82.0F * f);
        layoutParams1.addRule(14);
        layoutParams1.addRule(3, m);
        this.l.setLayoutParams((ViewGroup.LayoutParams)layoutParams1);
      } 
      if (this.m != null) {
        layoutParams1 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams1.bottomMargin = (int)(12.0F * f);
        layoutParams1.addRule(14);
        layoutParams1.addRule(2, m);
        this.m.setPadding(0, 0, 0, 0);
        this.m.setLayoutParams((ViewGroup.LayoutParams)layoutParams1);
      } 
      if (this.n != null) {
        layoutParams1 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams1.topMargin = (int)(32.0F * f);
        layoutParams1.addRule(14);
        layoutParams1.addRule(3, m);
        this.n.setPadding(0, 0, 0, 0);
        this.n.setLayoutParams((ViewGroup.LayoutParams)layoutParams1);
      } 
      layoutParams1 = new RelativeLayout.LayoutParams(-2, -2);
      layoutParams1.topMargin = (int)(8.0F * f);
      layoutParams1.leftMargin = (int)(f * 8.0F);
      layoutParams1.addRule(9);
      layoutParams1.addRule(3, m);
      if (this.o != null) {
        this.o.setLayoutParams((ViewGroup.LayoutParams)layoutParams1);
        if (this.o.getParent() == null)
          this.a.addView((View)this.o); 
      } 
      return;
    } 
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
    layoutParams.addRule(12);
    layoutParams.addRule(11);
    this.i.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    this.i.setPadding(0, 0, 0, 48);
    if (this.l != null) {
      layoutParams = new RelativeLayout.LayoutParams(-2, -2);
      layoutParams.addRule(10);
      layoutParams.addRule(11);
      layoutParams.topMargin = (int)(12.0F * f);
      layoutParams.rightMargin = (int)(12.0F * f);
      this.l.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    } 
    if (this.m != null) {
      layoutParams = new RelativeLayout.LayoutParams(-2, -2);
      layoutParams.topMargin = (int)(12.0F * f);
      layoutParams.addRule(10);
      layoutParams.addRule(9);
      this.m.setPadding(32, 12, 16, 12);
      this.m.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    } 
    if (this.n != null) {
      layoutParams = new RelativeLayout.LayoutParams((int)(f * 400.0F), -2);
      layoutParams.addRule(12);
      layoutParams.addRule(9);
      this.n.setPadding(32, 24, 32, 24);
      this.n.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    } 
    if (this.o != null)
      this.a.removeViewInLayout((View)this.o); 
  }
  
  @TargetApi(17)
  protected void a() {
    this.a.getEventBus().a(this.f);
    this.a.a((m)new i(this.c));
    this.a.a((m)new com.facebook.ads.internal.view.d.b.k(this.c));
    String str2 = this.b.getJSONObject("context").optString("orientation");
    if (!str2.isEmpty()) {
      this.k = j.a.a(Integer.parseInt(str2));
      this.k = j.a.a;
    } 
    int m = View.generateViewId();
    this.a.getVideoView().setId(m);
    m = c();
    if (m >= 0) {
      this.i = new h(this.c, m);
      this.a.a((m)this.i);
    } 
    if (this.b.has("cta") && !this.b.isNull("cta")) {
      JSONObject jSONObject1 = this.b.getJSONObject("cta");
      this.l = new a(this.c, jSONObject1.getString("url"), jSONObject1.getString("text"));
      this.a.a((m)this.l);
    } 
    JSONObject jSONObject = this.b.getJSONObject("text");
    String str3 = jSONObject.optString("title");
    if (!str3.isEmpty()) {
      this.m = new j(this.c, str3, 18);
      this.a.a((m)this.m);
    } 
    String str1 = jSONObject.optString("subtitle");
    if (!str1.isEmpty()) {
      this.n = new j(this.c, str1, 16);
      this.a.a((m)this.n);
    } 
    str1 = b();
    if (str1 != null) {
      this.o = new c(this.c, str1);
      this.a.a((m)this.o);
    } 
    a a1 = new a(this.c, "http://m.facebook.com/ads/ad_choices", "", new float[] { 0.0F, 8.0F, 0.0F, 0.0F });
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
    layoutParams.addRule(12);
    layoutParams.addRule(9);
    a1.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    this.a.a((m)a1);
    this.a.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
  }
  
  @TargetApi(17)
  public void a(Intent paramIntent, Bundle paramBundle, AudienceNetworkActivity paramAudienceNetworkActivity) {
    this.h = (Activity)paramAudienceNetworkActivity;
    if (!e && this.g == null)
      throw new AssertionError(); 
    if (!e && this.i == null)
      throw new AssertionError(); 
    paramAudienceNetworkActivity.addBackButtonInterceptor(this.j);
    this.g.a((View)this.a);
    a((this.h.getResources().getConfiguration()).orientation);
    d();
  }
  
  public void a(Configuration paramConfiguration) {
    a(paramConfiguration.orientation);
  }
  
  public void a(Bundle paramBundle) {}
  
  public void a(d.a parama) {
    this.g = parama;
  }
  
  public void e() {}
  
  public void f() {}
  
  public void g() {}
  
  public j.a h() {
    return this.k;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */