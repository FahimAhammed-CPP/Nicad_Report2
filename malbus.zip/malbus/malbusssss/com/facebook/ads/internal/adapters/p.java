package com.facebook.ads.internal.adapters;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import com.facebook.ads.internal.g.g;
import com.facebook.ads.internal.j.a;
import com.facebook.ads.internal.util.y;
import com.facebook.ads.internal.view.b;
import java.util.HashMap;
import java.util.Map;

public class p extends a {
  private static final String c = p.class.getSimpleName();
  
  private final b d;
  
  private final Context e;
  
  private o f;
  
  private boolean g;
  
  public p(Context paramContext, b paramb, a parama, b paramb1) {
    super(paramContext, paramb1, parama);
    this.e = paramContext.getApplicationContext();
    this.d = paramb;
  }
  
  private void b(Map<String, String> paramMap) {
    if (this.f != null) {
      if (!TextUtils.isEmpty(this.f.B())) {
        if (paramMap != null)
          paramMap.remove("evt"); 
        g.a(this.e).b(this.f.B(), paramMap);
        return;
      } 
      String str = this.f.c();
      if (!TextUtils.isEmpty(str))
        (new y(paramMap)).execute((Object[])new String[] { str }); 
    } 
  }
  
  public void a(o paramo) {
    this.f = paramo;
  }
  
  protected void a(Map<String, String> paramMap) {
    if (this.f != null) {
      if (this.d != null && !TextUtils.isEmpty(this.f.d()))
        if (this.d.c()) {
          Log.w(c, "Webview already destroyed, cannot send impression");
        } else {
          this.d.loadUrl("javascript:" + this.f.d());
        }  
      paramMap.put("evt", "native_imp");
      b(paramMap);
    } 
  }
  
  public void b() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield g : Z
    //   6: ifne -> 18
    //   9: aload_0
    //   10: getfield f : Lcom/facebook/ads/internal/adapters/o;
    //   13: astore_1
    //   14: aload_1
    //   15: ifnonnull -> 21
    //   18: aload_0
    //   19: monitorexit
    //   20: return
    //   21: aload_0
    //   22: iconst_1
    //   23: putfield g : Z
    //   26: aload_0
    //   27: getfield d : Lcom/facebook/ads/internal/view/b;
    //   30: ifnull -> 18
    //   33: aload_0
    //   34: getfield f : Lcom/facebook/ads/internal/adapters/o;
    //   37: invokevirtual b : ()Ljava/lang/String;
    //   40: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   43: ifne -> 18
    //   46: aload_0
    //   47: getfield d : Lcom/facebook/ads/internal/view/b;
    //   50: astore_1
    //   51: new com/facebook/ads/internal/adapters/p$1
    //   54: astore_2
    //   55: aload_2
    //   56: aload_0
    //   57: invokespecial <init> : (Lcom/facebook/ads/internal/adapters/p;)V
    //   60: aload_1
    //   61: aload_2
    //   62: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   65: pop
    //   66: goto -> 18
    //   69: astore_1
    //   70: aload_0
    //   71: monitorexit
    //   72: aload_1
    //   73: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	69	finally
    //   21	66	69	finally
  }
  
  public void c() {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("evt", "interstitial_displayed");
    this.b.a(hashMap);
    b((Map)hashMap);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */