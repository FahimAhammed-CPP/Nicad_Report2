package com.facebook.ads.internal.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import com.facebook.ads.NativeAdView;
import com.facebook.ads.internal.j.a;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class u extends a {
  private final v c;
  
  private NativeAdView.Type d;
  
  private boolean e;
  
  private boolean f;
  
  private boolean g;
  
  private View h;
  
  private List<View> i;
  
  public u(Context paramContext, b paramb, a parama, v paramv) {
    super(paramContext, paramb, parama);
    this.c = paramv;
  }
  
  private String b(View paramView) {
    String str;
    try {
      str = c(paramView).toString();
    } catch (JSONException jSONException) {
      str = "Json exception";
    } 
    return str;
  }
  
  private JSONObject c(View paramView) {
    boolean bool = true;
    byte b = 0;
    JSONObject jSONObject = new JSONObject();
    jSONObject.putOpt("id", Integer.valueOf(paramView.getId()));
    jSONObject.putOpt("class", paramView.getClass());
    jSONObject.putOpt("origin", String.format("{x:%d, y:%d}", new Object[] { Integer.valueOf(paramView.getTop()), Integer.valueOf(paramView.getLeft()) }));
    jSONObject.putOpt("size", String.format("{h:%d, w:%d}", new Object[] { Integer.valueOf(paramView.getHeight()), Integer.valueOf(paramView.getWidth()) }));
    if (this.i == null || !this.i.contains(paramView))
      bool = false; 
    jSONObject.putOpt("clickable", Boolean.valueOf(bool));
    String str = "unknown";
    if (paramView instanceof android.widget.Button) {
      str = "button";
    } else if (paramView instanceof android.widget.TextView) {
      str = "text";
    } else if (paramView instanceof android.widget.ImageView) {
      str = "image";
    } else if (paramView instanceof com.facebook.ads.MediaView) {
      str = "mediaview";
    } else if (paramView instanceof ViewGroup) {
      str = "viewgroup";
    } 
    jSONObject.putOpt("type", str);
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      JSONArray jSONArray = new JSONArray();
      while (b < viewGroup.getChildCount()) {
        jSONArray.put(c(viewGroup.getChildAt(b)));
        b++;
      } 
      jSONObject.putOpt("list", jSONArray);
    } 
    return jSONObject;
  }
  
  private String d(View paramView) {
    String str;
    if (paramView.getWidth() <= 0 || paramView.getHeight() <= 0)
      return ""; 
    try {
      Bitmap bitmap = Bitmap.createBitmap(paramView.getWidth(), paramView.getHeight(), Bitmap.Config.ARGB_8888);
      bitmap.setDensity((paramView.getResources().getDisplayMetrics()).densityDpi);
      Canvas canvas = new Canvas();
      this(bitmap);
      paramView.draw(canvas);
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      this();
      bitmap.compress(Bitmap.CompressFormat.JPEG, this.c.h(), byteArrayOutputStream);
      str = Base64.encodeToString(byteArrayOutputStream.toByteArray(), 0);
    } catch (Exception exception) {
      str = "";
    } 
    return str;
  }
  
  public void a(View paramView) {
    this.h = paramView;
  }
  
  public void a(NativeAdView.Type paramType) {
    this.d = paramType;
  }
  
  public void a(List<View> paramList) {
    this.i = paramList;
  }
  
  protected void a(Map<String, String> paramMap) {
    if (this.c != null) {
      if (this.a != null) {
        paramMap.put("mil", String.valueOf(this.a.a()));
        paramMap.put("eil", String.valueOf(this.a.b()));
        paramMap.put("eil_source", this.a.c());
      } 
      if (this.d != null)
        paramMap.put("nti", String.valueOf(this.d.getValue())); 
      if (this.e)
        paramMap.put("nhs", Boolean.TRUE.toString()); 
      if (this.f)
        paramMap.put("nmv", Boolean.TRUE.toString()); 
      if (this.g)
        paramMap.put("nmvap", Boolean.TRUE.toString()); 
      if (this.h != null && this.c.e())
        paramMap.put("view", b(this.h)); 
      if (this.h != null && this.c.d())
        paramMap.put("snapshot", d(this.h)); 
      this.c.a(paramMap);
    } 
  }
  
  public void a(boolean paramBoolean) {
    this.e = paramBoolean;
  }
  
  public void b(boolean paramBoolean) {
    this.f = paramBoolean;
  }
  
  public void c(boolean paramBoolean) {
    this.g = paramBoolean;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */