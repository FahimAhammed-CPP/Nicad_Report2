package com.facebook.ads.internal.adapters;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;
import com.facebook.ads.internal.view.d.a.o;
import com.facebook.ads.internal.view.i;
import java.io.Serializable;

public class aa extends BroadcastReceiver {
  private Context a;
  
  private i b;
  
  private boolean c = false;
  
  public aa(i parami, Context paramContext) {
    this.b = parami;
    this.a = paramContext;
  }
  
  public void a() {
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction("com.facebook.ads.interstitial.displayed:" + this.b.getUniqueId());
    intentFilter.addAction("videoInterstitalEvent:" + this.b.getUniqueId());
    LocalBroadcastManager.getInstance(this.a).registerReceiver(this, intentFilter);
  }
  
  public void b() {
    try {
      LocalBroadcastManager.getInstance(this.a).unregisterReceiver(this);
    } catch (Exception exception) {}
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    String[] arrayOfString = paramIntent.getAction().split(":");
    if (arrayOfString.length == 2 && arrayOfString[1].equals(this.b.getUniqueId())) {
      if (arrayOfString[0].equals("com.facebook.ads.interstitial.displayed")) {
        if (this.b.getListener() != null) {
          this.b.getListener().onEnterFullscreen(this.b.getMediaView());
          this.b.getListener().onVolumeChange(this.b.getMediaView(), 1.0F);
        } 
        return;
      } 
      if (arrayOfString[0].equals("videoInterstitalEvent")) {
        Serializable serializable = paramIntent.getSerializableExtra("event");
        if (serializable instanceof o) {
          if (this.b.getListener() != null) {
            this.b.getListener().onExitFullscreen(this.b.getMediaView());
            this.b.getListener().onVolumeChange(this.b.getMediaView(), 0.0F);
          } 
          if (this.c) {
            this.b.a(1);
          } else {
            this.b.a(((o)serializable).b());
          } 
          this.b.setVisibility(0);
          this.b.d();
          return;
        } 
        if (serializable instanceof com.facebook.ads.internal.view.d.a.f) {
          if (this.b.getListener() != null)
            this.b.getListener().onFullscreenBackground(this.b.getMediaView()); 
          return;
        } 
        if (serializable instanceof com.facebook.ads.internal.view.d.a.g) {
          if (this.b.getListener() != null)
            this.b.getListener().onFullscreenForeground(this.b.getMediaView()); 
          return;
        } 
        if (serializable instanceof com.facebook.ads.internal.view.d.a.b) {
          if (this.b.getListener() != null)
            this.b.getListener().onComplete(this.b.getMediaView()); 
          this.c = true;
          return;
        } 
        if (serializable instanceof com.facebook.ads.internal.view.d.a.j) {
          if (this.b.getListener() != null)
            this.b.getListener().onPlay(this.b.getMediaView()); 
          this.c = false;
          return;
        } 
        if (serializable instanceof com.facebook.ads.internal.view.d.a.h && this.b.getListener() != null)
          this.b.getListener().onPause(this.b.getMediaView()); 
      } 
    } 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/aa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */