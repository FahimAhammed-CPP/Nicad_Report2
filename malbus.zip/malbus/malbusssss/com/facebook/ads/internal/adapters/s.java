package com.facebook.ads.internal.adapters;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;
import com.facebook.ads.AdError;

public class s extends BroadcastReceiver {
  private String a;
  
  private Context b;
  
  private InterstitialAdapterListener c;
  
  private InterstitialAdapter d;
  
  public s(Context paramContext, String paramString, InterstitialAdapter paramInterstitialAdapter, InterstitialAdapterListener paramInterstitialAdapterListener) {
    this.b = paramContext;
    this.a = paramString;
    this.c = paramInterstitialAdapterListener;
    this.d = paramInterstitialAdapter;
  }
  
  public void a() {
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction("com.facebook.ads.interstitial.impression.logged:" + this.a);
    intentFilter.addAction("com.facebook.ads.interstitial.displayed:" + this.a);
    intentFilter.addAction("com.facebook.ads.interstitial.dismissed:" + this.a);
    intentFilter.addAction("com.facebook.ads.interstitial.clicked:" + this.a);
    intentFilter.addAction("com.facebook.ads.interstitial.error:" + this.a);
    LocalBroadcastManager.getInstance(this.b).registerReceiver(this, intentFilter);
  }
  
  public void b() {
    try {
      LocalBroadcastManager.getInstance(this.b).unregisterReceiver(this);
    } catch (Exception exception) {}
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    String str = paramIntent.getAction().split(":")[0];
    if (this.c != null && str != null) {
      if ("com.facebook.ads.interstitial.clicked".equals(str)) {
        this.c.onInterstitialAdClicked(this.d, null, true);
        return;
      } 
      if ("com.facebook.ads.interstitial.dismissed".equals(str)) {
        this.c.onInterstitialAdDismissed(this.d);
        return;
      } 
      if ("com.facebook.ads.interstitial.displayed".equals(str)) {
        this.c.onInterstitialAdDisplayed(this.d);
        return;
      } 
      if ("com.facebook.ads.interstitial.impression.logged".equals(str)) {
        this.c.onInterstitialLoggingImpression(this.d);
        return;
      } 
      if ("com.facebook.ads.interstitial.error".equals(str))
        this.c.onInterstitialError(this.d, AdError.INTERNAL_ERROR); 
    } 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/adapters/s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */