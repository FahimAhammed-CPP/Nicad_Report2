package com.facebook.ads.internal;

public class AdSdkVersion {
  public static final String BUILD = "4.19.0";
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/AdSdkVersion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */