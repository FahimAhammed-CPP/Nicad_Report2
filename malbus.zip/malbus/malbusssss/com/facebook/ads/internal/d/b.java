package com.facebook.ads.internal.d;

import android.os.Process;
import android.support.annotation.Nullable;
import com.facebook.ads.internal.e.e;
import com.facebook.ads.internal.f.g;
import com.facebook.ads.internal.f.i;
import com.facebook.ads.internal.g.d;
import com.facebook.ads.internal.g.p;
import com.facebook.ads.internal.util.af;
import com.facebook.ads.internal.util.n;

public class b implements Thread.UncaughtExceptionHandler {
  private final Thread.UncaughtExceptionHandler a;
  
  private final e b;
  
  public b(@Nullable Thread.UncaughtExceptionHandler paramUncaughtExceptionHandler, e parame) {
    this.a = paramUncaughtExceptionHandler;
    if (parame == null)
      throw new IllegalArgumentException("Missing Database helper"); 
    this.b = parame;
  }
  
  public void uncaughtException(Thread paramThread, Throwable paramThrowable) {
    String str = af.a(paramThrowable);
    if (str != null && str.contains("com.facebook.ads")) {
      n n = new n(str, i.f);
      p p = new p(g.b(), g.c(), n);
      this.b.a((d)p, true);
    } 
    if (this.a != null) {
      this.a.uncaughtException(paramThread, paramThrowable);
      return;
    } 
    try {
      Process.killProcess(Process.myPid());
    } catch (Throwable throwable) {}
    try {
      System.exit(10);
    } catch (Throwable throwable) {}
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/d/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */