package com.facebook.ads.internal.d;

import android.content.Context;

public class a {
  private static final String a = a.class.getName();
  
  private static a b;
  
  private static boolean c = false;
  
  private Context d;
  
  private a(Context paramContext) {
    this.d = paramContext;
  }
  
  public static a a(Context paramContext) {
    if (b == null)
      synchronized (paramContext.getApplicationContext()) {
        if (b == null) {
          a a1 = new a();
          this(paramContext);
          b = a1;
        } 
        return b;
      }  
    return b;
  }
  
  public void a() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic com/facebook/ads/internal/d/a.c : Z
    //   5: ifne -> 57
    //   8: aload_0
    //   9: getfield d : Landroid/content/Context;
    //   12: invokestatic c : (Landroid/content/Context;)Z
    //   15: istore_1
    //   16: iload_1
    //   17: ifeq -> 53
    //   20: invokestatic getDefaultUncaughtExceptionHandler : ()Ljava/lang/Thread$UncaughtExceptionHandler;
    //   23: astore_2
    //   24: new com/facebook/ads/internal/d/b
    //   27: astore_3
    //   28: new com/facebook/ads/internal/e/e
    //   31: astore #4
    //   33: aload #4
    //   35: aload_0
    //   36: getfield d : Landroid/content/Context;
    //   39: invokespecial <init> : (Landroid/content/Context;)V
    //   42: aload_3
    //   43: aload_2
    //   44: aload #4
    //   46: invokespecial <init> : (Ljava/lang/Thread$UncaughtExceptionHandler;Lcom/facebook/ads/internal/e/e;)V
    //   49: aload_3
    //   50: invokestatic setDefaultUncaughtExceptionHandler : (Ljava/lang/Thread$UncaughtExceptionHandler;)V
    //   53: iconst_1
    //   54: putstatic com/facebook/ads/internal/d/a.c : Z
    //   57: aload_0
    //   58: monitorexit
    //   59: return
    //   60: astore #4
    //   62: getstatic com/facebook/ads/internal/d/a.a : Ljava/lang/String;
    //   65: ldc 'No permissions to set the default uncaught exception handler'
    //   67: aload #4
    //   69: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   72: pop
    //   73: goto -> 53
    //   76: astore #4
    //   78: aload_0
    //   79: monitorexit
    //   80: aload #4
    //   82: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	76	finally
    //   20	53	60	java/lang/SecurityException
    //   20	53	76	finally
    //   53	57	76	finally
    //   62	73	76	finally
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/internal/d/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */