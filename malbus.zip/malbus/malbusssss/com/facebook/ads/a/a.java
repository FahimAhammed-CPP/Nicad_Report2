package com.facebook.ads.a;

import android.view.View;
import com.facebook.ads.AdError;
import com.facebook.ads.internal.adapters.r;

public interface a {
  void a(r paramr);
  
  void a(r paramr, View paramView);
  
  void a(r paramr, AdError paramAdError);
  
  void b(r paramr);
  
  void c(r paramr);
  
  void d(r paramr);
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */