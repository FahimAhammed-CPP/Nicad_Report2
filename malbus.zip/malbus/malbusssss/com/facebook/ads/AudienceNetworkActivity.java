package com.facebook.ads;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.facebook.ads.internal.a.a;
import com.facebook.ads.internal.a.b;
import com.facebook.ads.internal.adapters.j;
import com.facebook.ads.internal.adapters.k;
import com.facebook.ads.internal.g;
import com.facebook.ads.internal.g.q;
import com.facebook.ads.internal.j;
import com.facebook.ads.internal.util.c;
import com.facebook.ads.internal.util.d;
import com.facebook.ads.internal.util.i;
import com.facebook.ads.internal.util.y;
import com.facebook.ads.internal.util.z;
import com.facebook.ads.internal.view.c;
import com.facebook.ads.internal.view.d;
import com.facebook.ads.internal.view.f;
import com.facebook.ads.internal.view.h;
import com.facebook.ads.internal.view.k;
import com.facebook.ads.internal.view.q;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public class AudienceNetworkActivity extends Activity {
  public static final String AUDIENCE_NETWORK_UNIQUE_ID_EXTRA = "uniqueId";
  
  public static final String AUTOPLAY = "autoplay";
  
  public static final String BROWSER_URL = "browserURL";
  
  public static final String CLIENT_TOKEN = "clientToken";
  
  public static final String CLOSE_REPORT_URL = "closeReportURL";
  
  public static final String CONTEXT_SWITCH_BEHAVIOR = "contextSwitchBehavior";
  
  public static final String END_CARD_ACTIVATION_COMMAND = "facebookRewardedVideoEndCardActivationCommand";
  
  public static final String END_CARD_MARKUP = "facebookRewardedVideoEndCardMarkup";
  
  public static final String HANDLER_TIME = "handlerTime";
  
  public static final String IMPRESSION_REPORT_URL = "impressionReportURL";
  
  public static final String PREDEFINED_ORIENTATION_KEY = "predefinedOrientationKey";
  
  public static final String REWARD_SERVER_URL = "rewardServerURL";
  
  public static final String SKIP_DELAY_SECONDS_KEY = "skipAfterSeconds";
  
  public static final String VIDEO_LOGGER = "videoLogger";
  
  public static final String VIDEO_MPD = "videoMPD";
  
  public static final String VIDEO_PLAY_REPORT_URL = "videoPlayReportURL";
  
  public static final String VIDEO_REPORT_URL = "videoReportURL";
  
  public static final String VIDEO_SEEK_TIME = "videoSeekTime";
  
  public static final String VIDEO_TIME_REPORT_URL = "videoTimeReportURL";
  
  public static final String VIDEO_URL = "videoURL";
  
  public static final String VIEW_TYPE = "viewType";
  
  public static final String WEBVIEW_ENCODING = "utf-8";
  
  public static final String WEBVIEW_MIME_TYPE = "text/html";
  
  private static final String a = AudienceNetworkActivity.class.getSimpleName();
  
  private String b;
  
  private String c;
  
  private c d;
  
  private boolean e = false;
  
  private RelativeLayout f;
  
  private Intent g;
  
  private g h;
  
  private int i = -1;
  
  private String j;
  
  private Type k;
  
  private long l;
  
  private long m;
  
  private int n;
  
  private d o;
  
  private List<BackButtonInterceptor> p = new ArrayList<BackButtonInterceptor>();
  
  private void a(Intent paramIntent, Bundle paramBundle) {
    if (paramBundle != null) {
      this.i = paramBundle.getInt("predefinedOrientationKey", -1);
      this.j = paramBundle.getString("uniqueId");
      this.k = (Type)paramBundle.getSerializable("viewType");
      return;
    } 
    this.i = paramIntent.getIntExtra("predefinedOrientationKey", -1);
    this.j = paramIntent.getStringExtra("uniqueId");
    this.k = (Type)paramIntent.getSerializableExtra("viewType");
    this.n = paramIntent.getIntExtra("skipAfterSeconds", 0) * 1000;
  }
  
  private void a(String paramString) {
    Intent intent = new Intent(paramString + ":" + this.j);
    LocalBroadcastManager.getInstance((Context)this).sendBroadcast(intent);
  }
  
  private void a(String paramString, q paramq) {
    Intent intent = new Intent(paramString + ":" + this.j);
    intent.putExtra("event", (Serializable)paramq);
    LocalBroadcastManager.getInstance((Context)this).sendBroadcast(intent);
  }
  
  private void b() {
    String str = this.g.getStringExtra("rewardServerURL");
    if (!TextUtils.isEmpty(str)) {
      AsyncTask asyncTask = (new y(new HashMap<Object, Object>())).execute((Object[])new String[] { str });
      try {
        z z = (z)asyncTask.get();
        if (z != null && z.a()) {
          a(j.h.a());
          return;
        } 
        a(j.i.a());
        return;
      } catch (InterruptedException interruptedException) {
      
      } catch (ExecutionException executionException) {}
    } else {
      return;
    } 
    a(j.i.a());
  }
  
  private void c() {
    this.d = new c((Context)this, new c.b(this) {
          public void a() {
            if (AudienceNetworkActivity.g(this.a) != null && !TextUtils.isEmpty(AudienceNetworkActivity.h(this.a)))
              AudienceNetworkActivity.g(this.a).post(new Runnable(this) {
                    public void run() {
                      if (AudienceNetworkActivity.g(this.a.a).c()) {
                        Log.w(AudienceNetworkActivity.a(), "Webview already destroyed, cannot activate");
                        return;
                      } 
                      AudienceNetworkActivity.g(this.a.a).loadUrl("javascript:" + AudienceNetworkActivity.h(this.a.a));
                    }
                  }); 
          }
          
          public void a(int param1Int) {}
          
          public void a(String param1String, Map<String, String> param1Map) {
            Uri uri = Uri.parse(param1String);
            if ("fbad".equals(uri.getScheme()) && uri.getAuthority().equals("close")) {
              this.a.finish();
              return;
            } 
            if ("fbad".equals(uri.getScheme()) && b.a(uri.getAuthority()))
              AudienceNetworkActivity.a(this.a, j.e.a()); 
            a a = b.a((Context)this.a, AudienceNetworkActivity.f(this.a), uri, param1Map);
            if (a != null)
              try {
                a.b();
              } catch (Exception exception) {
                Log.e(AudienceNetworkActivity.a(), "Error executing action", exception);
              }  
          }
          
          public void b() {}
        }1);
    String str = this.g.getStringExtra("facebookRewardedVideoEndCardMarkup");
    this.c = this.g.getStringExtra("facebookRewardedVideoEndCardActivationCommand");
    this.d.loadDataWithBaseURL(i.a(), str, "text/html", "utf-8", null);
  }
  
  private void d() {
    if (this.d != null) {
      this.f.removeAllViews();
      this.o = null;
      setContentView((View)this.d);
    } 
  }
  
  public void addBackButtonInterceptor(BackButtonInterceptor paramBackButtonInterceptor) {
    this.p.add(paramBackButtonInterceptor);
  }
  
  public void onBackPressed() {
    long l = System.currentTimeMillis();
    this.m += l - this.l;
    this.l = l;
    if (this.m > this.n) {
      Iterator<BackButtonInterceptor> iterator = this.p.iterator();
      boolean bool = false;
      while (iterator.hasNext()) {
        if (((BackButtonInterceptor)iterator.next()).interceptBackButton())
          bool = true; 
      } 
      if (!bool)
        super.onBackPressed(); 
    } 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    if (this.o instanceof k)
      ((k)this.o).a(paramConfiguration); 
    super.onConfigurationChanged(paramConfiguration);
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    requestWindowFeature(1);
    getWindow().setFlags(1024, 1024);
    this.f = new RelativeLayout((Context)this);
    this.f.setBackgroundColor(-16777216);
    setContentView((View)this.f, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
    this.g = getIntent();
    if (this.g.getBooleanExtra("useNativeCloseButton", false)) {
      this.h = new g((Context)this);
      this.h.setId(100002);
      this.h.setOnClickListener(new View.OnClickListener(this) {
            public void onClick(View param1View) {
              this.a.finish();
            }
          });
    } 
    this.b = this.g.getStringExtra("clientToken");
    a(this.g, paramBundle);
    if (this.k == Type.VIDEO) {
      q q = new q(this, new d.a(this) {
            public void a(View param1View) {
              AudienceNetworkActivity.a(this.a).addView(param1View);
              if (AudienceNetworkActivity.b(this.a) != null)
                AudienceNetworkActivity.a(this.a).addView((View)AudienceNetworkActivity.b(this.a)); 
            }
            
            public void a(String param1String) {
              AudienceNetworkActivity.a(this.a, param1String);
            }
            
            public void a(String param1String, q param1q) {
              AudienceNetworkActivity.a(this.a, param1String, param1q);
            }
          });
      q.a((View)this.f);
      this.o = (d)q;
    } else if (this.k == Type.REWARDED_VIDEO) {
      c();
      this.o = (d)new k((Context)this, new d.a(this) {
            public void a(View param1View) {
              AudienceNetworkActivity.a(this.a).addView(param1View);
            }
            
            public void a(String param1String) {
              AudienceNetworkActivity.a(this.a, param1String);
              if (param1String.equals(j.c))
                this.a.finish(); 
            }
            
            public void a(String param1String, q param1q) {
              AudienceNetworkActivity.a(this.a, param1String);
              if (param1String.startsWith(j.a.a())) {
                AudienceNetworkActivity.c(this.a);
                if (!param1String.equals(j.b.a()))
                  AudienceNetworkActivity.d(this.a); 
                AudienceNetworkActivity.a(this.a, true);
              } 
            }
          });
      addBackButtonInterceptor(new BackButtonInterceptor(this) {
            public boolean interceptBackButton() {
              return !AudienceNetworkActivity.e(this.a);
            }
          });
    } else if (this.k == Type.DISPLAY) {
      this.o = (d)new h(this, new d.a(this) {
            public void a(View param1View) {
              AudienceNetworkActivity.a(this.a).addView(param1View);
              if (AudienceNetworkActivity.b(this.a) != null)
                AudienceNetworkActivity.a(this.a).addView((View)AudienceNetworkActivity.b(this.a)); 
            }
            
            public void a(String param1String) {
              AudienceNetworkActivity.a(this.a, param1String);
            }
            
            public void a(String param1String, q param1q) {
              AudienceNetworkActivity.a(this.a, param1String, param1q);
            }
          });
    } else if (this.k == Type.BROWSER) {
      this.o = (d)new f(this, new d.a(this) {
            public void a(View param1View) {
              AudienceNetworkActivity.a(this.a).addView(param1View);
              if (AudienceNetworkActivity.b(this.a) != null)
                AudienceNetworkActivity.a(this.a).addView((View)AudienceNetworkActivity.b(this.a)); 
            }
            
            public void a(String param1String) {
              AudienceNetworkActivity.a(this.a, param1String);
            }
            
            public void a(String param1String, q param1q) {
              AudienceNetworkActivity.a(this.a, param1String, param1q);
            }
          });
    } else if (this.k == Type.NATIVE) {
      this.o = j.a(this.g.getStringExtra("uniqueId"));
      if (this.o == null) {
        d.a(c.a(null, "Unable to find view"));
        a("com.facebook.ads.interstitial.error");
        finish();
        return;
      } 
      this.o.a(new d.a(this) {
            public void a(View param1View) {
              AudienceNetworkActivity.a(this.a).removeAllViews();
              AudienceNetworkActivity.a(this.a).addView(param1View);
            }
            
            public void a(String param1String) {
              AudienceNetworkActivity.a(this.a, param1String);
            }
            
            public void a(String param1String, q param1q) {
              AudienceNetworkActivity.a(this.a, param1String, param1q);
            }
          });
    } else {
      d.a(c.a(null, "Unable to infer viewType from intent or savedInstanceState"));
      a("com.facebook.ads.interstitial.error");
      finish();
      return;
    } 
    this.o.a(this.g, paramBundle, this);
    a("com.facebook.ads.interstitial.displayed");
    this.l = System.currentTimeMillis();
  }
  
  protected void onDestroy() {
    if (this.o != null) {
      this.o.g();
      this.o = null;
    } 
    this.f.removeAllViews();
    if (this.k == Type.REWARDED_VIDEO) {
      a(j.g.a());
    } else {
      a("com.facebook.ads.interstitial.dismissed");
    } 
    super.onDestroy();
  }
  
  public void onPause() {
    this.m += System.currentTimeMillis() - this.l;
    if (this.o != null && !this.e)
      this.o.e(); 
    super.onPause();
  }
  
  public void onResume() {
    super.onResume();
    this.l = System.currentTimeMillis();
    if (this.o != null)
      this.o.f(); 
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    if (this.o != null)
      this.o.a(paramBundle); 
    paramBundle.putInt("predefinedOrientationKey", this.i);
    paramBundle.putString("uniqueId", this.j);
    paramBundle.putSerializable("viewType", this.k);
  }
  
  public void onStart() {
    super.onStart();
    if (this.i != -1)
      setRequestedOrientation(this.i); 
  }
  
  public void removeBackButtonInterceptor(BackButtonInterceptor paramBackButtonInterceptor) {
    this.p.remove(paramBackButtonInterceptor);
  }
  
  public static interface BackButtonInterceptor {
    boolean interceptBackButton();
  }
  
  public enum Type {
    BROWSER, DISPLAY, NATIVE, REWARDED_VIDEO, VIDEO;
    
    static {
      NATIVE = new Type("NATIVE", 3);
      BROWSER = new Type("BROWSER", 4);
      a = new Type[] { DISPLAY, VIDEO, REWARDED_VIDEO, NATIVE, BROWSER };
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/AudienceNetworkActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */