package com.facebook.ads;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.facebook.ads.a.a;
import com.facebook.ads.internal.DisplayAdController;
import com.facebook.ads.internal.a;
import com.facebook.ads.internal.adapters.AdAdapter;
import com.facebook.ads.internal.adapters.i;
import com.facebook.ads.internal.adapters.r;
import com.facebook.ads.internal.b;
import com.facebook.ads.internal.c;
import com.facebook.ads.internal.e;
import com.facebook.ads.internal.g.f;
import com.facebook.ads.internal.g.g;
import com.facebook.ads.internal.server.AdPlacementType;
import com.facebook.ads.internal.util.ae;

public class InstreamVideoAdView extends RelativeLayout implements Ad, ae<Bundle> {
  private final String a;
  
  private final AdSize b;
  
  private DisplayAdController c;
  
  @Nullable
  private i d;
  
  private boolean e = false;
  
  @Nullable
  private InstreamVideoAdListener f;
  
  @Nullable
  private View g;
  
  @Nullable
  private Bundle h;
  
  public InstreamVideoAdView(Context paramContext, Bundle paramBundle) {
    this(paramContext, paramBundle.getString("placementID"), (AdSize)paramBundle.get("adSize"));
    this.h = paramBundle;
  }
  
  public InstreamVideoAdView(Context paramContext, String paramString, AdSize paramAdSize) {
    super(paramContext);
    this.a = paramString;
    this.b = paramAdSize;
    this.c = getController();
  }
  
  private final void a() {
    if (this.c != null) {
      this.c.d();
      this.c = null;
      this.c = getController();
      this.d = null;
      this.e = false;
      removeAllViews();
    } 
  }
  
  private DisplayAdController getController() {
    this.c = new DisplayAdController(getContext(), this.a, e.m, AdPlacementType.INSTREAM, this.b, c.a, 1, true);
    this.c.a(new a(this) {
          public void a() {
            if (InstreamVideoAdView.a(this.a) != null)
              InstreamVideoAdView.a(this.a).onAdClicked(this.a); 
          }
          
          public void a(View param1View) {
            if (param1View == null)
              throw new IllegalStateException("Cannot present null view"); 
            InstreamVideoAdView.a(this.a, param1View);
            this.a.removeAllViews();
            InstreamVideoAdView.c(this.a).setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
            this.a.addView(InstreamVideoAdView.c(this.a));
          }
          
          public void a(AdAdapter param1AdAdapter) {
            if (InstreamVideoAdView.b(this.a) != null) {
              InstreamVideoAdView.a(this.a, true);
              if (InstreamVideoAdView.a(this.a) != null)
                InstreamVideoAdView.a(this.a).onAdLoaded(this.a); 
            } 
          }
          
          public void a(b param1b) {
            if (InstreamVideoAdView.a(this.a) != null)
              InstreamVideoAdView.a(this.a).onError(this.a, param1b.b()); 
          }
          
          public void b() {}
          
          public void c() {
            if (InstreamVideoAdView.a(this.a) != null)
              InstreamVideoAdView.a(this.a).onAdVideoComplete(this.a); 
          }
        });
    return this.c;
  }
  
  public void destroy() {
    a();
  }
  
  public String getPlacementId() {
    return this.a;
  }
  
  public Bundle getSaveInstanceState() {
    r r;
    if (this.d != null) {
      i i1 = this.d;
    } else {
      r = (r)this.c.i();
    } 
    if (r == null)
      return null; 
    Bundle bundle2 = r.getSaveInstanceState();
    if (bundle2 == null)
      return null; 
    Bundle bundle1 = new Bundle();
    bundle1.putBundle("adapter", bundle2);
    bundle1.putString("placementID", this.a);
    bundle1.putSerializable("adSize", this.b);
    return bundle1;
  }
  
  public boolean isAdLoaded() {
    return this.e;
  }
  
  public void loadAd() {
    if (this.h != null) {
      this.d = new i();
      this.d.a(getContext(), new a(this) {
            public void a(r param1r) {
              InstreamVideoAdView.a(this.a, true);
              if (InstreamVideoAdView.a(this.a) != null)
                InstreamVideoAdView.a(this.a).onAdLoaded(this.a); 
            }
            
            public void a(r param1r, View param1View) {
              if (param1View == null)
                throw new IllegalStateException("Cannot present null view"); 
              InstreamVideoAdView.a(this.a, param1View);
              this.a.removeAllViews();
              InstreamVideoAdView.c(this.a).setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
              this.a.addView(InstreamVideoAdView.c(this.a));
            }
            
            public void a(r param1r, AdError param1AdError) {
              if (InstreamVideoAdView.a(this.a) != null)
                InstreamVideoAdView.a(this.a).onError(this.a, param1AdError); 
            }
            
            public void b(r param1r) {
              if (InstreamVideoAdView.a(this.a) != null)
                InstreamVideoAdView.a(this.a).onAdClicked(this.a); 
            }
            
            public void c(r param1r) {}
            
            public void d(r param1r) {
              if (InstreamVideoAdView.a(this.a) != null)
                InstreamVideoAdView.a(this.a).onAdVideoComplete(this.a); 
            }
          }(f)g.a(getContext()), this.h.getBundle("adapter"));
      return;
    } 
    this.c.b();
  }
  
  public void setAdListener(InstreamVideoAdListener paramInstreamVideoAdListener) {
    this.f = paramInstreamVideoAdListener;
  }
  
  public boolean show() {
    boolean bool = false;
    if (!this.e || (this.c == null && this.d == null)) {
      boolean bool1 = bool;
      if (this.f != null) {
        this.f.onError(this, AdError.INTERNAL_ERROR);
        bool1 = bool;
      } 
      return bool1;
    } 
    if (this.d != null) {
      this.d.d();
    } else {
      this.c.c();
    } 
    this.e = false;
    return true;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/InstreamVideoAdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */