package com.facebook.ads;

@Deprecated
public interface ImpressionListener {
  void onLoggingImpression(Ad paramAd);
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/ImpressionListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */