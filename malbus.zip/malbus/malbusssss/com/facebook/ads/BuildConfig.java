package com.facebook.ads;

public final class BuildConfig {
  public static final String APPLICATION_ID = "com.facebook.ads";
  
  public static final String BUILD_TYPE = "release";
  
  public static final boolean DEBUG = false;
  
  public static final String FLAVOR = "";
  
  public static final int VERSION_CODE = 16;
  
  public static final String VERSION_NAME = "4.19.0";
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/BuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */