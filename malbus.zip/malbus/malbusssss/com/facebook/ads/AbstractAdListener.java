package com.facebook.ads;

public abstract class AbstractAdListener implements AdListener, ImpressionListener, InterstitialAdListener {
  public void onAdClicked(Ad paramAd) {}
  
  public void onAdLoaded(Ad paramAd) {}
  
  public void onError(Ad paramAd, AdError paramAdError) {}
  
  public void onInterstitialDismissed(Ad paramAd) {}
  
  public void onInterstitialDisplayed(Ad paramAd) {}
  
  public void onLoggingImpression(Ad paramAd) {}
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/AbstractAdListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */