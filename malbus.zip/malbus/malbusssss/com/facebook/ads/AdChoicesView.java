package com.facebook.ads;

import android.content.Context;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Handler;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.facebook.ads.internal.util.h;

public class AdChoicesView extends RelativeLayout {
  private final Context a;
  
  private final NativeAd b;
  
  private final DisplayMetrics c;
  
  private boolean d = false;
  
  private TextView e;
  
  private String f;
  
  public AdChoicesView(Context paramContext, NativeAd paramNativeAd) {
    this(paramContext, paramNativeAd, false);
  }
  
  public AdChoicesView(Context paramContext, NativeAd paramNativeAd, boolean paramBoolean) {
    super(paramContext);
    this.a = paramContext;
    this.b = paramNativeAd;
    this.c = this.a.getResources().getDisplayMetrics();
    if (this.b.isAdLoaded() && !this.b.a().g()) {
      setVisibility(8);
      return;
    } 
    this.f = this.b.b();
    if (TextUtils.isEmpty(this.f))
      this.f = "AdChoices"; 
    NativeAd.Image image = this.b.getAdChoicesIcon();
    RelativeLayout.LayoutParams layoutParams1 = new RelativeLayout.LayoutParams(-2, -2);
    setOnTouchListener(new View.OnTouchListener(this, paramNativeAd) {
          public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
            if (param1MotionEvent.getAction() == 0) {
              if (AdChoicesView.a(this.b)) {
                if (!TextUtils.isEmpty(AdChoicesView.b(this.b).getAdChoicesLinkUrl()))
                  h.a(AdChoicesView.c(this.b), Uri.parse(AdChoicesView.b(this.b).getAdChoicesLinkUrl()), this.a.h()); 
              } else {
                AdChoicesView.d(this.b);
              } 
              return true;
            } 
            return false;
          }
        });
    this.e = new TextView(this.a);
    addView((View)this.e);
    RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
    if (paramBoolean && image != null) {
      layoutParams2.addRule(11, a(image).getId());
      layoutParams2.width = 0;
      layoutParams1.width = Math.round((image.getWidth() + 4) * this.c.density);
      layoutParams1.height = Math.round((image.getHeight() + 2) * this.c.density);
      this.d = false;
    } else {
      this.d = true;
    } 
    setLayoutParams((ViewGroup.LayoutParams)layoutParams1);
    layoutParams2.addRule(15, -1);
    this.e.setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
    this.e.setSingleLine();
    this.e.setText(this.f);
    this.e.setTextSize(10.0F);
    this.e.setTextColor(-4341303);
  }
  
  private ImageView a(NativeAd.Image paramImage) {
    ImageView imageView = new ImageView(this.a);
    addView((View)imageView);
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(Math.round(paramImage.getWidth() * this.c.density), Math.round(paramImage.getHeight() * this.c.density));
    layoutParams.addRule(9);
    layoutParams.addRule(15, -1);
    layoutParams.setMargins(Math.round(4.0F * this.c.density), Math.round(this.c.density * 2.0F), Math.round(this.c.density * 2.0F), Math.round(this.c.density * 2.0F));
    imageView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    NativeAd.downloadAndDisplayImage(paramImage, imageView);
    return imageView;
  }
  
  private void a() {
    Paint paint = new Paint();
    paint.setTextSize(this.e.getTextSize());
    int i = Math.round(paint.measureText(this.f) + 4.0F * this.c.density);
    int j = getWidth();
    i += j;
    this.d = true;
    Animation animation = new Animation(this, j, i) {
        protected void applyTransformation(float param1Float, Transformation param1Transformation) {
          int i = (int)(this.a + (this.b - this.a) * param1Float);
          (this.c.getLayoutParams()).width = i;
          this.c.requestLayout();
          (AdChoicesView.e(this.c).getLayoutParams()).width = i - this.a;
          AdChoicesView.e(this.c).requestLayout();
        }
        
        public boolean willChangeBounds() {
          return true;
        }
      };
    animation.setAnimationListener(new Animation.AnimationListener(this, i, j) {
          public void onAnimationEnd(Animation param1Animation) {
            (new Handler()).postDelayed(new Runnable(this) {
                  public void run() {
                    if (AdChoicesView.a(this.a.c)) {
                      AdChoicesView.a(this.a.c, false);
                      Animation animation = new Animation(this) {
                          protected void applyTransformation(float param3Float, Transformation param3Transformation) {
                            int i = (int)(this.a.a.a + (this.a.a.b - this.a.a.a) * param3Float);
                            (this.a.a.c.getLayoutParams()).width = i;
                            this.a.a.c.requestLayout();
                            (AdChoicesView.e(this.a.a.c).getLayoutParams()).width = i - this.a.a.b;
                            AdChoicesView.e(this.a.a.c).requestLayout();
                          }
                          
                          public boolean willChangeBounds() {
                            return true;
                          }
                        };
                      animation.setDuration(300L);
                      animation.setFillAfter(true);
                      this.a.c.startAnimation(animation);
                    } 
                  }
                }3000L);
          }
          
          public void onAnimationRepeat(Animation param1Animation) {}
          
          public void onAnimationStart(Animation param1Animation) {}
        });
    animation.setDuration(300L);
    animation.setFillAfter(true);
    startAnimation(animation);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/AdChoicesView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */