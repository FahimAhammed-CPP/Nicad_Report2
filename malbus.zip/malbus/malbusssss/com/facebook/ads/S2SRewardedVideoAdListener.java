package com.facebook.ads;

public interface S2SRewardedVideoAdListener extends RewardedVideoAdListener {
  void onRewardServerFailed();
  
  void onRewardServerSuccess();
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/S2SRewardedVideoAdListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */