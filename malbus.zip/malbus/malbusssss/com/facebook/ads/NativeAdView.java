package com.facebook.ads;

import android.content.Context;
import android.view.View;
import com.facebook.ads.internal.view.a;

public class NativeAdView {
  public static View render(Context paramContext, NativeAd paramNativeAd, Type paramType) {
    return render(paramContext, paramNativeAd, paramType, null);
  }
  
  public static View render(Context paramContext, NativeAd paramNativeAd, Type paramType, NativeAdViewAttributes paramNativeAdViewAttributes) {
    if (paramNativeAd.isNativeConfigEnabled()) {
      NativeAdViewAttributes nativeAdViewAttributes1 = paramNativeAd.getAdViewAttributes();
      paramNativeAd.a(paramType);
      return (View)new a(paramContext, paramNativeAd, paramType, nativeAdViewAttributes1);
    } 
    NativeAdViewAttributes nativeAdViewAttributes = paramNativeAdViewAttributes;
    if (paramNativeAdViewAttributes == null)
      nativeAdViewAttributes = new NativeAdViewAttributes(); 
    paramNativeAd.a(paramType);
    return (View)new a(paramContext, paramNativeAd, paramType, nativeAdViewAttributes);
  }
  
  public enum Type {
    HEIGHT_100(-1, 100),
    HEIGHT_120(-1, 120),
    HEIGHT_300(-1, 300),
    HEIGHT_400(-1, 400);
    
    private final int a;
    
    private final int b;
    
    Type(int param1Int1, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Int2;
    }
    
    public int getHeight() {
      return this.b;
    }
    
    public int getValue() {
      switch (this.b) {
        default:
          return -1;
        case 100:
          return 1;
        case 120:
          return 2;
        case 300:
          return 3;
        case 400:
          break;
      } 
      return 4;
    }
    
    public int getWidth() {
      return this.a;
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/NativeAdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */