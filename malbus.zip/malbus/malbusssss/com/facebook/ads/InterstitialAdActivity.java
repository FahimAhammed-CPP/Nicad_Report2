package com.facebook.ads;

@Deprecated
public class InterstitialAdActivity extends AudienceNetworkActivity {}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/InterstitialAdActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */