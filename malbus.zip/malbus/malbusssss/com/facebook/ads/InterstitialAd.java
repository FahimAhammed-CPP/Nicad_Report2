package com.facebook.ads;

import android.content.Context;
import android.view.View;
import com.facebook.ads.internal.DisplayAdController;
import com.facebook.ads.internal.a;
import com.facebook.ads.internal.adapters.AdAdapter;
import com.facebook.ads.internal.b;
import com.facebook.ads.internal.c;
import com.facebook.ads.internal.e;
import com.facebook.ads.internal.server.AdPlacementType;
import com.facebook.ads.internal.util.h;

public class InterstitialAd implements Ad {
  private static final c a = c.a;
  
  private final Context b;
  
  private final String c;
  
  private DisplayAdController d;
  
  private boolean e;
  
  private boolean f;
  
  private InterstitialAdListener g;
  
  private ImpressionListener h;
  
  public InterstitialAd(Context paramContext, String paramString) {
    this.b = paramContext;
    this.c = paramString;
  }
  
  public void destroy() {
    if (this.d != null) {
      this.d.d();
      this.d = null;
    } 
  }
  
  public String getPlacementId() {
    return this.c;
  }
  
  public boolean isAdLoaded() {
    return this.e;
  }
  
  public void loadAd() {
    this.e = false;
    if (this.f)
      throw new IllegalStateException("InterstitialAd cannot be loaded while being displayed. Make sure your adapter calls adapterListener.onInterstitialDismissed()."); 
    if (this.d != null) {
      this.d.d();
      this.d = null;
    } 
    AdSize adSize = AdSize.INTERSTITIAL;
    e e = h.a(AdSize.INTERSTITIAL);
    this.d = new DisplayAdController(this.b, this.c, e, AdPlacementType.INTERSTITIAL, adSize, a, 1, true);
    this.d.a(new a(this) {
          public void a() {
            if (InterstitialAd.a(this.a) != null)
              InterstitialAd.a(this.a).onAdClicked(this.a); 
          }
          
          public void a(View param1View) {}
          
          public void a(AdAdapter param1AdAdapter) {
            InterstitialAd.a(this.a, true);
            if (InterstitialAd.a(this.a) != null)
              InterstitialAd.a(this.a).onAdLoaded(this.a); 
          }
          
          public void a(b param1b) {
            if (InterstitialAd.a(this.a) != null)
              InterstitialAd.a(this.a).onError(this.a, param1b.b()); 
          }
          
          public void b() {
            if (InterstitialAd.b(this.a) != null)
              InterstitialAd.b(this.a).onLoggingImpression(this.a); 
            if (InterstitialAd.a(this.a) instanceof ImpressionListener && InterstitialAd.a(this.a) != InterstitialAd.b(this.a))
              ((ImpressionListener)InterstitialAd.a(this.a)).onLoggingImpression(this.a); 
          }
          
          public void d() {
            if (InterstitialAd.a(this.a) != null)
              InterstitialAd.a(this.a).onInterstitialDisplayed(this.a); 
          }
          
          public void e() {
            InterstitialAd.b(this.a, false);
            if (InterstitialAd.c(this.a) != null) {
              InterstitialAd.c(this.a).d();
              InterstitialAd.a(this.a, (DisplayAdController)null);
            } 
            if (InterstitialAd.a(this.a) != null)
              InterstitialAd.a(this.a).onInterstitialDismissed(this.a); 
          }
        });
    this.d.b();
  }
  
  public void setAdListener(InterstitialAdListener paramInterstitialAdListener) {
    this.g = paramInterstitialAdListener;
  }
  
  @Deprecated
  public void setImpressionListener(ImpressionListener paramImpressionListener) {
    this.h = paramImpressionListener;
  }
  
  public boolean show() {
    boolean bool = false;
    if (!this.e) {
      boolean bool1 = bool;
      if (this.g != null) {
        this.g.onError(this, AdError.INTERNAL_ERROR);
        bool1 = bool;
      } 
      return bool1;
    } 
    this.d.c();
    this.f = true;
    this.e = false;
    return true;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/InterstitialAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */