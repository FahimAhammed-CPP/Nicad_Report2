package com.facebook.ads;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import java.util.ArrayList;
import java.util.List;

public class NativeAdScrollView extends LinearLayout {
  public static final int DEFAULT_INSET = 20;
  
  public static final int DEFAULT_MAX_ADS = 10;
  
  private final Context a;
  
  private final NativeAdsManager b;
  
  private final AdViewProvider c;
  
  private final NativeAdView.Type d;
  
  private final int e;
  
  private final b f;
  
  private final NativeAdViewAttributes g;
  
  public NativeAdScrollView(Context paramContext, NativeAdsManager paramNativeAdsManager, AdViewProvider paramAdViewProvider) {
    this(paramContext, paramNativeAdsManager, paramAdViewProvider, null, null, 10);
  }
  
  public NativeAdScrollView(Context paramContext, NativeAdsManager paramNativeAdsManager, AdViewProvider paramAdViewProvider, int paramInt) {
    this(paramContext, paramNativeAdsManager, paramAdViewProvider, null, null, paramInt);
  }
  
  private NativeAdScrollView(Context paramContext, NativeAdsManager paramNativeAdsManager, AdViewProvider paramAdViewProvider, NativeAdView.Type paramType, NativeAdViewAttributes paramNativeAdViewAttributes, int paramInt) {
    super(paramContext);
    if (!paramNativeAdsManager.isLoaded())
      throw new IllegalStateException("NativeAdsManager not loaded"); 
    if (paramType == null && paramAdViewProvider == null)
      throw new IllegalArgumentException("Must provide a NativeAdView.Type or AdViewProvider"); 
    this.a = paramContext;
    this.b = paramNativeAdsManager;
    this.g = paramNativeAdViewAttributes;
    this.c = paramAdViewProvider;
    this.d = paramType;
    this.e = paramInt;
    a a = new a(this);
    this.f = new b(this, paramContext);
    this.f.setAdapter(a);
    setInset(20);
    a.a();
    addView((View)this.f);
  }
  
  public NativeAdScrollView(Context paramContext, NativeAdsManager paramNativeAdsManager, NativeAdView.Type paramType) {
    this(paramContext, paramNativeAdsManager, (AdViewProvider)null, paramType, new NativeAdViewAttributes(), 10);
  }
  
  public NativeAdScrollView(Context paramContext, NativeAdsManager paramNativeAdsManager, NativeAdView.Type paramType, NativeAdViewAttributes paramNativeAdViewAttributes) {
    this(paramContext, paramNativeAdsManager, (AdViewProvider)null, paramType, paramNativeAdViewAttributes, 10);
  }
  
  public NativeAdScrollView(Context paramContext, NativeAdsManager paramNativeAdsManager, NativeAdView.Type paramType, NativeAdViewAttributes paramNativeAdViewAttributes, int paramInt) {
    this(paramContext, paramNativeAdsManager, (AdViewProvider)null, paramType, paramNativeAdViewAttributes, paramInt);
  }
  
  public void setInset(int paramInt) {
    if (paramInt > 0) {
      DisplayMetrics displayMetrics = this.a.getResources().getDisplayMetrics();
      int i = Math.round(paramInt * displayMetrics.density);
      this.f.setPadding(i, 0, i, 0);
      b b1 = this.f;
      float f = (paramInt / 2);
      b1.setPageMargin(Math.round(displayMetrics.density * f));
      this.f.setClipToPadding(false);
    } 
  }
  
  public static interface AdViewProvider {
    View createView(NativeAd param1NativeAd, int param1Int);
    
    void destroyView(NativeAd param1NativeAd, View param1View);
  }
  
  private class a extends PagerAdapter {
    private List<NativeAd> b = new ArrayList<NativeAd>();
    
    public a(NativeAdScrollView this$0) {}
    
    public void a() {
      this.b.clear();
      int i = Math.min(NativeAdScrollView.a(this.a), NativeAdScrollView.b(this.a).getUniqueNativeAdCount());
      for (byte b = 0; b < i; b++) {
        NativeAd nativeAd = NativeAdScrollView.b(this.a).nextNativeAd();
        nativeAd.a(true);
        this.b.add(nativeAd);
      } 
      notifyDataSetChanged();
    }
    
    public void destroyItem(ViewGroup param1ViewGroup, int param1Int, Object param1Object) {
      if (param1Int < this.b.size())
        if (NativeAdScrollView.c(this.a) != null) {
          ((NativeAd)this.b.get(param1Int)).unregisterView();
        } else {
          NativeAdScrollView.f(this.a).destroyView(this.b.get(param1Int), (View)param1Object);
        }  
      param1ViewGroup.removeView((View)param1Object);
    }
    
    public int getCount() {
      return this.b.size();
    }
    
    public int getItemPosition(Object param1Object) {
      int i = this.b.indexOf(param1Object);
      if (i < 0)
        i = -2; 
      return i;
    }
    
    public Object instantiateItem(ViewGroup param1ViewGroup, int param1Int) {
      if (NativeAdScrollView.c(this.a) != null) {
        View view1 = NativeAdView.render(NativeAdScrollView.d(this.a), this.b.get(param1Int), NativeAdScrollView.c(this.a), NativeAdScrollView.e(this.a));
        param1ViewGroup.addView(view1);
        return view1;
      } 
      View view = NativeAdScrollView.f(this.a).createView(this.b.get(param1Int), param1Int);
      param1ViewGroup.addView(view);
      return view;
    }
    
    public boolean isViewFromObject(View param1View, Object param1Object) {
      return (param1View == param1Object);
    }
  }
  
  private class b extends ViewPager {
    public b(NativeAdScrollView this$0, Context param1Context) {
      super(param1Context);
    }
    
    protected void onMeasure(int param1Int1, int param1Int2) {
      byte b1 = 0;
      int i;
      for (i = 0; b1 < getChildCount(); i = param1Int2) {
        View view = getChildAt(b1);
        view.measure(param1Int1, View.MeasureSpec.makeMeasureSpec(0, 0));
        int j = view.getMeasuredHeight();
        param1Int2 = i;
        if (j > i)
          param1Int2 = j; 
        b1++;
      } 
      super.onMeasure(param1Int1, View.MeasureSpec.makeMeasureSpec(i, 1073741824));
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/NativeAdScrollView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */