package com.facebook.ads;

import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import android.webkit.CookieSyncManager;
import com.facebook.ads.internal.adapters.v;
import com.facebook.ads.internal.b;
import com.facebook.ads.internal.c;
import com.facebook.ads.internal.c.a;
import com.facebook.ads.internal.c.b;
import com.facebook.ads.internal.e;
import com.facebook.ads.internal.i;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

public class NativeAdsManager {
  private static final c a = c.a;
  
  private final Context b;
  
  private final String c;
  
  private final int d;
  
  private final List<NativeAd> e;
  
  private int f;
  
  private Listener g;
  
  private i h;
  
  private boolean i;
  
  private boolean j;
  
  public NativeAdsManager(Context paramContext, String paramString, int paramInt) {
    if (paramContext == null)
      throw new IllegalArgumentException("context can not be null"); 
    this.b = paramContext;
    this.c = paramString;
    this.d = Math.max(paramInt, 0);
    this.e = new ArrayList<NativeAd>(paramInt);
    this.f = -1;
    this.j = false;
    this.i = false;
    if (Build.VERSION.SDK_INT < 18)
      CookieSyncManager.createInstance(paramContext); 
  }
  
  public void disableAutoRefresh() {
    this.i = true;
    if (this.h != null)
      this.h.c(); 
  }
  
  public int getUniqueNativeAdCount() {
    return this.e.size();
  }
  
  public boolean isLoaded() {
    return this.j;
  }
  
  public void loadAds() {
    loadAds(EnumSet.of(NativeAd.MediaCacheFlag.NONE));
  }
  
  public void loadAds(EnumSet<NativeAd.MediaCacheFlag> paramEnumSet) {
    e e = e.j;
    int j = this.d;
    if (this.h != null)
      this.h.b(); 
    this.h = new i(this.b, this.c, e, null, a, j, paramEnumSet);
    if (this.i)
      this.h.c(); 
    this.h.a(new i.a(this, paramEnumSet) {
          public void a(b param1b) {
            if (NativeAdsManager.c(this.b) != null)
              NativeAdsManager.c(this.b).onAdError(param1b.b()); 
          }
          
          public void a(List<v> param1List) {
            b b = new b(NativeAdsManager.a(this.b));
            for (v v : param1List) {
              if (this.a.contains(NativeAd.MediaCacheFlag.ICON) && v.k() != null)
                b.a(v.k().getUrl()); 
              if (this.a.contains(NativeAd.MediaCacheFlag.IMAGE) && v.l() != null)
                b.a(v.l().getUrl()); 
              if (this.a.contains(NativeAd.MediaCacheFlag.VIDEO) && !TextUtils.isEmpty(v.w()))
                b.b(v.w()); 
            } 
            b.a(new a(this, param1List) {
                  public void a() {
                    NativeAdsManager.a(this.b.b, true);
                    NativeAdsManager.b(this.b.b).clear();
                    NativeAdsManager.a(this.b.b, 0);
                    for (v v : this.a)
                      NativeAdsManager.b(this.b.b).add(new NativeAd(NativeAdsManager.a(this.b.b), v, null)); 
                    if (NativeAdsManager.c(this.b.b) != null)
                      NativeAdsManager.c(this.b.b).onAdsLoaded(); 
                  }
                });
          }
        });
    this.h.a();
  }
  
  public NativeAd nextNativeAd() {
    if (this.e.size() == 0)
      return null; 
    int j = this.f;
    this.f = j + 1;
    NativeAd nativeAd2 = this.e.get(j % this.e.size());
    NativeAd nativeAd1 = nativeAd2;
    if (j >= this.e.size())
      nativeAd1 = new NativeAd(nativeAd2); 
    return nativeAd1;
  }
  
  public void setListener(Listener paramListener) {
    this.g = paramListener;
  }
  
  public static interface Listener {
    void onAdError(AdError param1AdError);
    
    void onAdsLoaded();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/NativeAdsManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */