package com.facebook.ads;

public enum AdNetwork {
  ADMOB, AN, FLURRY, INMOBI;
  
  static {
    ADMOB = new AdNetwork("ADMOB", 1);
    FLURRY = new AdNetwork("FLURRY", 2);
    INMOBI = new AdNetwork("INMOBI", 3);
    a = new AdNetwork[] { AN, ADMOB, FLURRY, INMOBI };
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/AdNetwork.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */