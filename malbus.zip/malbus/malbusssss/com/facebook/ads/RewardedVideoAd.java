package com.facebook.ads;

import android.content.Context;
import android.util.Log;
import com.facebook.ads.internal.DisplayAdController;
import com.facebook.ads.internal.a;
import com.facebook.ads.internal.adapters.AdAdapter;
import com.facebook.ads.internal.adapters.x;
import com.facebook.ads.internal.b;
import com.facebook.ads.internal.c;
import com.facebook.ads.internal.c.a;
import com.facebook.ads.internal.c.b;
import com.facebook.ads.internal.e;
import com.facebook.ads.internal.server.AdPlacementType;

public class RewardedVideoAd implements Ad {
  private static final String a = RewardedVideoAd.class.getSimpleName();
  
  private final Context b;
  
  private final String c;
  
  private DisplayAdController d;
  
  private boolean e = false;
  
  private RewardedVideoAdListener f;
  
  private b g;
  
  private RewardData h;
  
  public RewardedVideoAd(Context paramContext, String paramString) {
    this.b = paramContext;
    this.c = paramString;
    this.g = new b(paramContext);
  }
  
  private void a() {
    b();
    this.e = false;
    this.d = new DisplayAdController(this.b, this.c, e.k, AdPlacementType.REWARDED_VIDEO, AdSize.INTERSTITIAL, c.a, 1, true);
    this.d.a(new a(this) {
          public void a() {
            if (RewardedVideoAd.a(this.a) != null)
              RewardedVideoAd.a(this.a).onAdClicked(this.a); 
          }
          
          public void a(AdAdapter param1AdAdapter) {
            if (RewardedVideoAd.b(this.a) != null)
              ((x)param1AdAdapter).a(RewardedVideoAd.b(this.a)); 
            RewardedVideoAd.c(this.a).b(((x)param1AdAdapter).a());
            RewardedVideoAd.c(this.a).a(new a(this) {
                  public void a() {
                    RewardedVideoAd.a(this.a.a, true);
                    if (RewardedVideoAd.a(this.a.a) != null)
                      RewardedVideoAd.a(this.a.a).onAdLoaded(this.a.a); 
                  }
                });
          }
          
          public void a(b param1b) {
            if (RewardedVideoAd.a(this.a) != null)
              RewardedVideoAd.a(this.a).onError(this.a, param1b.b()); 
          }
          
          public void b() {
            if (RewardedVideoAd.a(this.a) != null)
              RewardedVideoAd.a(this.a).onLoggingImpression(this.a); 
          }
          
          public void f() {
            RewardedVideoAd.a(this.a).onRewardedVideoCompleted();
          }
          
          public void g() {
            if (RewardedVideoAd.a(this.a) != null)
              RewardedVideoAd.a(this.a).onRewardedVideoClosed(); 
          }
          
          public void h() {
            if (RewardedVideoAd.a(this.a) instanceof S2SRewardedVideoAdListener)
              ((S2SRewardedVideoAdListener)RewardedVideoAd.a(this.a)).onRewardServerFailed(); 
          }
          
          public void i() {
            if (RewardedVideoAd.a(this.a) instanceof S2SRewardedVideoAdListener)
              ((S2SRewardedVideoAdListener)RewardedVideoAd.a(this.a)).onRewardServerSuccess(); 
          }
        });
    this.d.b();
  }
  
  private final void b() {
    if (this.d != null) {
      this.d.d();
      this.d = null;
    } 
  }
  
  public void destroy() {
    b();
  }
  
  public String getPlacementId() {
    return this.c;
  }
  
  public boolean isAdLoaded() {
    return this.e;
  }
  
  public void loadAd() {
    try {
      a();
    } catch (Exception exception) {
      Log.e(a, "Error loading rewarded video ad", exception);
    } 
  }
  
  public void setAdListener(RewardedVideoAdListener paramRewardedVideoAdListener) {
    this.f = paramRewardedVideoAdListener;
  }
  
  public void setRewardData(RewardData paramRewardData) {
    this.h = paramRewardData;
  }
  
  public boolean show() {
    boolean bool = false;
    if (!this.e) {
      boolean bool1 = bool;
      if (this.f != null) {
        this.f.onError(this, AdError.INTERNAL_ERROR);
        bool1 = bool;
      } 
      return bool1;
    } 
    this.d.c();
    this.e = false;
    return true;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/RewardedVideoAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */