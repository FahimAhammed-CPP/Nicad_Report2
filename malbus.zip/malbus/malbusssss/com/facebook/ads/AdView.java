package com.facebook.ads;

import android.content.Context;
import android.content.res.Configuration;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.RelativeLayout;
import com.facebook.ads.internal.DisplayAdController;
import com.facebook.ads.internal.a;
import com.facebook.ads.internal.adapters.AdAdapter;
import com.facebook.ads.internal.b;
import com.facebook.ads.internal.c;
import com.facebook.ads.internal.server.AdPlacementType;
import com.facebook.ads.internal.util.h;

public class AdView extends RelativeLayout implements Ad {
  private static final c a = c.a;
  
  private final DisplayMetrics b;
  
  private final AdSize c;
  
  private final String d;
  
  private DisplayAdController e;
  
  private AdListener f;
  
  private ImpressionListener g;
  
  private View h;
  
  private volatile boolean i;
  
  public AdView(Context paramContext, String paramString, AdSize paramAdSize) {
    super(paramContext);
    if (paramAdSize == null || paramAdSize == AdSize.INTERSTITIAL)
      throw new IllegalArgumentException("adSize"); 
    this.b = getContext().getResources().getDisplayMetrics();
    this.c = paramAdSize;
    this.d = paramString;
    this.e = new DisplayAdController(paramContext, paramString, h.a(paramAdSize), AdPlacementType.BANNER, paramAdSize, a, 1, false);
    this.e.a(new a(this) {
          public void a() {
            if (AdView.a(this.a) != null)
              AdView.a(this.a).onAdClicked(this.a); 
          }
          
          public void a(View param1View) {
            if (param1View == null)
              throw new IllegalStateException("Cannot present null view"); 
            AdView.a(this.a, param1View);
            this.a.removeAllViews();
            this.a.addView(AdView.c(this.a));
            if (AdView.c(this.a) instanceof com.facebook.ads.internal.view.c)
              h.a(AdView.d(this.a), AdView.c(this.a), AdView.e(this.a)); 
            if (AdView.a(this.a) != null)
              AdView.a(this.a).onAdLoaded(this.a); 
          }
          
          public void a(AdAdapter param1AdAdapter) {
            if (AdView.b(this.a) != null)
              AdView.b(this.a).c(); 
          }
          
          public void a(b param1b) {
            if (AdView.a(this.a) != null)
              AdView.a(this.a).onError(this.a, param1b.b()); 
          }
          
          public void b() {
            if (AdView.f(this.a) != null)
              AdView.f(this.a).onLoggingImpression(this.a); 
            if (AdView.a(this.a) instanceof ImpressionListener && AdView.a(this.a) != AdView.f(this.a))
              ((ImpressionListener)AdView.a(this.a)).onLoggingImpression(this.a); 
          }
        });
  }
  
  public void destroy() {
    if (this.e != null) {
      this.e.d();
      this.e = null;
    } 
    removeAllViews();
    this.h = null;
  }
  
  public void disableAutoRefresh() {
    if (this.e != null)
      this.e.h(); 
  }
  
  public String getPlacementId() {
    return this.d;
  }
  
  public void loadAd() {
    if (!this.i) {
      this.e.b();
      this.i = true;
      return;
    } 
    if (this.e != null)
      this.e.g(); 
  }
  
  protected void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    if (this.h != null)
      h.a(this.b, this.h, this.c); 
  }
  
  protected void onWindowVisibilityChanged(int paramInt) {
    super.onWindowVisibilityChanged(paramInt);
    if (this.e != null) {
      if (paramInt == 0) {
        this.e.f();
        return;
      } 
      if (paramInt == 8)
        this.e.e(); 
    } 
  }
  
  public void setAdListener(AdListener paramAdListener) {
    this.f = paramAdListener;
  }
  
  @Deprecated
  public void setImpressionListener(ImpressionListener paramImpressionListener) {
    this.g = paramImpressionListener;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/AdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */