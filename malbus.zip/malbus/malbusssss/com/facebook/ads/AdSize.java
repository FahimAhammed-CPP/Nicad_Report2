package com.facebook.ads;

import java.io.Serializable;

public class AdSize implements Serializable {
  @Deprecated
  public static final AdSize BANNER_320_50 = new AdSize(320, 50);
  
  public static final AdSize BANNER_HEIGHT_50;
  
  public static final AdSize BANNER_HEIGHT_90;
  
  public static final AdSize INTERSTITIAL = new AdSize(0, 0);
  
  public static final AdSize RECTANGLE_HEIGHT_250;
  
  private final int a;
  
  private final int b;
  
  static {
    BANNER_HEIGHT_50 = new AdSize(-1, 50);
    BANNER_HEIGHT_90 = new AdSize(-1, 90);
    RECTANGLE_HEIGHT_250 = new AdSize(-1, 250);
  }
  
  public AdSize(int paramInt1, int paramInt2) {
    this.a = paramInt1;
    this.b = paramInt2;
  }
  
  public static AdSize fromWidthAndHeight(int paramInt1, int paramInt2) {
    return (INTERSTITIAL.b == paramInt2 && INTERSTITIAL.a == paramInt1) ? INTERSTITIAL : ((BANNER_320_50.b == paramInt2 && BANNER_320_50.a == paramInt1) ? BANNER_320_50 : ((BANNER_HEIGHT_50.b == paramInt2 && BANNER_HEIGHT_50.a == paramInt1) ? BANNER_HEIGHT_50 : ((BANNER_HEIGHT_90.b == paramInt2 && BANNER_HEIGHT_90.a == paramInt1) ? BANNER_HEIGHT_90 : ((RECTANGLE_HEIGHT_250.b == paramInt2 && RECTANGLE_HEIGHT_250.a == paramInt1) ? RECTANGLE_HEIGHT_250 : null))));
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = true;
    if (this != paramObject) {
      if (paramObject == null || getClass() != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      if (this.a != ((AdSize)paramObject).a)
        return false; 
      if (this.b != ((AdSize)paramObject).b)
        bool = false; 
    } 
    return bool;
  }
  
  public int getHeight() {
    return this.b;
  }
  
  public int getWidth() {
    return this.a;
  }
  
  public int hashCode() {
    return this.a * 31 + this.b;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/AdSize.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */