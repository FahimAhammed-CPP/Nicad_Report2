package com.facebook.ads;

import android.graphics.Color;
import android.graphics.Typeface;
import com.facebook.ads.internal.util.c;
import com.facebook.ads.internal.util.d;
import org.json.JSONObject;

public class NativeAdViewAttributes {
  private Typeface a = Typeface.DEFAULT;
  
  private int b = -1;
  
  private int c = -16777216;
  
  private int d = -11643291;
  
  private int e = 0;
  
  private int f = -12420889;
  
  private int g = -12420889;
  
  private boolean h = AdSettings.isVideoAutoplay();
  
  private boolean i = AdSettings.isVideoAutoplayOnMobile();
  
  public NativeAdViewAttributes() {}
  
  public NativeAdViewAttributes(JSONObject paramJSONObject) {
    try {
      int j;
      int n;
      if (paramJSONObject.getBoolean("background_transparent")) {
        j = 0;
      } else {
        j = Color.parseColor(paramJSONObject.getString("background_color"));
      } 
      int k = Color.parseColor(paramJSONObject.getString("title_text_color"));
      int m = Color.parseColor(paramJSONObject.getString("description_text_color"));
      if (paramJSONObject.getBoolean("button_transparent")) {
        n = 0;
      } else {
        n = Color.parseColor(paramJSONObject.getString("button_color"));
      } 
      if (!paramJSONObject.getBoolean("button_border_transparent"))
        i = Color.parseColor(paramJSONObject.getString("button_border_color")); 
      int i1 = Color.parseColor(paramJSONObject.getString("button_text_color"));
      Typeface typeface = Typeface.create(paramJSONObject.getString("android_typeface"), 0);
      this.b = j;
      this.c = k;
      this.d = m;
      this.e = n;
      this.g = i;
      this.f = i1;
      this.a = typeface;
    } catch (Exception exception) {
      d.a(c.a(exception, "Error retrieving native ui configuration data"));
    } 
  }
  
  public boolean getAutoplay() {
    return this.h;
  }
  
  public boolean getAutoplayOnMobile() {
    return AdSettings.isVideoAutoplayOnMobile();
  }
  
  public int getBackgroundColor() {
    return this.b;
  }
  
  public int getButtonBorderColor() {
    return this.g;
  }
  
  public int getButtonColor() {
    return this.e;
  }
  
  public int getButtonTextColor() {
    return this.f;
  }
  
  public int getDescriptionTextColor() {
    return this.d;
  }
  
  public int getDescriptionTextSize() {
    return 10;
  }
  
  public int getTitleTextColor() {
    return this.c;
  }
  
  public int getTitleTextSize() {
    return 16;
  }
  
  public Typeface getTypeface() {
    return this.a;
  }
  
  public NativeAdViewAttributes setAutoplay(boolean paramBoolean) {
    this.h = paramBoolean;
    return this;
  }
  
  public NativeAdViewAttributes setAutoplayOnMobile(boolean paramBoolean) {
    this.i = paramBoolean;
    return this;
  }
  
  public NativeAdViewAttributes setBackgroundColor(int paramInt) {
    this.b = paramInt;
    return this;
  }
  
  public NativeAdViewAttributes setButtonBorderColor(int paramInt) {
    this.g = paramInt;
    return this;
  }
  
  public NativeAdViewAttributes setButtonColor(int paramInt) {
    this.e = paramInt;
    return this;
  }
  
  public NativeAdViewAttributes setButtonTextColor(int paramInt) {
    this.f = paramInt;
    return this;
  }
  
  public NativeAdViewAttributes setDescriptionTextColor(int paramInt) {
    this.d = paramInt;
    return this;
  }
  
  public NativeAdViewAttributes setTitleTextColor(int paramInt) {
    this.c = paramInt;
    return this;
  }
  
  public NativeAdViewAttributes setTypeface(Typeface paramTypeface) {
    this.a = paramTypeface;
    return this;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/NativeAdViewAttributes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */