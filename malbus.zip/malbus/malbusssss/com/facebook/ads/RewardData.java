package com.facebook.ads;

public class RewardData {
  private String a;
  
  private String b;
  
  public RewardData(String paramString1, String paramString2) {
    this.a = paramString1;
    this.b = paramString2;
  }
  
  public String getCurrency() {
    return this.b;
  }
  
  public String getUserID() {
    return this.a;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/facebook/ads/RewardData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */