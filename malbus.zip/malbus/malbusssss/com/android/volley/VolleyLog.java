package com.android.volley;

import android.util.Log;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class VolleyLog {
  public static boolean DEBUG;
  
  public static String TAG = "Volley";
  
  static {
    DEBUG = Log.isLoggable(TAG, 2);
  }
  
  private static String buildMessage(String paramString, Object... paramVarArgs) {
    if (paramVarArgs != null)
      paramString = String.format(Locale.US, paramString, paramVarArgs); 
    StackTraceElement[] arrayOfStackTraceElement = (new Throwable()).fillInStackTrace().getStackTrace();
    String str = "<unknown>";
    for (byte b = 2;; b++) {
      String str1 = str;
      if (b < arrayOfStackTraceElement.length) {
        if (!arrayOfStackTraceElement[b].getClass().equals(VolleyLog.class)) {
          str1 = arrayOfStackTraceElement[b].getClassName();
          str1 = str1.substring(str1.lastIndexOf('.') + 1);
          str1 = str1.substring(str1.lastIndexOf('$') + 1);
          str1 = str1 + "." + arrayOfStackTraceElement[b].getMethodName();
          return String.format(Locale.US, "[%d] %s: %s", new Object[] { Long.valueOf(Thread.currentThread().getId()), str1, paramString });
        } 
      } else {
        return String.format(Locale.US, "[%d] %s: %s", new Object[] { Long.valueOf(Thread.currentThread().getId()), str1, paramString });
      } 
    } 
  }
  
  public static void d(String paramString, Object... paramVarArgs) {
    Log.d(TAG, buildMessage(paramString, paramVarArgs));
  }
  
  public static void e(String paramString, Object... paramVarArgs) {
    Log.e(TAG, buildMessage(paramString, paramVarArgs));
  }
  
  public static void e(Throwable paramThrowable, String paramString, Object... paramVarArgs) {
    Log.e(TAG, buildMessage(paramString, paramVarArgs), paramThrowable);
  }
  
  public static void setTag(String paramString) {
    d("Changing log tag to %s", new Object[] { paramString });
    TAG = paramString;
    DEBUG = Log.isLoggable(TAG, 2);
  }
  
  public static void v(String paramString, Object... paramVarArgs) {
    if (DEBUG)
      Log.v(TAG, buildMessage(paramString, paramVarArgs)); 
  }
  
  public static void wtf(String paramString, Object... paramVarArgs) {
    Log.wtf(TAG, buildMessage(paramString, paramVarArgs));
  }
  
  public static void wtf(Throwable paramThrowable, String paramString, Object... paramVarArgs) {
    Log.wtf(TAG, buildMessage(paramString, paramVarArgs), paramThrowable);
  }
  
  static class MarkerLog {
    public static final boolean ENABLED = VolleyLog.DEBUG;
    
    private static final long MIN_DURATION_FOR_LOGGING_MS = 0L;
    
    private boolean mFinished = false;
    
    private final List<Marker> mMarkers = new ArrayList<Marker>();
    
    private long getTotalDuration() {
      if (this.mMarkers.size() == 0)
        return 0L; 
      null = ((Marker)this.mMarkers.get(0)).time;
      return ((Marker)this.mMarkers.get(this.mMarkers.size() - 1)).time - null;
    }
    
    public void add(String param1String, long param1Long) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield mFinished : Z
      //   6: ifeq -> 26
      //   9: new java/lang/IllegalStateException
      //   12: astore_1
      //   13: aload_1
      //   14: ldc 'Marker added to finished log'
      //   16: invokespecial <init> : (Ljava/lang/String;)V
      //   19: aload_1
      //   20: athrow
      //   21: astore_1
      //   22: aload_0
      //   23: monitorexit
      //   24: aload_1
      //   25: athrow
      //   26: aload_0
      //   27: getfield mMarkers : Ljava/util/List;
      //   30: astore #4
      //   32: new com/android/volley/VolleyLog$MarkerLog$Marker
      //   35: astore #5
      //   37: aload #5
      //   39: aload_1
      //   40: lload_2
      //   41: invokestatic elapsedRealtime : ()J
      //   44: invokespecial <init> : (Ljava/lang/String;JJ)V
      //   47: aload #4
      //   49: aload #5
      //   51: invokeinterface add : (Ljava/lang/Object;)Z
      //   56: pop
      //   57: aload_0
      //   58: monitorexit
      //   59: return
      // Exception table:
      //   from	to	target	type
      //   2	21	21	finally
      //   26	57	21	finally
    }
    
    protected void finalize() throws Throwable {
      if (!this.mFinished) {
        finish("Request on the loose");
        VolleyLog.e("Marker log finalized without finish() - uncaught exit point for request", new Object[0]);
      } 
    }
    
    public void finish(String param1String) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: iconst_1
      //   4: putfield mFinished : Z
      //   7: aload_0
      //   8: invokespecial getTotalDuration : ()J
      //   11: lstore_2
      //   12: lload_2
      //   13: lconst_0
      //   14: lcmp
      //   15: ifgt -> 21
      //   18: aload_0
      //   19: monitorexit
      //   20: return
      //   21: aload_0
      //   22: getfield mMarkers : Ljava/util/List;
      //   25: iconst_0
      //   26: invokeinterface get : (I)Ljava/lang/Object;
      //   31: checkcast com/android/volley/VolleyLog$MarkerLog$Marker
      //   34: getfield time : J
      //   37: lstore #4
      //   39: ldc '(%-4d ms) %s'
      //   41: iconst_2
      //   42: anewarray java/lang/Object
      //   45: dup
      //   46: iconst_0
      //   47: lload_2
      //   48: invokestatic valueOf : (J)Ljava/lang/Long;
      //   51: aastore
      //   52: dup
      //   53: iconst_1
      //   54: aload_1
      //   55: aastore
      //   56: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
      //   59: aload_0
      //   60: getfield mMarkers : Ljava/util/List;
      //   63: invokeinterface iterator : ()Ljava/util/Iterator;
      //   68: astore_1
      //   69: aload_1
      //   70: invokeinterface hasNext : ()Z
      //   75: ifeq -> 18
      //   78: aload_1
      //   79: invokeinterface next : ()Ljava/lang/Object;
      //   84: checkcast com/android/volley/VolleyLog$MarkerLog$Marker
      //   87: astore #6
      //   89: aload #6
      //   91: getfield time : J
      //   94: lstore_2
      //   95: ldc '(+%-4d) [%2d] %s'
      //   97: iconst_3
      //   98: anewarray java/lang/Object
      //   101: dup
      //   102: iconst_0
      //   103: lload_2
      //   104: lload #4
      //   106: lsub
      //   107: invokestatic valueOf : (J)Ljava/lang/Long;
      //   110: aastore
      //   111: dup
      //   112: iconst_1
      //   113: aload #6
      //   115: getfield thread : J
      //   118: invokestatic valueOf : (J)Ljava/lang/Long;
      //   121: aastore
      //   122: dup
      //   123: iconst_2
      //   124: aload #6
      //   126: getfield name : Ljava/lang/String;
      //   129: aastore
      //   130: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
      //   133: lload_2
      //   134: lstore #4
      //   136: goto -> 69
      //   139: astore_1
      //   140: aload_0
      //   141: monitorexit
      //   142: aload_1
      //   143: athrow
      // Exception table:
      //   from	to	target	type
      //   2	12	139	finally
      //   21	69	139	finally
      //   69	133	139	finally
    }
    
    private static class Marker {
      public final String name;
      
      public final long thread;
      
      public final long time;
      
      public Marker(String param2String, long param2Long1, long param2Long2) {
        this.name = param2String;
        this.thread = param2Long1;
        this.time = param2Long2;
      }
    }
  }
  
  private static class Marker {
    public final String name;
    
    public final long thread;
    
    public final long time;
    
    public Marker(String param1String, long param1Long1, long param1Long2) {
      this.name = param1String;
      this.thread = param1Long1;
      this.time = param1Long2;
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/android/volley/VolleyLog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */