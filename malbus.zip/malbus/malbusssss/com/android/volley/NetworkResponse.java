package com.android.volley;

import java.io.Serializable;
import java.util.Collections;
import java.util.Map;

public class NetworkResponse implements Serializable {
  private static final long serialVersionUID = -20150728102000L;
  
  public final byte[] data;
  
  public final Map<String, String> headers;
  
  public final long networkTimeMs;
  
  public final boolean notModified;
  
  public final int statusCode;
  
  public NetworkResponse(int paramInt, byte[] paramArrayOfbyte, Map<String, String> paramMap, boolean paramBoolean) {
    this(paramInt, paramArrayOfbyte, paramMap, paramBoolean, 0L);
  }
  
  public NetworkResponse(int paramInt, byte[] paramArrayOfbyte, Map<String, String> paramMap, boolean paramBoolean, long paramLong) {
    this.statusCode = paramInt;
    this.data = paramArrayOfbyte;
    this.headers = paramMap;
    this.notModified = paramBoolean;
    this.networkTimeMs = paramLong;
  }
  
  public NetworkResponse(byte[] paramArrayOfbyte) {
    this(200, paramArrayOfbyte, Collections.emptyMap(), false, 0L);
  }
  
  public NetworkResponse(byte[] paramArrayOfbyte, Map<String, String> paramMap) {
    this(200, paramArrayOfbyte, paramMap, false, 0L);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/android/volley/NetworkResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */