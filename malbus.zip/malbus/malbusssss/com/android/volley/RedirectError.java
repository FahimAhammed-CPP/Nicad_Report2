package com.android.volley;

public class RedirectError extends VolleyError {
  public RedirectError() {}
  
  public RedirectError(NetworkResponse paramNetworkResponse) {
    super(paramNetworkResponse);
  }
  
  public RedirectError(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/android/volley/RedirectError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */