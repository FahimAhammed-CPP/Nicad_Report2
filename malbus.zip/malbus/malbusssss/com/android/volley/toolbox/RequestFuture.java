package com.android.volley.toolbox;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class RequestFuture<T> implements Future<T>, Response.Listener<T>, Response.ErrorListener {
  private VolleyError mException;
  
  private Request<?> mRequest;
  
  private T mResult;
  
  private boolean mResultReceived = false;
  
  private T doGet(Long paramLong) throws InterruptedException, ExecutionException, TimeoutException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mException : Lcom/android/volley/VolleyError;
    //   6: ifnull -> 28
    //   9: new java/util/concurrent/ExecutionException
    //   12: astore_1
    //   13: aload_1
    //   14: aload_0
    //   15: getfield mException : Lcom/android/volley/VolleyError;
    //   18: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   21: aload_1
    //   22: athrow
    //   23: astore_1
    //   24: aload_0
    //   25: monitorexit
    //   26: aload_1
    //   27: athrow
    //   28: aload_0
    //   29: getfield mResultReceived : Z
    //   32: ifeq -> 44
    //   35: aload_0
    //   36: getfield mResult : Ljava/lang/Object;
    //   39: astore_1
    //   40: aload_0
    //   41: monitorexit
    //   42: aload_1
    //   43: areturn
    //   44: aload_1
    //   45: ifnonnull -> 74
    //   48: aload_0
    //   49: lconst_0
    //   50: invokevirtual wait : (J)V
    //   53: aload_0
    //   54: getfield mException : Lcom/android/volley/VolleyError;
    //   57: ifnull -> 94
    //   60: new java/util/concurrent/ExecutionException
    //   63: astore_1
    //   64: aload_1
    //   65: aload_0
    //   66: getfield mException : Lcom/android/volley/VolleyError;
    //   69: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   72: aload_1
    //   73: athrow
    //   74: aload_1
    //   75: invokevirtual longValue : ()J
    //   78: lconst_0
    //   79: lcmp
    //   80: ifle -> 53
    //   83: aload_0
    //   84: aload_1
    //   85: invokevirtual longValue : ()J
    //   88: invokevirtual wait : (J)V
    //   91: goto -> 53
    //   94: aload_0
    //   95: getfield mResultReceived : Z
    //   98: ifne -> 111
    //   101: new java/util/concurrent/TimeoutException
    //   104: astore_1
    //   105: aload_1
    //   106: invokespecial <init> : ()V
    //   109: aload_1
    //   110: athrow
    //   111: aload_0
    //   112: getfield mResult : Ljava/lang/Object;
    //   115: astore_1
    //   116: goto -> 40
    // Exception table:
    //   from	to	target	type
    //   2	23	23	finally
    //   28	40	23	finally
    //   48	53	23	finally
    //   53	74	23	finally
    //   74	91	23	finally
    //   94	111	23	finally
    //   111	116	23	finally
  }
  
  public static <E> RequestFuture<E> newFuture() {
    return new RequestFuture<E>();
  }
  
  public boolean cancel(boolean paramBoolean) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield mRequest : Lcom/android/volley/Request;
    //   8: astore_2
    //   9: aload_2
    //   10: ifnonnull -> 17
    //   13: aload_0
    //   14: monitorexit
    //   15: iload_1
    //   16: ireturn
    //   17: aload_0
    //   18: invokevirtual isDone : ()Z
    //   21: ifne -> 13
    //   24: aload_0
    //   25: getfield mRequest : Lcom/android/volley/Request;
    //   28: invokevirtual cancel : ()V
    //   31: iconst_1
    //   32: istore_1
    //   33: goto -> 13
    //   36: astore_2
    //   37: aload_0
    //   38: monitorexit
    //   39: aload_2
    //   40: athrow
    // Exception table:
    //   from	to	target	type
    //   4	9	36	finally
    //   17	31	36	finally
  }
  
  public T get() throws InterruptedException, ExecutionException {
    try {
      return doGet(null);
    } catch (TimeoutException timeoutException) {
      throw new AssertionError(timeoutException);
    } 
  }
  
  public T get(long paramLong, TimeUnit paramTimeUnit) throws InterruptedException, ExecutionException, TimeoutException {
    return doGet(Long.valueOf(TimeUnit.MILLISECONDS.convert(paramLong, paramTimeUnit)));
  }
  
  public boolean isCancelled() {
    return (this.mRequest == null) ? false : this.mRequest.isCanceled();
  }
  
  public boolean isDone() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mResultReceived : Z
    //   6: ifne -> 25
    //   9: aload_0
    //   10: getfield mException : Lcom/android/volley/VolleyError;
    //   13: ifnonnull -> 25
    //   16: aload_0
    //   17: invokevirtual isCancelled : ()Z
    //   20: istore_1
    //   21: iload_1
    //   22: ifeq -> 31
    //   25: iconst_1
    //   26: istore_1
    //   27: aload_0
    //   28: monitorexit
    //   29: iload_1
    //   30: ireturn
    //   31: iconst_0
    //   32: istore_1
    //   33: goto -> 27
    //   36: astore_2
    //   37: aload_0
    //   38: monitorexit
    //   39: aload_2
    //   40: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	36	finally
  }
  
  public void onErrorResponse(VolleyError paramVolleyError) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: putfield mException : Lcom/android/volley/VolleyError;
    //   7: aload_0
    //   8: invokevirtual notifyAll : ()V
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	14	finally
  }
  
  public void onResponse(T paramT) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iconst_1
    //   4: putfield mResultReceived : Z
    //   7: aload_0
    //   8: aload_1
    //   9: putfield mResult : Ljava/lang/Object;
    //   12: aload_0
    //   13: invokevirtual notifyAll : ()V
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: astore_1
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_1
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	19	finally
  }
  
  public void setRequest(Request<?> paramRequest) {
    this.mRequest = paramRequest;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/android/volley/toolbox/RequestFuture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */