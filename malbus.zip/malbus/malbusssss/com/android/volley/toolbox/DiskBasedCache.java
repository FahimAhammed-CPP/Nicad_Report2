package com.android.volley.toolbox;

import android.os.SystemClock;
import com.android.volley.Cache;
import com.android.volley.VolleyLog;
import java.io.EOFException;
import java.io.File;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

public class DiskBasedCache implements Cache {
  private static final int CACHE_MAGIC = 538247942;
  
  private static final int DEFAULT_DISK_USAGE_BYTES = 5242880;
  
  private static final float HYSTERESIS_FACTOR = 0.9F;
  
  private final Map<String, CacheHeader> mEntries = new LinkedHashMap<String, CacheHeader>(16, 0.75F, true);
  
  private final int mMaxCacheSizeInBytes;
  
  private final File mRootDirectory;
  
  private long mTotalSize = 0L;
  
  public DiskBasedCache(File paramFile) {
    this(paramFile, 5242880);
  }
  
  public DiskBasedCache(File paramFile, int paramInt) {
    this.mRootDirectory = paramFile;
    this.mMaxCacheSizeInBytes = paramInt;
  }
  
  private String getFilenameForKey(String paramString) {
    int i = paramString.length() / 2;
    int j = paramString.substring(0, i).hashCode();
    return String.valueOf(j) + String.valueOf(paramString.substring(i).hashCode());
  }
  
  private void pruneIfNeeded(int paramInt) {
    if (this.mTotalSize + paramInt >= this.mMaxCacheSizeInBytes) {
      if (VolleyLog.DEBUG)
        VolleyLog.v("Pruning old cache entries.", new Object[0]); 
      long l1 = this.mTotalSize;
      int i = 0;
      long l2 = SystemClock.elapsedRealtime();
      Iterator<Map.Entry> iterator = this.mEntries.entrySet().iterator();
      while (true) {
        int j = i;
        if (iterator.hasNext()) {
          CacheHeader cacheHeader = (CacheHeader)((Map.Entry)iterator.next()).getValue();
          if (getFileForKey(cacheHeader.key).delete()) {
            this.mTotalSize -= cacheHeader.size;
          } else {
            VolleyLog.d("Could not delete cache entry for key=%s, filename=%s", new Object[] { cacheHeader.key, getFilenameForKey(cacheHeader.key) });
          } 
          iterator.remove();
          j = i + 1;
          i = j;
          if ((float)(this.mTotalSize + paramInt) < this.mMaxCacheSizeInBytes * 0.9F) {
            if (VolleyLog.DEBUG)
              VolleyLog.v("pruned %d files, %d bytes, %d ms", new Object[] { Integer.valueOf(j), Long.valueOf(this.mTotalSize - l1), Long.valueOf(SystemClock.elapsedRealtime() - l2) }); 
            return;
          } 
          continue;
        } 
        if (VolleyLog.DEBUG)
          VolleyLog.v("pruned %d files, %d bytes, %d ms", new Object[] { Integer.valueOf(j), Long.valueOf(this.mTotalSize - l1), Long.valueOf(SystemClock.elapsedRealtime() - l2) }); 
        return;
      } 
    } 
  }
  
  private void putEntry(String paramString, CacheHeader paramCacheHeader) {
    if (!this.mEntries.containsKey(paramString)) {
      this.mTotalSize += paramCacheHeader.size;
    } else {
      CacheHeader cacheHeader = this.mEntries.get(paramString);
      this.mTotalSize += paramCacheHeader.size - cacheHeader.size;
    } 
    this.mEntries.put(paramString, paramCacheHeader);
  }
  
  private static int read(InputStream paramInputStream) throws IOException {
    int i = paramInputStream.read();
    if (i == -1)
      throw new EOFException(); 
    return i;
  }
  
  static int readInt(InputStream paramInputStream) throws IOException {
    return 0x0 | read(paramInputStream) << 0 | read(paramInputStream) << 8 | read(paramInputStream) << 16 | read(paramInputStream) << 24;
  }
  
  static long readLong(InputStream paramInputStream) throws IOException {
    return 0x0L | (read(paramInputStream) & 0xFFL) << 0L | (read(paramInputStream) & 0xFFL) << 8L | (read(paramInputStream) & 0xFFL) << 16L | (read(paramInputStream) & 0xFFL) << 24L | (read(paramInputStream) & 0xFFL) << 32L | (read(paramInputStream) & 0xFFL) << 40L | (read(paramInputStream) & 0xFFL) << 48L | (read(paramInputStream) & 0xFFL) << 56L;
  }
  
  static String readString(InputStream paramInputStream) throws IOException {
    return new String(streamToBytes(paramInputStream, (int)readLong(paramInputStream)), "UTF-8");
  }
  
  static Map<String, String> readStringStringMap(InputStream paramInputStream) throws IOException {
    Map<?, ?> map;
    int i = readInt(paramInputStream);
    if (i == 0) {
      map = Collections.emptyMap();
    } else {
      map = new HashMap<Object, Object>(i);
    } 
    for (byte b = 0; b < i; b++)
      map.put(readString(paramInputStream).intern(), readString(paramInputStream).intern()); 
    return (Map)map;
  }
  
  private void removeEntry(String paramString) {
    CacheHeader cacheHeader = this.mEntries.get(paramString);
    if (cacheHeader != null) {
      this.mTotalSize -= cacheHeader.size;
      this.mEntries.remove(paramString);
    } 
  }
  
  private static byte[] streamToBytes(InputStream paramInputStream, int paramInt) throws IOException {
    byte[] arrayOfByte = new byte[paramInt];
    int i = 0;
    while (i < paramInt) {
      int j = paramInputStream.read(arrayOfByte, i, paramInt - i);
      if (j != -1)
        i += j; 
    } 
    if (i != paramInt)
      throw new IOException("Expected " + paramInt + " bytes, read " + i + " bytes"); 
    return arrayOfByte;
  }
  
  static void writeInt(OutputStream paramOutputStream, int paramInt) throws IOException {
    paramOutputStream.write(paramInt >> 0 & 0xFF);
    paramOutputStream.write(paramInt >> 8 & 0xFF);
    paramOutputStream.write(paramInt >> 16 & 0xFF);
    paramOutputStream.write(paramInt >> 24 & 0xFF);
  }
  
  static void writeLong(OutputStream paramOutputStream, long paramLong) throws IOException {
    paramOutputStream.write((byte)(int)(paramLong >>> 0L));
    paramOutputStream.write((byte)(int)(paramLong >>> 8L));
    paramOutputStream.write((byte)(int)(paramLong >>> 16L));
    paramOutputStream.write((byte)(int)(paramLong >>> 24L));
    paramOutputStream.write((byte)(int)(paramLong >>> 32L));
    paramOutputStream.write((byte)(int)(paramLong >>> 40L));
    paramOutputStream.write((byte)(int)(paramLong >>> 48L));
    paramOutputStream.write((byte)(int)(paramLong >>> 56L));
  }
  
  static void writeString(OutputStream paramOutputStream, String paramString) throws IOException {
    byte[] arrayOfByte = paramString.getBytes("UTF-8");
    writeLong(paramOutputStream, arrayOfByte.length);
    paramOutputStream.write(arrayOfByte, 0, arrayOfByte.length);
  }
  
  static void writeStringStringMap(Map<String, String> paramMap, OutputStream paramOutputStream) throws IOException {
    if (paramMap != null) {
      writeInt(paramOutputStream, paramMap.size());
      for (Map.Entry<String, String> entry : paramMap.entrySet()) {
        writeString(paramOutputStream, (String)entry.getKey());
        writeString(paramOutputStream, (String)entry.getValue());
      } 
    } else {
      writeInt(paramOutputStream, 0);
    } 
  }
  
  public void clear() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mRootDirectory : Ljava/io/File;
    //   6: invokevirtual listFiles : ()[Ljava/io/File;
    //   9: astore_1
    //   10: aload_1
    //   11: ifnull -> 37
    //   14: aload_1
    //   15: arraylength
    //   16: istore_2
    //   17: iconst_0
    //   18: istore_3
    //   19: iload_3
    //   20: iload_2
    //   21: if_icmpge -> 37
    //   24: aload_1
    //   25: iload_3
    //   26: aaload
    //   27: invokevirtual delete : ()Z
    //   30: pop
    //   31: iinc #3, 1
    //   34: goto -> 19
    //   37: aload_0
    //   38: getfield mEntries : Ljava/util/Map;
    //   41: invokeinterface clear : ()V
    //   46: aload_0
    //   47: lconst_0
    //   48: putfield mTotalSize : J
    //   51: ldc_w 'Cache cleared.'
    //   54: iconst_0
    //   55: anewarray java/lang/Object
    //   58: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   61: aload_0
    //   62: monitorexit
    //   63: return
    //   64: astore_1
    //   65: aload_0
    //   66: monitorexit
    //   67: aload_1
    //   68: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	64	finally
    //   14	17	64	finally
    //   24	31	64	finally
    //   37	61	64	finally
  }
  
  public Cache.Entry get(String paramString) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield mEntries : Ljava/util/Map;
    //   8: aload_1
    //   9: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   14: checkcast com/android/volley/toolbox/DiskBasedCache$CacheHeader
    //   17: astore_3
    //   18: aload_3
    //   19: ifnonnull -> 28
    //   22: aload_2
    //   23: astore_1
    //   24: aload_0
    //   25: monitorexit
    //   26: aload_1
    //   27: areturn
    //   28: aload_0
    //   29: aload_1
    //   30: invokevirtual getFileForKey : (Ljava/lang/String;)Ljava/io/File;
    //   33: astore #4
    //   35: aconst_null
    //   36: astore #5
    //   38: aconst_null
    //   39: astore #6
    //   41: aconst_null
    //   42: astore #7
    //   44: aload #6
    //   46: astore #8
    //   48: new com/android/volley/toolbox/DiskBasedCache$CountingInputStream
    //   51: astore #9
    //   53: aload #6
    //   55: astore #8
    //   57: new java/io/BufferedInputStream
    //   60: astore #10
    //   62: aload #6
    //   64: astore #8
    //   66: new java/io/FileInputStream
    //   69: astore #11
    //   71: aload #6
    //   73: astore #8
    //   75: aload #11
    //   77: aload #4
    //   79: invokespecial <init> : (Ljava/io/File;)V
    //   82: aload #6
    //   84: astore #8
    //   86: aload #10
    //   88: aload #11
    //   90: invokespecial <init> : (Ljava/io/InputStream;)V
    //   93: aload #6
    //   95: astore #8
    //   97: aload #9
    //   99: aload #10
    //   101: aconst_null
    //   102: invokespecial <init> : (Ljava/io/InputStream;Lcom/android/volley/toolbox/DiskBasedCache$1;)V
    //   105: aload #9
    //   107: invokestatic readHeader : (Ljava/io/InputStream;)Lcom/android/volley/toolbox/DiskBasedCache$CacheHeader;
    //   110: pop
    //   111: aload_3
    //   112: aload #9
    //   114: aload #4
    //   116: invokevirtual length : ()J
    //   119: aload #9
    //   121: invokestatic access$100 : (Lcom/android/volley/toolbox/DiskBasedCache$CountingInputStream;)I
    //   124: i2l
    //   125: lsub
    //   126: l2i
    //   127: invokestatic streamToBytes : (Ljava/io/InputStream;I)[B
    //   130: invokevirtual toCacheEntry : ([B)Lcom/android/volley/Cache$Entry;
    //   133: astore #8
    //   135: aload #9
    //   137: ifnull -> 145
    //   140: aload #9
    //   142: invokevirtual close : ()V
    //   145: aload #8
    //   147: astore_1
    //   148: goto -> 24
    //   151: astore_1
    //   152: aload_2
    //   153: astore_1
    //   154: goto -> 24
    //   157: astore #6
    //   159: aload #7
    //   161: astore #9
    //   163: aload #9
    //   165: astore #8
    //   167: ldc_w '%s: %s'
    //   170: iconst_2
    //   171: anewarray java/lang/Object
    //   174: dup
    //   175: iconst_0
    //   176: aload #4
    //   178: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   181: aastore
    //   182: dup
    //   183: iconst_1
    //   184: aload #6
    //   186: invokevirtual toString : ()Ljava/lang/String;
    //   189: aastore
    //   190: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   193: aload #9
    //   195: astore #8
    //   197: aload_0
    //   198: aload_1
    //   199: invokevirtual remove : (Ljava/lang/String;)V
    //   202: aload_2
    //   203: astore_1
    //   204: aload #9
    //   206: ifnull -> 24
    //   209: aload #9
    //   211: invokevirtual close : ()V
    //   214: aload_2
    //   215: astore_1
    //   216: goto -> 24
    //   219: astore_1
    //   220: aload_2
    //   221: astore_1
    //   222: goto -> 24
    //   225: astore #6
    //   227: aload #5
    //   229: astore #9
    //   231: aload #9
    //   233: astore #8
    //   235: ldc_w '%s: %s'
    //   238: iconst_2
    //   239: anewarray java/lang/Object
    //   242: dup
    //   243: iconst_0
    //   244: aload #4
    //   246: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   249: aastore
    //   250: dup
    //   251: iconst_1
    //   252: aload #6
    //   254: invokevirtual toString : ()Ljava/lang/String;
    //   257: aastore
    //   258: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   261: aload #9
    //   263: astore #8
    //   265: aload_0
    //   266: aload_1
    //   267: invokevirtual remove : (Ljava/lang/String;)V
    //   270: aload_2
    //   271: astore_1
    //   272: aload #9
    //   274: ifnull -> 24
    //   277: aload #9
    //   279: invokevirtual close : ()V
    //   282: aload_2
    //   283: astore_1
    //   284: goto -> 24
    //   287: astore_1
    //   288: aload_2
    //   289: astore_1
    //   290: goto -> 24
    //   293: astore_1
    //   294: aload #8
    //   296: ifnull -> 304
    //   299: aload #8
    //   301: invokevirtual close : ()V
    //   304: aload_1
    //   305: athrow
    //   306: astore_1
    //   307: aload_0
    //   308: monitorexit
    //   309: aload_1
    //   310: athrow
    //   311: astore_1
    //   312: aload_2
    //   313: astore_1
    //   314: goto -> 24
    //   317: astore_1
    //   318: aload #9
    //   320: astore #8
    //   322: goto -> 294
    //   325: astore #8
    //   327: aload #8
    //   329: astore #6
    //   331: goto -> 231
    //   334: astore #6
    //   336: goto -> 163
    // Exception table:
    //   from	to	target	type
    //   4	18	306	finally
    //   28	35	306	finally
    //   48	53	157	java/io/IOException
    //   48	53	225	java/lang/NegativeArraySizeException
    //   48	53	293	finally
    //   57	62	157	java/io/IOException
    //   57	62	225	java/lang/NegativeArraySizeException
    //   57	62	293	finally
    //   66	71	157	java/io/IOException
    //   66	71	225	java/lang/NegativeArraySizeException
    //   66	71	293	finally
    //   75	82	157	java/io/IOException
    //   75	82	225	java/lang/NegativeArraySizeException
    //   75	82	293	finally
    //   86	93	157	java/io/IOException
    //   86	93	225	java/lang/NegativeArraySizeException
    //   86	93	293	finally
    //   97	105	157	java/io/IOException
    //   97	105	225	java/lang/NegativeArraySizeException
    //   97	105	293	finally
    //   105	135	334	java/io/IOException
    //   105	135	325	java/lang/NegativeArraySizeException
    //   105	135	317	finally
    //   140	145	151	java/io/IOException
    //   140	145	306	finally
    //   167	193	293	finally
    //   197	202	293	finally
    //   209	214	219	java/io/IOException
    //   209	214	306	finally
    //   235	261	293	finally
    //   265	270	293	finally
    //   277	282	287	java/io/IOException
    //   277	282	306	finally
    //   299	304	311	java/io/IOException
    //   299	304	306	finally
    //   304	306	306	finally
  }
  
  public File getFileForKey(String paramString) {
    return new File(this.mRootDirectory, getFilenameForKey(paramString));
  }
  
  public void initialize() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mRootDirectory : Ljava/io/File;
    //   6: invokevirtual exists : ()Z
    //   9: ifne -> 45
    //   12: aload_0
    //   13: getfield mRootDirectory : Ljava/io/File;
    //   16: invokevirtual mkdirs : ()Z
    //   19: ifne -> 42
    //   22: ldc_w 'Unable to create cache dir %s'
    //   25: iconst_1
    //   26: anewarray java/lang/Object
    //   29: dup
    //   30: iconst_0
    //   31: aload_0
    //   32: getfield mRootDirectory : Ljava/io/File;
    //   35: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   38: aastore
    //   39: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   42: aload_0
    //   43: monitorexit
    //   44: return
    //   45: aload_0
    //   46: getfield mRootDirectory : Ljava/io/File;
    //   49: invokevirtual listFiles : ()[Ljava/io/File;
    //   52: astore_1
    //   53: aload_1
    //   54: ifnull -> 42
    //   57: aload_1
    //   58: arraylength
    //   59: istore_2
    //   60: iconst_0
    //   61: istore_3
    //   62: iload_3
    //   63: iload_2
    //   64: if_icmpge -> 42
    //   67: aload_1
    //   68: iload_3
    //   69: aaload
    //   70: astore #4
    //   72: aconst_null
    //   73: astore #5
    //   75: aconst_null
    //   76: astore #6
    //   78: aload #5
    //   80: astore #7
    //   82: new java/io/BufferedInputStream
    //   85: astore #8
    //   87: aload #5
    //   89: astore #7
    //   91: new java/io/FileInputStream
    //   94: astore #9
    //   96: aload #5
    //   98: astore #7
    //   100: aload #9
    //   102: aload #4
    //   104: invokespecial <init> : (Ljava/io/File;)V
    //   107: aload #5
    //   109: astore #7
    //   111: aload #8
    //   113: aload #9
    //   115: invokespecial <init> : (Ljava/io/InputStream;)V
    //   118: aload #8
    //   120: invokestatic readHeader : (Ljava/io/InputStream;)Lcom/android/volley/toolbox/DiskBasedCache$CacheHeader;
    //   123: astore #7
    //   125: aload #7
    //   127: aload #4
    //   129: invokevirtual length : ()J
    //   132: putfield size : J
    //   135: aload_0
    //   136: aload #7
    //   138: getfield key : Ljava/lang/String;
    //   141: aload #7
    //   143: invokespecial putEntry : (Ljava/lang/String;Lcom/android/volley/toolbox/DiskBasedCache$CacheHeader;)V
    //   146: aload #8
    //   148: ifnull -> 156
    //   151: aload #8
    //   153: invokevirtual close : ()V
    //   156: iinc #3, 1
    //   159: goto -> 62
    //   162: astore #7
    //   164: goto -> 156
    //   167: astore #7
    //   169: aload #6
    //   171: astore #8
    //   173: aload #4
    //   175: ifnull -> 188
    //   178: aload #8
    //   180: astore #7
    //   182: aload #4
    //   184: invokevirtual delete : ()Z
    //   187: pop
    //   188: aload #8
    //   190: ifnull -> 156
    //   193: aload #8
    //   195: invokevirtual close : ()V
    //   198: goto -> 156
    //   201: astore #7
    //   203: goto -> 156
    //   206: astore #8
    //   208: aload #7
    //   210: astore #6
    //   212: aload #6
    //   214: ifnull -> 222
    //   217: aload #6
    //   219: invokevirtual close : ()V
    //   222: aload #8
    //   224: athrow
    //   225: astore #7
    //   227: aload_0
    //   228: monitorexit
    //   229: aload #7
    //   231: athrow
    //   232: astore #7
    //   234: goto -> 222
    //   237: astore #7
    //   239: aload #8
    //   241: astore #6
    //   243: aload #7
    //   245: astore #8
    //   247: goto -> 212
    //   250: astore #7
    //   252: goto -> 173
    // Exception table:
    //   from	to	target	type
    //   2	42	225	finally
    //   45	53	225	finally
    //   57	60	225	finally
    //   82	87	167	java/io/IOException
    //   82	87	206	finally
    //   91	96	167	java/io/IOException
    //   91	96	206	finally
    //   100	107	167	java/io/IOException
    //   100	107	206	finally
    //   111	118	167	java/io/IOException
    //   111	118	206	finally
    //   118	146	250	java/io/IOException
    //   118	146	237	finally
    //   151	156	162	java/io/IOException
    //   151	156	225	finally
    //   182	188	206	finally
    //   193	198	201	java/io/IOException
    //   193	198	225	finally
    //   217	222	232	java/io/IOException
    //   217	222	225	finally
    //   222	225	225	finally
  }
  
  public void invalidate(String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: invokevirtual get : (Ljava/lang/String;)Lcom/android/volley/Cache$Entry;
    //   7: astore_3
    //   8: aload_3
    //   9: ifnull -> 32
    //   12: aload_3
    //   13: lconst_0
    //   14: putfield softTtl : J
    //   17: iload_2
    //   18: ifeq -> 26
    //   21: aload_3
    //   22: lconst_0
    //   23: putfield ttl : J
    //   26: aload_0
    //   27: aload_1
    //   28: aload_3
    //   29: invokevirtual put : (Ljava/lang/String;Lcom/android/volley/Cache$Entry;)V
    //   32: aload_0
    //   33: monitorexit
    //   34: return
    //   35: astore_1
    //   36: aload_0
    //   37: monitorexit
    //   38: aload_1
    //   39: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	35	finally
    //   12	17	35	finally
    //   21	26	35	finally
    //   26	32	35	finally
  }
  
  public void put(String paramString, Cache.Entry paramEntry) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_2
    //   4: getfield data : [B
    //   7: arraylength
    //   8: invokespecial pruneIfNeeded : (I)V
    //   11: aload_0
    //   12: aload_1
    //   13: invokevirtual getFileForKey : (Ljava/lang/String;)Ljava/io/File;
    //   16: astore_3
    //   17: new java/io/BufferedOutputStream
    //   20: astore #4
    //   22: new java/io/FileOutputStream
    //   25: astore #5
    //   27: aload #5
    //   29: aload_3
    //   30: invokespecial <init> : (Ljava/io/File;)V
    //   33: aload #4
    //   35: aload #5
    //   37: invokespecial <init> : (Ljava/io/OutputStream;)V
    //   40: new com/android/volley/toolbox/DiskBasedCache$CacheHeader
    //   43: astore #5
    //   45: aload #5
    //   47: aload_1
    //   48: aload_2
    //   49: invokespecial <init> : (Ljava/lang/String;Lcom/android/volley/Cache$Entry;)V
    //   52: aload #5
    //   54: aload #4
    //   56: invokevirtual writeHeader : (Ljava/io/OutputStream;)Z
    //   59: ifne -> 122
    //   62: aload #4
    //   64: invokevirtual close : ()V
    //   67: ldc_w 'Failed to write header for %s'
    //   70: iconst_1
    //   71: anewarray java/lang/Object
    //   74: dup
    //   75: iconst_0
    //   76: aload_3
    //   77: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   80: aastore
    //   81: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   84: new java/io/IOException
    //   87: astore_1
    //   88: aload_1
    //   89: invokespecial <init> : ()V
    //   92: aload_1
    //   93: athrow
    //   94: astore_1
    //   95: aload_3
    //   96: invokevirtual delete : ()Z
    //   99: ifne -> 119
    //   102: ldc_w 'Could not clean up file %s'
    //   105: iconst_1
    //   106: anewarray java/lang/Object
    //   109: dup
    //   110: iconst_0
    //   111: aload_3
    //   112: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   115: aastore
    //   116: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   119: aload_0
    //   120: monitorexit
    //   121: return
    //   122: aload #4
    //   124: aload_2
    //   125: getfield data : [B
    //   128: invokevirtual write : ([B)V
    //   131: aload #4
    //   133: invokevirtual close : ()V
    //   136: aload_0
    //   137: aload_1
    //   138: aload #5
    //   140: invokespecial putEntry : (Ljava/lang/String;Lcom/android/volley/toolbox/DiskBasedCache$CacheHeader;)V
    //   143: goto -> 119
    //   146: astore_1
    //   147: aload_0
    //   148: monitorexit
    //   149: aload_1
    //   150: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	146	finally
    //   17	94	94	java/io/IOException
    //   17	94	146	finally
    //   95	119	146	finally
    //   122	143	94	java/io/IOException
    //   122	143	146	finally
  }
  
  public void remove(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: invokevirtual getFileForKey : (Ljava/lang/String;)Ljava/io/File;
    //   7: invokevirtual delete : ()Z
    //   10: istore_2
    //   11: aload_0
    //   12: aload_1
    //   13: invokespecial removeEntry : (Ljava/lang/String;)V
    //   16: iload_2
    //   17: ifne -> 41
    //   20: ldc 'Could not delete cache entry for key=%s, filename=%s'
    //   22: iconst_2
    //   23: anewarray java/lang/Object
    //   26: dup
    //   27: iconst_0
    //   28: aload_1
    //   29: aastore
    //   30: dup
    //   31: iconst_1
    //   32: aload_0
    //   33: aload_1
    //   34: invokespecial getFilenameForKey : (Ljava/lang/String;)Ljava/lang/String;
    //   37: aastore
    //   38: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   41: aload_0
    //   42: monitorexit
    //   43: return
    //   44: astore_1
    //   45: aload_0
    //   46: monitorexit
    //   47: aload_1
    //   48: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	44	finally
    //   20	41	44	finally
  }
  
  static class CacheHeader {
    public String etag;
    
    public String key;
    
    public long lastModified;
    
    public Map<String, String> responseHeaders;
    
    public long serverDate;
    
    public long size;
    
    public long softTtl;
    
    public long ttl;
    
    private CacheHeader() {}
    
    public CacheHeader(String param1String, Cache.Entry param1Entry) {
      this.key = param1String;
      this.size = param1Entry.data.length;
      this.etag = param1Entry.etag;
      this.serverDate = param1Entry.serverDate;
      this.lastModified = param1Entry.lastModified;
      this.ttl = param1Entry.ttl;
      this.softTtl = param1Entry.softTtl;
      this.responseHeaders = param1Entry.responseHeaders;
    }
    
    public static CacheHeader readHeader(InputStream param1InputStream) throws IOException {
      CacheHeader cacheHeader = new CacheHeader();
      if (DiskBasedCache.readInt(param1InputStream) != 538247942)
        throw new IOException(); 
      cacheHeader.key = DiskBasedCache.readString(param1InputStream);
      cacheHeader.etag = DiskBasedCache.readString(param1InputStream);
      if (cacheHeader.etag.equals(""))
        cacheHeader.etag = null; 
      cacheHeader.serverDate = DiskBasedCache.readLong(param1InputStream);
      cacheHeader.lastModified = DiskBasedCache.readLong(param1InputStream);
      cacheHeader.ttl = DiskBasedCache.readLong(param1InputStream);
      cacheHeader.softTtl = DiskBasedCache.readLong(param1InputStream);
      cacheHeader.responseHeaders = DiskBasedCache.readStringStringMap(param1InputStream);
      return cacheHeader;
    }
    
    public Cache.Entry toCacheEntry(byte[] param1ArrayOfbyte) {
      Cache.Entry entry = new Cache.Entry();
      entry.data = param1ArrayOfbyte;
      entry.etag = this.etag;
      entry.serverDate = this.serverDate;
      entry.lastModified = this.lastModified;
      entry.ttl = this.ttl;
      entry.softTtl = this.softTtl;
      entry.responseHeaders = this.responseHeaders;
      return entry;
    }
    
    public boolean writeHeader(OutputStream param1OutputStream) {
      boolean bool = true;
      try {
        String str;
        DiskBasedCache.writeInt(param1OutputStream, 538247942);
        DiskBasedCache.writeString(param1OutputStream, this.key);
        if (this.etag == null) {
          str = "";
        } else {
          str = this.etag;
        } 
        DiskBasedCache.writeString(param1OutputStream, str);
        DiskBasedCache.writeLong(param1OutputStream, this.serverDate);
        DiskBasedCache.writeLong(param1OutputStream, this.lastModified);
        DiskBasedCache.writeLong(param1OutputStream, this.ttl);
        DiskBasedCache.writeLong(param1OutputStream, this.softTtl);
        DiskBasedCache.writeStringStringMap(this.responseHeaders, param1OutputStream);
        param1OutputStream.flush();
      } catch (IOException iOException) {
        VolleyLog.d("%s", new Object[] { iOException.toString() });
        bool = false;
      } 
      return bool;
    }
  }
  
  private static class CountingInputStream extends FilterInputStream {
    private int bytesRead = 0;
    
    private CountingInputStream(InputStream param1InputStream) {
      super(param1InputStream);
    }
    
    public int read() throws IOException {
      int i = super.read();
      if (i != -1)
        this.bytesRead++; 
      return i;
    }
    
    public int read(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
      param1Int1 = super.read(param1ArrayOfbyte, param1Int1, param1Int2);
      if (param1Int1 != -1)
        this.bytesRead += param1Int1; 
      return param1Int1;
    }
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/android/volley/toolbox/DiskBasedCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */