package com.android.volley.toolbox;

import com.android.volley.Cache;
import com.android.volley.NetworkResponse;
import java.util.Map;
import org.apache.http.impl.cookie.DateParseException;
import org.apache.http.impl.cookie.DateUtils;

public class HttpHeaderParser {
  public static Cache.Entry parseCacheHeaders(NetworkResponse paramNetworkResponse) {
    // Byte code:
    //   0: invokestatic currentTimeMillis : ()J
    //   3: lstore_1
    //   4: aload_0
    //   5: getfield headers : Ljava/util/Map;
    //   8: astore_3
    //   9: lconst_0
    //   10: lstore #4
    //   12: lconst_0
    //   13: lstore #6
    //   15: lconst_0
    //   16: lstore #8
    //   18: lconst_0
    //   19: lstore #10
    //   21: lconst_0
    //   22: lstore #12
    //   24: lconst_0
    //   25: lstore #14
    //   27: lconst_0
    //   28: lstore #16
    //   30: iconst_0
    //   31: istore #18
    //   33: iconst_0
    //   34: istore #19
    //   36: iconst_0
    //   37: istore #20
    //   39: aload_3
    //   40: ldc 'Date'
    //   42: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   47: checkcast java/lang/String
    //   50: astore #21
    //   52: aload #21
    //   54: ifnull -> 64
    //   57: aload #21
    //   59: invokestatic parseDateAsEpoch : (Ljava/lang/String;)J
    //   62: lstore #4
    //   64: aload_3
    //   65: ldc 'Cache-Control'
    //   67: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   72: checkcast java/lang/String
    //   75: astore #21
    //   77: lload #14
    //   79: lstore #22
    //   81: lload #16
    //   83: lstore #24
    //   85: aload #21
    //   87: ifnull -> 274
    //   90: iconst_1
    //   91: istore #26
    //   93: aload #21
    //   95: ldc ','
    //   97: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   100: astore #21
    //   102: iconst_0
    //   103: istore #27
    //   105: iload #26
    //   107: istore #18
    //   109: iload #20
    //   111: istore #19
    //   113: lload #14
    //   115: lstore #22
    //   117: lload #16
    //   119: lstore #24
    //   121: iload #27
    //   123: aload #21
    //   125: arraylength
    //   126: if_icmpge -> 274
    //   129: aload #21
    //   131: iload #27
    //   133: aaload
    //   134: invokevirtual trim : ()Ljava/lang/String;
    //   137: astore #28
    //   139: aload #28
    //   141: ldc 'no-cache'
    //   143: invokevirtual equals : (Ljava/lang/Object;)Z
    //   146: ifne -> 159
    //   149: aload #28
    //   151: ldc 'no-store'
    //   153: invokevirtual equals : (Ljava/lang/Object;)Z
    //   156: ifeq -> 163
    //   159: aconst_null
    //   160: astore_0
    //   161: aload_0
    //   162: areturn
    //   163: aload #28
    //   165: ldc 'max-age='
    //   167: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   170: ifeq -> 203
    //   173: aload #28
    //   175: bipush #8
    //   177: invokevirtual substring : (I)Ljava/lang/String;
    //   180: invokestatic parseLong : (Ljava/lang/String;)J
    //   183: lstore #24
    //   185: lload #16
    //   187: lstore #22
    //   189: iinc #27, 1
    //   192: lload #24
    //   194: lstore #14
    //   196: lload #22
    //   198: lstore #16
    //   200: goto -> 105
    //   203: aload #28
    //   205: ldc 'stale-while-revalidate='
    //   207: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   210: ifeq -> 232
    //   213: aload #28
    //   215: bipush #23
    //   217: invokevirtual substring : (I)Ljava/lang/String;
    //   220: invokestatic parseLong : (Ljava/lang/String;)J
    //   223: lstore #22
    //   225: lload #14
    //   227: lstore #24
    //   229: goto -> 189
    //   232: aload #28
    //   234: ldc 'must-revalidate'
    //   236: invokevirtual equals : (Ljava/lang/Object;)Z
    //   239: ifne -> 260
    //   242: lload #14
    //   244: lstore #24
    //   246: lload #16
    //   248: lstore #22
    //   250: aload #28
    //   252: ldc 'proxy-revalidate'
    //   254: invokevirtual equals : (Ljava/lang/Object;)Z
    //   257: ifeq -> 189
    //   260: iconst_1
    //   261: istore #20
    //   263: lload #14
    //   265: lstore #24
    //   267: lload #16
    //   269: lstore #22
    //   271: goto -> 189
    //   274: aload_3
    //   275: ldc 'Expires'
    //   277: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   282: checkcast java/lang/String
    //   285: astore #21
    //   287: aload #21
    //   289: ifnull -> 299
    //   292: aload #21
    //   294: invokestatic parseDateAsEpoch : (Ljava/lang/String;)J
    //   297: lstore #8
    //   299: aload_3
    //   300: ldc 'Last-Modified'
    //   302: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   307: checkcast java/lang/String
    //   310: astore #21
    //   312: aload #21
    //   314: ifnull -> 324
    //   317: aload #21
    //   319: invokestatic parseDateAsEpoch : (Ljava/lang/String;)J
    //   322: lstore #6
    //   324: aload_3
    //   325: ldc 'ETag'
    //   327: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   332: checkcast java/lang/String
    //   335: astore #28
    //   337: iload #18
    //   339: ifeq -> 440
    //   342: lload_1
    //   343: ldc2_w 1000
    //   346: lload #22
    //   348: lmul
    //   349: ladd
    //   350: lstore #14
    //   352: iload #19
    //   354: ifeq -> 426
    //   357: lload #14
    //   359: lstore #16
    //   361: new com/android/volley/Cache$Entry
    //   364: dup
    //   365: invokespecial <init> : ()V
    //   368: astore #21
    //   370: aload #21
    //   372: aload_0
    //   373: getfield data : [B
    //   376: putfield data : [B
    //   379: aload #21
    //   381: aload #28
    //   383: putfield etag : Ljava/lang/String;
    //   386: aload #21
    //   388: lload #14
    //   390: putfield softTtl : J
    //   393: aload #21
    //   395: lload #16
    //   397: putfield ttl : J
    //   400: aload #21
    //   402: lload #4
    //   404: putfield serverDate : J
    //   407: aload #21
    //   409: lload #6
    //   411: putfield lastModified : J
    //   414: aload #21
    //   416: aload_3
    //   417: putfield responseHeaders : Ljava/util/Map;
    //   420: aload #21
    //   422: astore_0
    //   423: goto -> 161
    //   426: lload #14
    //   428: ldc2_w 1000
    //   431: lload #24
    //   433: lmul
    //   434: ladd
    //   435: lstore #16
    //   437: goto -> 361
    //   440: lload #12
    //   442: lstore #16
    //   444: lload #10
    //   446: lstore #14
    //   448: lload #4
    //   450: lconst_0
    //   451: lcmp
    //   452: ifle -> 361
    //   455: lload #12
    //   457: lstore #16
    //   459: lload #10
    //   461: lstore #14
    //   463: lload #8
    //   465: lload #4
    //   467: lcmp
    //   468: iflt -> 361
    //   471: lload_1
    //   472: lload #8
    //   474: lload #4
    //   476: lsub
    //   477: ladd
    //   478: lstore #14
    //   480: lload #14
    //   482: lstore #16
    //   484: goto -> 361
    //   487: astore #28
    //   489: lload #14
    //   491: lstore #24
    //   493: lload #16
    //   495: lstore #22
    //   497: goto -> 189
    //   500: astore #28
    //   502: lload #14
    //   504: lstore #24
    //   506: lload #16
    //   508: lstore #22
    //   510: goto -> 189
    // Exception table:
    //   from	to	target	type
    //   173	185	500	java/lang/Exception
    //   213	225	487	java/lang/Exception
  }
  
  public static String parseCharset(Map<String, String> paramMap) {
    return parseCharset(paramMap, "ISO-8859-1");
  }
  
  public static String parseCharset(Map<String, String> paramMap, String paramString) {
    String str2 = paramMap.get("Content-Type");
    String str1 = paramString;
    if (str2 != null) {
      String[] arrayOfString = str2.split(";");
      for (byte b = 1;; b++) {
        str1 = paramString;
        if (b < arrayOfString.length) {
          String[] arrayOfString1 = arrayOfString[b].trim().split("=");
          if (arrayOfString1.length == 2 && arrayOfString1[0].equals("charset"))
            return arrayOfString1[1]; 
        } else {
          return str1;
        } 
      } 
    } 
    return str1;
  }
  
  public static long parseDateAsEpoch(String paramString) {
    long l;
    try {
      l = DateUtils.parseDate(paramString).getTime();
    } catch (DateParseException dateParseException) {
      l = 0L;
    } 
    return l;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/android/volley/toolbox/HttpHeaderParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */