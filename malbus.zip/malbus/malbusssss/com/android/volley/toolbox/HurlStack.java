package com.android.volley.toolbox;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ProtocolVersion;
import org.apache.http.StatusLine;
import org.apache.http.entity.BasicHttpEntity;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicHttpResponse;
import org.apache.http.message.BasicStatusLine;

public class HurlStack implements HttpStack {
  private static final String HEADER_CONTENT_TYPE = "Content-Type";
  
  private final SSLSocketFactory mSslSocketFactory;
  
  private final UrlRewriter mUrlRewriter;
  
  public HurlStack() {
    this(null);
  }
  
  public HurlStack(UrlRewriter paramUrlRewriter) {
    this(paramUrlRewriter, null);
  }
  
  public HurlStack(UrlRewriter paramUrlRewriter, SSLSocketFactory paramSSLSocketFactory) {
    this.mUrlRewriter = paramUrlRewriter;
    this.mSslSocketFactory = paramSSLSocketFactory;
  }
  
  private static void addBodyIfExists(HttpURLConnection paramHttpURLConnection, Request<?> paramRequest) throws IOException, AuthFailureError {
    byte[] arrayOfByte = paramRequest.getBody();
    if (arrayOfByte != null) {
      paramHttpURLConnection.setDoOutput(true);
      paramHttpURLConnection.addRequestProperty("Content-Type", paramRequest.getBodyContentType());
      DataOutputStream dataOutputStream = new DataOutputStream(paramHttpURLConnection.getOutputStream());
      dataOutputStream.write(arrayOfByte);
      dataOutputStream.close();
    } 
  }
  
  private static HttpEntity entityFromConnection(HttpURLConnection paramHttpURLConnection) {
    InputStream inputStream;
    BasicHttpEntity basicHttpEntity = new BasicHttpEntity();
    try {
      inputStream = paramHttpURLConnection.getInputStream();
    } catch (IOException iOException) {
      inputStream = paramHttpURLConnection.getErrorStream();
    } 
    basicHttpEntity.setContent(inputStream);
    basicHttpEntity.setContentLength(paramHttpURLConnection.getContentLength());
    basicHttpEntity.setContentEncoding(paramHttpURLConnection.getContentEncoding());
    basicHttpEntity.setContentType(paramHttpURLConnection.getContentType());
    return (HttpEntity)basicHttpEntity;
  }
  
  private static boolean hasResponseBody(int paramInt1, int paramInt2) {
    return (paramInt1 != 4 && (100 > paramInt2 || paramInt2 >= 200) && paramInt2 != 204 && paramInt2 != 304);
  }
  
  private HttpURLConnection openConnection(URL paramURL, Request<?> paramRequest) throws IOException {
    HttpURLConnection httpURLConnection = createConnection(paramURL);
    int i = paramRequest.getTimeoutMs();
    httpURLConnection.setConnectTimeout(i);
    httpURLConnection.setReadTimeout(i);
    httpURLConnection.setUseCaches(false);
    httpURLConnection.setDoInput(true);
    if ("https".equals(paramURL.getProtocol()) && this.mSslSocketFactory != null)
      ((HttpsURLConnection)httpURLConnection).setSSLSocketFactory(this.mSslSocketFactory); 
    return httpURLConnection;
  }
  
  static void setConnectionParametersForRequest(HttpURLConnection paramHttpURLConnection, Request<?> paramRequest) throws IOException, AuthFailureError {
    DataOutputStream dataOutputStream;
    byte[] arrayOfByte;
    switch (paramRequest.getMethod()) {
      default:
        throw new IllegalStateException("Unknown method type.");
      case -1:
        arrayOfByte = paramRequest.getPostBody();
        if (arrayOfByte != null) {
          paramHttpURLConnection.setDoOutput(true);
          paramHttpURLConnection.setRequestMethod("POST");
          paramHttpURLConnection.addRequestProperty("Content-Type", paramRequest.getPostBodyContentType());
          dataOutputStream = new DataOutputStream(paramHttpURLConnection.getOutputStream());
          dataOutputStream.write(arrayOfByte);
          dataOutputStream.close();
        } 
        return;
      case 0:
        dataOutputStream.setRequestMethod("GET");
        return;
      case 3:
        dataOutputStream.setRequestMethod("DELETE");
        return;
      case 1:
        dataOutputStream.setRequestMethod("POST");
        addBodyIfExists((HttpURLConnection)dataOutputStream, paramRequest);
        return;
      case 2:
        dataOutputStream.setRequestMethod("PUT");
        addBodyIfExists((HttpURLConnection)dataOutputStream, paramRequest);
        return;
      case 4:
        dataOutputStream.setRequestMethod("HEAD");
        return;
      case 5:
        dataOutputStream.setRequestMethod("OPTIONS");
        return;
      case 6:
        dataOutputStream.setRequestMethod("TRACE");
        return;
      case 7:
        break;
    } 
    dataOutputStream.setRequestMethod("PATCH");
    addBodyIfExists((HttpURLConnection)dataOutputStream, paramRequest);
  }
  
  protected HttpURLConnection createConnection(URL paramURL) throws IOException {
    return (HttpURLConnection)paramURL.openConnection();
  }
  
  public HttpResponse performRequest(Request<?> paramRequest, Map<String, String> paramMap) throws IOException, AuthFailureError {
    str2 = paramRequest.getUrl();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.putAll(paramRequest.getHeaders());
    hashMap.putAll(paramMap);
    String str1 = str2;
    if (this.mUrlRewriter != null) {
      str1 = this.mUrlRewriter.rewriteUrl(str2);
      if (str1 == null)
        throw new IOException("URL blocked by rewriter: " + str2); 
    } 
    HttpURLConnection httpURLConnection = openConnection(new URL(str1), paramRequest);
    for (String str2 : hashMap.keySet())
      httpURLConnection.addRequestProperty(str2, (String)hashMap.get(str2)); 
    setConnectionParametersForRequest(httpURLConnection, paramRequest);
    ProtocolVersion protocolVersion = new ProtocolVersion("HTTP", 1, 1);
    if (httpURLConnection.getResponseCode() == -1)
      throw new IOException("Could not retrieve response code from HttpUrlConnection."); 
    BasicStatusLine basicStatusLine = new BasicStatusLine(protocolVersion, httpURLConnection.getResponseCode(), httpURLConnection.getResponseMessage());
    BasicHttpResponse basicHttpResponse = new BasicHttpResponse((StatusLine)basicStatusLine);
    if (hasResponseBody(paramRequest.getMethod(), basicStatusLine.getStatusCode()))
      basicHttpResponse.setEntity(entityFromConnection(httpURLConnection)); 
    for (Map.Entry<String, List<String>> entry : httpURLConnection.getHeaderFields().entrySet()) {
      if (entry.getKey() != null)
        basicHttpResponse.addHeader((Header)new BasicHeader((String)entry.getKey(), ((List<String>)entry.getValue()).get(0))); 
    } 
    return (HttpResponse)basicHttpResponse;
  }
  
  public static interface UrlRewriter {
    String rewriteUrl(String param1String);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/android/volley/toolbox/HurlStack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */