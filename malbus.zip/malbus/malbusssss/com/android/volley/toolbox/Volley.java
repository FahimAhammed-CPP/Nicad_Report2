package com.android.volley.toolbox;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.http.AndroidHttpClient;
import android.os.Build;
import com.android.volley.Network;
import com.android.volley.RequestQueue;
import java.io.File;
import org.apache.http.client.HttpClient;

public class Volley {
  private static final String DEFAULT_CACHE_DIR = "volley";
  
  public static RequestQueue newRequestQueue(Context paramContext) {
    return newRequestQueue(paramContext, (HttpStack)null);
  }
  
  public static RequestQueue newRequestQueue(Context paramContext, int paramInt) {
    return newRequestQueue(paramContext, null, paramInt);
  }
  
  public static RequestQueue newRequestQueue(Context paramContext, HttpStack paramHttpStack) {
    return newRequestQueue(paramContext, paramHttpStack, -1);
  }
  
  public static RequestQueue newRequestQueue(Context paramContext, HttpStack paramHttpStack, int paramInt) {
    File file = new File(paramContext.getCacheDir(), "volley");
    String str = "volley/0";
    try {
      String str2 = paramContext.getPackageName();
      PackageInfo packageInfo = paramContext.getPackageManager().getPackageInfo(str2, 0);
      StringBuilder stringBuilder = new StringBuilder();
      this();
      String str1 = stringBuilder.append(str2).append("/").append(packageInfo.versionCode).toString();
      str = str1;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {}
    HttpStack httpStack = paramHttpStack;
    if (paramHttpStack == null)
      if (Build.VERSION.SDK_INT >= 9) {
        httpStack = new HurlStack();
      } else {
        httpStack = new HttpClientStack((HttpClient)AndroidHttpClient.newInstance(str));
      }  
    BasicNetwork basicNetwork = new BasicNetwork(httpStack);
    if (paramInt <= -1) {
      requestQueue = new RequestQueue(new DiskBasedCache(file), basicNetwork);
      requestQueue.start();
      return requestQueue;
    } 
    RequestQueue requestQueue = new RequestQueue(new DiskBasedCache(file, paramInt), (Network)requestQueue);
    requestQueue.start();
    return requestQueue;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/android/volley/toolbox/Volley.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */