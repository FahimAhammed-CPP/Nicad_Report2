package com.android.volley.toolbox;

import android.os.SystemClock;
import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RetryPolicy;
import com.android.volley.ServerError;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import java.io.IOException;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.StatusLine;
import org.apache.http.impl.cookie.DateUtils;

public class BasicNetwork implements Network {
  protected static final boolean DEBUG = VolleyLog.DEBUG;
  
  private static int DEFAULT_POOL_SIZE;
  
  private static int SLOW_REQUEST_THRESHOLD_MS = 3000;
  
  protected final HttpStack mHttpStack;
  
  protected final ByteArrayPool mPool;
  
  static {
    DEFAULT_POOL_SIZE = 4096;
  }
  
  public BasicNetwork(HttpStack paramHttpStack) {
    this(paramHttpStack, new ByteArrayPool(DEFAULT_POOL_SIZE));
  }
  
  public BasicNetwork(HttpStack paramHttpStack, ByteArrayPool paramByteArrayPool) {
    this.mHttpStack = paramHttpStack;
    this.mPool = paramByteArrayPool;
  }
  
  private void addCacheHeaders(Map<String, String> paramMap, Cache.Entry paramEntry) {
    if (paramEntry != null) {
      if (paramEntry.etag != null)
        paramMap.put("If-None-Match", paramEntry.etag); 
      if (paramEntry.lastModified > 0L)
        paramMap.put("If-Modified-Since", DateUtils.formatDate(new Date(paramEntry.lastModified))); 
    } 
  }
  
  private static void attemptRetryOnException(String paramString, Request<?> paramRequest, VolleyError paramVolleyError) throws VolleyError {
    RetryPolicy retryPolicy = paramRequest.getRetryPolicy();
    int i = paramRequest.getTimeoutMs();
    try {
      retryPolicy.retry(paramVolleyError);
      paramRequest.addMarker(String.format("%s-retry [timeout=%s]", new Object[] { paramString, Integer.valueOf(i) }));
      return;
    } catch (VolleyError volleyError) {
      paramRequest.addMarker(String.format("%s-timeout-giveup [timeout=%s]", new Object[] { paramString, Integer.valueOf(i) }));
      throw volleyError;
    } 
  }
  
  protected static Map<String, String> convertHeaders(Header[] paramArrayOfHeader) {
    TreeMap<String, Object> treeMap = new TreeMap<String, Object>(String.CASE_INSENSITIVE_ORDER);
    for (byte b = 0; b < paramArrayOfHeader.length; b++)
      treeMap.put(paramArrayOfHeader[b].getName(), paramArrayOfHeader[b].getValue()); 
    return (Map)treeMap;
  }
  
  private byte[] entityToBytes(HttpEntity paramHttpEntity) throws IOException, ServerError {
    // Byte code:
    //   0: new com/android/volley/toolbox/PoolingByteArrayOutputStream
    //   3: dup
    //   4: aload_0
    //   5: getfield mPool : Lcom/android/volley/toolbox/ByteArrayPool;
    //   8: aload_1
    //   9: invokeinterface getContentLength : ()J
    //   14: l2i
    //   15: invokespecial <init> : (Lcom/android/volley/toolbox/ByteArrayPool;I)V
    //   18: astore_2
    //   19: aconst_null
    //   20: astore_3
    //   21: aload_3
    //   22: astore #4
    //   24: aload_1
    //   25: invokeinterface getContent : ()Ljava/io/InputStream;
    //   30: astore #5
    //   32: aload #5
    //   34: ifnonnull -> 81
    //   37: aload_3
    //   38: astore #4
    //   40: new com/android/volley/ServerError
    //   43: astore #5
    //   45: aload_3
    //   46: astore #4
    //   48: aload #5
    //   50: invokespecial <init> : ()V
    //   53: aload_3
    //   54: astore #4
    //   56: aload #5
    //   58: athrow
    //   59: astore_3
    //   60: aload_1
    //   61: invokeinterface consumeContent : ()V
    //   66: aload_0
    //   67: getfield mPool : Lcom/android/volley/toolbox/ByteArrayPool;
    //   70: aload #4
    //   72: invokevirtual returnBuf : ([B)V
    //   75: aload_2
    //   76: invokevirtual close : ()V
    //   79: aload_3
    //   80: athrow
    //   81: aload_3
    //   82: astore #4
    //   84: aload_0
    //   85: getfield mPool : Lcom/android/volley/toolbox/ByteArrayPool;
    //   88: sipush #1024
    //   91: invokevirtual getBuf : (I)[B
    //   94: astore_3
    //   95: aload_3
    //   96: astore #4
    //   98: aload #5
    //   100: aload_3
    //   101: invokevirtual read : ([B)I
    //   104: istore #6
    //   106: iload #6
    //   108: iconst_m1
    //   109: if_icmpeq -> 126
    //   112: aload_3
    //   113: astore #4
    //   115: aload_2
    //   116: aload_3
    //   117: iconst_0
    //   118: iload #6
    //   120: invokevirtual write : ([BII)V
    //   123: goto -> 95
    //   126: aload_3
    //   127: astore #4
    //   129: aload_2
    //   130: invokevirtual toByteArray : ()[B
    //   133: astore #5
    //   135: aload_1
    //   136: invokeinterface consumeContent : ()V
    //   141: aload_0
    //   142: getfield mPool : Lcom/android/volley/toolbox/ByteArrayPool;
    //   145: aload_3
    //   146: invokevirtual returnBuf : ([B)V
    //   149: aload_2
    //   150: invokevirtual close : ()V
    //   153: aload #5
    //   155: areturn
    //   156: astore_1
    //   157: ldc 'Error occured when calling consumingContent'
    //   159: iconst_0
    //   160: anewarray java/lang/Object
    //   163: invokestatic v : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   166: goto -> 141
    //   169: astore_1
    //   170: ldc 'Error occured when calling consumingContent'
    //   172: iconst_0
    //   173: anewarray java/lang/Object
    //   176: invokestatic v : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   179: goto -> 66
    // Exception table:
    //   from	to	target	type
    //   24	32	59	finally
    //   40	45	59	finally
    //   48	53	59	finally
    //   56	59	59	finally
    //   60	66	169	java/io/IOException
    //   84	95	59	finally
    //   98	106	59	finally
    //   115	123	59	finally
    //   129	135	59	finally
    //   135	141	156	java/io/IOException
  }
  
  private void logSlowRequests(long paramLong, Request<?> paramRequest, byte[] paramArrayOfbyte, StatusLine paramStatusLine) {
    if (DEBUG || paramLong > SLOW_REQUEST_THRESHOLD_MS) {
      String str;
      if (paramArrayOfbyte != null) {
        Integer integer = Integer.valueOf(paramArrayOfbyte.length);
      } else {
        str = "null";
      } 
      VolleyLog.d("HTTP response for request=<%s> [lifetime=%d], [size=%s], [rc=%d], [retryCount=%s]", new Object[] { paramRequest, Long.valueOf(paramLong), str, Integer.valueOf(paramStatusLine.getStatusCode()), Integer.valueOf(paramRequest.getRetryPolicy().getCurrentRetryCount()) });
    } 
  }
  
  protected void logError(String paramString1, String paramString2, long paramLong) {
    VolleyLog.v("HTTP ERROR(%s) %d ms to fetch %s", new Object[] { paramString1, Long.valueOf(SystemClock.elapsedRealtime() - paramLong), paramString2 });
  }
  
  public NetworkResponse performRequest(Request<?> paramRequest) throws VolleyError {
    // Byte code:
    //   0: invokestatic elapsedRealtime : ()J
    //   3: lstore_2
    //   4: aconst_null
    //   5: astore #4
    //   7: invokestatic emptyMap : ()Ljava/util/Map;
    //   10: astore #5
    //   12: aload #5
    //   14: astore #6
    //   16: aload #4
    //   18: astore #7
    //   20: new java/util/HashMap
    //   23: astore #8
    //   25: aload #5
    //   27: astore #6
    //   29: aload #4
    //   31: astore #7
    //   33: aload #8
    //   35: invokespecial <init> : ()V
    //   38: aload #5
    //   40: astore #6
    //   42: aload #4
    //   44: astore #7
    //   46: aload_0
    //   47: aload #8
    //   49: aload_1
    //   50: invokevirtual getCacheEntry : ()Lcom/android/volley/Cache$Entry;
    //   53: invokespecial addCacheHeaders : (Ljava/util/Map;Lcom/android/volley/Cache$Entry;)V
    //   56: aload #5
    //   58: astore #6
    //   60: aload #4
    //   62: astore #7
    //   64: aload_0
    //   65: getfield mHttpStack : Lcom/android/volley/toolbox/HttpStack;
    //   68: aload_1
    //   69: aload #8
    //   71: invokeinterface performRequest : (Lcom/android/volley/Request;Ljava/util/Map;)Lorg/apache/http/HttpResponse;
    //   76: astore #4
    //   78: aload #5
    //   80: astore #6
    //   82: aload #4
    //   84: astore #7
    //   86: aload #4
    //   88: invokeinterface getStatusLine : ()Lorg/apache/http/StatusLine;
    //   93: astore #9
    //   95: aload #5
    //   97: astore #6
    //   99: aload #4
    //   101: astore #7
    //   103: aload #9
    //   105: invokeinterface getStatusCode : ()I
    //   110: istore #10
    //   112: aload #5
    //   114: astore #6
    //   116: aload #4
    //   118: astore #7
    //   120: aload #4
    //   122: invokeinterface getAllHeaders : ()[Lorg/apache/http/Header;
    //   127: invokestatic convertHeaders : ([Lorg/apache/http/Header;)Ljava/util/Map;
    //   130: astore #5
    //   132: iload #10
    //   134: sipush #304
    //   137: if_icmpne -> 255
    //   140: aload #5
    //   142: astore #6
    //   144: aload #4
    //   146: astore #7
    //   148: aload_1
    //   149: invokevirtual getCacheEntry : ()Lcom/android/volley/Cache$Entry;
    //   152: astore #8
    //   154: aload #8
    //   156: ifnonnull -> 193
    //   159: aload #5
    //   161: astore #6
    //   163: aload #4
    //   165: astore #7
    //   167: new com/android/volley/NetworkResponse
    //   170: dup
    //   171: sipush #304
    //   174: aconst_null
    //   175: aload #5
    //   177: iconst_1
    //   178: invokestatic elapsedRealtime : ()J
    //   181: lload_2
    //   182: lsub
    //   183: invokespecial <init> : (I[BLjava/util/Map;ZJ)V
    //   186: astore #4
    //   188: aload #4
    //   190: astore_1
    //   191: aload_1
    //   192: areturn
    //   193: aload #5
    //   195: astore #6
    //   197: aload #4
    //   199: astore #7
    //   201: aload #8
    //   203: getfield responseHeaders : Ljava/util/Map;
    //   206: aload #5
    //   208: invokeinterface putAll : (Ljava/util/Map;)V
    //   213: aload #5
    //   215: astore #6
    //   217: aload #4
    //   219: astore #7
    //   221: new com/android/volley/NetworkResponse
    //   224: dup
    //   225: sipush #304
    //   228: aload #8
    //   230: getfield data : [B
    //   233: aload #8
    //   235: getfield responseHeaders : Ljava/util/Map;
    //   238: iconst_1
    //   239: invokestatic elapsedRealtime : ()J
    //   242: lload_2
    //   243: lsub
    //   244: invokespecial <init> : (I[BLjava/util/Map;ZJ)V
    //   247: astore #4
    //   249: aload #4
    //   251: astore_1
    //   252: goto -> 191
    //   255: iload #10
    //   257: sipush #301
    //   260: if_icmpeq -> 271
    //   263: iload #10
    //   265: sipush #302
    //   268: if_icmpne -> 296
    //   271: aload #5
    //   273: astore #6
    //   275: aload #4
    //   277: astore #7
    //   279: aload_1
    //   280: aload #5
    //   282: ldc_w 'Location'
    //   285: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   290: checkcast java/lang/String
    //   293: invokevirtual setRedirectUrl : (Ljava/lang/String;)V
    //   296: aload #5
    //   298: astore #6
    //   300: aload #4
    //   302: astore #7
    //   304: aload #4
    //   306: invokeinterface getEntity : ()Lorg/apache/http/HttpEntity;
    //   311: ifnull -> 401
    //   314: aload #5
    //   316: astore #6
    //   318: aload #4
    //   320: astore #7
    //   322: aload_0
    //   323: aload #4
    //   325: invokeinterface getEntity : ()Lorg/apache/http/HttpEntity;
    //   330: invokespecial entityToBytes : (Lorg/apache/http/HttpEntity;)[B
    //   333: astore #8
    //   335: aload #8
    //   337: astore #6
    //   339: aload_0
    //   340: invokestatic elapsedRealtime : ()J
    //   343: lload_2
    //   344: lsub
    //   345: aload_1
    //   346: aload #6
    //   348: aload #9
    //   350: invokespecial logSlowRequests : (JLcom/android/volley/Request;[BLorg/apache/http/StatusLine;)V
    //   353: iload #10
    //   355: sipush #200
    //   358: if_icmplt -> 369
    //   361: iload #10
    //   363: sipush #299
    //   366: if_icmple -> 421
    //   369: new java/io/IOException
    //   372: astore #7
    //   374: aload #7
    //   376: invokespecial <init> : ()V
    //   379: aload #7
    //   381: athrow
    //   382: astore #6
    //   384: ldc_w 'socket'
    //   387: aload_1
    //   388: new com/android/volley/TimeoutError
    //   391: dup
    //   392: invokespecial <init> : ()V
    //   395: invokestatic attemptRetryOnException : (Ljava/lang/String;Lcom/android/volley/Request;Lcom/android/volley/VolleyError;)V
    //   398: goto -> 4
    //   401: aload #5
    //   403: astore #6
    //   405: aload #4
    //   407: astore #7
    //   409: iconst_0
    //   410: newarray byte
    //   412: astore #8
    //   414: aload #8
    //   416: astore #6
    //   418: goto -> 339
    //   421: new com/android/volley/NetworkResponse
    //   424: dup
    //   425: iload #10
    //   427: aload #6
    //   429: aload #5
    //   431: iconst_0
    //   432: invokestatic elapsedRealtime : ()J
    //   435: lload_2
    //   436: lsub
    //   437: invokespecial <init> : (I[BLjava/util/Map;ZJ)V
    //   440: astore #7
    //   442: aload #7
    //   444: astore_1
    //   445: goto -> 191
    //   448: astore #6
    //   450: ldc_w 'connection'
    //   453: aload_1
    //   454: new com/android/volley/TimeoutError
    //   457: dup
    //   458: invokespecial <init> : ()V
    //   461: invokestatic attemptRetryOnException : (Ljava/lang/String;Lcom/android/volley/Request;Lcom/android/volley/VolleyError;)V
    //   464: goto -> 4
    //   467: astore #6
    //   469: new java/lang/RuntimeException
    //   472: dup
    //   473: new java/lang/StringBuilder
    //   476: dup
    //   477: invokespecial <init> : ()V
    //   480: ldc_w 'Bad URL '
    //   483: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   486: aload_1
    //   487: invokevirtual getUrl : ()Ljava/lang/String;
    //   490: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   493: invokevirtual toString : ()Ljava/lang/String;
    //   496: aload #6
    //   498: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   501: athrow
    //   502: astore #4
    //   504: aconst_null
    //   505: astore #9
    //   507: aload #7
    //   509: astore #8
    //   511: aload #6
    //   513: astore #5
    //   515: aload #4
    //   517: astore #7
    //   519: aload #8
    //   521: ifnull -> 639
    //   524: aload #8
    //   526: invokeinterface getStatusLine : ()Lorg/apache/http/StatusLine;
    //   531: invokeinterface getStatusCode : ()I
    //   536: istore #10
    //   538: iload #10
    //   540: sipush #301
    //   543: if_icmpeq -> 554
    //   546: iload #10
    //   548: sipush #302
    //   551: if_icmpne -> 649
    //   554: ldc_w 'Request at %s has been redirected to %s'
    //   557: iconst_2
    //   558: anewarray java/lang/Object
    //   561: dup
    //   562: iconst_0
    //   563: aload_1
    //   564: invokevirtual getOriginUrl : ()Ljava/lang/String;
    //   567: aastore
    //   568: dup
    //   569: iconst_1
    //   570: aload_1
    //   571: invokevirtual getUrl : ()Ljava/lang/String;
    //   574: aastore
    //   575: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   578: aload #9
    //   580: ifnull -> 722
    //   583: new com/android/volley/NetworkResponse
    //   586: dup
    //   587: iload #10
    //   589: aload #9
    //   591: aload #5
    //   593: iconst_0
    //   594: invokestatic elapsedRealtime : ()J
    //   597: lload_2
    //   598: lsub
    //   599: invokespecial <init> : (I[BLjava/util/Map;ZJ)V
    //   602: astore #6
    //   604: iload #10
    //   606: sipush #401
    //   609: if_icmpeq -> 620
    //   612: iload #10
    //   614: sipush #403
    //   617: if_icmpne -> 677
    //   620: ldc_w 'auth'
    //   623: aload_1
    //   624: new com/android/volley/AuthFailureError
    //   627: dup
    //   628: aload #6
    //   630: invokespecial <init> : (Lcom/android/volley/NetworkResponse;)V
    //   633: invokestatic attemptRetryOnException : (Ljava/lang/String;Lcom/android/volley/Request;Lcom/android/volley/VolleyError;)V
    //   636: goto -> 4
    //   639: new com/android/volley/NoConnectionError
    //   642: dup
    //   643: aload #7
    //   645: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   648: athrow
    //   649: ldc_w 'Unexpected response code %d for %s'
    //   652: iconst_2
    //   653: anewarray java/lang/Object
    //   656: dup
    //   657: iconst_0
    //   658: iload #10
    //   660: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   663: aastore
    //   664: dup
    //   665: iconst_1
    //   666: aload_1
    //   667: invokevirtual getUrl : ()Ljava/lang/String;
    //   670: aastore
    //   671: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   674: goto -> 578
    //   677: iload #10
    //   679: sipush #301
    //   682: if_icmpeq -> 693
    //   685: iload #10
    //   687: sipush #302
    //   690: if_icmpne -> 712
    //   693: ldc_w 'redirect'
    //   696: aload_1
    //   697: new com/android/volley/RedirectError
    //   700: dup
    //   701: aload #6
    //   703: invokespecial <init> : (Lcom/android/volley/NetworkResponse;)V
    //   706: invokestatic attemptRetryOnException : (Ljava/lang/String;Lcom/android/volley/Request;Lcom/android/volley/VolleyError;)V
    //   709: goto -> 4
    //   712: new com/android/volley/ServerError
    //   715: dup
    //   716: aload #6
    //   718: invokespecial <init> : (Lcom/android/volley/NetworkResponse;)V
    //   721: athrow
    //   722: new com/android/volley/NetworkError
    //   725: dup
    //   726: aload #7
    //   728: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   731: athrow
    //   732: astore #7
    //   734: aload #6
    //   736: astore #9
    //   738: aload #4
    //   740: astore #8
    //   742: goto -> 519
    //   745: astore #6
    //   747: goto -> 469
    //   750: astore #6
    //   752: goto -> 450
    //   755: astore #6
    //   757: goto -> 384
    // Exception table:
    //   from	to	target	type
    //   20	25	755	java/net/SocketTimeoutException
    //   20	25	448	org/apache/http/conn/ConnectTimeoutException
    //   20	25	467	java/net/MalformedURLException
    //   20	25	502	java/io/IOException
    //   33	38	755	java/net/SocketTimeoutException
    //   33	38	448	org/apache/http/conn/ConnectTimeoutException
    //   33	38	467	java/net/MalformedURLException
    //   33	38	502	java/io/IOException
    //   46	56	755	java/net/SocketTimeoutException
    //   46	56	448	org/apache/http/conn/ConnectTimeoutException
    //   46	56	467	java/net/MalformedURLException
    //   46	56	502	java/io/IOException
    //   64	78	755	java/net/SocketTimeoutException
    //   64	78	448	org/apache/http/conn/ConnectTimeoutException
    //   64	78	467	java/net/MalformedURLException
    //   64	78	502	java/io/IOException
    //   86	95	755	java/net/SocketTimeoutException
    //   86	95	448	org/apache/http/conn/ConnectTimeoutException
    //   86	95	467	java/net/MalformedURLException
    //   86	95	502	java/io/IOException
    //   103	112	755	java/net/SocketTimeoutException
    //   103	112	448	org/apache/http/conn/ConnectTimeoutException
    //   103	112	467	java/net/MalformedURLException
    //   103	112	502	java/io/IOException
    //   120	132	755	java/net/SocketTimeoutException
    //   120	132	448	org/apache/http/conn/ConnectTimeoutException
    //   120	132	467	java/net/MalformedURLException
    //   120	132	502	java/io/IOException
    //   148	154	755	java/net/SocketTimeoutException
    //   148	154	448	org/apache/http/conn/ConnectTimeoutException
    //   148	154	467	java/net/MalformedURLException
    //   148	154	502	java/io/IOException
    //   167	188	755	java/net/SocketTimeoutException
    //   167	188	448	org/apache/http/conn/ConnectTimeoutException
    //   167	188	467	java/net/MalformedURLException
    //   167	188	502	java/io/IOException
    //   201	213	755	java/net/SocketTimeoutException
    //   201	213	448	org/apache/http/conn/ConnectTimeoutException
    //   201	213	467	java/net/MalformedURLException
    //   201	213	502	java/io/IOException
    //   221	249	755	java/net/SocketTimeoutException
    //   221	249	448	org/apache/http/conn/ConnectTimeoutException
    //   221	249	467	java/net/MalformedURLException
    //   221	249	502	java/io/IOException
    //   279	296	755	java/net/SocketTimeoutException
    //   279	296	448	org/apache/http/conn/ConnectTimeoutException
    //   279	296	467	java/net/MalformedURLException
    //   279	296	502	java/io/IOException
    //   304	314	755	java/net/SocketTimeoutException
    //   304	314	448	org/apache/http/conn/ConnectTimeoutException
    //   304	314	467	java/net/MalformedURLException
    //   304	314	502	java/io/IOException
    //   322	335	755	java/net/SocketTimeoutException
    //   322	335	448	org/apache/http/conn/ConnectTimeoutException
    //   322	335	467	java/net/MalformedURLException
    //   322	335	502	java/io/IOException
    //   339	353	382	java/net/SocketTimeoutException
    //   339	353	750	org/apache/http/conn/ConnectTimeoutException
    //   339	353	745	java/net/MalformedURLException
    //   339	353	732	java/io/IOException
    //   369	382	382	java/net/SocketTimeoutException
    //   369	382	750	org/apache/http/conn/ConnectTimeoutException
    //   369	382	745	java/net/MalformedURLException
    //   369	382	732	java/io/IOException
    //   409	414	755	java/net/SocketTimeoutException
    //   409	414	448	org/apache/http/conn/ConnectTimeoutException
    //   409	414	467	java/net/MalformedURLException
    //   409	414	502	java/io/IOException
    //   421	442	382	java/net/SocketTimeoutException
    //   421	442	750	org/apache/http/conn/ConnectTimeoutException
    //   421	442	745	java/net/MalformedURLException
    //   421	442	732	java/io/IOException
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/android/volley/toolbox/BasicNetwork.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */