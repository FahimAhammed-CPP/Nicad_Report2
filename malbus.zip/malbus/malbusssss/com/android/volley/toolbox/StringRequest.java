package com.android.volley.toolbox;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import java.io.UnsupportedEncodingException;

public class StringRequest extends Request<String> {
  private Response.Listener<String> mListener;
  
  public StringRequest(int paramInt, String paramString, Response.Listener<String> paramListener, Response.ErrorListener paramErrorListener) {
    super(paramInt, paramString, paramErrorListener);
    this.mListener = paramListener;
  }
  
  public StringRequest(String paramString, Response.Listener<String> paramListener, Response.ErrorListener paramErrorListener) {
    this(0, paramString, paramListener, paramErrorListener);
  }
  
  protected void deliverResponse(String paramString) {
    if (this.mListener != null)
      this.mListener.onResponse(paramString); 
  }
  
  protected void onFinish() {
    super.onFinish();
    this.mListener = null;
  }
  
  protected Response<String> parseNetworkResponse(NetworkResponse paramNetworkResponse) {
    String str;
    try {
      str = new String();
      this(paramNetworkResponse.data, HttpHeaderParser.parseCharset(paramNetworkResponse.headers));
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      str = new String(paramNetworkResponse.data);
    } 
    return Response.success(str, HttpHeaderParser.parseCacheHeaders(paramNetworkResponse));
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/android/volley/toolbox/StringRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */