package com.android.volley.toolbox;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.widget.ImageView;
import com.android.volley.VolleyError;

public class NetworkImageView extends ImageView {
  private int mDefaultImageId;
  
  private int mErrorImageId;
  
  private ImageLoader.ImageContainer mImageContainer;
  
  private ImageLoader mImageLoader;
  
  private String mUrl;
  
  public NetworkImageView(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public NetworkImageView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public NetworkImageView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  private void setDefaultImageOrNull() {
    if (this.mDefaultImageId != 0) {
      setImageResource(this.mDefaultImageId);
      return;
    } 
    setImageBitmap(null);
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    invalidate();
  }
  
  public String getImageURL() {
    return this.mUrl;
  }
  
  void loadImageIfNecessary(final boolean isInLayoutPass) {
    boolean bool;
    int i = getWidth();
    int j = getHeight();
    ImageView.ScaleType scaleType = getScaleType();
    int k = 0;
    int m = 0;
    if (getLayoutParams() != null) {
      if ((getLayoutParams()).width == -2) {
        k = 1;
      } else {
        k = 0;
      } 
      if ((getLayoutParams()).height == -2) {
        m = 1;
      } else {
        m = 0;
      } 
    } 
    if (k && m) {
      bool = true;
    } else {
      bool = false;
    } 
    if (i != 0 || j != 0 || bool) {
      if (TextUtils.isEmpty(this.mUrl)) {
        if (this.mImageContainer != null) {
          this.mImageContainer.cancelRequest();
          this.mImageContainer = null;
        } 
        setDefaultImageOrNull();
        return;
      } 
      if (this.mImageContainer != null && this.mImageContainer.getRequestUrl() != null)
        if (!this.mImageContainer.getRequestUrl().equals(this.mUrl)) {
          this.mImageContainer.cancelRequest();
          setDefaultImageOrNull();
        } else {
          return;
        }  
      if (k) {
        k = 0;
      } else {
        k = i;
      } 
      if (m) {
        m = 0;
      } else {
        m = j;
      } 
      this.mImageContainer = this.mImageLoader.get(this.mUrl, new ImageLoader.ImageListener() {
            public void onErrorResponse(VolleyError param1VolleyError) {
              if (NetworkImageView.this.mErrorImageId != 0)
                NetworkImageView.this.setImageResource(NetworkImageView.this.mErrorImageId); 
            }
            
            public void onResponse(final ImageLoader.ImageContainer response, boolean param1Boolean) {
              if (param1Boolean && isInLayoutPass) {
                NetworkImageView.this.post(new Runnable() {
                      public void run() {
                        NetworkImageView.null.this.onResponse(response, false);
                      }
                    });
                return;
              } 
              if (response.getBitmap() != null) {
                NetworkImageView.this.setImageBitmap(response.getBitmap());
                return;
              } 
              if (NetworkImageView.this.mDefaultImageId != 0)
                NetworkImageView.this.setImageResource(NetworkImageView.this.mDefaultImageId); 
            }
          }k, m, scaleType);
    } 
  }
  
  protected void onDetachedFromWindow() {
    if (this.mImageContainer != null) {
      this.mImageContainer.cancelRequest();
      setImageBitmap(null);
      this.mImageContainer = null;
    } 
    super.onDetachedFromWindow();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    loadImageIfNecessary(true);
  }
  
  public void setDefaultImageResId(int paramInt) {
    this.mDefaultImageId = paramInt;
  }
  
  public void setErrorImageResId(int paramInt) {
    this.mErrorImageId = paramInt;
  }
  
  public void setImageUrl(String paramString, ImageLoader paramImageLoader) {
    this.mUrl = paramString;
    this.mImageLoader = paramImageLoader;
    loadImageIfNecessary(false);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/android/volley/toolbox/NetworkImageView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */