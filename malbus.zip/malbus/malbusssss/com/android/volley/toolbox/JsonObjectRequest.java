package com.android.volley.toolbox;

import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import java.io.UnsupportedEncodingException;
import org.json.JSONException;
import org.json.JSONObject;

public class JsonObjectRequest extends JsonRequest<JSONObject> {
  public JsonObjectRequest(int paramInt, String paramString, Response.Listener<JSONObject> paramListener, Response.ErrorListener paramErrorListener) {
    super(paramInt, paramString, null, paramListener, paramErrorListener);
  }
  
  public JsonObjectRequest(int paramInt, String paramString1, String paramString2, Response.Listener<JSONObject> paramListener, Response.ErrorListener paramErrorListener) {
    super(paramInt, paramString1, paramString2, paramListener, paramErrorListener);
  }
  
  public JsonObjectRequest(int paramInt, String paramString, JSONObject paramJSONObject, Response.Listener<JSONObject> paramListener, Response.ErrorListener paramErrorListener) {
    super(paramInt, paramString, str, paramListener, paramErrorListener);
  }
  
  public JsonObjectRequest(String paramString, Response.Listener<JSONObject> paramListener, Response.ErrorListener paramErrorListener) {
    super(0, paramString, null, paramListener, paramErrorListener);
  }
  
  public JsonObjectRequest(String paramString, JSONObject paramJSONObject, Response.Listener<JSONObject> paramListener, Response.ErrorListener paramErrorListener) {
    this(bool, paramString, paramJSONObject, paramListener, paramErrorListener);
  }
  
  protected Response<JSONObject> parseNetworkResponse(NetworkResponse paramNetworkResponse) {
    Response<JSONObject> response;
    try {
      String str = new String();
      this(paramNetworkResponse.data, HttpHeaderParser.parseCharset(paramNetworkResponse.headers, "utf-8"));
      JSONObject jSONObject = new JSONObject();
      this(str);
      response = Response.success(jSONObject, HttpHeaderParser.parseCacheHeaders(paramNetworkResponse));
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      response = Response.error((VolleyError)new ParseError(unsupportedEncodingException));
    } catch (JSONException jSONException) {
      response = Response.error((VolleyError)new ParseError((Throwable)jSONException));
    } 
    return response;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/android/volley/toolbox/JsonObjectRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */