package com.android.volley;

public class TimeoutError extends VolleyError {}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/android/volley/TimeoutError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */