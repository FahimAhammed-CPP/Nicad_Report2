package com.android.volley;

public class NetworkError extends VolleyError {
  public NetworkError() {}
  
  public NetworkError(NetworkResponse paramNetworkResponse) {
    super(paramNetworkResponse);
  }
  
  public NetworkError(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/android/volley/NetworkError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */