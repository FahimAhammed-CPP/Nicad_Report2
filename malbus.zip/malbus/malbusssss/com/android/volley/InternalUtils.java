package com.android.volley;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

class InternalUtils {
  private static final char[] HEX_CHARS = "0123456789ABCDEF".toCharArray();
  
  private static String convertToHex(byte[] paramArrayOfbyte) {
    char[] arrayOfChar = new char[paramArrayOfbyte.length * 2];
    for (byte b = 0; b < paramArrayOfbyte.length; b++) {
      int i = paramArrayOfbyte[b] & 0xFF;
      arrayOfChar[b * 2] = (char)HEX_CHARS[i >>> 4];
      arrayOfChar[b * 2 + 1] = (char)HEX_CHARS[i & 0xF];
    } 
    return new String(arrayOfChar);
  }
  
  public static String sha1Hash(String paramString) {
    NoSuchAlgorithmException noSuchAlgorithmException1;
    NoSuchAlgorithmException noSuchAlgorithmException2 = null;
    try {
      MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
      byte[] arrayOfByte = paramString.getBytes("UTF-8");
      messageDigest.update(arrayOfByte, 0, arrayOfByte.length);
      String str = convertToHex(messageDigest.digest());
    } catch (NoSuchAlgorithmException null) {
      noSuchAlgorithmException1.printStackTrace();
      noSuchAlgorithmException1 = noSuchAlgorithmException2;
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      unsupportedEncodingException.printStackTrace();
      noSuchAlgorithmException1 = noSuchAlgorithmException2;
    } 
    return (String)noSuchAlgorithmException1;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/android/volley/InternalUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */