package com.android.volley;

import android.os.Process;
import java.util.concurrent.BlockingQueue;

public class CacheDispatcher extends Thread {
  private static final boolean DEBUG = VolleyLog.DEBUG;
  
  private final Cache mCache;
  
  private final BlockingQueue<Request<?>> mCacheQueue;
  
  private final ResponseDelivery mDelivery;
  
  private final BlockingQueue<Request<?>> mNetworkQueue;
  
  private volatile boolean mQuit = false;
  
  public CacheDispatcher(BlockingQueue<Request<?>> paramBlockingQueue1, BlockingQueue<Request<?>> paramBlockingQueue2, Cache paramCache, ResponseDelivery paramResponseDelivery) {
    this.mCacheQueue = paramBlockingQueue1;
    this.mNetworkQueue = paramBlockingQueue2;
    this.mCache = paramCache;
    this.mDelivery = paramResponseDelivery;
  }
  
  public void quit() {
    this.mQuit = true;
    interrupt();
  }
  
  public void run() {
    if (DEBUG)
      VolleyLog.v("start new dispatcher", new Object[0]); 
    Process.setThreadPriority(10);
    this.mCache.initialize();
    while (true) {
      try {
        Request request = this.mCacheQueue.take();
        try {
          request.addMarker("cache-queue-take");
          if (request.isCanceled()) {
            request.finish("cache-discard-canceled");
            continue;
          } 
        } catch (Exception null) {
          VolleyLog.e(exception, "Unhandled exception %s", new Object[] { exception.toString() });
          continue;
        } 
      } catch (InterruptedException exception) {
        if (this.mQuit)
          return; 
        continue;
      } 
      Cache.Entry entry = this.mCache.get(exception.getCacheKey());
      if (entry == null) {
        exception.addMarker("cache-miss");
        this.mNetworkQueue.put(exception);
        continue;
      } 
      if (entry.isExpired()) {
        exception.addMarker("cache-hit-expired");
        exception.setCacheEntry(entry);
        this.mNetworkQueue.put(exception);
        continue;
      } 
      exception.addMarker("cache-hit");
      NetworkResponse networkResponse = new NetworkResponse();
      this(entry.data, entry.responseHeaders);
      Response<?> response = exception.parseNetworkResponse(networkResponse);
      exception.addMarker("cache-hit-parsed");
      if (!entry.refreshNeeded()) {
        this.mDelivery.postResponse((Request<?>)exception, response);
        continue;
      } 
      exception.addMarker("cache-hit-refresh-needed");
      exception.setCacheEntry(entry);
      response.intermediate = true;
      ResponseDelivery responseDelivery = this.mDelivery;
      Runnable runnable = new Runnable() {
          public void run() {
            try {
              CacheDispatcher.this.mNetworkQueue.put(finalRequest);
            } catch (InterruptedException interruptedException) {}
          }
        };
      super(this, (Request)exception);
      responseDelivery.postResponse((Request<?>)exception, response, runnable);
    } 
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/android/volley/CacheDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */