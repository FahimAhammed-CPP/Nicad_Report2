package com.gc.materialdesign;

public final class R {
  public static final class anim {
    public static final int dialog_main_hide_amination = 2130968587;
    
    public static final int dialog_main_show_amination = 2130968588;
    
    public static final int dialog_root_hide_amin = 2130968589;
    
    public static final int dialog_root_show_amin = 2130968590;
    
    public static final int progress_indeterminate_animation = 2130968594;
    
    public static final int snackbar_hide_animation = 2130968606;
    
    public static final int snackbar_show_animation = 2130968607;
  }
  
  public static final class attr {
    public static final int animate = 2130772229;
    
    public static final int check = 2130772224;
    
    public static final int checkBoxSize = 2130772225;
    
    public static final int clickAfterRipple = 2130772231;
    
    public static final int iconDrawable = 2130772227;
    
    public static final int iconSize = 2130772228;
    
    public static final int max = 2130772219;
    
    public static final int min = 2130772220;
    
    public static final int progress = 2130772222;
    
    public static final int ringWidth = 2130772223;
    
    public static final int rippleBorderRadius = 2130772230;
    
    public static final int rippleColor = 2130772216;
    
    public static final int rippleSpeed = 2130772217;
    
    public static final int showNumberIndicator = 2130772218;
    
    public static final int thumbSize = 2130772226;
    
    public static final int value = 2130772221;
  }
  
  public static final class color {
    public static final int green = 2131427401;
    
    public static final int thumbColor = 2131427472;
  }
  
  public static final class drawable {
    public static final int background_button = 2130837587;
    
    public static final int background_button_float = 2130837588;
    
    public static final int background_button_rectangle = 2130837589;
    
    public static final int background_checkbox = 2130837591;
    
    public static final int background_checkbox_check = 2130837592;
    
    public static final int background_checkbox_uncheck = 2130837593;
    
    public static final int background_progress = 2130837594;
    
    public static final int background_switch_ball_uncheck = 2130837595;
    
    public static final int background_transparent = 2130837597;
    
    public static final int dialog_background = 2130837691;
    
    public static final int float_button1_shadowp = 2130837706;
    
    public static final int float_button_shadow1 = 2130837707;
    
    public static final int ic_launcher = 2130837769;
    
    public static final int ic_reloj_max = 2130837876;
    
    public static final int shadow_down = 2130837999;
    
    public static final int shadow_right = 2130838000;
    
    public static final int sprite_check = 2130838002;
  }
  
  public static final class id {
    public static final int blue = 2131558463;
    
    public static final int button_accept = 2131558705;
    
    public static final int button_cancel = 2131558704;
    
    public static final int buttonflat = 2131559013;
    
    public static final int contentDialog = 2131558701;
    
    public static final int contentSelector = 2131558684;
    
    public static final int dialog_rootView = 2131558700;
    
    public static final int green = 2131558464;
    
    public static final int message = 2131558703;
    
    public static final int message_scrollView = 2131558702;
    
    public static final int number_indicator_spinner_content = 2131558992;
    
    public static final int progressBarCircularIndetermininate = 2131559001;
    
    public static final int red = 2131558466;
    
    public static final int rootSelector = 2131558683;
    
    public static final int shape_bacground = 2131559018;
    
    public static final int snackbar = 2131559012;
    
    public static final int text = 2131558682;
    
    public static final int title = 2131558562;
    
    public static final int viewColor = 2131558685;
  }
  
  public static final class layout {
    public static final int color_selector = 2130903084;
    
    public static final int dialog = 2130903087;
    
    public static final int number_indicator_spinner = 2130903157;
    
    public static final int progress_dialog = 2130903162;
    
    public static final int snackbar = 2130903171;
  }
  
  public static final class styleable {
    public static final int[] CustomAttributes = new int[] { 
        2130772216, 2130772217, 2130772218, 2130772219, 2130772220, 2130772221, 2130772222, 2130772223, 2130772224, 2130772225, 
        2130772226, 2130772227, 2130772228, 2130772229, 2130772230, 2130772231 };
    
    public static final int CustomAttributes_animate = 13;
    
    public static final int CustomAttributes_check = 8;
    
    public static final int CustomAttributes_checkBoxSize = 9;
    
    public static final int CustomAttributes_clickAfterRipple = 15;
    
    public static final int CustomAttributes_iconDrawable = 11;
    
    public static final int CustomAttributes_iconSize = 12;
    
    public static final int CustomAttributes_max = 3;
    
    public static final int CustomAttributes_min = 4;
    
    public static final int CustomAttributes_progress = 6;
    
    public static final int CustomAttributes_ringWidth = 7;
    
    public static final int CustomAttributes_rippleBorderRadius = 14;
    
    public static final int CustomAttributes_rippleColor = 0;
    
    public static final int CustomAttributes_rippleSpeed = 1;
    
    public static final int CustomAttributes_showNumberIndicator = 2;
    
    public static final int CustomAttributes_thumbSize = 10;
    
    public static final int CustomAttributes_value = 5;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */