package com.gc.materialdesign.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.AttributeSet;
import android.widget.RelativeLayout;

public class CustomView extends RelativeLayout {
  static final String ANDROIDXML = "http://schemas.android.com/apk/res/android";
  
  static final String MATERIALDESIGNXML = "http://schemas.android.com/apk/res-auto";
  
  boolean animation = false;
  
  int beforeBackground;
  
  final int disabledBackgroundColor = Color.parseColor("#E2E2E2");
  
  public boolean isLastTouch = false;
  
  public CustomView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  protected void onAnimationEnd() {
    super.onAnimationEnd();
    this.animation = false;
  }
  
  protected void onAnimationStart() {
    super.onAnimationStart();
    this.animation = true;
  }
  
  protected void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.animation)
      invalidate(); 
  }
  
  public void setEnabled(boolean paramBoolean) {
    super.setEnabled(paramBoolean);
    if (paramBoolean) {
      setBackgroundColor(this.beforeBackground);
    } else {
      setBackgroundColor(this.disabledBackgroundColor);
    } 
    invalidate();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/views/CustomView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */