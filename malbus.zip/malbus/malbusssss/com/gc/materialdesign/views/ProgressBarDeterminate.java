package com.gc.materialdesign.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.gc.materialdesign.R;
import com.gc.materialdesign.utils.Utils;

public class ProgressBarDeterminate extends CustomView {
  int backgroundColor = Color.parseColor("#1E88E5");
  
  int max = 100;
  
  int min = 0;
  
  int pendindProgress = -1;
  
  int progress = 0;
  
  View progressView;
  
  public ProgressBarDeterminate(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setAttributes(paramAttributeSet);
  }
  
  public int getProgress() {
    return this.progress;
  }
  
  protected int makePressColor() {
    return Color.argb(128, this.backgroundColor >> 16 & 0xFF, this.backgroundColor >> 8 & 0xFF, this.backgroundColor >> 0 & 0xFF);
  }
  
  protected void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.pendindProgress != -1)
      setProgress(this.pendindProgress); 
  }
  
  protected void setAttributes(AttributeSet paramAttributeSet) {
    this.progressView = new View(getContext());
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(1, 1);
    this.progressView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    this.progressView.setBackgroundResource(R.drawable.background_progress);
    addView(this.progressView);
    int i = paramAttributeSet.getAttributeResourceValue("http://schemas.android.com/apk/res/android", "background", -1);
    if (i != -1) {
      setBackgroundColor(getResources().getColor(i));
    } else {
      i = paramAttributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "background", -1);
      if (i != -1) {
        setBackgroundColor(i);
      } else {
        setBackgroundColor(Color.parseColor("#1E88E5"));
      } 
    } 
    this.min = paramAttributeSet.getAttributeIntValue("http://schemas.android.com/apk/res-auto", "min", 0);
    this.max = paramAttributeSet.getAttributeIntValue("http://schemas.android.com/apk/res-auto", "max", 100);
    this.progress = paramAttributeSet.getAttributeIntValue("http://schemas.android.com/apk/res-auto", "progress", this.min);
    setMinimumHeight(Utils.dpToPx(3.0F, getResources()));
    post(new Runnable() {
          public void run() {
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams)ProgressBarDeterminate.this.progressView.getLayoutParams();
            layoutParams.height = ProgressBarDeterminate.this.getHeight();
            ProgressBarDeterminate.this.progressView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
          }
        });
  }
  
  public void setBackgroundColor(int paramInt) {
    this.backgroundColor = paramInt;
    if (isEnabled())
      this.beforeBackground = this.backgroundColor; 
    ((GradientDrawable)((LayerDrawable)this.progressView.getBackground()).findDrawableByLayerId(R.id.shape_bacground)).setColor(paramInt);
    super.setBackgroundColor(makePressColor());
  }
  
  public void setMax(int paramInt) {
    this.max = paramInt;
  }
  
  public void setMin(int paramInt) {
    this.min = paramInt;
  }
  
  public void setProgress(int paramInt) {
    if (getWidth() == 0) {
      this.pendindProgress = paramInt;
      return;
    } 
    this.progress = paramInt;
    int i = paramInt;
    if (paramInt > this.max)
      i = this.max; 
    paramInt = i;
    if (i < this.min)
      paramInt = this.min; 
    i = this.max;
    int j = this.min;
    double d = paramInt / (i - j);
    paramInt = (int)(getWidth() * d);
    RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams)this.progressView.getLayoutParams();
    layoutParams.width = paramInt;
    layoutParams.height = getHeight();
    this.progressView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    this.pendindProgress = -1;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/views/ProgressBarDeterminate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */