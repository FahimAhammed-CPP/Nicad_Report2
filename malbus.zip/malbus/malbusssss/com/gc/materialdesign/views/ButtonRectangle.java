package com.gc.materialdesign.views;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.gc.materialdesign.R;
import com.gc.materialdesign.utils.Utils;

public class ButtonRectangle extends Button {
  Integer height;
  
  int paddingBottom;
  
  int paddingLeft;
  
  int paddingRight;
  
  int paddingTop;
  
  TextView textButton;
  
  Integer width;
  
  public ButtonRectangle(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setDefaultProperties();
  }
  
  protected void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.x != -1.0F) {
      Rect rect1 = new Rect(0, 0, getWidth() - Utils.dpToPx(6.0F, getResources()), getHeight() - Utils.dpToPx(7.0F, getResources()));
      Rect rect2 = new Rect(Utils.dpToPx(6.0F, getResources()), Utils.dpToPx(6.0F, getResources()), getWidth() - Utils.dpToPx(6.0F, getResources()), getHeight() - Utils.dpToPx(7.0F, getResources()));
      paramCanvas.drawBitmap(makeCircle(), rect1, rect2, null);
      invalidate();
    } 
  }
  
  protected void setAttributes(AttributeSet paramAttributeSet) {
    String str;
    int i = paramAttributeSet.getAttributeResourceValue("http://schemas.android.com/apk/res/android", "background", -1);
    if (i != -1) {
      setBackgroundColor(getResources().getColor(i));
    } else {
      this.background = paramAttributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "background", -1);
      if (this.background != -1)
        setBackgroundColor(this.background); 
    } 
    paramAttributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "padding");
    i = paramAttributeSet.getAttributeResourceValue("http://schemas.android.com/apk/res/android", "text", -1);
    if (i != -1) {
      str = getResources().getString(i);
    } else {
      str = paramAttributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "text");
    } 
    if (str != null) {
      this.textButton = new TextView(getContext());
      this.textButton.setText(str);
      this.textButton.setTextColor(-1);
      this.textButton.setTypeface(null, 1);
      RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
      layoutParams.addRule(13, -1);
      layoutParams.setMargins(Utils.dpToPx(5.0F, getResources()), Utils.dpToPx(5.0F, getResources()), Utils.dpToPx(5.0F, getResources()), Utils.dpToPx(5.0F, getResources()));
      this.textButton.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
      addView((View)this.textButton);
      i = paramAttributeSet.getAttributeResourceValue("http://schemas.android.com/apk/res/android", "textColor", -1);
      if (i != -1) {
        this.textButton.setTextColor(i);
      } else {
        i = paramAttributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "textColor", -1);
        if (i != -1)
          this.textButton.setTextColor(i); 
      } 
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, new int[] { 16842901 });
      float f = typedArray.getDimension(0, -1.0F);
      typedArray.recycle();
      if (f != -1.0F)
        this.textButton.setTextSize(f); 
    } 
    this.rippleSpeed = paramAttributeSet.getAttributeFloatValue("http://schemas.android.com/apk/res-auto", "rippleSpeed", Utils.dpToPx(6.0F, getResources()));
  }
  
  protected void setDefaultProperties() {
    this.minWidth = 80;
    this.minHeight = 36;
    this.background = R.drawable.background_button_rectangle;
    super.setDefaultProperties();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/views/ButtonRectangle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */