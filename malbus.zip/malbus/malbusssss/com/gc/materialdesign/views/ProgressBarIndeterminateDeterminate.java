package com.gc.materialdesign.views;

import android.content.Context;
import android.util.AttributeSet;
import com.nineoldandroids.animation.Animator;
import com.nineoldandroids.animation.ObjectAnimator;
import com.nineoldandroids.view.ViewHelper;

public class ProgressBarIndeterminateDeterminate extends ProgressBarDeterminate {
  ObjectAnimator animation;
  
  boolean firstProgress = true;
  
  boolean runAnimation = true;
  
  public ProgressBarIndeterminateDeterminate(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    post(new Runnable() {
          public void run() {
            ProgressBarIndeterminateDeterminate.this.setProgress(60);
            ViewHelper.setX(ProgressBarIndeterminateDeterminate.this.progressView, (ProgressBarIndeterminateDeterminate.this.getWidth() + ProgressBarIndeterminateDeterminate.this.progressView.getWidth() / 2));
            ProgressBarIndeterminateDeterminate.this.animation = ObjectAnimator.ofFloat(ProgressBarIndeterminateDeterminate.this.progressView, "x", new float[] { (-this.this$0.progressView.getWidth() / 2) });
            ProgressBarIndeterminateDeterminate.this.animation.setDuration(1200L);
            ProgressBarIndeterminateDeterminate.this.animation.addListener(new Animator.AnimatorListener() {
                  int cont = 1;
                  
                  int duration = 1200;
                  
                  int suma = 1;
                  
                  public void onAnimationCancel(Animator param2Animator) {}
                  
                  public void onAnimationEnd(Animator param2Animator) {
                    if (ProgressBarIndeterminateDeterminate.this.runAnimation) {
                      ViewHelper.setX(ProgressBarIndeterminateDeterminate.this.progressView, (ProgressBarIndeterminateDeterminate.this.getWidth() + ProgressBarIndeterminateDeterminate.this.progressView.getWidth() / 2));
                      this.cont += this.suma;
                      ProgressBarIndeterminateDeterminate.this.animation = ObjectAnimator.ofFloat(ProgressBarIndeterminateDeterminate.this.progressView, "x", new float[] { (-this.this$1.this$0.progressView.getWidth() / 2) });
                      ProgressBarIndeterminateDeterminate.this.animation.setDuration((this.duration / this.cont));
                      ProgressBarIndeterminateDeterminate.this.animation.addListener(this);
                      ProgressBarIndeterminateDeterminate.this.animation.start();
                      if (this.cont == 3 || this.cont == 1)
                        this.suma *= -1; 
                    } 
                  }
                  
                  public void onAnimationRepeat(Animator param2Animator) {}
                  
                  public void onAnimationStart(Animator param2Animator) {}
                });
            ProgressBarIndeterminateDeterminate.this.animation.start();
          }
        });
  }
  
  private void stopIndeterminate() {
    this.animation.cancel();
    ViewHelper.setX(this.progressView, 0.0F);
    this.runAnimation = false;
  }
  
  public void setProgress(int paramInt) {
    if (this.firstProgress) {
      this.firstProgress = false;
    } else {
      stopIndeterminate();
    } 
    super.setProgress(paramInt);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/views/ProgressBarIndeterminateDeterminate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */