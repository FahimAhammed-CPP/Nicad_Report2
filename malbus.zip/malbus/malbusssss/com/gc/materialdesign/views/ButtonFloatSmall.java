package com.gc.materialdesign.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.gc.materialdesign.R;
import com.gc.materialdesign.utils.Utils;

public class ButtonFloatSmall extends ButtonFloat {
  public ButtonFloatSmall(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setDefaultProperties();
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(Utils.dpToPx(this.sizeIcon, getResources()), Utils.dpToPx(this.sizeIcon, getResources()));
    layoutParams.addRule(13, -1);
    this.icon.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
  }
  
  protected void setDefaultProperties() {
    this.rippleSpeed = Utils.dpToPx(2.0F, getResources());
    this.rippleSize = 10;
    setMinimumHeight(Utils.dpToPx((this.sizeRadius * 2), getResources()));
    setMinimumWidth(Utils.dpToPx((this.sizeRadius * 2), getResources()));
    setBackgroundResource(R.drawable.background_button_float);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/views/ButtonFloatSmall.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */