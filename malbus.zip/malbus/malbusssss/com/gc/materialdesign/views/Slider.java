package com.gc.materialdesign.views;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Xfermode;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.gc.materialdesign.R;
import com.gc.materialdesign.utils.Utils;
import com.nineoldandroids.view.ViewHelper;

public class Slider extends CustomView {
  int backgroundColor = Color.parseColor("#4CAF50");
  
  Ball ball;
  
  int max = 100;
  
  int min = 0;
  
  NumberIndicator numberIndicator;
  
  OnValueChangedListener onValueChangedListener;
  
  boolean placedBall = false;
  
  boolean press = false;
  
  boolean showNumberIndicator = false;
  
  int value = 0;
  
  public Slider(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setAttributes(paramAttributeSet);
  }
  
  private void placeBall() {
    ViewHelper.setX(this.ball, (getHeight() / 2 - this.ball.getWidth() / 2));
    this.ball.xIni = ViewHelper.getX(this.ball);
    this.ball.xFin = (getWidth() - getHeight() / 2 - this.ball.getWidth() / 2);
    this.ball.xCen = (getWidth() / 2 - this.ball.getWidth() / 2);
    this.placedBall = true;
  }
  
  public int getMax() {
    return this.max;
  }
  
  public int getMin() {
    return this.min;
  }
  
  public OnValueChangedListener getOnValueChangedListener() {
    return this.onValueChangedListener;
  }
  
  public int getValue() {
    return this.value;
  }
  
  public void invalidate() {
    if (this.ball != null)
      this.ball.invalidate(); 
    super.invalidate();
  }
  
  public boolean isShowNumberIndicator() {
    return this.showNumberIndicator;
  }
  
  protected int makePressColor() {
    int i = this.backgroundColor >> 16 & 0xFF;
    int j = this.backgroundColor >> 8 & 0xFF;
    int k = this.backgroundColor >> 0 & 0xFF;
    if (i - 30 < 0) {
      i = 0;
    } else {
      i -= 30;
    } 
    if (j - 30 < 0) {
      j = 0;
    } else {
      j -= 30;
    } 
    if (k - 30 < 0) {
      k = 0;
      return Color.argb(70, i, j, k);
    } 
    k -= 30;
    return Color.argb(70, i, j, k);
  }
  
  protected void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (!this.placedBall)
      placeBall(); 
    if (this.value == this.min) {
      Bitmap bitmap = Bitmap.createBitmap(paramCanvas.getWidth(), paramCanvas.getHeight(), Bitmap.Config.ARGB_8888);
      Canvas canvas = new Canvas(bitmap);
      Paint paint = new Paint();
      paint.setColor(Color.parseColor("#B0B0B0"));
      paint.setStrokeWidth(Utils.dpToPx(2.0F, getResources()));
      canvas.drawLine((getHeight() / 2), (getHeight() / 2), (getWidth() - getHeight() / 2), (getHeight() / 2), paint);
      paint = new Paint();
      paint.setColor(getResources().getColor(17170445));
      paint.setXfermode((Xfermode)new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
      canvas.drawCircle(ViewHelper.getX(this.ball) + (this.ball.getWidth() / 2), ViewHelper.getY(this.ball) + (this.ball.getHeight() / 2), (this.ball.getWidth() / 2), paint);
      paramCanvas.drawBitmap(bitmap, 0.0F, 0.0F, new Paint());
    } else {
      Paint paint = new Paint();
      paint.setColor(Color.parseColor("#B0B0B0"));
      paint.setStrokeWidth(Utils.dpToPx(2.0F, getResources()));
      paramCanvas.drawLine((getHeight() / 2), (getHeight() / 2), (getWidth() - getHeight() / 2), (getHeight() / 2), paint);
      paint.setColor(this.backgroundColor);
      float f = (this.ball.xFin - this.ball.xIni) / (this.max - this.min);
      int i = this.value;
      int j = this.min;
      paramCanvas.drawLine((getHeight() / 2), (getHeight() / 2), (i - j) * f + (getHeight() / 2), (getHeight() / 2), paint);
    } 
    if (this.press && !this.showNumberIndicator) {
      Paint paint = new Paint();
      paint.setColor(this.backgroundColor);
      paint.setAntiAlias(true);
      paramCanvas.drawCircle(ViewHelper.getX(this.ball) + (this.ball.getWidth() / 2), (getHeight() / 2), (getHeight() / 3), paint);
    } 
    invalidate();
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    this.isLastTouch = true;
    if (isEnabled()) {
      if (paramMotionEvent.getAction() == 0 || paramMotionEvent.getAction() == 2) {
        if (this.numberIndicator != null && !this.numberIndicator.isShowing())
          this.numberIndicator.show(); 
        if (paramMotionEvent.getX() <= getWidth() && paramMotionEvent.getX() >= 0.0F) {
          int i;
          this.press = true;
          float f1 = (this.ball.xFin - this.ball.xIni) / (this.max - this.min);
          if (paramMotionEvent.getX() > this.ball.xFin) {
            i = this.max;
          } else if (paramMotionEvent.getX() < this.ball.xIni) {
            i = this.min;
          } else {
            i = this.min + (int)((paramMotionEvent.getX() - this.ball.xIni) / f1);
          } 
          if (this.value != i) {
            this.value = i;
            if (this.onValueChangedListener != null)
              this.onValueChangedListener.onValueChanged(i); 
          } 
          float f2 = paramMotionEvent.getX();
          f1 = f2;
          if (f2 < this.ball.xIni)
            f1 = this.ball.xIni; 
          f2 = f1;
          if (f1 > this.ball.xFin)
            f2 = this.ball.xFin; 
          ViewHelper.setX(this.ball, f2);
          this.ball.changeBackground();
          if (this.numberIndicator != null) {
            this.numberIndicator.indicator.x = f2;
            this.numberIndicator.indicator.finalY = (Utils.getRelativeTop((View)this) - getHeight() / 2);
            this.numberIndicator.indicator.finalSize = (getHeight() / 2);
            this.numberIndicator.numberIndicator.setText("");
          } 
          return true;
        } 
        this.press = false;
        this.isLastTouch = false;
        if (this.numberIndicator != null)
          this.numberIndicator.dismiss(); 
        return true;
      } 
    } else {
      return true;
    } 
    if (paramMotionEvent.getAction() == 1 || paramMotionEvent.getAction() == 3) {
      if (this.numberIndicator != null)
        this.numberIndicator.dismiss(); 
      this.isLastTouch = false;
      this.press = false;
    } 
    return true;
  }
  
  protected void setAttributes(AttributeSet paramAttributeSet) {
    setBackgroundResource(R.drawable.background_transparent);
    setMinimumHeight(Utils.dpToPx(48.0F, getResources()));
    setMinimumWidth(Utils.dpToPx(80.0F, getResources()));
    int i = paramAttributeSet.getAttributeResourceValue("http://schemas.android.com/apk/res/android", "background", -1);
    if (i != -1) {
      setBackgroundColor(getResources().getColor(i));
    } else {
      i = paramAttributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "background", -1);
      if (i != -1)
        setBackgroundColor(i); 
    } 
    this.showNumberIndicator = paramAttributeSet.getAttributeBooleanValue("http://schemas.android.com/apk/res-auto", "showNumberIndicator", false);
    this.min = paramAttributeSet.getAttributeIntValue("http://schemas.android.com/apk/res-auto", "min", 0);
    this.max = paramAttributeSet.getAttributeIntValue("http://schemas.android.com/apk/res-auto", "max", 0);
    this.value = paramAttributeSet.getAttributeIntValue("http://schemas.android.com/apk/res-auto", "value", this.min);
    this.ball = new Ball(getContext());
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(Utils.dpToPx(20.0F, getResources()), Utils.dpToPx(20.0F, getResources()));
    layoutParams.addRule(15, -1);
    this.ball.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    addView(this.ball);
    if (this.showNumberIndicator)
      this.numberIndicator = new NumberIndicator(getContext()); 
  }
  
  public void setBackgroundColor(int paramInt) {
    this.backgroundColor = paramInt;
    if (isEnabled())
      this.beforeBackground = this.backgroundColor; 
  }
  
  public void setMax(int paramInt) {
    this.max = paramInt;
  }
  
  public void setMin(int paramInt) {
    this.min = paramInt;
  }
  
  public void setOnValueChangedListener(OnValueChangedListener paramOnValueChangedListener) {
    this.onValueChangedListener = paramOnValueChangedListener;
  }
  
  public void setShowNumberIndicator(boolean paramBoolean) {
    NumberIndicator numberIndicator;
    this.showNumberIndicator = paramBoolean;
    if (paramBoolean) {
      numberIndicator = new NumberIndicator(getContext());
    } else {
      numberIndicator = null;
    } 
    this.numberIndicator = numberIndicator;
  }
  
  public void setValue(final int value) {
    if (!this.placedBall) {
      post(new Runnable() {
            public void run() {
              Slider.this.setValue(value);
            }
          });
      return;
    } 
    this.value = value;
    float f = (this.ball.xFin - this.ball.xIni) / this.max;
    ViewHelper.setX(this.ball, value * f + (getHeight() / 2) - (this.ball.getWidth() / 2));
    this.ball.changeBackground();
  }
  
  class Ball extends View {
    float xCen;
    
    float xFin;
    
    float xIni;
    
    public Ball(Context param1Context) {
      super(param1Context);
      setBackgroundResource(R.drawable.background_switch_ball_uncheck);
    }
    
    public void changeBackground() {
      if (Slider.this.value != Slider.this.min) {
        setBackgroundResource(R.drawable.background_checkbox);
        ((GradientDrawable)((LayerDrawable)getBackground()).findDrawableByLayerId(R.id.shape_bacground)).setColor(Slider.this.backgroundColor);
        return;
      } 
      setBackgroundResource(R.drawable.background_switch_ball_uncheck);
    }
  }
  
  class Indicator extends RelativeLayout {
    boolean animate = true;
    
    float finalSize = 0.0F;
    
    float finalY = 0.0F;
    
    boolean numberIndicatorResize = false;
    
    float size = 0.0F;
    
    float x = 0.0F;
    
    float y = 0.0F;
    
    public Indicator(Context param1Context) {
      super(param1Context);
      setBackgroundColor(getResources().getColor(17170445));
    }
    
    protected void onDraw(Canvas param1Canvas) {
      super.onDraw(param1Canvas);
      if (!this.numberIndicatorResize) {
        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams)Slider.this.numberIndicator.numberIndicator.getLayoutParams();
        layoutParams.height = (int)this.finalSize * 2;
        layoutParams.width = (int)this.finalSize * 2;
        Slider.this.numberIndicator.numberIndicator.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
      } 
      Paint paint = new Paint();
      paint.setAntiAlias(true);
      paint.setColor(Slider.this.backgroundColor);
      if (this.animate) {
        if (this.y == 0.0F)
          this.y = this.finalY + this.finalSize * 2.0F; 
        this.y -= Utils.dpToPx(6.0F, getResources());
        this.size += Utils.dpToPx(2.0F, getResources());
      } 
      float f = ViewHelper.getX(Slider.this.ball);
      param1Canvas.drawCircle(Utils.getRelativeLeft((View)Slider.this.ball.getParent()) + f + (Slider.this.ball.getWidth() / 2), this.y, this.size, paint);
      if (this.animate && this.size >= this.finalSize)
        this.animate = false; 
      if (!this.animate) {
        TextView textView = Slider.this.numberIndicator.numberIndicator;
        f = ViewHelper.getX(Slider.this.ball);
        ViewHelper.setX((View)textView, Utils.getRelativeLeft((View)Slider.this.ball.getParent()) + f + (Slider.this.ball.getWidth() / 2) - this.size);
        ViewHelper.setY((View)Slider.this.numberIndicator.numberIndicator, this.y - this.size);
        Slider.this.numberIndicator.numberIndicator.setText(Slider.this.value + "");
      } 
      invalidate();
    }
  }
  
  class NumberIndicator extends Dialog {
    Slider.Indicator indicator;
    
    TextView numberIndicator;
    
    public NumberIndicator(Context param1Context) {
      super(param1Context, 16973839);
    }
    
    public void dismiss() {
      super.dismiss();
      this.indicator.y = 0.0F;
      this.indicator.size = 0.0F;
      this.indicator.animate = true;
    }
    
    public void onBackPressed() {}
    
    protected void onCreate(Bundle param1Bundle) {
      requestWindowFeature(1);
      super.onCreate(param1Bundle);
      setContentView(R.layout.number_indicator_spinner);
      setCanceledOnTouchOutside(false);
      RelativeLayout relativeLayout = (RelativeLayout)findViewById(R.id.number_indicator_spinner_content);
      this.indicator = new Slider.Indicator(getContext());
      relativeLayout.addView((View)this.indicator);
      this.numberIndicator = new TextView(getContext());
      this.numberIndicator.setTextColor(-1);
      this.numberIndicator.setGravity(17);
      relativeLayout.addView((View)this.numberIndicator);
      this.indicator.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
    }
  }
  
  public static interface OnValueChangedListener {
    void onValueChanged(int param1Int);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/views/Slider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */