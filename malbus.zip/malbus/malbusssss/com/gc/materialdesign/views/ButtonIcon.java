package com.gc.materialdesign.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import com.gc.materialdesign.utils.Utils;

public class ButtonIcon extends ButtonFloat {
  public ButtonIcon(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    try {
      ColorDrawable colorDrawable = new ColorDrawable();
      this(getResources().getColor(17170445));
      setBackground((Drawable)colorDrawable);
    } catch (NoSuchMethodError noSuchMethodError) {
      setBackgroundDrawable((Drawable)new ColorDrawable(getResources().getColor(17170445)));
    } 
    this.rippleSpeed = Utils.dpToPx(2.0F, getResources());
    this.rippleSize = Utils.dpToPx(5.0F, getResources());
  }
  
  protected int makePressColor() {
    return this.backgroundColor;
  }
  
  protected void onDraw(Canvas paramCanvas) {
    if (this.x != -1.0F) {
      Paint paint = new Paint();
      paint.setAntiAlias(true);
      paint.setColor(makePressColor());
      paramCanvas.drawCircle(this.x, this.y, this.radius, paint);
      if (this.radius > (getHeight() / this.rippleSize))
        this.radius += this.rippleSpeed; 
      if (this.radius >= (getWidth() / 2) - this.rippleSpeed) {
        this.x = -1.0F;
        this.y = -1.0F;
        this.radius = (getHeight() / this.rippleSize);
        if (this.onClickListener != null && this.clickAfterRipple)
          this.onClickListener.onClick((View)this); 
      } 
      invalidate();
    } 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    boolean bool = super.onTouchEvent(paramMotionEvent);
    if (this.x != -1.0F) {
      this.x = (getWidth() / 2);
      this.y = (getHeight() / 2);
    } 
    return bool;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/views/ButtonIcon.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */