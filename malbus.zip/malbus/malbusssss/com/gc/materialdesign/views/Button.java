package com.gc.materialdesign.views;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import com.gc.materialdesign.R;
import com.gc.materialdesign.utils.Utils;

public abstract class Button extends CustomView {
  static final String ANDROIDXML = "http://schemas.android.com/apk/res/android";
  
  int background;
  
  int backgroundColor = Color.parseColor("#1E88E5");
  
  boolean clickAfterRipple = true;
  
  int minHeight;
  
  int minWidth;
  
  View.OnClickListener onClickListener;
  
  float radius = -1.0F;
  
  Integer rippleColor;
  
  int rippleSize = 3;
  
  float rippleSpeed = 12.0F;
  
  TextView textButton;
  
  float x = -1.0F;
  
  float y = -1.0F;
  
  public Button(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setDefaultProperties();
    this.clickAfterRipple = paramAttributeSet.getAttributeBooleanValue("http://schemas.android.com/apk/res-auto", "animate", true);
    setAttributes(paramAttributeSet);
    this.beforeBackground = this.backgroundColor;
    if (this.rippleColor == null)
      this.rippleColor = Integer.valueOf(makePressColor()); 
  }
  
  public float getRippleSpeed() {
    return this.rippleSpeed;
  }
  
  public String getText() {
    return this.textButton.getText().toString();
  }
  
  public TextView getTextView() {
    return this.textButton;
  }
  
  public Bitmap makeCircle() {
    Bitmap bitmap = Bitmap.createBitmap(getWidth() - Utils.dpToPx(6.0F, getResources()), getHeight() - Utils.dpToPx(7.0F, getResources()), Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    canvas.drawARGB(0, 0, 0, 0);
    Paint paint = new Paint();
    paint.setAntiAlias(true);
    paint.setColor(this.rippleColor.intValue());
    canvas.drawCircle(this.x, this.y, this.radius, paint);
    if (this.radius > (getHeight() / this.rippleSize))
      this.radius += this.rippleSpeed; 
    if (this.radius >= getWidth()) {
      this.x = -1.0F;
      this.y = -1.0F;
      this.radius = (getHeight() / this.rippleSize);
      if (this.onClickListener != null && this.clickAfterRipple)
        this.onClickListener.onClick((View)this); 
    } 
    return bitmap;
  }
  
  protected int makePressColor() {
    int i = this.backgroundColor >> 16 & 0xFF;
    int j = this.backgroundColor >> 8 & 0xFF;
    int k = this.backgroundColor >> 0 & 0xFF;
    if (i - 30 < 0) {
      i = 0;
    } else {
      i -= 30;
    } 
    if (j - 30 < 0) {
      j = 0;
    } else {
      j -= 30;
    } 
    if (k - 30 < 0) {
      k = 0;
      return Color.rgb(i, j, k);
    } 
    k -= 30;
    return Color.rgb(i, j, k);
  }
  
  protected void onFocusChanged(boolean paramBoolean, int paramInt, Rect paramRect) {
    if (!paramBoolean) {
      this.x = -1.0F;
      this.y = -1.0F;
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    return true;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    invalidate();
    if (isEnabled()) {
      this.isLastTouch = true;
      if (paramMotionEvent.getAction() == 0) {
        this.radius = (getHeight() / this.rippleSize);
        this.x = paramMotionEvent.getX();
        this.y = paramMotionEvent.getY();
        return true;
      } 
    } else {
      return true;
    } 
    if (paramMotionEvent.getAction() == 2) {
      this.radius = (getHeight() / this.rippleSize);
      this.x = paramMotionEvent.getX();
      this.y = paramMotionEvent.getY();
      if (paramMotionEvent.getX() > getWidth() || paramMotionEvent.getX() < 0.0F || paramMotionEvent.getY() > getHeight() || paramMotionEvent.getY() < 0.0F) {
        this.isLastTouch = false;
        this.x = -1.0F;
        this.y = -1.0F;
      } 
      return true;
    } 
    if (paramMotionEvent.getAction() == 1) {
      if (paramMotionEvent.getX() <= getWidth() && paramMotionEvent.getX() >= 0.0F && paramMotionEvent.getY() <= getHeight() && paramMotionEvent.getY() >= 0.0F) {
        this.radius++;
        if (!this.clickAfterRipple && this.onClickListener != null)
          this.onClickListener.onClick((View)this); 
        return true;
      } 
      this.isLastTouch = false;
      this.x = -1.0F;
      this.y = -1.0F;
      return true;
    } 
    if (paramMotionEvent.getAction() == 3) {
      this.isLastTouch = false;
      this.x = -1.0F;
      this.y = -1.0F;
    } 
    return true;
  }
  
  protected abstract void setAttributes(AttributeSet paramAttributeSet);
  
  public void setBackgroundColor(int paramInt) {
    this.backgroundColor = paramInt;
    if (isEnabled())
      this.beforeBackground = this.backgroundColor; 
    try {
      ((GradientDrawable)((LayerDrawable)getBackground()).findDrawableByLayerId(R.id.shape_bacground)).setColor(this.backgroundColor);
      this.rippleColor = Integer.valueOf(makePressColor());
    } catch (Exception exception) {}
  }
  
  protected void setDefaultProperties() {
    setMinimumHeight(Utils.dpToPx(this.minHeight, getResources()));
    setMinimumWidth(Utils.dpToPx(this.minWidth, getResources()));
    setBackgroundResource(this.background);
    setBackgroundColor(this.backgroundColor);
  }
  
  public void setOnClickListener(View.OnClickListener paramOnClickListener) {
    this.onClickListener = paramOnClickListener;
  }
  
  public void setRippleSpeed(float paramFloat) {
    this.rippleSpeed = paramFloat;
  }
  
  public void setText(String paramString) {
    this.textButton.setText(paramString);
  }
  
  public void setTextColor(int paramInt) {
    this.textButton.setTextColor(paramInt);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/views/Button.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */