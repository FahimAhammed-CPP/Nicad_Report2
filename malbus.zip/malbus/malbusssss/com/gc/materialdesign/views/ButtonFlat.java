package com.gc.materialdesign.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.gc.materialdesign.R;
import com.gc.materialdesign.utils.Utils;

public class ButtonFlat extends Button {
  TextView textButton;
  
  public ButtonFlat(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  public String getText() {
    return this.textButton.getText().toString();
  }
  
  public TextView getTextView() {
    return this.textButton;
  }
  
  protected int makePressColor() {
    return Color.parseColor("#88DDDDDD");
  }
  
  protected void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.x != -1.0F) {
      Paint paint = new Paint();
      paint.setAntiAlias(true);
      paint.setColor(makePressColor());
      paramCanvas.drawCircle(this.x, this.y, this.radius, paint);
      if (this.radius > (getHeight() / this.rippleSize))
        this.radius += this.rippleSpeed; 
      if (this.radius >= getWidth()) {
        this.x = -1.0F;
        this.y = -1.0F;
        this.radius = (getHeight() / this.rippleSize);
        if (this.onClickListener != null && this.clickAfterRipple)
          this.onClickListener.onClick((View)this); 
      } 
      invalidate();
    } 
  }
  
  protected void setAttributes(AttributeSet paramAttributeSet) {
    String str;
    int i = paramAttributeSet.getAttributeResourceValue("http://schemas.android.com/apk/res/android", "text", -1);
    if (i != -1) {
      str = getResources().getString(i);
    } else {
      str = paramAttributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "text");
    } 
    if (str != null) {
      this.textButton = new TextView(getContext());
      this.textButton.setText(str.toUpperCase());
      this.textButton.setTextColor(this.backgroundColor);
      this.textButton.setTypeface(null, 1);
      RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
      layoutParams.addRule(13, -1);
      this.textButton.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
      addView((View)this.textButton);
    } 
    i = paramAttributeSet.getAttributeResourceValue("http://schemas.android.com/apk/res/android", "background", -1);
    if (i != -1) {
      setBackgroundColor(getResources().getColor(i));
      return;
    } 
    this.background = paramAttributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "background", -1);
    if (this.background != -1)
      setBackgroundColor(this.background); 
  }
  
  public void setBackgroundColor(int paramInt) {
    this.backgroundColor = paramInt;
    if (isEnabled())
      this.beforeBackground = this.backgroundColor; 
    this.textButton.setTextColor(paramInt);
  }
  
  protected void setDefaultProperties() {
    this.minHeight = 36;
    this.minWidth = 88;
    this.rippleSize = 3;
    setMinimumHeight(Utils.dpToPx(this.minHeight, getResources()));
    setMinimumWidth(Utils.dpToPx(this.minWidth, getResources()));
    setBackgroundResource(R.drawable.background_transparent);
  }
  
  public void setText(String paramString) {
    this.textButton.setText(paramString.toUpperCase());
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/views/ButtonFlat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */