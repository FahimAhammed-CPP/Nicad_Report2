package com.gc.materialdesign.views;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Xfermode;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.gc.materialdesign.R;
import com.gc.materialdesign.utils.Utils;
import com.nineoldandroids.animation.ObjectAnimator;
import com.nineoldandroids.view.ViewHelper;

public class Switch extends CustomView {
  int backgroundColor = Color.parseColor("#4CAF50");
  
  Ball ball;
  
  boolean check = false;
  
  boolean eventCheck = false;
  
  OnCheckListener onCheckListener;
  
  boolean placedBall = false;
  
  boolean press = false;
  
  public Switch(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setAttributes(paramAttributeSet);
    setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            if (Switch.this.check) {
              Switch.this.setChecked(false);
              return;
            } 
            Switch.this.setChecked(true);
          }
        });
  }
  
  private void placeBall() {
    ViewHelper.setX(this.ball, (getHeight() / 2 - this.ball.getWidth() / 2));
    this.ball.xIni = ViewHelper.getX(this.ball);
    this.ball.xFin = (getWidth() - getHeight() / 2 - this.ball.getWidth() / 2);
    this.ball.xCen = (getWidth() / 2 - this.ball.getWidth() / 2);
    this.placedBall = true;
    this.ball.animateCheck();
  }
  
  public boolean isCheck() {
    return this.check;
  }
  
  protected int makePressColor() {
    int i = this.backgroundColor >> 16 & 0xFF;
    int j = this.backgroundColor >> 8 & 0xFF;
    int k = this.backgroundColor >> 0 & 0xFF;
    if (i - 30 < 0) {
      i = 0;
    } else {
      i -= 30;
    } 
    if (j - 30 < 0) {
      j = 0;
    } else {
      j -= 30;
    } 
    if (k - 30 < 0) {
      k = 0;
      return Color.argb(70, i, j, k);
    } 
    k -= 30;
    return Color.argb(70, i, j, k);
  }
  
  protected void onDraw(Canvas paramCanvas) {
    int i;
    super.onDraw(paramCanvas);
    if (!this.placedBall)
      placeBall(); 
    Bitmap bitmap = Bitmap.createBitmap(paramCanvas.getWidth(), paramCanvas.getHeight(), Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    Paint paint1 = new Paint();
    paint1.setAntiAlias(true);
    if (this.check) {
      i = this.backgroundColor;
    } else {
      i = Color.parseColor("#B0B0B0");
    } 
    paint1.setColor(i);
    paint1.setStrokeWidth(Utils.dpToPx(2.0F, getResources()));
    canvas.drawLine((getHeight() / 2), (getHeight() / 2), (getWidth() - getHeight() / 2), (getHeight() / 2), paint1);
    Paint paint2 = new Paint();
    paint2.setAntiAlias(true);
    paint2.setColor(getResources().getColor(17170445));
    paint2.setXfermode((Xfermode)new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
    canvas.drawCircle(ViewHelper.getX(this.ball) + (this.ball.getWidth() / 2), ViewHelper.getY(this.ball) + (this.ball.getHeight() / 2), (this.ball.getWidth() / 2), paint2);
    paramCanvas.drawBitmap(bitmap, 0.0F, 0.0F, new Paint());
    if (this.press) {
      if (this.check) {
        i = makePressColor();
      } else {
        i = Color.parseColor("#446D6D6D");
      } 
      paint1.setColor(i);
      paramCanvas.drawCircle(ViewHelper.getX(this.ball) + (this.ball.getWidth() / 2), (getHeight() / 2), (getHeight() / 2), paint1);
    } 
    invalidate();
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (isEnabled()) {
      this.isLastTouch = true;
      if (paramMotionEvent.getAction() == 0) {
        this.press = true;
        return true;
      } 
    } else {
      return true;
    } 
    if (paramMotionEvent.getAction() == 2) {
      float f1 = paramMotionEvent.getX();
      float f2 = f1;
      if (f1 < this.ball.xIni)
        f2 = this.ball.xIni; 
      f1 = f2;
      if (f2 > this.ball.xFin)
        f1 = this.ball.xFin; 
      if (f1 > this.ball.xCen) {
        this.check = true;
      } else {
        this.check = false;
      } 
      ViewHelper.setX(this.ball, f1);
      this.ball.changeBackground();
      if (paramMotionEvent.getX() <= getWidth() && paramMotionEvent.getX() >= 0.0F) {
        this.isLastTouch = false;
        this.press = false;
      } 
      return true;
    } 
    if (paramMotionEvent.getAction() == 1 || paramMotionEvent.getAction() == 3) {
      this.press = false;
      this.isLastTouch = false;
      if (this.eventCheck != this.check) {
        this.eventCheck = this.check;
        if (this.onCheckListener != null)
          this.onCheckListener.onCheck(this, this.check); 
      } 
      if (paramMotionEvent.getX() <= getWidth() && paramMotionEvent.getX() >= 0.0F)
        this.ball.animateCheck(); 
    } 
    return true;
  }
  
  protected void setAttributes(AttributeSet paramAttributeSet) {
    setBackgroundResource(R.drawable.background_transparent);
    setMinimumHeight(Utils.dpToPx(48.0F, getResources()));
    setMinimumWidth(Utils.dpToPx(80.0F, getResources()));
    int i = paramAttributeSet.getAttributeResourceValue("http://schemas.android.com/apk/res/android", "background", -1);
    if (i != -1) {
      setBackgroundColor(getResources().getColor(i));
    } else {
      i = paramAttributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "background", -1);
      if (i != -1)
        setBackgroundColor(i); 
    } 
    this.check = paramAttributeSet.getAttributeBooleanValue("http://schemas.android.com/apk/res-auto", "check", false);
    this.eventCheck = this.check;
    this.ball = new Ball(getContext());
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(Utils.dpToPx(20.0F, getResources()), Utils.dpToPx(20.0F, getResources()));
    layoutParams.addRule(15, -1);
    this.ball.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    addView(this.ball);
  }
  
  public void setBackgroundColor(int paramInt) {
    this.backgroundColor = paramInt;
    if (isEnabled())
      this.beforeBackground = this.backgroundColor; 
  }
  
  public void setChecked(boolean paramBoolean) {
    invalidate();
    this.check = paramBoolean;
    this.ball.animateCheck();
  }
  
  public void setOncheckListener(OnCheckListener paramOnCheckListener) {
    this.onCheckListener = paramOnCheckListener;
  }
  
  class Ball extends View {
    float xCen;
    
    float xFin;
    
    float xIni;
    
    public Ball(Context param1Context) {
      super(param1Context);
      setBackgroundResource(R.drawable.background_switch_ball_uncheck);
    }
    
    public void animateCheck() {
      ObjectAnimator objectAnimator;
      changeBackground();
      if (Switch.this.check) {
        objectAnimator = ObjectAnimator.ofFloat(this, "x", new float[] { this.this$0.ball.xFin });
      } else {
        objectAnimator = ObjectAnimator.ofFloat(this, "x", new float[] { this.this$0.ball.xIni });
      } 
      objectAnimator.setDuration(300L);
      objectAnimator.start();
    }
    
    public void changeBackground() {
      if (Switch.this.check) {
        setBackgroundResource(R.drawable.background_checkbox);
        ((GradientDrawable)((LayerDrawable)getBackground()).findDrawableByLayerId(R.id.shape_bacground)).setColor(Switch.this.backgroundColor);
        return;
      } 
      setBackgroundResource(R.drawable.background_switch_ball_uncheck);
    }
  }
  
  public static interface OnCheckListener {
    void onCheck(Switch param1Switch, boolean param1Boolean);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/views/Switch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */