package com.gc.materialdesign.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import com.gc.materialdesign.R;
import com.nineoldandroids.animation.Animator;
import com.nineoldandroids.animation.ObjectAnimator;
import com.nineoldandroids.view.ViewHelper;

public class ProgressBarIndeterminate extends ProgressBarDeterminate {
  public ProgressBarIndeterminate(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    post(new Runnable() {
          public void run() {
            ProgressBarIndeterminate.this.setProgress(60);
            Animation animation = AnimationUtils.loadAnimation(ProgressBarIndeterminate.this.getContext(), R.anim.progress_indeterminate_animation);
            ProgressBarIndeterminate.this.progressView.startAnimation(animation);
            ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(ProgressBarIndeterminate.this.progressView, "x", new float[] { this.this$0.getWidth() });
            objectAnimator.setDuration(1200L);
            objectAnimator.addListener(new Animator.AnimatorListener() {
                  int cont = 1;
                  
                  int duration = 1200;
                  
                  int suma = 1;
                  
                  public void onAnimationCancel(Animator param2Animator) {}
                  
                  public void onAnimationEnd(Animator param2Animator) {
                    ViewHelper.setX(ProgressBarIndeterminate.this.progressView, (-ProgressBarIndeterminate.this.progressView.getWidth() / 2));
                    this.cont += this.suma;
                    ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(ProgressBarIndeterminate.this.progressView, "x", new float[] { this.this$1.this$0.getWidth() });
                    objectAnimator.setDuration((this.duration / this.cont));
                    objectAnimator.addListener(this);
                    objectAnimator.start();
                    if (this.cont == 3 || this.cont == 1)
                      this.suma *= -1; 
                  }
                  
                  public void onAnimationRepeat(Animator param2Animator) {}
                  
                  public void onAnimationStart(Animator param2Animator) {}
                });
            objectAnimator.start();
          }
        });
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/views/ProgressBarIndeterminate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */