package com.gc.materialdesign.views;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class LayoutRipple extends CustomView {
  int background;
  
  int backgroundColor = Color.parseColor("#FFFFFF");
  
  View.OnClickListener onClickListener;
  
  float radius = -1.0F;
  
  Integer rippleColor;
  
  int rippleSize = 3;
  
  float rippleSpeed = 10.0F;
  
  float x = -1.0F;
  
  Float xRippleOrigin;
  
  float y = -1.0F;
  
  Float yRippleOrigin;
  
  public LayoutRipple(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setAttributes(paramAttributeSet);
  }
  
  public Bitmap makeCircle() {
    float f;
    Bitmap bitmap = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    canvas.drawARGB(0, 0, 0, 0);
    Paint paint = new Paint();
    paint.setAntiAlias(true);
    if (this.rippleColor == null)
      this.rippleColor = Integer.valueOf(makePressColor()); 
    paint.setColor(this.rippleColor.intValue());
    if (this.xRippleOrigin == null) {
      f = this.x;
    } else {
      f = this.xRippleOrigin.floatValue();
    } 
    this.x = f;
    if (this.yRippleOrigin == null) {
      f = this.y;
    } else {
      f = this.yRippleOrigin.floatValue();
    } 
    this.y = f;
    canvas.drawCircle(this.x, this.y, this.radius, paint);
    if (this.radius > (getHeight() / this.rippleSize))
      this.radius += this.rippleSpeed; 
    if (this.radius >= getWidth()) {
      this.x = -1.0F;
      this.y = -1.0F;
      this.radius = (getHeight() / this.rippleSize);
      if (this.onClickListener != null)
        this.onClickListener.onClick((View)this); 
    } 
    return bitmap;
  }
  
  protected int makePressColor() {
    int i = this.backgroundColor >> 16 & 0xFF;
    int j = this.backgroundColor >> 8 & 0xFF;
    int k = this.backgroundColor >> 0 & 0xFF;
    if (i - 30 < 0) {
      i = 0;
    } else {
      i -= 30;
    } 
    if (j - 30 < 0) {
      j = 0;
    } else {
      j -= 30;
    } 
    if (k - 30 < 0) {
      k = 0;
      return Color.rgb(i, j, k);
    } 
    k -= 30;
    return Color.rgb(i, j, k);
  }
  
  protected void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.x != -1.0F) {
      Rect rect1 = new Rect(0, 0, getWidth(), getHeight());
      Rect rect2 = new Rect(0, 0, getWidth(), getHeight());
      paramCanvas.drawBitmap(makeCircle(), rect1, rect2, null);
      invalidate();
    } 
  }
  
  protected void onFocusChanged(boolean paramBoolean, int paramInt, Rect paramRect) {
    if (!paramBoolean) {
      this.x = -1.0F;
      this.y = -1.0F;
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    return true;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    invalidate();
    if (isEnabled()) {
      this.isLastTouch = true;
      if (paramMotionEvent.getAction() == 0) {
        this.radius = (getHeight() / this.rippleSize);
        this.x = paramMotionEvent.getX();
        this.y = paramMotionEvent.getY();
      } else if (paramMotionEvent.getAction() == 2) {
        this.radius = (getHeight() / this.rippleSize);
        this.x = paramMotionEvent.getX();
        this.y = paramMotionEvent.getY();
        if (paramMotionEvent.getX() > getWidth() || paramMotionEvent.getX() < 0.0F || paramMotionEvent.getY() > getHeight() || paramMotionEvent.getY() < 0.0F) {
          this.isLastTouch = false;
          this.x = -1.0F;
          this.y = -1.0F;
        } 
      } else if (paramMotionEvent.getAction() == 1) {
        if (paramMotionEvent.getX() <= getWidth() && paramMotionEvent.getX() >= 0.0F && paramMotionEvent.getY() <= getHeight() && paramMotionEvent.getY() >= 0.0F) {
          this.radius++;
        } else {
          this.isLastTouch = false;
          this.x = -1.0F;
          this.y = -1.0F;
        } 
      } 
      if (paramMotionEvent.getAction() == 3) {
        this.isLastTouch = false;
        this.x = -1.0F;
        this.y = -1.0F;
      } 
    } 
    return true;
  }
  
  protected void setAttributes(AttributeSet paramAttributeSet) {
    int i = paramAttributeSet.getAttributeResourceValue("http://schemas.android.com/apk/res/android", "background", -1);
    if (i != -1) {
      setBackgroundColor(getResources().getColor(i));
    } else {
      this.background = paramAttributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "background", -1);
      if (this.background != -1) {
        setBackgroundColor(this.background);
      } else {
        setBackgroundColor(this.backgroundColor);
      } 
    } 
    i = paramAttributeSet.getAttributeResourceValue("http://schemas.android.com/apk/res-auto", "rippleColor", -1);
    if (i != -1) {
      setRippleColor(getResources().getColor(i));
    } else {
      i = paramAttributeSet.getAttributeIntValue("http://schemas.android.com/apk/res-auto", "rippleColor", -1);
      if (i != -1) {
        setRippleColor(i);
      } else {
        setRippleColor(makePressColor());
      } 
    } 
    this.rippleSpeed = paramAttributeSet.getAttributeFloatValue("http://schemas.android.com/apk/res-auto", "rippleSpeed", 20.0F);
  }
  
  public void setBackgroundColor(int paramInt) {
    this.backgroundColor = paramInt;
    if (isEnabled())
      this.beforeBackground = this.backgroundColor; 
    super.setBackgroundColor(paramInt);
  }
  
  public void setOnClickListener(View.OnClickListener paramOnClickListener) {
    this.onClickListener = paramOnClickListener;
  }
  
  public void setRippleColor(int paramInt) {
    this.rippleColor = Integer.valueOf(paramInt);
  }
  
  public void setRippleSpeed(int paramInt) {
    this.rippleSpeed = paramInt;
  }
  
  public void setxRippleOrigin(Float paramFloat) {
    this.xRippleOrigin = paramFloat;
  }
  
  public void setyRippleOrigin(Float paramFloat) {
    this.yRippleOrigin = paramFloat;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/views/LayoutRipple.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */