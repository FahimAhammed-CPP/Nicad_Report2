package com.gc.materialdesign.views;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Xfermode;
import android.util.AttributeSet;
import com.gc.materialdesign.utils.Utils;

public class ProgressBarCircularIndeterminate extends CustomView {
  static final String ANDROIDXML = "http://schemas.android.com/apk/res/android";
  
  int arcD = 1;
  
  int arcO = 0;
  
  int backgroundColor = Color.parseColor("#1E88E5");
  
  int cont = 0;
  
  boolean firstAnimationOver = false;
  
  int limite = 0;
  
  float radius1 = 0.0F;
  
  float radius2 = 0.0F;
  
  float rotateAngle = 0.0F;
  
  public ProgressBarCircularIndeterminate(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setAttributes(paramAttributeSet);
  }
  
  private void drawFirstAnimation(Canvas paramCanvas) {
    if (this.radius1 < (getWidth() / 2)) {
      float f;
      Paint paint1 = new Paint();
      paint1.setAntiAlias(true);
      paint1.setColor(makePressColor());
      if (this.radius1 >= (getWidth() / 2)) {
        f = getWidth() / 2.0F;
      } else {
        f = this.radius1 + 1.0F;
      } 
      this.radius1 = f;
      paramCanvas.drawCircle((getWidth() / 2), (getHeight() / 2), this.radius1, paint1);
      return;
    } 
    Bitmap bitmap = Bitmap.createBitmap(paramCanvas.getWidth(), paramCanvas.getHeight(), Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint();
    paint.setAntiAlias(true);
    paint.setColor(makePressColor());
    canvas.drawCircle((getWidth() / 2), (getHeight() / 2), (getHeight() / 2), paint);
    paint = new Paint();
    paint.setAntiAlias(true);
    paint.setColor(getResources().getColor(17170445));
    paint.setXfermode((Xfermode)new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
    if (this.cont >= 50) {
      float f;
      if (this.radius2 >= (getWidth() / 2)) {
        f = getWidth() / 2.0F;
      } else {
        f = this.radius2 + 1.0F;
      } 
      this.radius2 = f;
    } else {
      float f;
      if (this.radius2 >= (getWidth() / 2 - Utils.dpToPx(4.0F, getResources()))) {
        f = getWidth() / 2.0F - Utils.dpToPx(4.0F, getResources());
      } else {
        f = this.radius2 + 1.0F;
      } 
      this.radius2 = f;
    } 
    canvas.drawCircle((getWidth() / 2), (getHeight() / 2), this.radius2, paint);
    paramCanvas.drawBitmap(bitmap, 0.0F, 0.0F, new Paint());
    if (this.radius2 >= (getWidth() / 2 - Utils.dpToPx(4.0F, getResources())))
      this.cont++; 
    if (this.radius2 >= (getWidth() / 2))
      this.firstAnimationOver = true; 
  }
  
  private void drawSecondAnimation(Canvas paramCanvas) {
    if (this.arcO == this.limite)
      this.arcD += 6; 
    if (this.arcD >= 290 || this.arcO > this.limite) {
      this.arcO += 6;
      this.arcD -= 6;
    } 
    if (this.arcO > this.limite + 290) {
      this.limite = this.arcO;
      this.arcO = this.limite;
      this.arcD = 1;
    } 
    this.rotateAngle += 4.0F;
    paramCanvas.rotate(this.rotateAngle, (getWidth() / 2), (getHeight() / 2));
    Bitmap bitmap = Bitmap.createBitmap(paramCanvas.getWidth(), paramCanvas.getHeight(), Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint();
    paint.setAntiAlias(true);
    paint.setColor(this.backgroundColor);
    canvas.drawArc(new RectF(0.0F, 0.0F, getWidth(), getHeight()), this.arcO, this.arcD, true, paint);
    paint = new Paint();
    paint.setAntiAlias(true);
    paint.setColor(getResources().getColor(17170445));
    paint.setXfermode((Xfermode)new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
    canvas.drawCircle((getWidth() / 2), (getHeight() / 2), (getWidth() / 2 - Utils.dpToPx(4.0F, getResources())), paint);
    paramCanvas.drawBitmap(bitmap, 0.0F, 0.0F, new Paint());
  }
  
  protected int makePressColor() {
    return Color.argb(128, this.backgroundColor >> 16 & 0xFF, this.backgroundColor >> 8 & 0xFF, this.backgroundColor >> 0 & 0xFF);
  }
  
  protected void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (!this.firstAnimationOver)
      drawFirstAnimation(paramCanvas); 
    if (this.cont > 0)
      drawSecondAnimation(paramCanvas); 
    invalidate();
  }
  
  protected void setAttributes(AttributeSet paramAttributeSet) {
    setMinimumHeight(Utils.dpToPx(32.0F, getResources()));
    setMinimumWidth(Utils.dpToPx(32.0F, getResources()));
    int i = paramAttributeSet.getAttributeResourceValue("http://schemas.android.com/apk/res/android", "background", -1);
    if (i != -1) {
      setBackgroundColor(getResources().getColor(i));
    } else {
      i = paramAttributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "background", -1);
      if (i != -1) {
        setBackgroundColor(i);
      } else {
        setBackgroundColor(Color.parseColor("#1E88E5"));
      } 
    } 
    setMinimumHeight(Utils.dpToPx(3.0F, getResources()));
  }
  
  public void setBackgroundColor(int paramInt) {
    super.setBackgroundColor(getResources().getColor(17170445));
    if (isEnabled())
      this.beforeBackground = this.backgroundColor; 
    this.backgroundColor = paramInt;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/views/ProgressBarCircularIndeterminate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */