package com.gc.materialdesign.views;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Xfermode;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.BounceInterpolator;
import android.view.animation.Interpolator;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.gc.materialdesign.R;
import com.gc.materialdesign.utils.Utils;
import com.nineoldandroids.animation.ObjectAnimator;
import com.nineoldandroids.view.ViewHelper;

public class ButtonFloat extends Button {
  Drawable drawableIcon;
  
  Integer height;
  
  float hidePosition;
  
  ImageView icon;
  
  public boolean isShow = false;
  
  float showPosition;
  
  int sizeIcon = 24;
  
  int sizeRadius = 28;
  
  Integer width;
  
  public ButtonFloat(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setBackgroundResource(R.drawable.background_button_float);
    setBackgroundColor(this.backgroundColor);
    this.sizeRadius = 28;
    setDefaultProperties();
    this.icon = new ImageView(paramContext);
    this.icon.setAdjustViewBounds(true);
    this.icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
    if (this.drawableIcon != null)
      this.icon.setImageDrawable(this.drawableIcon); 
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(Utils.dpToPx(this.sizeIcon, getResources()), Utils.dpToPx(this.sizeIcon, getResources()));
    layoutParams.addRule(13, -1);
    this.icon.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    addView((View)this.icon);
  }
  
  public Bitmap cropCircle(Bitmap paramBitmap) {
    Bitmap bitmap = Bitmap.createBitmap(paramBitmap.getWidth(), paramBitmap.getHeight(), Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint();
    Rect rect = new Rect(0, 0, paramBitmap.getWidth(), paramBitmap.getHeight());
    paint.setAntiAlias(true);
    canvas.drawARGB(0, 0, 0, 0);
    paint.setColor(-12434878);
    canvas.drawCircle((paramBitmap.getWidth() / 2), (paramBitmap.getHeight() / 2), (paramBitmap.getWidth() / 2), paint);
    paint.setXfermode((Xfermode)new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
    canvas.drawBitmap(paramBitmap, rect, rect, paint);
    return bitmap;
  }
  
  public Drawable getDrawableIcon() {
    return this.drawableIcon;
  }
  
  public ImageView getIcon() {
    return this.icon;
  }
  
  public TextView getTextView() {
    return null;
  }
  
  public void hide() {
    ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(this, "y", new float[] { this.hidePosition });
    objectAnimator.setInterpolator((Interpolator)new BounceInterpolator());
    objectAnimator.setDuration(1500L);
    objectAnimator.start();
    this.isShow = false;
  }
  
  public boolean isShow() {
    return this.isShow;
  }
  
  protected void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.x != -1.0F) {
      Rect rect1 = new Rect(0, 0, getWidth(), getHeight());
      Rect rect2 = new Rect(Utils.dpToPx(1.0F, getResources()), Utils.dpToPx(2.0F, getResources()), getWidth() - Utils.dpToPx(1.0F, getResources()), getHeight() - Utils.dpToPx(2.0F, getResources()));
      paramCanvas.drawBitmap(cropCircle(makeCircle()), rect1, rect2, null);
      invalidate();
    } 
  }
  
  protected void setAttributes(AttributeSet paramAttributeSet) {
    int i = paramAttributeSet.getAttributeResourceValue("http://schemas.android.com/apk/res/android", "background", -1);
    if (i != -1) {
      setBackgroundColor(getResources().getColor(i));
    } else {
      this.background = paramAttributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "background", -1);
      if (this.background != -1)
        setBackgroundColor(this.background); 
    } 
    i = paramAttributeSet.getAttributeResourceValue("http://schemas.android.com/apk/res-auto", "rippleColor", -1);
    if (i != -1) {
      setRippleColor(getResources().getColor(i));
    } else {
      i = paramAttributeSet.getAttributeIntValue("http://schemas.android.com/apk/res-auto", "rippleColor", -1);
      if (i != -1) {
        setRippleColor(i);
      } else {
        setRippleColor(makePressColor());
      } 
    } 
    i = paramAttributeSet.getAttributeResourceValue("http://schemas.android.com/apk/res-auto", "iconDrawable", -1);
    if (i != -1)
      this.drawableIcon = getResources().getDrawable(i); 
    post(new Runnable() {
          public void run() {
            ButtonFloat.this.showPosition = ViewHelper.getY((View)ButtonFloat.this) - Utils.dpToPx(24.0F, ButtonFloat.this.getResources());
            ButtonFloat.this.hidePosition = ViewHelper.getY((View)ButtonFloat.this) + (ButtonFloat.this.getHeight() * 3);
            if (animate) {
              ViewHelper.setY((View)ButtonFloat.this, ButtonFloat.this.hidePosition);
              ButtonFloat.this.show();
            } 
          }
        });
  }
  
  protected void setDefaultProperties() {
    this.rippleSpeed = Utils.dpToPx(2.0F, getResources());
    this.rippleSize = Utils.dpToPx(5.0F, getResources());
    setMinimumWidth(Utils.dpToPx((this.sizeRadius * 2), getResources()));
    setMinimumHeight(Utils.dpToPx((this.sizeRadius * 2), getResources()));
    this.background = R.drawable.background_button_float;
  }
  
  public void setDrawableIcon(Drawable paramDrawable) {
    this.drawableIcon = paramDrawable;
    try {
      this.icon.setBackground(paramDrawable);
    } catch (NoSuchMethodError noSuchMethodError) {
      this.icon.setBackgroundDrawable(paramDrawable);
    } 
  }
  
  public void setIcon(ImageView paramImageView) {
    this.icon = paramImageView;
  }
  
  public void setRippleColor(int paramInt) {
    this.rippleColor = Integer.valueOf(paramInt);
  }
  
  public void show() {
    ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(this, "y", new float[] { this.showPosition });
    objectAnimator.setInterpolator((Interpolator)new BounceInterpolator());
    objectAnimator.setDuration(1500L);
    objectAnimator.start();
    this.isShow = true;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/views/ButtonFloat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */