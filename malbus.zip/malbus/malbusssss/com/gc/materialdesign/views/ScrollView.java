package com.gc.materialdesign.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.ScrollView;

public class ScrollView extends ScrollView {
  public ScrollView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: iload_2
    //   3: aload_0
    //   4: iconst_0
    //   5: invokevirtual getChildAt : (I)Landroid/view/View;
    //   8: checkcast android/view/ViewGroup
    //   11: invokevirtual getChildCount : ()I
    //   14: if_icmpge -> 59
    //   17: aload_0
    //   18: iconst_0
    //   19: invokevirtual getChildAt : (I)Landroid/view/View;
    //   22: checkcast android/view/ViewGroup
    //   25: iload_2
    //   26: invokevirtual getChildAt : (I)Landroid/view/View;
    //   29: checkcast com/gc/materialdesign/views/CustomView
    //   32: astore_3
    //   33: aload_3
    //   34: getfield isLastTouch : Z
    //   37: ifeq -> 53
    //   40: aload_3
    //   41: aload_1
    //   42: invokevirtual onTouchEvent : (Landroid/view/MotionEvent;)Z
    //   45: pop
    //   46: iconst_1
    //   47: istore #4
    //   49: iload #4
    //   51: ireturn
    //   52: astore_3
    //   53: iinc #2, 1
    //   56: goto -> 2
    //   59: aload_0
    //   60: aload_1
    //   61: invokespecial onTouchEvent : (Landroid/view/MotionEvent;)Z
    //   64: istore #4
    //   66: goto -> 49
    // Exception table:
    //   from	to	target	type
    //   17	46	52	java/lang/ClassCastException
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/views/ScrollView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */