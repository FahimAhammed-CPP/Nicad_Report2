package com.gc.materialdesign;

public final class BuildConfig {
  public static final String APPLICATION_ID = "com.gc.materialdesign";
  
  public static final String BUILD_TYPE = "release";
  
  public static final boolean DEBUG = false;
  
  public static final String FLAVOR = "";
  
  public static final int VERSION_CODE = 7;
  
  public static final String VERSION_NAME = "1.5";
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/BuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */