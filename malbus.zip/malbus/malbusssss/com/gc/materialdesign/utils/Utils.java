package com.gc.materialdesign.utils;

import android.content.res.Resources;
import android.util.TypedValue;
import android.view.View;

public class Utils {
  public static int dpToPx(float paramFloat, Resources paramResources) {
    return (int)TypedValue.applyDimension(1, paramFloat, paramResources.getDisplayMetrics());
  }
  
  public static int getRelativeLeft(View paramView) {
    if (paramView.getId() == 16908290)
      return paramView.getLeft(); 
    null = paramView.getLeft();
    return getRelativeLeft((View)paramView.getParent()) + null;
  }
  
  public static int getRelativeTop(View paramView) {
    if (paramView.getId() == 16908290)
      return paramView.getTop(); 
    null = paramView.getTop();
    return getRelativeTop((View)paramView.getParent()) + null;
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/utils/Utils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */