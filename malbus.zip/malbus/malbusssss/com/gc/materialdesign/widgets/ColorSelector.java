package com.gc.materialdesign.widgets;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import com.gc.materialdesign.R;
import com.gc.materialdesign.views.Slider;

public class ColorSelector extends Dialog implements Slider.OnValueChangedListener {
  View backView;
  
  Slider blue;
  
  int color = -16777216;
  
  View colorView;
  
  Context context;
  
  Slider green;
  
  OnColorSelectedListener onColorSelectedListener;
  
  Slider red;
  
  View view;
  
  public ColorSelector(Context paramContext, Integer paramInteger, OnColorSelectedListener paramOnColorSelectedListener) {
    super(paramContext, 16973839);
    this.context = paramContext;
    this.onColorSelectedListener = paramOnColorSelectedListener;
    if (paramInteger != null)
      this.color = paramInteger.intValue(); 
    setOnDismissListener(new DialogInterface.OnDismissListener() {
          public void onDismiss(DialogInterface param1DialogInterface) {
            if (ColorSelector.this.onColorSelectedListener != null)
              ColorSelector.this.onColorSelectedListener.onColorSelected(ColorSelector.this.color); 
          }
        });
  }
  
  public void dismiss() {
    Animation animation1 = AnimationUtils.loadAnimation(this.context, R.anim.dialog_main_hide_amination);
    animation1.setAnimationListener(new Animation.AnimationListener() {
          public void onAnimationEnd(Animation param1Animation) {
            ColorSelector.this.view.post(new Runnable() {
                  public void run() {
                    ColorSelector.this.dismiss();
                  }
                });
          }
          
          public void onAnimationRepeat(Animation param1Animation) {}
          
          public void onAnimationStart(Animation param1Animation) {}
        });
    Animation animation2 = AnimationUtils.loadAnimation(this.context, R.anim.dialog_root_hide_amin);
    this.view.startAnimation(animation1);
    this.backView.startAnimation(animation2);
  }
  
  protected void onCreate(Bundle paramBundle) {
    requestWindowFeature(1);
    super.onCreate(paramBundle);
    setContentView(R.layout.color_selector);
    this.view = findViewById(R.id.contentSelector);
    this.backView = findViewById(R.id.rootSelector);
    this.backView.setOnTouchListener(new View.OnTouchListener() {
          public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
            if (param1MotionEvent.getX() < ColorSelector.this.view.getLeft() || param1MotionEvent.getX() > ColorSelector.this.view.getRight() || param1MotionEvent.getY() > ColorSelector.this.view.getBottom() || param1MotionEvent.getY() < ColorSelector.this.view.getTop())
              ColorSelector.this.dismiss(); 
            return false;
          }
        });
    this.colorView = findViewById(R.id.viewColor);
    this.colorView.setBackgroundColor(this.color);
    this.colorView.post(new Runnable() {
          public void run() {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)ColorSelector.this.colorView.getLayoutParams();
            layoutParams.height = ColorSelector.this.colorView.getWidth();
            ColorSelector.this.colorView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
          }
        });
    this.red = (Slider)findViewById(R.id.red);
    this.green = (Slider)findViewById(R.id.green);
    this.blue = (Slider)findViewById(R.id.blue);
    int i = this.color;
    int j = this.color;
    int k = this.color;
    this.red.setValue(i >> 16 & 0xFF);
    this.green.setValue(j >> 8 & 0xFF);
    this.blue.setValue(k >> 0 & 0xFF);
    this.red.setOnValueChangedListener(this);
    this.green.setOnValueChangedListener(this);
    this.blue.setOnValueChangedListener(this);
  }
  
  public void onValueChanged(int paramInt) {
    this.color = Color.rgb(this.red.getValue(), this.green.getValue(), this.blue.getValue());
    this.colorView.setBackgroundColor(this.color);
  }
  
  public void show() {
    super.show();
    this.view.startAnimation(AnimationUtils.loadAnimation(this.context, R.anim.dialog_main_show_amination));
    this.backView.startAnimation(AnimationUtils.loadAnimation(this.context, R.anim.dialog_root_show_amin));
  }
  
  public static interface OnColorSelectedListener {
    void onColorSelected(int param1Int);
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/widgets/ColorSelector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */