package com.gc.materialdesign.widgets;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import com.gc.materialdesign.R;
import com.gc.materialdesign.views.ProgressBarCircularIndeterminate;

public class ProgressDialog extends Dialog {
  View backView;
  
  Context context;
  
  int progressColor = -1;
  
  String title;
  
  TextView titleTextView;
  
  View view;
  
  public ProgressDialog(Context paramContext, String paramString) {
    super(paramContext, 16973839);
    this.title = paramString;
    this.context = paramContext;
  }
  
  public ProgressDialog(Context paramContext, String paramString, int paramInt) {
    super(paramContext, 16973839);
    this.title = paramString;
    this.progressColor = paramInt;
    this.context = paramContext;
  }
  
  public void dismiss() {
    Animation animation1 = AnimationUtils.loadAnimation(this.context, R.anim.dialog_main_hide_amination);
    animation1.setAnimationListener(new Animation.AnimationListener() {
          public void onAnimationEnd(Animation param1Animation) {
            ProgressDialog.this.view.post(new Runnable() {
                  public void run() {
                    ProgressDialog.this.dismiss();
                  }
                });
          }
          
          public void onAnimationRepeat(Animation param1Animation) {}
          
          public void onAnimationStart(Animation param1Animation) {}
        });
    Animation animation2 = AnimationUtils.loadAnimation(this.context, R.anim.dialog_root_hide_amin);
    this.view.startAnimation(animation1);
    this.backView.startAnimation(animation2);
  }
  
  public String getTitle() {
    return this.title;
  }
  
  public TextView getTitleTextView() {
    return this.titleTextView;
  }
  
  protected void onCreate(Bundle paramBundle) {
    requestWindowFeature(1);
    super.onCreate(paramBundle);
    setContentView(R.layout.progress_dialog);
    this.view = findViewById(R.id.contentDialog);
    this.backView = findViewById(R.id.dialog_rootView);
    this.backView.setOnTouchListener(new View.OnTouchListener() {
          public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
            if (param1MotionEvent.getX() < ProgressDialog.this.view.getLeft() || param1MotionEvent.getX() > ProgressDialog.this.view.getRight() || param1MotionEvent.getY() > ProgressDialog.this.view.getBottom() || param1MotionEvent.getY() < ProgressDialog.this.view.getTop())
              ProgressDialog.this.dismiss(); 
            return false;
          }
        });
    this.titleTextView = (TextView)findViewById(R.id.title);
    setTitle(this.title);
    if (this.progressColor != -1)
      ((ProgressBarCircularIndeterminate)findViewById(R.id.progressBarCircularIndetermininate)).setBackgroundColor(this.progressColor); 
  }
  
  public void setTitle(String paramString) {
    this.title = paramString;
    if (paramString == null) {
      this.titleTextView.setVisibility(8);
      return;
    } 
    this.titleTextView.setVisibility(0);
    this.titleTextView.setText(paramString);
  }
  
  public void setTitleTextView(TextView paramTextView) {
    this.titleTextView = paramTextView;
  }
  
  public void show() {
    super.show();
    this.view.startAnimation(AnimationUtils.loadAnimation(this.context, R.anim.dialog_main_show_amination));
    this.backView.startAnimation(AnimationUtils.loadAnimation(this.context, R.anim.dialog_root_show_amin));
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/widgets/ProgressDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */