package com.gc.materialdesign.widgets;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import com.gc.materialdesign.R;
import com.gc.materialdesign.views.ButtonFlat;

public class SnackBar extends Dialog {
  Activity activity;
  
  int backgroundButton = Color.parseColor("#1E88E5");
  
  int backgroundSnackBar = Color.parseColor("#333333");
  
  ButtonFlat button;
  
  String buttonText;
  
  Thread dismissTimer = new Thread(new Runnable() {
        public void run() {
          try {
            Thread.sleep(SnackBar.this.mTimer);
          } catch (InterruptedException interruptedException) {
            interruptedException.printStackTrace();
          } 
          SnackBar.this.handler.sendMessage(new Message());
        }
      });
  
  Handler handler = new Handler(new Handler.Callback() {
        public boolean handleMessage(Message param1Message) {
          if (SnackBar.this.onHideListener != null)
            SnackBar.this.onHideListener.onHide(); 
          SnackBar.this.dismiss();
          return false;
        }
      });
  
  private boolean mIndeterminate = false;
  
  private int mTimer = 3000;
  
  View.OnClickListener onClickListener;
  
  OnHideListener onHideListener;
  
  String text;
  
  float textSize = 14.0F;
  
  View view;
  
  public SnackBar(Activity paramActivity, String paramString) {
    super((Context)paramActivity, 16973839);
    this.activity = paramActivity;
    this.text = paramString;
  }
  
  public SnackBar(Activity paramActivity, String paramString1, String paramString2, View.OnClickListener paramOnClickListener) {
    super((Context)paramActivity, 16973839);
    this.activity = paramActivity;
    this.text = paramString1;
    this.buttonText = paramString2;
    this.onClickListener = paramOnClickListener;
  }
  
  public void dismiss() {
    Animation animation = AnimationUtils.loadAnimation((Context)this.activity, R.anim.snackbar_hide_animation);
    animation.setAnimationListener(new Animation.AnimationListener() {
          public void onAnimationEnd(Animation param1Animation) {
            SnackBar.this.dismiss();
          }
          
          public void onAnimationRepeat(Animation param1Animation) {}
          
          public void onAnimationStart(Animation param1Animation) {}
        });
    this.view.startAnimation(animation);
  }
  
  public int getDismissTimer() {
    return this.mTimer;
  }
  
  public boolean isIndeterminate() {
    return this.mIndeterminate;
  }
  
  public void onBackPressed() {}
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    requestWindowFeature(1);
    setContentView(R.layout.snackbar);
    setCanceledOnTouchOutside(false);
    ((TextView)findViewById(R.id.text)).setText(this.text);
    ((TextView)findViewById(R.id.text)).setTextSize(this.textSize);
    this.button = (ButtonFlat)findViewById(R.id.buttonflat);
    if (this.text == null || this.onClickListener == null) {
      this.button.setVisibility(8);
    } else {
      this.button.setText(this.buttonText);
      this.button.setBackgroundColor(this.backgroundButton);
      this.button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View param1View) {
              SnackBar.this.dismiss();
              SnackBar.this.onClickListener.onClick(param1View);
            }
          });
    } 
    this.view = findViewById(R.id.snackbar);
    this.view.setBackgroundColor(this.backgroundSnackBar);
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 4)
      dismiss(); 
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    return this.activity.dispatchTouchEvent(paramMotionEvent);
  }
  
  public void setBackgroundSnackBar(int paramInt) {
    this.backgroundSnackBar = paramInt;
    if (this.view != null)
      this.view.setBackgroundColor(paramInt); 
  }
  
  public void setColorButton(int paramInt) {
    this.backgroundButton = paramInt;
    if (this.button != null)
      this.button.setBackgroundColor(paramInt); 
  }
  
  public void setDismissTimer(int paramInt) {
    this.mTimer = paramInt;
  }
  
  public void setIndeterminate(boolean paramBoolean) {
    this.mIndeterminate = paramBoolean;
  }
  
  public void setMessageTextSize(float paramFloat) {
    this.textSize = paramFloat;
  }
  
  public void setOnhideListener(OnHideListener paramOnHideListener) {
    this.onHideListener = paramOnHideListener;
  }
  
  public void show() {
    super.show();
    this.view.setVisibility(0);
    this.view.startAnimation(AnimationUtils.loadAnimation((Context)this.activity, R.anim.snackbar_show_animation));
    if (!this.mIndeterminate)
      this.dismissTimer.start(); 
  }
  
  public static interface OnHideListener {
    void onHide();
  }
}


/* Location:              /home/fahim/Desktop/malbus1-dex2jar.jar!/com/gc/materialdesign/widgets/SnackBar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */