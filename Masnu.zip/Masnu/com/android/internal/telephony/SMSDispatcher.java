package com.android.internal.telephony;

import android.os.Handler;

public abstract class SMSDispatcher extends Handler {}


/* Location:              /home/fahim/Desktop/BreakBottleNeckMasnu-dex2jar.jar!/com/android/internal/telephony/SMSDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */