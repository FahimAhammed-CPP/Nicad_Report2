package com.android.internal.telephony;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.telephony.NeighboringCellInfo;
import java.util.List;

public interface ITelephony extends IInterface {
  void answerRingingCall() throws RemoteException;
  
  void call(String paramString) throws RemoteException;
  
  void cancelMissedCallsNotification() throws RemoteException;
  
  void dial(String paramString) throws RemoteException;
  
  int disableApnType(String paramString) throws RemoteException;
  
  boolean disableDataConnectivity() throws RemoteException;
  
  void disableLocationUpdates() throws RemoteException;
  
  int enableApnType(String paramString) throws RemoteException;
  
  boolean enableDataConnectivity() throws RemoteException;
  
  void enableLocationUpdates() throws RemoteException;
  
  boolean endCall() throws RemoteException;
  
  int getActivePhoneType() throws RemoteException;
  
  int getCallState() throws RemoteException;
  
  int getCdmaEriIconIndex() throws RemoteException;
  
  int getCdmaEriIconMode() throws RemoteException;
  
  String getCdmaEriText() throws RemoteException;
  
  boolean getCdmaNeedsProvisioning() throws RemoteException;
  
  Bundle getCellLocation() throws RemoteException;
  
  int getDataActivity() throws RemoteException;
  
  int getDataState() throws RemoteException;
  
  List<NeighboringCellInfo> getNeighboringCellInfo() throws RemoteException;
  
  int getNetworkType() throws RemoteException;
  
  int getVoiceMessageCount() throws RemoteException;
  
  boolean handlePinMmi(String paramString) throws RemoteException;
  
  boolean hasIccCard() throws RemoteException;
  
  boolean isDataConnectivityPossible() throws RemoteException;
  
  boolean isIdle() throws RemoteException;
  
  boolean isOffhook() throws RemoteException;
  
  boolean isRadioOn() throws RemoteException;
  
  boolean isRinging() throws RemoteException;
  
  boolean isSimPinEnabled() throws RemoteException;
  
  boolean setRadio(boolean paramBoolean) throws RemoteException;
  
  boolean showCallScreen() throws RemoteException;
  
  boolean showCallScreenWithDialpad(boolean paramBoolean) throws RemoteException;
  
  void silenceRinger() throws RemoteException;
  
  boolean supplyPin(String paramString) throws RemoteException;
  
  void toggleRadioOnOff() throws RemoteException;
  
  void updateServiceLocation() throws RemoteException;
  
  public static abstract class Stub extends Binder implements ITelephony {
    private static final String DESCRIPTOR = "com.android.internal.telephony.ITelephony";
    
    static final int TRANSACTION_answerRingingCall = 6;
    
    static final int TRANSACTION_call = 2;
    
    static final int TRANSACTION_cancelMissedCallsNotification = 13;
    
    static final int TRANSACTION_dial = 1;
    
    static final int TRANSACTION_disableApnType = 22;
    
    static final int TRANSACTION_disableDataConnectivity = 24;
    
    static final int TRANSACTION_disableLocationUpdates = 20;
    
    static final int TRANSACTION_enableApnType = 21;
    
    static final int TRANSACTION_enableDataConnectivity = 23;
    
    static final int TRANSACTION_enableLocationUpdates = 19;
    
    static final int TRANSACTION_endCall = 5;
    
    static final int TRANSACTION_getActivePhoneType = 31;
    
    static final int TRANSACTION_getCallState = 28;
    
    static final int TRANSACTION_getCdmaEriIconIndex = 32;
    
    static final int TRANSACTION_getCdmaEriIconMode = 33;
    
    static final int TRANSACTION_getCdmaEriText = 34;
    
    static final int TRANSACTION_getCdmaNeedsProvisioning = 35;
    
    static final int TRANSACTION_getCellLocation = 26;
    
    static final int TRANSACTION_getDataActivity = 29;
    
    static final int TRANSACTION_getDataState = 30;
    
    static final int TRANSACTION_getNeighboringCellInfo = 27;
    
    static final int TRANSACTION_getNetworkType = 37;
    
    static final int TRANSACTION_getVoiceMessageCount = 36;
    
    static final int TRANSACTION_handlePinMmi = 15;
    
    static final int TRANSACTION_hasIccCard = 38;
    
    static final int TRANSACTION_isDataConnectivityPossible = 25;
    
    static final int TRANSACTION_isIdle = 10;
    
    static final int TRANSACTION_isOffhook = 8;
    
    static final int TRANSACTION_isRadioOn = 11;
    
    static final int TRANSACTION_isRinging = 9;
    
    static final int TRANSACTION_isSimPinEnabled = 12;
    
    static final int TRANSACTION_setRadio = 17;
    
    static final int TRANSACTION_showCallScreen = 3;
    
    static final int TRANSACTION_showCallScreenWithDialpad = 4;
    
    static final int TRANSACTION_silenceRinger = 7;
    
    static final int TRANSACTION_supplyPin = 14;
    
    static final int TRANSACTION_toggleRadioOnOff = 16;
    
    static final int TRANSACTION_updateServiceLocation = 18;
    
    public Stub() {
      attachInterface(this, "com.android.internal.telephony.ITelephony");
    }
    
    public static ITelephony asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.android.internal.telephony.ITelephony");
      return (iInterface != null && iInterface instanceof ITelephony) ? (ITelephony)iInterface : new Proxy(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      Bundle bundle;
      List<NeighboringCellInfo> list;
      String str;
      boolean bool1 = false;
      boolean bool2 = false;
      boolean bool3 = false;
      boolean bool4 = false;
      boolean bool5 = false;
      boolean bool6 = false;
      boolean bool7 = false;
      boolean bool8 = false;
      boolean bool9 = false;
      boolean bool10 = false;
      boolean bool11 = false;
      boolean bool12 = false;
      boolean bool13 = false;
      boolean bool14 = false;
      boolean bool15 = false;
      boolean bool16 = false;
      boolean bool17 = true;
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.android.internal.telephony.ITelephony");
          return bool17;
        case 1:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          dial(param1Parcel1.readString());
          param1Parcel2.writeNoException();
          return bool17;
        case 2:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          call(param1Parcel1.readString());
          param1Parcel2.writeNoException();
          return bool17;
        case 3:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          null = showCallScreen();
          param1Parcel2.writeNoException();
          param1Int1 = bool16;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 4:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          if (param1Parcel1.readInt() != 0) {
            null = true;
          } else {
            null = false;
          } 
          null = showCallScreenWithDialpad(null);
          param1Parcel2.writeNoException();
          param1Int1 = bool1;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 5:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          null = endCall();
          param1Parcel2.writeNoException();
          param1Int1 = bool2;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 6:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          answerRingingCall();
          param1Parcel2.writeNoException();
          return bool17;
        case 7:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          silenceRinger();
          param1Parcel2.writeNoException();
          return bool17;
        case 8:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          null = isOffhook();
          param1Parcel2.writeNoException();
          param1Int1 = bool3;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 9:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          null = isRinging();
          param1Parcel2.writeNoException();
          param1Int1 = bool4;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 10:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          null = isIdle();
          param1Parcel2.writeNoException();
          param1Int1 = bool5;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 11:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          null = isRadioOn();
          param1Parcel2.writeNoException();
          param1Int1 = bool6;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 12:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          null = isSimPinEnabled();
          param1Parcel2.writeNoException();
          param1Int1 = bool7;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 13:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          cancelMissedCallsNotification();
          param1Parcel2.writeNoException();
          return bool17;
        case 14:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          null = supplyPin(param1Parcel1.readString());
          param1Parcel2.writeNoException();
          param1Int1 = bool8;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 15:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          null = handlePinMmi(param1Parcel1.readString());
          param1Parcel2.writeNoException();
          param1Int1 = bool9;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 16:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          toggleRadioOnOff();
          param1Parcel2.writeNoException();
          return bool17;
        case 17:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          if (param1Parcel1.readInt() != 0) {
            null = true;
          } else {
            null = false;
          } 
          null = setRadio(null);
          param1Parcel2.writeNoException();
          param1Int1 = bool10;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 18:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          updateServiceLocation();
          param1Parcel2.writeNoException();
          return bool17;
        case 19:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          enableLocationUpdates();
          param1Parcel2.writeNoException();
          return bool17;
        case 20:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          disableLocationUpdates();
          param1Parcel2.writeNoException();
          return bool17;
        case 21:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          param1Int1 = enableApnType(param1Parcel1.readString());
          param1Parcel2.writeNoException();
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 22:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          param1Int1 = disableApnType(param1Parcel1.readString());
          param1Parcel2.writeNoException();
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 23:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          null = enableDataConnectivity();
          param1Parcel2.writeNoException();
          param1Int1 = bool11;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 24:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          null = disableDataConnectivity();
          param1Parcel2.writeNoException();
          param1Int1 = bool12;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 25:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          null = isDataConnectivityPossible();
          param1Parcel2.writeNoException();
          param1Int1 = bool13;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 26:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ITelephony");
          bundle = getCellLocation();
          param1Parcel2.writeNoException();
          if (bundle != null) {
            param1Parcel2.writeInt(1);
            bundle.writeToParcel(param1Parcel2, 1);
            return bool17;
          } 
          param1Parcel2.writeInt(0);
          return bool17;
        case 27:
          bundle.enforceInterface("com.android.internal.telephony.ITelephony");
          list = getNeighboringCellInfo();
          param1Parcel2.writeNoException();
          param1Parcel2.writeTypedList(list);
          return bool17;
        case 28:
          list.enforceInterface("com.android.internal.telephony.ITelephony");
          param1Int1 = getCallState();
          param1Parcel2.writeNoException();
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 29:
          list.enforceInterface("com.android.internal.telephony.ITelephony");
          param1Int1 = getDataActivity();
          param1Parcel2.writeNoException();
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 30:
          list.enforceInterface("com.android.internal.telephony.ITelephony");
          param1Int1 = getDataState();
          param1Parcel2.writeNoException();
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 31:
          list.enforceInterface("com.android.internal.telephony.ITelephony");
          param1Int1 = getActivePhoneType();
          param1Parcel2.writeNoException();
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 32:
          list.enforceInterface("com.android.internal.telephony.ITelephony");
          param1Int1 = getCdmaEriIconIndex();
          param1Parcel2.writeNoException();
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 33:
          list.enforceInterface("com.android.internal.telephony.ITelephony");
          param1Int1 = getCdmaEriIconMode();
          param1Parcel2.writeNoException();
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 34:
          list.enforceInterface("com.android.internal.telephony.ITelephony");
          str = getCdmaEriText();
          param1Parcel2.writeNoException();
          param1Parcel2.writeString(str);
          return bool17;
        case 35:
          str.enforceInterface("com.android.internal.telephony.ITelephony");
          null = getCdmaNeedsProvisioning();
          param1Parcel2.writeNoException();
          param1Int1 = bool14;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 36:
          str.enforceInterface("com.android.internal.telephony.ITelephony");
          param1Int1 = getVoiceMessageCount();
          param1Parcel2.writeNoException();
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 37:
          str.enforceInterface("com.android.internal.telephony.ITelephony");
          param1Int1 = getNetworkType();
          param1Parcel2.writeNoException();
          param1Parcel2.writeInt(param1Int1);
          return bool17;
        case 38:
          break;
      } 
      str.enforceInterface("com.android.internal.telephony.ITelephony");
      null = hasIccCard();
      param1Parcel2.writeNoException();
      param1Int1 = bool15;
      if (null)
        param1Int1 = 1; 
      param1Parcel2.writeInt(param1Int1);
      return bool17;
    }
    
    private static class Proxy implements ITelephony {
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public void answerRingingCall() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(6, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public void call(String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          parcel1.writeString(param2String);
          this.mRemote.transact(2, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void cancelMissedCallsNotification() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(13, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void dial(String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          parcel1.writeString(param2String);
          this.mRemote.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public int disableApnType(String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          parcel1.writeString(param2String);
          this.mRemote.transact(22, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readInt();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disableDataConnectivity() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(24, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disableLocationUpdates() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(20, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public int enableApnType(String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          parcel1.writeString(param2String);
          this.mRemote.transact(21, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readInt();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean enableDataConnectivity() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(23, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void enableLocationUpdates() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(19, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean endCall() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(5, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public int getActivePhoneType() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(31, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readInt();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public int getCallState() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(28, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readInt();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public int getCdmaEriIconIndex() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(32, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readInt();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public int getCdmaEriIconMode() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(33, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readInt();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getCdmaEriText() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(34, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readString();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean getCdmaNeedsProvisioning() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(35, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public Bundle getCellLocation() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(26, parcel1, parcel2, 0);
          parcel2.readException();
          if (parcel2.readInt() != 0)
            return (Bundle)Bundle.CREATOR.createFromParcel(parcel2); 
          return null;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public int getDataActivity() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(29, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readInt();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public int getDataState() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(30, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readInt();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getInterfaceDescriptor() {
        return "com.android.internal.telephony.ITelephony";
      }
      
      public List<NeighboringCellInfo> getNeighboringCellInfo() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(27, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.createTypedArrayList(NeighboringCellInfo.CREATOR);
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public int getNetworkType() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(37, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readInt();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public int getVoiceMessageCount() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(36, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readInt();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean handlePinMmi(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          parcel1.writeString(param2String);
          this.mRemote.transact(15, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean hasIccCard() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(38, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isDataConnectivityPossible() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(25, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isIdle() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(10, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isOffhook() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(8, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isRadioOn() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(11, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isRinging() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(9, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isSimPinEnabled() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(12, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean setRadio(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          this.mRemote.transact(17, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
            return param2Boolean;
          } 
          param2Boolean = false;
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean showCallScreen() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(3, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean showCallScreenWithDialpad(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          this.mRemote.transact(4, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
            return param2Boolean;
          } 
          param2Boolean = false;
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void silenceRinger() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(7, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean supplyPin(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          parcel1.writeString(param2String);
          this.mRemote.transact(14, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void toggleRadioOnOff() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(16, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void updateServiceLocation() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
          this.mRemote.transact(18, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class Proxy implements ITelephony {
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public void answerRingingCall() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(6, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public void call(String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        parcel1.writeString(param1String);
        this.mRemote.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void cancelMissedCallsNotification() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(13, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void dial(String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        parcel1.writeString(param1String);
        this.mRemote.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public int disableApnType(String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        parcel1.writeString(param1String);
        this.mRemote.transact(22, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readInt();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disableDataConnectivity() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(24, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disableLocationUpdates() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(20, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public int enableApnType(String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        parcel1.writeString(param1String);
        this.mRemote.transact(21, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readInt();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean enableDataConnectivity() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(23, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void enableLocationUpdates() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(19, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean endCall() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(5, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public int getActivePhoneType() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(31, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readInt();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public int getCallState() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(28, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readInt();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public int getCdmaEriIconIndex() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(32, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readInt();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public int getCdmaEriIconMode() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(33, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readInt();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getCdmaEriText() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(34, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readString();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean getCdmaNeedsProvisioning() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(35, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public Bundle getCellLocation() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(26, parcel1, parcel2, 0);
        parcel2.readException();
        if (parcel2.readInt() != 0)
          return (Bundle)Bundle.CREATOR.createFromParcel(parcel2); 
        return null;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public int getDataActivity() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(29, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readInt();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public int getDataState() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(30, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readInt();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getInterfaceDescriptor() {
      return "com.android.internal.telephony.ITelephony";
    }
    
    public List<NeighboringCellInfo> getNeighboringCellInfo() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(27, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.createTypedArrayList(NeighboringCellInfo.CREATOR);
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public int getNetworkType() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(37, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readInt();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public int getVoiceMessageCount() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(36, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readInt();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean handlePinMmi(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        parcel1.writeString(param1String);
        this.mRemote.transact(15, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean hasIccCard() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(38, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isDataConnectivityPossible() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(25, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isIdle() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(10, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isOffhook() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(8, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isRadioOn() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(11, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isRinging() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(9, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isSimPinEnabled() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(12, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean setRadio(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        this.mRemote.transact(17, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
          return param1Boolean;
        } 
        param1Boolean = false;
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean showCallScreen() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(3, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean showCallScreenWithDialpad(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        this.mRemote.transact(4, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
          return param1Boolean;
        } 
        param1Boolean = false;
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void silenceRinger() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(7, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean supplyPin(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        parcel1.writeString(param1String);
        this.mRemote.transact(14, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void toggleRadioOnOff() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(16, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void updateServiceLocation() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ITelephony");
        this.mRemote.transact(18, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckMasnu-dex2jar.jar!/com/android/internal/telephony/ITelephony.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */