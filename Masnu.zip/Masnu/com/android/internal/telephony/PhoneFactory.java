package com.android.internal.telephony;

public class PhoneFactory {
  private static Phone sProxyPhone = null;
  
  public static Phone getDefaultPhone() {
    return sProxyPhone;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckMasnu-dex2jar.jar!/com/android/internal/telephony/PhoneFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */