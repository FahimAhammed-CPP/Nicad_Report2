package com.android.internal.telephony;

public interface Phone {
  IccSmsInterfaceManager getIccSmsInterfaceManager();
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckMasnu-dex2jar.jar!/com/android/internal/telephony/Phone.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */