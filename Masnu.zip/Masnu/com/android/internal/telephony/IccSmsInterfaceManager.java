package com.android.internal.telephony;

import android.content.Context;

public abstract class IccSmsInterfaceManager extends ISms.Stub {
  protected Context mContext;
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckMasnu-dex2jar.jar!/com/android/internal/telephony/IccSmsInterfaceManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */