package com.android.internal.telephony;

import android.os.Parcel;
import android.os.Parcelable;

public class SmsRawData implements Parcelable {
  public static final Parcelable.Creator<SmsRawData> CREATOR = new Parcelable.Creator<SmsRawData>() {
      public SmsRawData createFromParcel(Parcel param1Parcel) {
        byte[] arrayOfByte = new byte[param1Parcel.readInt()];
        param1Parcel.readByteArray(arrayOfByte);
        return new SmsRawData(arrayOfByte);
      }
      
      public SmsRawData[] newArray(int param1Int) {
        return new SmsRawData[param1Int];
      }
    };
  
  byte[] data;
  
  public SmsRawData(byte[] paramArrayOfbyte) {
    this.data = paramArrayOfbyte;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public byte[] getBytes() {
    return this.data;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.data.length);
    paramParcel.writeByteArray(this.data);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckMasnu-dex2jar.jar!/com/android/internal/telephony/SmsRawData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */