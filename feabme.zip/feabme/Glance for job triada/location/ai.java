package com.baidu.location;

abstract class ai extends q implements au {}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/ai.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */