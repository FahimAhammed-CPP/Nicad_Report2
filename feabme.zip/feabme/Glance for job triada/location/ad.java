package com.baidu.location;

import android.os.Handler;
import android.os.Message;

class ad extends ae implements au, l {
  private static ad ef = null;
  
  final Handler d7 = new ae.b(this);
  
  final int ec = 1000;
  
  public ae.a ed = null;
  
  private volatile boolean ee = false;
  
  private int eg;
  
  private long eh = 0L;
  
  private ap ei = null;
  
  private long ej = 0L;
  
  private r.a ek = null;
  
  private ao.b el = null;
  
  private boolean em = false;
  
  private boolean en = true;
  
  private boolean eo = true;
  
  private BDLocation ep = null;
  
  private BDLocation eq = null;
  
  final int er = 2000;
  
  private String es = null;
  
  private ad() {
    this.ei = new ap();
    this.ed = new ae.a(this);
  }
  
  private boolean ah() {
    this.eb = ao.bC().bH();
    return !this.ei.do(this.eb);
  }
  
  private void ai() {
    this.ee = false;
    aq();
  }
  
  public static ad al() {
    if (ef == null)
      ef = new ad(); 
    return ef;
  }
  
  private void ao() {
    if (this.eo) {
      ar();
      return;
    } 
    if (!this.ee) {
      if (ao.bC().bD()) {
        this.em = true;
        this.d7.postDelayed(new a(), 2000L);
        return;
      } 
      ar();
    } 
  }
  
  private void aq() {
    if (this.ep != null)
      o.u().A(); 
  }
  
  private void ar() {
    if (!this.ee) {
      if (System.currentTimeMillis() - this.eh < 1000L && this.ep != null) {
        i.m().do(this.ep);
        ai();
        return;
      } 
      c.if("baidu_location_service", "start network locating ...");
      this.ee = true;
      this.en = if(this.ek);
      if (!if(this.el) && !this.en && this.ep != null && this.eg == 0) {
        if (this.eq != null && System.currentTimeMillis() - this.ej > 30000L) {
          this.ep = this.eq;
          this.eq = null;
        } 
        i.m().do(this.ep);
        ai();
        return;
      } 
      String str1 = d(null);
      if (str1 == null) {
        BDLocation bDLocation = new BDLocation();
        bDLocation.setLocType(62);
        i.m().do(bDLocation);
        ai();
        return;
      } 
      String str2 = str1;
      if (this.es != null) {
        str2 = str1 + this.es;
        this.es = null;
      } 
      this.ed.void(str2);
      this.ek = this.d8;
      this.el = this.eb;
      if (this.eo == true)
        this.eo = false; 
      this.eh = System.currentTimeMillis();
    } 
  }
  
  private void char(Message paramMessage) {
    String str = v.aR().aC();
    BDLocation bDLocation = new BDLocation(str);
    i.m().if(bDLocation, paramMessage);
    ah.a().a((String)null);
    ah.a().if(str);
  }
  
  private void else(Message paramMessage) {
    c.if("baidu_location_service", "on request location ...");
    if (!ab.a5().a6()) {
      int i = i.m().for(paramMessage);
      this.eg = paramMessage.arg1;
      switch (i) {
        default:
          throw new IllegalArgumentException(String.format("this type %d is illegal", new Object[] { Integer.valueOf(i) }));
        case 3:
          if (v.aR().aE())
            char(paramMessage); 
          return;
        case 1:
          goto(paramMessage);
          return;
        case 2:
          break;
      } 
      ao();
    } 
  }
  
  private void goto(Message paramMessage) {
    if (v.aR().aE()) {
      char(paramMessage);
      return;
    } 
    ao();
  }
  
  private boolean if(ao.b paramb) {
    boolean bool1 = true;
    this.eb = ao.bC().bH();
    if (paramb == this.eb)
      return false; 
    boolean bool2 = bool1;
    if (this.eb != null) {
      bool2 = bool1;
      if (paramb != null) {
        bool2 = bool1;
        if (paramb.a(this.eb))
          bool2 = false; 
      } 
    } 
    return bool2;
  }
  
  private boolean if(r.a parama) {
    boolean bool1 = true;
    this.d8 = r.aa().X();
    if (this.d8 == parama)
      return false; 
    boolean bool2 = bool1;
    if (this.d8 != null) {
      bool2 = bool1;
      if (parama != null) {
        bool2 = bool1;
        if (parama.a(this.d8))
          bool2 = false; 
      } 
    } 
    return bool2;
  }
  
  void ag() {
    c.if("baidu_location_service", "on network exception");
    if (this.en || this.ep == null) {
      i.m().if(av.bW().case(false), 21);
    } else {
      i.m().if(this.ep, 21);
    } 
    this.ep = null;
    this.eq = null;
    this.ei.bM();
    ai();
  }
  
  public void aj() {
    if (this.em) {
      ar();
      this.em = false;
    } 
  }
  
  void ak() {
    this.ee = false;
    am();
  }
  
  void am() {
    this.ep = null;
    this.ei.bM();
  }
  
  public boolean an() {
    return this.en;
  }
  
  void ap() {
    this.eo = true;
    this.ee = false;
  }
  
  void byte(Message paramMessage) {
    c.if("baidu_location_service", "on network success");
    BDLocation bDLocation2 = (BDLocation)paramMessage.obj;
    BDLocation bDLocation1 = new BDLocation(bDLocation2);
    this.eq = null;
    byte b1 = 0;
    int i = b1;
    if (bDLocation2.getLocType() == 161) {
      i = b1;
      if ("cl".equals(bDLocation2.getNetworkLocationType())) {
        i = b1;
        if (this.ep != null) {
          i = b1;
          if (this.ep.getLocType() == 161) {
            i = b1;
            if ("wf".equals(this.ep.getNetworkLocationType())) {
              i = b1;
              if (System.currentTimeMillis() - this.ej < 30000L) {
                i = 1;
                this.eq = bDLocation2;
              } 
            } 
          } 
        } 
      } 
    } 
    if (i) {
      i.m().if(this.ep, 21);
    } else {
      i.m().if(bDLocation2, 21);
      this.ej = System.currentTimeMillis();
    } 
    if (c.if(bDLocation2)) {
      if (!i)
        this.ep = bDLocation2; 
    } else {
      this.ep = null;
      this.ei.bM();
    } 
    i = c.do(d5, "ssid\":\"", "\"");
    if (i != Integer.MIN_VALUE && this.el != null) {
      this.es = this.el.if(i);
    } else {
      this.es = null;
    } 
    av.bW().if(d5, this.ek, this.el, bDLocation1);
    h.cK().byte(bDLocation1);
    ai();
  }
  
  public void case(Message paramMessage) {
    else(paramMessage);
  }
  
  public void for(BDLocation paramBDLocation) {
    am();
    this.ep = paramBDLocation;
  }
  
  private class a implements Runnable {
    private a(ad this$0) {}
    
    public void run() {
      if (ad.do(this.a) == true) {
        ad.if(this.a, false);
        ad.if(this.a);
      } 
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */