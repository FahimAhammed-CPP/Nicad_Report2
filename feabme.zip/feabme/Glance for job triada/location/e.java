package com.baidu.location;

class e implements as {
  private static e a = null;
  
  public static e for() {
    if (a == null)
      a = new e(); 
    return a;
  }
  
  public void a() {}
  
  public void do() {}
  
  public void if() {}
  
  public void int() {}
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */