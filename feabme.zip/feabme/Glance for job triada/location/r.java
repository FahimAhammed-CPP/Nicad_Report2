package com.baidu.location;

import android.telephony.CellLocation;
import android.telephony.NeighboringCellInfo;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

class r implements au, l {
  private static long d0;
  
  private static int d2;
  
  private static Class d3;
  
  private static Method dQ;
  
  private static r dT = null;
  
  private static String dV = null;
  
  private static Method dW;
  
  private static boolean dX;
  
  private static Method dZ = null;
  
  private boolean d1 = false;
  
  private a dO = new a(this);
  
  private int dP = 0;
  
  private b dR = null;
  
  private List dS = null;
  
  private TelephonyManager dU = null;
  
  private int dY = 0;
  
  static {
    dW = null;
    dQ = null;
    d3 = null;
    d0 = 3000L;
    d2 = 3;
    dX = false;
  }
  
  private boolean Y() {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: iload_1
    //   3: istore_2
    //   4: getstatic com/baidu/location/r.dV : Ljava/lang/String;
    //   7: ifnull -> 23
    //   10: getstatic com/baidu/location/r.dV : Ljava/lang/String;
    //   13: invokevirtual length : ()I
    //   16: bipush #10
    //   18: if_icmpge -> 25
    //   21: iload_1
    //   22: istore_2
    //   23: iload_2
    //   24: ireturn
    //   25: getstatic com/baidu/location/r.dV : Ljava/lang/String;
    //   28: invokevirtual toCharArray : ()[C
    //   31: astore_3
    //   32: iconst_0
    //   33: istore #4
    //   35: iload #4
    //   37: bipush #10
    //   39: if_icmpge -> 74
    //   42: iload_1
    //   43: istore_2
    //   44: aload_3
    //   45: iload #4
    //   47: caload
    //   48: bipush #57
    //   50: if_icmpgt -> 23
    //   53: aload_3
    //   54: iload #4
    //   56: caload
    //   57: istore #5
    //   59: iload_1
    //   60: istore_2
    //   61: iload #5
    //   63: bipush #48
    //   65: if_icmplt -> 23
    //   68: iinc #4, 1
    //   71: goto -> 35
    //   74: iconst_1
    //   75: istore_2
    //   76: goto -> 23
    //   79: astore_3
    //   80: iload_1
    //   81: istore_2
    //   82: goto -> 23
    // Exception table:
    //   from	to	target	type
    //   25	32	79	java/lang/Exception
  }
  
  public static r aa() {
    if (dT == null)
      dT = new r(); 
    return dT;
  }
  
  private void if(CellLocation paramCellLocation) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 11
    //   4: aload_0
    //   5: getfield dU : Landroid/telephony/TelephonyManager;
    //   8: ifnonnull -> 12
    //   11: return
    //   12: getstatic com/baidu/location/r.dX : Z
    //   15: ifne -> 35
    //   18: aload_0
    //   19: getfield dU : Landroid/telephony/TelephonyManager;
    //   22: invokevirtual getDeviceId : ()Ljava/lang/String;
    //   25: putstatic com/baidu/location/r.dV : Ljava/lang/String;
    //   28: aload_0
    //   29: invokespecial Y : ()Z
    //   32: putstatic com/baidu/location/r.dX : Z
    //   35: new com/baidu/location/r$a
    //   38: dup
    //   39: aload_0
    //   40: invokespecial <init> : (Lcom/baidu/location/r;)V
    //   43: astore_2
    //   44: aload_2
    //   45: invokestatic currentTimeMillis : ()J
    //   48: putfield byte : J
    //   51: aload_0
    //   52: getfield dU : Landroid/telephony/TelephonyManager;
    //   55: invokevirtual getNetworkOperator : ()Ljava/lang/String;
    //   58: astore_3
    //   59: aload_3
    //   60: ifnull -> 202
    //   63: aload_3
    //   64: invokevirtual length : ()I
    //   67: ifle -> 202
    //   70: aload_3
    //   71: invokevirtual length : ()I
    //   74: iconst_3
    //   75: if_icmplt -> 116
    //   78: aload_3
    //   79: iconst_0
    //   80: iconst_3
    //   81: invokevirtual substring : (II)Ljava/lang/String;
    //   84: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   87: invokevirtual intValue : ()I
    //   90: istore #4
    //   92: iload #4
    //   94: istore #5
    //   96: iload #4
    //   98: ifge -> 110
    //   101: aload_0
    //   102: getfield dO : Lcom/baidu/location/r$a;
    //   105: getfield do : I
    //   108: istore #5
    //   110: aload_2
    //   111: iload #5
    //   113: putfield do : I
    //   116: aload_3
    //   117: iconst_3
    //   118: invokevirtual substring : (I)Ljava/lang/String;
    //   121: astore #6
    //   123: aload #6
    //   125: ifnull -> 680
    //   128: aload #6
    //   130: invokevirtual toCharArray : ()[C
    //   133: astore_3
    //   134: iconst_0
    //   135: istore #5
    //   137: iload #5
    //   139: istore #4
    //   141: iload #5
    //   143: aload_3
    //   144: arraylength
    //   145: if_icmpge -> 162
    //   148: aload_3
    //   149: iload #5
    //   151: caload
    //   152: invokestatic isDigit : (C)Z
    //   155: ifne -> 417
    //   158: iload #5
    //   160: istore #4
    //   162: aload #6
    //   164: iconst_0
    //   165: iload #4
    //   167: invokevirtual substring : (II)Ljava/lang/String;
    //   170: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   173: invokevirtual intValue : ()I
    //   176: istore #4
    //   178: iload #4
    //   180: istore #5
    //   182: iload #4
    //   184: ifge -> 196
    //   187: aload_0
    //   188: getfield dO : Lcom/baidu/location/r$a;
    //   191: getfield if : I
    //   194: istore #5
    //   196: aload_2
    //   197: iload #5
    //   199: putfield if : I
    //   202: aload_0
    //   203: aload_0
    //   204: getfield dU : Landroid/telephony/TelephonyManager;
    //   207: invokevirtual getSimState : ()I
    //   210: putfield dY : I
    //   213: aload_1
    //   214: instanceof android/telephony/gsm/GsmCellLocation
    //   217: ifeq -> 432
    //   220: aload_2
    //   221: aload_1
    //   222: checkcast android/telephony/gsm/GsmCellLocation
    //   225: invokevirtual getLac : ()I
    //   228: putfield for : I
    //   231: aload_2
    //   232: aload_1
    //   233: checkcast android/telephony/gsm/GsmCellLocation
    //   236: invokevirtual getCid : ()I
    //   239: putfield try : I
    //   242: aload_2
    //   243: bipush #103
    //   245: i2c
    //   246: putfield new : C
    //   249: aload_2
    //   250: invokevirtual for : ()Z
    //   253: ifeq -> 11
    //   256: aload_0
    //   257: getfield dO : Lcom/baidu/location/r$a;
    //   260: ifnull -> 274
    //   263: aload_0
    //   264: getfield dO : Lcom/baidu/location/r$a;
    //   267: aload_2
    //   268: invokevirtual a : (Lcom/baidu/location/r$a;)Z
    //   271: ifne -> 11
    //   274: aload_0
    //   275: aload_2
    //   276: putfield dO : Lcom/baidu/location/r$a;
    //   279: aload_2
    //   280: invokevirtual for : ()Z
    //   283: ifeq -> 661
    //   286: aload_0
    //   287: getfield dS : Ljava/util/List;
    //   290: ifnonnull -> 304
    //   293: aload_0
    //   294: new java/util/LinkedList
    //   297: dup
    //   298: invokespecial <init> : ()V
    //   301: putfield dS : Ljava/util/List;
    //   304: aload_0
    //   305: getfield dS : Ljava/util/List;
    //   308: invokeinterface size : ()I
    //   313: istore #5
    //   315: iload #5
    //   317: ifne -> 641
    //   320: aconst_null
    //   321: astore_1
    //   322: aload_1
    //   323: ifnull -> 354
    //   326: aload_1
    //   327: getfield try : I
    //   330: aload_0
    //   331: getfield dO : Lcom/baidu/location/r$a;
    //   334: getfield try : I
    //   337: if_icmpne -> 354
    //   340: aload_1
    //   341: getfield for : I
    //   344: aload_0
    //   345: getfield dO : Lcom/baidu/location/r$a;
    //   348: getfield for : I
    //   351: if_icmpeq -> 11
    //   354: aload_1
    //   355: ifnull -> 374
    //   358: aload_1
    //   359: aload_0
    //   360: getfield dO : Lcom/baidu/location/r$a;
    //   363: getfield byte : J
    //   366: aload_1
    //   367: getfield byte : J
    //   370: lsub
    //   371: putfield byte : J
    //   374: aload_0
    //   375: getfield dS : Ljava/util/List;
    //   378: aload_0
    //   379: getfield dO : Lcom/baidu/location/r$a;
    //   382: invokeinterface add : (Ljava/lang/Object;)Z
    //   387: pop
    //   388: aload_0
    //   389: getfield dS : Ljava/util/List;
    //   392: invokeinterface size : ()I
    //   397: getstatic com/baidu/location/r.d2 : I
    //   400: if_icmple -> 11
    //   403: aload_0
    //   404: getfield dS : Ljava/util/List;
    //   407: iconst_0
    //   408: invokeinterface remove : (I)Ljava/lang/Object;
    //   413: pop
    //   414: goto -> 11
    //   417: iinc #5, 1
    //   420: goto -> 137
    //   423: astore_3
    //   424: aload_0
    //   425: iconst_1
    //   426: putfield dP : I
    //   429: goto -> 213
    //   432: aload_1
    //   433: instanceof android/telephony/cdma/CdmaCellLocation
    //   436: ifeq -> 249
    //   439: aload_2
    //   440: bipush #99
    //   442: i2c
    //   443: putfield new : C
    //   446: getstatic android/os/Build$VERSION.SDK : Ljava/lang/String;
    //   449: invokestatic parseInt : (Ljava/lang/String;)I
    //   452: iconst_5
    //   453: if_icmplt -> 11
    //   456: getstatic com/baidu/location/r.d3 : Ljava/lang/Class;
    //   459: ifnonnull -> 515
    //   462: ldc 'android.telephony.cdma.CdmaCellLocation'
    //   464: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   467: putstatic com/baidu/location/r.d3 : Ljava/lang/Class;
    //   470: getstatic com/baidu/location/r.d3 : Ljava/lang/Class;
    //   473: ldc 'getBaseStationId'
    //   475: iconst_0
    //   476: anewarray java/lang/Class
    //   479: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   482: putstatic com/baidu/location/r.dZ : Ljava/lang/reflect/Method;
    //   485: getstatic com/baidu/location/r.d3 : Ljava/lang/Class;
    //   488: ldc 'getNetworkId'
    //   490: iconst_0
    //   491: anewarray java/lang/Class
    //   494: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   497: putstatic com/baidu/location/r.dW : Ljava/lang/reflect/Method;
    //   500: getstatic com/baidu/location/r.d3 : Ljava/lang/Class;
    //   503: ldc 'getSystemId'
    //   505: iconst_0
    //   506: anewarray java/lang/Class
    //   509: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   512: putstatic com/baidu/location/r.dQ : Ljava/lang/reflect/Method;
    //   515: getstatic com/baidu/location/r.d3 : Ljava/lang/Class;
    //   518: ifnull -> 249
    //   521: getstatic com/baidu/location/r.d3 : Ljava/lang/Class;
    //   524: aload_1
    //   525: invokevirtual isInstance : (Ljava/lang/Object;)Z
    //   528: ifeq -> 249
    //   531: getstatic com/baidu/location/r.dQ : Ljava/lang/reflect/Method;
    //   534: aload_1
    //   535: iconst_0
    //   536: anewarray java/lang/Object
    //   539: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   542: checkcast java/lang/Integer
    //   545: invokevirtual intValue : ()I
    //   548: istore #4
    //   550: iload #4
    //   552: istore #5
    //   554: iload #4
    //   556: ifge -> 568
    //   559: aload_0
    //   560: getfield dO : Lcom/baidu/location/r$a;
    //   563: getfield if : I
    //   566: istore #5
    //   568: aload_2
    //   569: iload #5
    //   571: putfield if : I
    //   574: aload_2
    //   575: getstatic com/baidu/location/r.dZ : Ljava/lang/reflect/Method;
    //   578: aload_1
    //   579: iconst_0
    //   580: anewarray java/lang/Object
    //   583: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   586: checkcast java/lang/Integer
    //   589: invokevirtual intValue : ()I
    //   592: putfield try : I
    //   595: aload_2
    //   596: getstatic com/baidu/location/r.dW : Ljava/lang/reflect/Method;
    //   599: aload_1
    //   600: iconst_0
    //   601: anewarray java/lang/Object
    //   604: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   607: checkcast java/lang/Integer
    //   610: invokevirtual intValue : ()I
    //   613: putfield for : I
    //   616: goto -> 249
    //   619: astore_1
    //   620: aload_0
    //   621: iconst_3
    //   622: putfield dP : I
    //   625: goto -> 11
    //   628: astore_1
    //   629: aconst_null
    //   630: putstatic com/baidu/location/r.d3 : Ljava/lang/Class;
    //   633: aload_0
    //   634: iconst_2
    //   635: putfield dP : I
    //   638: goto -> 11
    //   641: aload_0
    //   642: getfield dS : Ljava/util/List;
    //   645: iload #5
    //   647: iconst_1
    //   648: isub
    //   649: invokeinterface get : (I)Ljava/lang/Object;
    //   654: checkcast com/baidu/location/r$a
    //   657: astore_1
    //   658: goto -> 322
    //   661: aload_0
    //   662: getfield dS : Ljava/util/List;
    //   665: ifnull -> 11
    //   668: aload_0
    //   669: getfield dS : Ljava/util/List;
    //   672: invokeinterface clear : ()V
    //   677: goto -> 11
    //   680: iconst_0
    //   681: istore #4
    //   683: goto -> 162
    // Exception table:
    //   from	to	target	type
    //   51	59	423	java/lang/Exception
    //   63	92	423	java/lang/Exception
    //   101	110	423	java/lang/Exception
    //   110	116	423	java/lang/Exception
    //   116	123	423	java/lang/Exception
    //   128	134	423	java/lang/Exception
    //   141	158	423	java/lang/Exception
    //   162	178	423	java/lang/Exception
    //   187	196	423	java/lang/Exception
    //   196	202	423	java/lang/Exception
    //   202	213	423	java/lang/Exception
    //   462	515	628	java/lang/Exception
    //   531	550	619	java/lang/Exception
    //   559	568	619	java/lang/Exception
    //   568	616	619	java/lang/Exception
  }
  
  public a X() {
    if ((this.dO == null || !this.dO.do() || !this.dO.for()) && this.dU != null)
      try {
        if(this.dU.getCellLocation());
      } catch (Exception exception) {} 
    return this.dO;
  }
  
  public void Z() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d1 : Z
    //   6: istore_1
    //   7: iload_1
    //   8: iconst_1
    //   9: if_icmpne -> 15
    //   12: aload_0
    //   13: monitorexit
    //   14: return
    //   15: getstatic com/baidu/location/f.isServing : Z
    //   18: ifeq -> 12
    //   21: aload_0
    //   22: invokestatic getServiceContext : ()Landroid/content/Context;
    //   25: ldc_w 'phone'
    //   28: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   31: checkcast android/telephony/TelephonyManager
    //   34: putfield dU : Landroid/telephony/TelephonyManager;
    //   37: new java/util/LinkedList
    //   40: astore_2
    //   41: aload_2
    //   42: invokespecial <init> : ()V
    //   45: aload_0
    //   46: aload_2
    //   47: putfield dS : Ljava/util/List;
    //   50: new com/baidu/location/r$b
    //   53: astore_2
    //   54: aload_2
    //   55: aload_0
    //   56: invokespecial <init> : (Lcom/baidu/location/r;)V
    //   59: aload_0
    //   60: aload_2
    //   61: putfield dR : Lcom/baidu/location/r$b;
    //   64: aload_0
    //   65: getfield dU : Landroid/telephony/TelephonyManager;
    //   68: ifnull -> 12
    //   71: aload_0
    //   72: getfield dR : Lcom/baidu/location/r$b;
    //   75: astore_2
    //   76: aload_2
    //   77: ifnull -> 12
    //   80: aload_0
    //   81: getfield dU : Landroid/telephony/TelephonyManager;
    //   84: aload_0
    //   85: getfield dR : Lcom/baidu/location/r$b;
    //   88: sipush #272
    //   91: invokevirtual listen : (Landroid/telephony/PhoneStateListener;I)V
    //   94: aload_0
    //   95: invokespecial Y : ()Z
    //   98: putstatic com/baidu/location/r.dX : Z
    //   101: new java/lang/StringBuilder
    //   104: astore_2
    //   105: aload_2
    //   106: invokespecial <init> : ()V
    //   109: ldc_w 'baidu_location_service'
    //   112: aload_2
    //   113: ldc_w 'i:'
    //   116: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   119: getstatic com/baidu/location/r.dV : Ljava/lang/String;
    //   122: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   125: invokevirtual toString : ()Ljava/lang/String;
    //   128: invokestatic if : (Ljava/lang/String;Ljava/lang/String;)V
    //   131: aload_0
    //   132: iconst_1
    //   133: putfield d1 : Z
    //   136: goto -> 12
    //   139: astore_2
    //   140: aload_0
    //   141: monitorexit
    //   142: aload_2
    //   143: athrow
    //   144: astore_2
    //   145: goto -> 94
    // Exception table:
    //   from	to	target	type
    //   2	7	139	finally
    //   15	76	139	finally
    //   80	94	144	java/lang/Exception
    //   80	94	139	finally
    //   94	136	139	finally
  }
  
  public String ab() {
    return dV;
  }
  
  public int ac() {
    return (this.dU == null) ? 0 : this.dU.getNetworkType();
  }
  
  public int ad() {
    String str = ((TelephonyManager)f.getServiceContext().getSystemService("phone")).getSubscriberId();
    if (str != null) {
      if (str.startsWith("46000") || str.startsWith("46002") || str.startsWith("46007"))
        return 1; 
      if (str.startsWith("46001"))
        return 2; 
      if (str.startsWith("46003"))
        return 3; 
    } 
    return 0;
  }
  
  public void af() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d1 : Z
    //   6: istore_1
    //   7: iload_1
    //   8: ifne -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aload_0
    //   15: getfield dR : Lcom/baidu/location/r$b;
    //   18: ifnull -> 40
    //   21: aload_0
    //   22: getfield dU : Landroid/telephony/TelephonyManager;
    //   25: ifnull -> 40
    //   28: aload_0
    //   29: getfield dU : Landroid/telephony/TelephonyManager;
    //   32: aload_0
    //   33: getfield dR : Lcom/baidu/location/r$b;
    //   36: iconst_0
    //   37: invokevirtual listen : (Landroid/telephony/PhoneStateListener;I)V
    //   40: aload_0
    //   41: aconst_null
    //   42: putfield dR : Lcom/baidu/location/r$b;
    //   45: aload_0
    //   46: aconst_null
    //   47: putfield dU : Landroid/telephony/TelephonyManager;
    //   50: aload_0
    //   51: getfield dS : Ljava/util/List;
    //   54: invokeinterface clear : ()V
    //   59: aload_0
    //   60: aconst_null
    //   61: putfield dS : Ljava/util/List;
    //   64: aload_0
    //   65: iconst_0
    //   66: putfield d1 : Z
    //   69: goto -> 11
    //   72: astore_2
    //   73: aload_0
    //   74: monitorexit
    //   75: aload_2
    //   76: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	72	finally
    //   14	40	72	finally
    //   40	69	72	finally
  }
  
  public class a {
    public long byte = 0L;
    
    public int do = -1;
    
    public int for = -1;
    
    public int if = -1;
    
    public int int = -1;
    
    public char new = (char)Character.MIN_VALUE;
    
    public int try = -1;
    
    public a(r this$0) {
      this.byte = System.currentTimeMillis();
    }
    
    public a(r this$0, int param1Int1, int param1Int2, int param1Int3, int param1Int4, char param1Char) {
      this.for = param1Int1;
      this.try = param1Int2;
      this.do = param1Int3;
      this.if = param1Int4;
      this.new = (char)param1Char;
      this.byte = System.currentTimeMillis() / 1000L;
    }
    
    public String a() {
      StringBuffer stringBuffer = new StringBuffer(128);
      stringBuffer.append(this.try + 23);
      stringBuffer.append("H");
      stringBuffer.append(this.for + 45);
      stringBuffer.append("K");
      stringBuffer.append(this.if + 54);
      stringBuffer.append("Q");
      stringBuffer.append(this.do + 203);
      return stringBuffer.toString();
    }
    
    public boolean a(a param1a) {
      return (this.for == param1a.for && this.try == param1a.try && this.if == param1a.if);
    }
    
    public boolean do() {
      return (System.currentTimeMillis() - this.byte < r.ae());
    }
    
    public boolean for() {
      return (this.for > -1 && this.try > 0);
    }
    
    public String if() {
      StringBuffer stringBuffer = new StringBuffer(64);
      stringBuffer.append(String.format(Locale.CHINA, "cell=%d|%d|%d|%d:%d", new Object[] { Integer.valueOf(this.do), Integer.valueOf(this.if), Integer.valueOf(this.for), Integer.valueOf(this.try), Integer.valueOf(this.int) }));
      return stringBuffer.toString();
    }
    
    public String int() {
      try {
        List list = r.int(this.a).getNeighboringCellInfo();
        if (list != null && !list.isEmpty()) {
          String str = "&nc=";
          Iterator<NeighboringCellInfo> iterator = list.iterator();
          for (byte b = 0; iterator.hasNext(); b++) {
            NeighboringCellInfo neighboringCellInfo = iterator.next();
            if (!b) {
              if (neighboringCellInfo.getLac() != this.for) {
                StringBuilder stringBuilder = new StringBuilder();
                this();
                str = stringBuilder.append(str).append(neighboringCellInfo.getLac()).append("|").append(neighboringCellInfo.getCid()).append("|").append(neighboringCellInfo.getRssi()).toString();
              } else {
                StringBuilder stringBuilder = new StringBuilder();
                this();
                str = stringBuilder.append(str).append("|").append(neighboringCellInfo.getCid()).append("|").append(neighboringCellInfo.getRssi()).toString();
              } 
            } else if (b < 8) {
              if (neighboringCellInfo.getLac() != this.for) {
                StringBuilder stringBuilder = new StringBuilder();
                this();
                str = stringBuilder.append(str).append(";").append(neighboringCellInfo.getLac()).append("|").append(neighboringCellInfo.getCid()).append("|").append(neighboringCellInfo.getRssi()).toString();
              } else {
                StringBuilder stringBuilder = new StringBuilder();
                this();
                str = stringBuilder.append(str).append(";").append("|").append(neighboringCellInfo.getCid()).append("|").append(neighboringCellInfo.getRssi()).toString();
              } 
            } else {
              break;
            } 
          } 
          return str;
        } 
      } catch (Exception null) {
        return null;
      } 
      return null;
    }
    
    public String toString() {
      StringBuffer stringBuffer = new StringBuffer(128);
      stringBuffer.append("&nw=");
      stringBuffer.append((r.for(this.a)).new);
      stringBuffer.append(String.format(Locale.CHINA, "&cl=%d|%d|%d|%d&cl_s=%d", new Object[] { Integer.valueOf(this.do), Integer.valueOf(this.if), Integer.valueOf(this.for), Integer.valueOf(this.try), Integer.valueOf(this.int) }));
      stringBuffer.append("&cl_t=");
      stringBuffer.append(this.byte);
      if (r.do(this.a) != null && r.do(this.a).size() > 0) {
        int k = r.do(this.a).size();
        stringBuffer.append("&clt=");
        for (byte b = 0; b < k; b++) {
          a a1 = r.do(this.a).get(b);
          if (a1.do != this.do)
            stringBuffer.append(a1.do); 
          stringBuffer.append("|");
          if (a1.if != this.if)
            stringBuffer.append(a1.if); 
          stringBuffer.append("|");
          if (a1.for != this.for)
            stringBuffer.append(a1.for); 
          stringBuffer.append("|");
          if (a1.try != this.try)
            stringBuffer.append(a1.try); 
          stringBuffer.append("|");
          if (b != k - 1) {
            stringBuffer.append(a1.byte / 1000L);
          } else {
            stringBuffer.append((System.currentTimeMillis() - a1.byte) / 1000L);
          } 
          stringBuffer.append(";");
        } 
      } 
      if (r.new(this.a) > 100)
        r.if(this.a, 0); 
      int j = r.if(this.a);
      int i = r.new(this.a);
      stringBuffer.append("&cs=" + ((j << 8) + i));
      return stringBuffer.toString();
    }
  }
  
  private class b extends PhoneStateListener {
    public b(r this$0) {}
    
    public void onCellLocationChanged(CellLocation param1CellLocation) {
      if (param1CellLocation != null)
        try {
          r.if(this.a, r.int(this.a).getCellLocation());
        } catch (Exception exception) {} 
    }
    
    public void onSignalStrengthsChanged(SignalStrength param1SignalStrength) {
      if (r.for(this.a) != null) {
        if ((r.for(this.a)).new == 'g') {
          (r.for(this.a)).int = param1SignalStrength.getGsmSignalStrength();
          return;
        } 
      } else {
        return;
      } 
      if ((r.for(this.a)).new == 'c')
        (r.for(this.a)).int = param1SignalStrength.getCdmaDbm(); 
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */