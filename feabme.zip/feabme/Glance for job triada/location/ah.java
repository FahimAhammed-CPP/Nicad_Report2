package com.baidu.location;

import android.os.Message;
import android.os.Messenger;
import org.apache.http.message.BasicNameValuePair;

class ah {
  private static ah goto;
  
  private boolean a = false;
  
  private String byte = null;
  
  private String case = null;
  
  private long char = 0L;
  
  private String do = null;
  
  private String else = null;
  
  private long for = 0L;
  
  private long if = 0L;
  
  private String int = null;
  
  public String new = null;
  
  private a try = null;
  
  private ah() {
    this.try = new a(this);
  }
  
  public static ah a() {
    if (goto == null)
      goto = new ah(); 
    return goto;
  }
  
  public void a(Message paramMessage) {
    if (this.case == null || this.do == null) {
      this.case = this.int;
      this.do = this.byte;
    } 
    this.try.try(paramMessage);
  }
  
  public void a(String paramString) {
    this.else = paramString;
    this.a = true;
    this.for = System.currentTimeMillis();
  }
  
  public void do() {
    this.case = this.int;
    this.do = this.byte;
    this.char = System.currentTimeMillis();
  }
  
  public void if() {
    this.case = null;
    this.do = null;
    this.char = 0L;
  }
  
  public void if(String paramString) {
    if (this.a) {
      this.int = this.else;
      this.a = false;
      this.if = this.for;
    } 
    this.byte = paramString;
  }
  
  class a extends q {
    String dr = null;
    
    Messenger ds = null;
    
    boolean dt = false;
    
    public a(ah this$0) {}
    
    void O() {
      this.cN = c.new();
      if (ah.a(this.dq) == null)
        ah.if(this.dq, Jni.h("none")); 
      this.cP.add(new BasicNameValuePair("erpt[0]", ah.a(this.dq)));
      if (ah.if(this.dq) == null)
        ah.a(this.dq, "none"); 
      this.cP.add(new BasicNameValuePair("erpt[1]", Jni.h(ah.if(this.dq))));
      if (this.dr == null)
        this.dr = "none"; 
      this.cP.add(new BasicNameValuePair("erpt[2]", Jni.h(this.dr)));
      StringBuffer stringBuffer = new StringBuffer(512);
      stringBuffer.append("&t1=");
      stringBuffer.append(ah.do(this.dq));
      stringBuffer.append("&t2=");
      stringBuffer.append(ah.for(this.dq));
      String str = v.aR().aL();
      if (str != null)
        stringBuffer.append(str); 
      this.cP.add(new BasicNameValuePair("erpt[3]", Jni.h(stringBuffer.toString())));
      ah.if(this.dq, null);
      ah.a(this.dq, (String)null);
      ah.a(this.dq, 0L);
    }
    
    void do(boolean param1Boolean) {
      Message message;
      if (this.cP != null)
        this.cP.clear(); 
      if (param1Boolean) {
        message = Message.obtain(null, 205);
      } else {
        message = Message.obtain(null, 204);
      } 
      try {
        this.ds.send(message);
      } catch (Exception exception) {}
      this.dt = false;
    }
    
    public void try(Message param1Message) {
      this.ds = param1Message.replyTo;
      if (this.dt) {
        param1Message = Message.obtain(null, 204);
        try {
          this.ds.send(param1Message);
        } catch (Exception exception) {}
        return;
      } 
      this.dt = true;
      this.dr = exception.getData().getString("errInfo");
      J();
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/ah.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */