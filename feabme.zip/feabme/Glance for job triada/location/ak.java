package com.baidu.location;

public final class ak {
  public static Object a(Object paramObject) {
    if (paramObject == null)
      throw new NullPointerException("null reference"); 
    return paramObject;
  }
  
  public static Object a(Object paramObject1, Object paramObject2) {
    if (paramObject1 == null)
      throw new NullPointerException(String.valueOf(paramObject2)); 
    return paramObject1;
  }
  
  public static void a(boolean paramBoolean) {
    if (!paramBoolean)
      throw new IllegalStateException(); 
  }
  
  public static void a(boolean paramBoolean, Object paramObject) {
    if (!paramBoolean)
      throw new IllegalStateException(String.valueOf(paramObject)); 
  }
  
  public static void a(boolean paramBoolean, String paramString, Object[] paramArrayOfObject) {
    if (!paramBoolean)
      throw new IllegalArgumentException(String.format(paramString, paramArrayOfObject)); 
  }
  
  public static void if(boolean paramBoolean) {
    if (!paramBoolean)
      throw new IllegalArgumentException(); 
  }
  
  public static void if(boolean paramBoolean, Object paramObject) {
    if (!paramBoolean)
      throw new IllegalArgumentException(String.valueOf(paramObject)); 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/ak.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */