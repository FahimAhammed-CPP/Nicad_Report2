package com.baidu.location;

public final class LocationClientOption {
  public static final int GpsFirst = 1;
  
  public static final int MIN_SCAN_SPAN = 1000;
  
  public static final int MIN_SCAN_SPAN_NETWORK = 3000;
  
  public static final int NetWorkFirst = 2;
  
  protected static final int try = 3;
  
  protected boolean a = true;
  
  protected int b = 12000;
  
  protected String byte = "com.baidu.location.service_v2.9";
  
  protected boolean c = false;
  
  protected boolean case = false;
  
  protected String char = "detail";
  
  protected LocationMode d;
  
  protected String do = "gcj02";
  
  protected boolean e = false;
  
  protected boolean else = false;
  
  protected int f = 1;
  
  protected boolean for = false;
  
  protected int goto = 3;
  
  protected String if = "SDK2.0";
  
  protected int int = 0;
  
  protected boolean long = false;
  
  protected boolean new = false;
  
  protected float void = 500.0F;
  
  public LocationClientOption() {}
  
  public LocationClientOption(LocationClientOption paramLocationClientOption) {
    this.do = paramLocationClientOption.do;
    this.char = paramLocationClientOption.char;
    this.for = paramLocationClientOption.for;
    this.int = paramLocationClientOption.int;
    this.b = paramLocationClientOption.b;
    this.if = paramLocationClientOption.if;
    this.f = paramLocationClientOption.f;
    this.else = paramLocationClientOption.else;
    this.c = paramLocationClientOption.c;
    this.void = paramLocationClientOption.void;
    this.goto = paramLocationClientOption.goto;
    this.byte = paramLocationClientOption.byte;
    this.a = paramLocationClientOption.a;
    this.long = paramLocationClientOption.long;
    this.case = paramLocationClientOption.case;
    this.e = paramLocationClientOption.e;
    this.d = paramLocationClientOption.d;
  }
  
  public void SetIgnoreCacheException(boolean paramBoolean) {
    this.long = paramBoolean;
  }
  
  public void disableCache(boolean paramBoolean) {
    this.a = paramBoolean;
  }
  
  public boolean equals(LocationClientOption paramLocationClientOption) {
    return (this.do.equals(paramLocationClientOption.do) && this.char.equals(paramLocationClientOption.char) && this.for == paramLocationClientOption.for && this.int == paramLocationClientOption.int && this.b == paramLocationClientOption.b && this.if.equals(paramLocationClientOption.if) && this.else == paramLocationClientOption.else && this.f == paramLocationClientOption.f && this.goto == paramLocationClientOption.goto && this.c == paramLocationClientOption.c && this.void == paramLocationClientOption.void && this.a == paramLocationClientOption.a && this.long == paramLocationClientOption.long && this.case == paramLocationClientOption.case && this.e == paramLocationClientOption.e && this.d == paramLocationClientOption.d);
  }
  
  public String getAddrType() {
    return this.char;
  }
  
  public String getCoorType() {
    return this.do;
  }
  
  public LocationMode getLocationMode() {
    return this.d;
  }
  
  public float getPoiDistance() {
    return this.void;
  }
  
  public boolean getPoiExtranInfo() {
    return this.c;
  }
  
  public int getPoiNumber() {
    return this.goto;
  }
  
  public int getPriority() {
    return this.f;
  }
  
  public String getProdName() {
    return this.if;
  }
  
  public int getScanSpan() {
    return this.int;
  }
  
  public String getServiceName() {
    return this.byte;
  }
  
  public int getTimeOut() {
    return this.b;
  }
  
  public boolean isDisableCache() {
    return this.a;
  }
  
  public boolean isLocationNotify() {
    return this.else;
  }
  
  public boolean isOpenGps() {
    return this.for;
  }
  
  public void setAddrType(String paramString) {
    String str = paramString;
    if (paramString.length() > 32)
      str = paramString.substring(0, 32); 
    this.char = str;
    if ("all".equals(this.char))
      this.f = 2; 
  }
  
  public void setCoorType(String paramString) {
    paramString = paramString.toLowerCase();
    if (paramString.equals("gcj02") || paramString.equals("bd09") || paramString.equals("bd09ll"))
      this.do = paramString; 
  }
  
  public void setIgnoreKillProcess(boolean paramBoolean) {
    this.case = paramBoolean;
  }
  
  public void setIsNeedAddress(boolean paramBoolean) {
    if (paramBoolean) {
      this.char = "all";
      this.f = 2;
    } 
  }
  
  public void setLocationMode(LocationMode paramLocationMode) {
    switch (null.a[paramLocationMode.ordinal()]) {
      default:
        throw new IllegalArgumentException("Illegal this mode : " + paramLocationMode);
      case 1:
        this.for = true;
        this.d = paramLocationMode;
        return;
      case 2:
        this.for = false;
        this.d = paramLocationMode;
        return;
      case 3:
        break;
    } 
    this.f = 3;
    this.for = true;
    this.d = paramLocationMode;
  }
  
  public void setLocationNotify(boolean paramBoolean) {
    this.else = paramBoolean;
  }
  
  public void setNeedDeviceDirect(boolean paramBoolean) {
    this.e = paramBoolean;
  }
  
  public void setOpenGps(boolean paramBoolean) {
    this.for = paramBoolean;
  }
  
  public void setPoiDistance(float paramFloat) {
    this.void = paramFloat;
  }
  
  public void setPoiExtraInfo(boolean paramBoolean) {
    this.c = paramBoolean;
  }
  
  public void setPoiNumber(int paramInt) {
    int i = paramInt;
    if (paramInt > 10)
      i = 10; 
    this.goto = i;
  }
  
  public void setPriority(int paramInt) {
    if (paramInt == 1 || paramInt == 2)
      this.f = paramInt; 
  }
  
  public void setProdName(String paramString) {
    String str = paramString;
    if (paramString.length() > 64)
      str = paramString.substring(0, 64); 
    this.if = str;
  }
  
  public void setScanSpan(int paramInt) {
    this.int = paramInt;
  }
  
  public void setServiceName(String paramString) {
    this.byte = paramString;
  }
  
  public void setTimeOut(int paramInt) {
    this.b = paramInt;
  }
  
  public enum LocationMode {
    Battery_Saving, Device_Sensors, Hight_Accuracy;
    
    static {
    
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/LocationClientOption.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */