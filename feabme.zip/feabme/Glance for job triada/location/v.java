package com.baidu.location;

import android.content.Context;
import android.location.GpsSatellite;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

class v implements au, l {
  private static final int fA = 10000;
  
  private static final int fD = 5;
  
  private static v fE = null;
  
  private static File fF;
  
  private static final int fM = 290000;
  
  private static String fP;
  
  private static StringBuilder fg;
  
  private static final double fh = 1.0E-5D;
  
  private static final int fj = 3000;
  
  private static String fl;
  
  private static int fs = 0;
  
  private static final int ft = 1;
  
  private static String fv = null;
  
  private static final int fy = 3;
  
  private GpsStatus e7;
  
  private int e8;
  
  private Handler e9 = null;
  
  private long fB;
  
  private b fC = null;
  
  private boolean fG = false;
  
  private c fH = null;
  
  private String fI = null;
  
  private Location fJ;
  
  private final int fK = 1;
  
  private long fL = 0L;
  
  private long fN;
  
  private int fO;
  
  private long fQ;
  
  private final int fa = 2;
  
  private LocationManager fb = null;
  
  private boolean fc = false;
  
  private Location fd;
  
  private a fe = null;
  
  private final int ff = 4;
  
  private HashMap fi;
  
  private long fk = 0L;
  
  private Location fm;
  
  private long fn = 0L;
  
  private long fo;
  
  private Location fp;
  
  private Context fq;
  
  private long fr = 0L;
  
  private final long fu = 1000L;
  
  private final int fw = 3;
  
  private Location fx;
  
  private boolean fz = false;
  
  static {
    fP = "Temp_in.dat";
    fF = new File(f.H, fP);
  }
  
  private boolean aD() {
    return false;
  }
  
  private static String aK() {
    if (fg != null) {
      if (!TextUtils.isEmpty(fg.toString()))
        fg.insert(0, "&snls="); 
      if (!TextUtils.isEmpty(fl))
        fg.append("&pogr=").append(fl); 
      return fg.toString();
    } 
    return null;
  }
  
  public static v aR() {
    if (fE == null)
      fE = new v(); 
    return fE;
  }
  
  public static String byte(Location paramLocation) {
    String str2 = case(paramLocation);
    String str1 = str2;
    if (str2 != null)
      str1 = str2 + "&g_tp=0"; 
    return str1;
  }
  
  public static String case(Location paramLocation) {
    float f2;
    double d;
    if (paramLocation == null)
      return null; 
    float f1 = (float)(paramLocation.getSpeed() * 3.6D);
    if (paramLocation.hasAccuracy()) {
      f2 = paramLocation.getAccuracy();
    } else {
      f2 = -1.0F;
    } 
    int i = (int)f2;
    if (paramLocation.hasAltitude()) {
      d = paramLocation.getAltitude();
    } else {
      d = 555.0D;
    } 
    return String.format(Locale.CHINA, "&ll=%.5f|%.5f&s=%.1f&d=%.1f&ll_r=%d&ll_n=%d&ll_h=%.2f&ll_t=%d", new Object[] { Double.valueOf(paramLocation.getLongitude()), Double.valueOf(paramLocation.getLatitude()), Float.valueOf(f1), Float.valueOf(paramLocation.getBearing()), Integer.valueOf(i), Integer.valueOf(fs), Double.valueOf(d), Long.valueOf(paramLocation.getTime() / 1000L) });
  }
  
  private double[] do(double paramDouble1, double paramDouble2) {
    return new double[] { Math.sin(Math.toRadians(paramDouble2)) * paramDouble1, Math.cos(Math.toRadians(paramDouble2)) * paramDouble1 };
  }
  
  private void for(Location paramLocation) {
    this.fJ = paramLocation;
    if (this.fJ == null) {
      this.fI = null;
    } else {
      long l1 = System.currentTimeMillis();
      this.fJ.setTime(l1);
      float f = (float)(this.fJ.getSpeed() * 3.6D);
      int i = fs;
      int j = i;
      if (i == 0)
        try {
          j = this.fJ.getExtras().getInt("satellites");
        } catch (Exception exception) {
          j = i;
        }  
      this.fI = String.format(Locale.CHINA, "&ll=%.5f|%.5f&s=%.1f&d=%.1f&ll_n=%d&ll_t=%d", new Object[] { Double.valueOf(this.fJ.getLongitude()), Double.valueOf(this.fJ.getLatitude()), Float.valueOf(f), Float.valueOf(this.fJ.getBearing()), Integer.valueOf(j), Long.valueOf(l1) });
      if(this.fJ.getLongitude(), this.fJ.getLatitude(), f);
    } 
    try {
      u.ax().do(this.fJ);
    } catch (Exception exception) {}
    if (aE()) {
      i.m().try(aC());
      if (fs > 2 && o.if(this.fJ, true)) {
        ao.bC().bJ();
        o.do(r.aa().X(), ao.bC().by(), this.fJ, i.m().l());
      } 
    } 
  }
  
  private double[] for(double paramDouble1, double paramDouble2) {
    double d = 0.0D;
    if (paramDouble2 == 0.0D) {
      if (paramDouble1 > 0.0D) {
        d = 90.0D;
        return new double[] { Math.sqrt(paramDouble1 * paramDouble1 + paramDouble2 * paramDouble2), d };
      } 
      if (paramDouble1 < 0.0D)
        d = 270.0D; 
      return new double[] { Math.sqrt(paramDouble1 * paramDouble1 + paramDouble2 * paramDouble2), d };
    } 
    d = Math.toDegrees(Math.atan(paramDouble1 / paramDouble2));
    return new double[] { Math.sqrt(paramDouble1 * paramDouble1 + paramDouble2 * paramDouble2), d };
  }
  
  private int if(aq paramaq, int paramInt) {
    byte b1 = 1;
    if (fs >= c.V)
      return b1; 
    if (fs <= c.aG)
      return 4; 
    double d = paramaq.cE();
    int i = b1;
    if (d > c.ad) {
      if (d >= c.aP)
        return 4; 
      d = paramaq.cH();
      i = b1;
      if (d > c.af) {
        if (d >= c.aR)
          return 4; 
        i = b1;
        if (paramInt < c.W) {
          if (paramInt <= c.aH)
            return 4; 
          if (this.fi != null)
            return if(this.fi); 
          i = 3;
        } 
      } 
    } 
    return i;
  }
  
  private int if(HashMap paramHashMap) {
    if (this.fO > 4) {
      ArrayList<double[]> arrayList = new ArrayList();
      ArrayList<Integer> arrayList1 = new ArrayList();
      Iterator<Map.Entry> iterator = paramHashMap.entrySet().iterator();
      int i = 0;
      while (iterator.hasNext()) {
        List list = (List)((Map.Entry)iterator.next()).getValue();
        if (list != null) {
          double[] arrayOfDouble = if(list);
          if (arrayOfDouble != null) {
            arrayList.add(arrayOfDouble);
            int j = i + 1;
            arrayList1.add(Integer.valueOf(i));
            i = j;
          } 
        } 
      } 
      if (!arrayList.isEmpty()) {
        double[] arrayOfDouble1 = new double[2];
        int j = arrayList.size();
        for (i = 0; i < j; i++) {
          double[] arrayOfDouble = arrayList.get(i);
          int k = ((Integer)arrayList1.get(i)).intValue();
          arrayOfDouble[0] = arrayOfDouble[0] * k;
          arrayOfDouble[1] = arrayOfDouble[1] * k;
          arrayOfDouble1[0] = arrayOfDouble1[0] + arrayOfDouble[0];
          arrayOfDouble1[1] = arrayOfDouble1[1] + arrayOfDouble[1];
        } 
        arrayOfDouble1[0] = arrayOfDouble1[0] / j;
        arrayOfDouble1[1] = arrayOfDouble1[1] / j;
        double[] arrayOfDouble2 = for(arrayOfDouble1[0], arrayOfDouble1[1]);
        fl = String.format(Locale.CHINA, "%d,%d,%d,%d", new Object[] { Long.valueOf(Math.round(arrayOfDouble1[0] * 100.0D)), Long.valueOf(Math.round(arrayOfDouble1[1] * 100.0D)), Long.valueOf(Math.round(arrayOfDouble2[0] * 100.0D)), Long.valueOf(Math.round(arrayOfDouble2[1] * 100.0D)) });
        if (arrayOfDouble2[0] <= c.aw)
          return 1; 
        if (arrayOfDouble2[0] >= c.a2)
          return 4; 
      } 
    } 
    return 3;
  }
  
  private String if(GpsSatellite paramGpsSatellite, HashMap<Integer, List<GpsSatellite>> paramHashMap) {
    int i = (int)Math.floor((paramGpsSatellite.getAzimuth() / 30.0F));
    float f1 = paramGpsSatellite.getElevation();
    int j = (int)Math.floor((f1 / 15.0F));
    float f2 = paramGpsSatellite.getSnr();
    int k = Math.round(f2 / 5.0F);
    if (f2 >= 10.0F && f1 >= 1.0F) {
      List<GpsSatellite> list1 = (List)paramHashMap.get(Integer.valueOf(k));
      List<GpsSatellite> list2 = list1;
      if (list1 == null)
        list2 = new ArrayList(); 
      list2.add(paramGpsSatellite);
      paramHashMap.put(Integer.valueOf(k), list2);
      this.fO++;
    } 
    int m = i;
    if (i >= 12)
      m = 11; 
    if (j >= 6)
      j = 5; 
    return String.format(Locale.CHINA, "%02d%d", new Object[] { Integer.valueOf(j + m * 6 + 1), Integer.valueOf(k) });
  }
  
  private void if(double paramDouble1, double paramDouble2, float paramFloat) {
    byte b1 = 0;
    if (w.fS) {
      int i = b1;
      if (paramDouble1 >= 73.146973D) {
        i = b1;
        if (paramDouble1 <= 135.252686D) {
          i = b1;
          if (paramDouble2 <= 54.258807D) {
            i = b1;
            if (paramDouble2 >= 14.604847D)
              if (paramFloat > 18.0F) {
                i = b1;
              } else {
                double d1 = c.aF;
                double d2 = c.ab;
                i = (int)((paramDouble1 - d1) * 1000.0D);
                int j = (int)((d2 - paramDouble2) * 1000.0D);
                if (i > 0 && i < 50 && j > 0 && j < 50) {
                  j = i + j * 50;
                  i = b1;
                  if (c.aq)
                    i = c.aA[j >> 2] >> (j & 0x3) * 2 & 0x3; 
                } else {
                  String str = String.format(Locale.CHINA, "&ll=%.5f|%.5f", new Object[] { Double.valueOf(paramDouble1), Double.valueOf(paramDouble2) });
                  str = str + "&im=" + aw.b6().b3();
                  c.a7 = paramDouble1;
                  c.am = paramDouble2;
                  w.aU().l(str);
                  i = b1;
                } 
              }  
          } 
        } 
      } 
      if (c.aj != i)
        c.aj = i; 
    } 
  }
  
  private void if(String paramString, Location paramLocation) {
    paramString = paramString + i.m().l();
    o.do(r.aa().X(), ao.bC().by(), paramLocation, paramString);
  }
  
  public static boolean if(Location paramLocation1, Location paramLocation2, boolean paramBoolean) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_3
    //   2: aload_0
    //   3: aload_1
    //   4: if_acmpne -> 13
    //   7: iconst_0
    //   8: istore #4
    //   10: iload #4
    //   12: ireturn
    //   13: iload_3
    //   14: istore #4
    //   16: aload_0
    //   17: ifnull -> 10
    //   20: iload_3
    //   21: istore #4
    //   23: aload_1
    //   24: ifnull -> 10
    //   27: aload_1
    //   28: invokevirtual getSpeed : ()F
    //   31: fstore #5
    //   33: iload_2
    //   34: ifeq -> 56
    //   37: getstatic com/baidu/location/c.aj : I
    //   40: iconst_3
    //   41: if_icmpne -> 56
    //   44: iload_3
    //   45: istore #4
    //   47: fload #5
    //   49: ldc_w 5.0
    //   52: fcmpg
    //   53: iflt -> 10
    //   56: aload_1
    //   57: aload_0
    //   58: invokevirtual distanceTo : (Landroid/location/Location;)F
    //   61: fstore #6
    //   63: fload #5
    //   65: getstatic com/baidu/location/c.a9 : F
    //   68: fcmpl
    //   69: ifle -> 90
    //   72: iload_3
    //   73: istore #4
    //   75: fload #6
    //   77: getstatic com/baidu/location/c.aY : F
    //   80: fcmpl
    //   81: ifgt -> 10
    //   84: iconst_0
    //   85: istore #4
    //   87: goto -> 10
    //   90: fload #5
    //   92: getstatic com/baidu/location/c.bc : F
    //   95: fcmpl
    //   96: ifle -> 117
    //   99: iload_3
    //   100: istore #4
    //   102: fload #6
    //   104: getstatic com/baidu/location/c.ao : F
    //   107: fcmpl
    //   108: ifgt -> 10
    //   111: iconst_0
    //   112: istore #4
    //   114: goto -> 10
    //   117: iload_3
    //   118: istore #4
    //   120: fload #6
    //   122: ldc_w 5.0
    //   125: fcmpl
    //   126: ifgt -> 10
    //   129: iconst_0
    //   130: istore #4
    //   132: goto -> 10
  }
  
  private double[] if(List paramList) {
    if (paramList == null || paramList.isEmpty())
      return null; 
    double[] arrayOfDouble = new double[2];
    for (GpsSatellite gpsSatellite : paramList) {
      if (gpsSatellite != null) {
        double[] arrayOfDouble1 = do((90.0F - gpsSatellite.getElevation()), gpsSatellite.getAzimuth());
        arrayOfDouble[0] = arrayOfDouble[0] + arrayOfDouble1[0];
        arrayOfDouble[1] = arrayOfDouble[1] + arrayOfDouble1[1];
      } 
    } 
    int i = paramList.size();
    arrayOfDouble[0] = arrayOfDouble[0] / i;
    arrayOfDouble[1] = arrayOfDouble[1] / i;
    return arrayOfDouble;
  }
  
  private void int(Location paramLocation) {
    Message message = this.e9.obtainMessage(1, paramLocation);
    this.e9.sendMessage(message);
  }
  
  public static String new(Location paramLocation) {
    String str2 = case(paramLocation);
    String str1 = str2;
    if (str2 != null)
      str1 = str2 + fv; 
    String str3 = aK();
    str2 = str1;
    if (!TextUtils.isEmpty(str3))
      str2 = str1 + str3; 
    return str2;
  }
  
  private void new(boolean paramBoolean) {
    this.fG = paramBoolean;
    if (!paramBoolean || !aE());
  }
  
  private void try(Location paramLocation) {
    long l1 = System.currentTimeMillis();
    this.fx = paramLocation;
    this.fN = l1;
    if (this.fB == 0L || l1 - this.fB >= 290000L || this.fp == null) {
      if (this.fd == null) {
        this.fd = paramLocation;
        this.fm = this.fd;
        this.fB = l1;
        this.fQ = this.fB;
        this.fp = null;
        return;
      } 
    } else {
      return;
    } 
    if (l1 - this.fB >= 10000L) {
      this.fp = paramLocation;
      String str2 = String.format("&dt=%.6f|%.6f|%s|%s|%s", new Object[] { Double.valueOf(this.fp.getLongitude() - this.fd.getLongitude()), Double.valueOf(this.fp.getLatitude() - this.fd.getLatitude()), Float.valueOf(this.fp.getSpeed()), Float.valueOf(this.fp.getBearing()), Long.valueOf(l1 - this.fB) });
      String str1 = o.if(r.aa().X(), ao.bC().by(), paramLocation, i.m().l(), str2);
      if (!TextUtils.isEmpty(str1)) {
        str1 = Jni.h(str1);
        o.u().goto(str1);
      } 
      this.fd = null;
    } 
  }
  
  public String aC() {
    String str = null;
    if (this.fJ != null) {
      str = "{\"result\":{\"time\":\"" + c.int() + "\",\"error\":\"61\"},\"content\":{\"point\":{\"x\":" + "\"%f\",\"y\":\"%f\"},\"radius\":\"%d\",\"d\":\"%f\"," + "\"s\":\"%f\",\"n\":\"%d\"}}";
      if (this.fJ.hasAccuracy()) {
        f = this.fJ.getAccuracy();
      } else {
        f = 10.0F;
      } 
      int i = (int)f;
      float f = (float)(this.fJ.getSpeed() * 3.6D);
      double[] arrayOfDouble = Jni.if(this.fJ.getLongitude(), this.fJ.getLatitude(), "gps2gcj");
      if (arrayOfDouble[0] <= 0.0D && arrayOfDouble[1] <= 0.0D) {
        arrayOfDouble[0] = this.fJ.getLongitude();
        arrayOfDouble[1] = this.fJ.getLatitude();
      } 
      str = String.format(Locale.CHINA, str, new Object[] { Double.valueOf(arrayOfDouble[0]), Double.valueOf(arrayOfDouble[1]), Integer.valueOf(i), Float.valueOf(this.fJ.getBearing()), Float.valueOf(f), Integer.valueOf(fs) });
    } 
    return str;
  }
  
  public boolean aE() {
    boolean bool = false;
    if (aG() && System.currentTimeMillis() - this.fr <= 10000L) {
      long l1 = System.currentTimeMillis();
      if (this.fc && l1 - this.fk < 3000L)
        return true; 
      bool = this.fG;
    } 
    return bool;
  }
  
  public Location aF() {
    return this.fJ;
  }
  
  public boolean aG() {
    return (this.fJ != null && this.fJ.getLatitude() != 0.0D && this.fJ.getLongitude() != 0.0D);
  }
  
  public void aH() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic com/baidu/location/f.isServing : Z
    //   5: istore_1
    //   6: iload_1
    //   7: ifne -> 13
    //   10: aload_0
    //   11: monitorexit
    //   12: return
    //   13: aload_0
    //   14: invokestatic getServiceContext : ()Landroid/content/Context;
    //   17: putfield fq : Landroid/content/Context;
    //   20: aload_0
    //   21: aload_0
    //   22: getfield fq : Landroid/content/Context;
    //   25: ldc_w 'location'
    //   28: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   31: checkcast android/location/LocationManager
    //   34: putfield fb : Landroid/location/LocationManager;
    //   37: new com/baidu/location/v$a
    //   40: astore_2
    //   41: aload_2
    //   42: aload_0
    //   43: aconst_null
    //   44: invokespecial <init> : (Lcom/baidu/location/v;Lcom/baidu/location/v$1;)V
    //   47: aload_0
    //   48: aload_2
    //   49: putfield fe : Lcom/baidu/location/v$a;
    //   52: aload_0
    //   53: getfield fb : Landroid/location/LocationManager;
    //   56: aload_0
    //   57: getfield fe : Lcom/baidu/location/v$a;
    //   60: invokevirtual addGpsStatusListener : (Landroid/location/GpsStatus$Listener;)Z
    //   63: pop
    //   64: new com/baidu/location/v$c
    //   67: astore_2
    //   68: aload_2
    //   69: aload_0
    //   70: aconst_null
    //   71: invokespecial <init> : (Lcom/baidu/location/v;Lcom/baidu/location/v$1;)V
    //   74: aload_0
    //   75: aload_2
    //   76: putfield fH : Lcom/baidu/location/v$c;
    //   79: aload_0
    //   80: getfield fb : Landroid/location/LocationManager;
    //   83: ldc_w 'passive'
    //   86: ldc2_w 1000
    //   89: fconst_0
    //   90: aload_0
    //   91: getfield fH : Lcom/baidu/location/v$c;
    //   94: invokevirtual requestLocationUpdates : (Ljava/lang/String;JFLandroid/location/LocationListener;)V
    //   97: new com/baidu/location/v$1
    //   100: astore_2
    //   101: aload_2
    //   102: aload_0
    //   103: invokespecial <init> : (Lcom/baidu/location/v;)V
    //   106: aload_0
    //   107: aload_2
    //   108: putfield e9 : Landroid/os/Handler;
    //   111: goto -> 10
    //   114: astore_2
    //   115: aload_0
    //   116: monitorexit
    //   117: aload_2
    //   118: athrow
    //   119: astore_2
    //   120: goto -> 97
    // Exception table:
    //   from	to	target	type
    //   2	6	114	finally
    //   13	20	114	finally
    //   20	97	119	java/lang/Exception
    //   20	97	114	finally
    //   97	111	114	finally
  }
  
  public String aI() {
    return this.fI;
  }
  
  public void aJ() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual aQ : ()V
    //   6: aload_0
    //   7: getfield fb : Landroid/location/LocationManager;
    //   10: astore_1
    //   11: aload_1
    //   12: ifnonnull -> 18
    //   15: aload_0
    //   16: monitorexit
    //   17: return
    //   18: aload_0
    //   19: getfield fe : Lcom/baidu/location/v$a;
    //   22: ifnull -> 36
    //   25: aload_0
    //   26: getfield fb : Landroid/location/LocationManager;
    //   29: aload_0
    //   30: getfield fe : Lcom/baidu/location/v$a;
    //   33: invokevirtual removeGpsStatusListener : (Landroid/location/GpsStatus$Listener;)V
    //   36: aload_0
    //   37: getfield fb : Landroid/location/LocationManager;
    //   40: aload_0
    //   41: getfield fH : Lcom/baidu/location/v$c;
    //   44: invokevirtual removeUpdates : (Landroid/location/LocationListener;)V
    //   47: aload_0
    //   48: aconst_null
    //   49: putfield fe : Lcom/baidu/location/v$a;
    //   52: aload_0
    //   53: aconst_null
    //   54: putfield fb : Landroid/location/LocationManager;
    //   57: goto -> 15
    //   60: astore_1
    //   61: aload_0
    //   62: monitorexit
    //   63: aload_1
    //   64: athrow
    //   65: astore_1
    //   66: goto -> 47
    // Exception table:
    //   from	to	target	type
    //   2	11	60	finally
    //   18	36	65	java/lang/Exception
    //   18	36	60	finally
    //   36	47	65	java/lang/Exception
    //   36	47	60	finally
    //   47	57	60	finally
  }
  
  public String aL() {
    return (aE() && this.fJ != null) ? case(this.fJ) : null;
  }
  
  public void aN() {
    try {
      if (this.fx != null || this.fm != null) {
        String str = String.format(Locale.CHINA, "&dt=%.6f|%.6f|%s|%s|%s", new Object[] { Double.valueOf(this.fx.getLongitude() - this.fm.getLongitude()), Double.valueOf(this.fx.getLatitude() - this.fm.getLatitude()), Float.valueOf(this.fx.getSpeed()), Float.valueOf(this.fx.getBearing()), Long.valueOf(this.fN - this.fQ) });
        str = o.if(r.aa().X(), ao.bC().by(), this.fx, i.m().l(), str);
        if (!TextUtils.isEmpty(str)) {
          str = Jni.h(str);
          o.u().goto(str);
        } 
      } 
    } catch (Exception exception) {}
  }
  
  public boolean aO() {
    return (this.fb != null) ? this.fb.isProviderEnabled("gps") : false;
  }
  
  public void aP() {
    if (!this.fz)
      try {
        b b1 = new b();
        this(this, null);
        this.fC = b1;
        this.fb.requestLocationUpdates("gps", 1000L, 0.0F, this.fC);
        this.fb.addNmeaListener(this.fe);
        this.fz = true;
      } catch (Exception exception) {} 
  }
  
  public void aQ() {
    if (this.fz) {
      if (this.fb != null)
        try {
          if (this.fC != null)
            this.fb.removeUpdates(this.fC); 
          if (this.fe != null)
            this.fb.removeNmeaListener(this.fe); 
        } catch (Exception exception) {} 
      c.ak = 0;
      c.aj = 0;
      this.fC = null;
      this.fz = false;
      new(false);
    } 
  }
  
  public void int(boolean paramBoolean) {
    if (paramBoolean) {
      aP();
      return;
    } 
    aQ();
  }
  
  private class a implements GpsStatus.Listener, GpsStatus.NmeaListener {
    private long a = 0L;
    
    private boolean byte = false;
    
    private List case = new ArrayList();
    
    private final int char = 400;
    
    private String do = null;
    
    private String for = null;
    
    long if = 0L;
    
    private String new = null;
    
    private boolean try = true;
    
    private a(v this$0) {}
    
    public void a(String param1String) {
      if (System.currentTimeMillis() - this.a > 400L && this.byte && this.case.size() > 0) {
        try {
          aq aq = new aq();
          this(this.case, this.for, this.new, this.do);
          if (aq.cG()) {
            c.ak = v.if(this.int, aq, v.try(this.int));
            if (c.ak > 0)
              v.k(String.format(Locale.CHINA, "&nmea=%.1f|%.1f&g_tp=%d", new Object[] { Double.valueOf(aq.cE()), Double.valueOf(aq.cH()), Integer.valueOf(c.ak) })); 
          } else {
            c.ak = 0;
          } 
        } catch (Exception exception) {
          c.ak = 0;
        } 
        this.case.clear();
        this.do = null;
        this.new = null;
        this.for = null;
        this.byte = false;
      } 
      if (param1String.startsWith("$GPGGA")) {
        this.byte = true;
        this.for = param1String.trim();
      } else if (param1String.startsWith("$GPGSV")) {
        this.case.add(param1String.trim());
      } else if (param1String.startsWith("$GPGSA")) {
        this.do = param1String.trim();
      } 
      this.a = System.currentTimeMillis();
    }
    
    public void onGpsStatusChanged(int param1Int) {
      if (v.if(this.int) == null);
      switch (param1Int) {
        default:
          return;
        case 2:
          v.if(this.int, (Location)null);
          v.if(this.int, false);
          v.int(0);
        case 4:
          break;
      } 
      if (v.case(this.int) || System.currentTimeMillis() - this.if >= 10000L) {
        if (v.do(this.int) == null) {
          v.if(this.int, v.if(this.int).getGpsStatus(null));
        } else {
          v.if(this.int).getGpsStatus(v.do(this.int));
        } 
        Iterator<GpsSatellite> iterator = v.do(this.int).getSatellites().iterator();
        v.if(new StringBuilder());
        v.do(this.int, 0);
        v.if(this.int, 0);
        v.do(this.int, new HashMap<Object, Object>());
        param1Int = 0;
        byte b = 0;
        int i;
        for (i = 0; iterator.hasNext(); i = j) {
          GpsSatellite gpsSatellite = iterator.next();
          b++;
          int j = i;
          if (gpsSatellite.usedInFix())
            j = i + 1; 
          i = param1Int;
          if (gpsSatellite.getSnr() > 0.0F)
            i = param1Int + 1; 
          if (gpsSatellite.getSnr() >= c.Z)
            v.int(this.int); 
          v.aM().append(v.if(this.int, gpsSatellite, v.new(this.int)));
          param1Int = i;
        } 
        v.int(param1Int);
        v.if(this.int, v.new(this.int));
        if (!v.case(this.int) && System.currentTimeMillis() - v.char(this.int) >= 60000L && (i > 3 || b > 15)) {
          Location location = v.if(this.int).getLastKnownLocation("gps");
          if (location != null) {
            this.if = System.currentTimeMillis();
            long l = System.currentTimeMillis() + (d.long()).bm - location.getTime();
            if (l < 3500L && l > -200L && o.if(location, false)) {
              Message message = v.byte(this.int).obtainMessage(3, location);
              v.byte(this.int).sendMessage(message);
            } 
          } 
        } 
      } 
    }
    
    public void onNmeaReceived(long param1Long, String param1String) {
      if (v.case(this.int)) {
        if (!w.fW) {
          c.ak = 0;
          return;
        } 
        if (param1String != null && !param1String.equals("") && param1String.length() >= 9 && param1String.length() <= 150 && this.int.aE())
          v.byte(this.int).sendMessage(v.byte(this.int).obtainMessage(2, param1String)); 
      } 
    }
  }
  
  private class b implements LocationListener {
    private b(v this$0) {}
    
    public void onLocationChanged(Location param1Location) {
      v.do(this.a, System.currentTimeMillis());
      v.if(this.a, true);
      v.if(this.a, param1Location);
      v.do(this.a, false);
    }
    
    public void onProviderDisabled(String param1String) {
      v.if(this.a, (Location)null);
      v.if(this.a, false);
    }
    
    public void onProviderEnabled(String param1String) {}
    
    public void onStatusChanged(String param1String, int param1Int, Bundle param1Bundle) {
      switch (param1Int) {
        default:
          return;
        case 0:
          v.if(this.a, (Location)null);
          v.if(this.a, false);
        case 1:
          v.if(this.a, System.currentTimeMillis());
          v.do(this.a, true);
          v.if(this.a, false);
        case 2:
          break;
      } 
      v.do(this.a, false);
    }
  }
  
  private class c implements LocationListener {
    private long if = 0L;
    
    private c(v this$0) {}
    
    public void onLocationChanged(Location param1Location) {
      if (!v.case(this.a) && param1Location != null && param1Location.getProvider() == "gps") {
        v.for(this.a, System.currentTimeMillis());
        if (System.currentTimeMillis() - this.if >= 10000L && o.if(param1Location, false)) {
          this.if = System.currentTimeMillis();
          Message message = v.byte(this.a).obtainMessage(4, param1Location);
          v.byte(this.a).sendMessage(message);
        } 
      } 
    }
    
    public void onProviderDisabled(String param1String) {}
    
    public void onProviderEnabled(String param1String) {}
    
    public void onStatusChanged(String param1String, int param1Int, Bundle param1Bundle) {}
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */