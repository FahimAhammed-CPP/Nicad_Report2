package com.baidu.location;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.Location;
import java.util.ArrayList;
import java.util.Iterator;

public class x implements au, l {
  public static final String f9 = "android.com.baidu.location.TIMER.NOTIFY";
  
  private int f5 = 0;
  
  private Context f6 = null;
  
  private AlarmManager f7 = null;
  
  private a f8 = new a(this);
  
  private PendingIntent ga = null;
  
  private ArrayList gb = null;
  
  private BDLocation gc = null;
  
  private long gd = 0L;
  
  private b ge = null;
  
  private float gf = Float.MAX_VALUE;
  
  private boolean gg = false;
  
  private boolean gh = false;
  
  private long gi = 0L;
  
  private boolean gj = false;
  
  private LocationClient gk = null;
  
  public x(Context paramContext, LocationClient paramLocationClient) {
    this.f6 = paramContext;
    this.gk = paramLocationClient;
    this.gk.registerNotifyLocationListener(this.f8);
    this.f7 = (AlarmManager)this.f6.getSystemService("alarm");
    this.ge = new b(this);
    this.gj = false;
  }
  
  private void a0() {
    // Byte code:
    //   0: sipush #10000
    //   3: istore_1
    //   4: aload_0
    //   5: invokespecial a2 : ()Z
    //   8: ifne -> 12
    //   11: return
    //   12: aload_0
    //   13: getfield gf : F
    //   16: ldc 5000.0
    //   18: fcmpl
    //   19: ifle -> 106
    //   22: ldc 600000
    //   24: istore_2
    //   25: aload_0
    //   26: getfield gg : Z
    //   29: ifeq -> 150
    //   32: aload_0
    //   33: iconst_0
    //   34: putfield gg : Z
    //   37: iload_1
    //   38: istore_2
    //   39: aload_0
    //   40: getfield f5 : I
    //   43: ifeq -> 145
    //   46: aload_0
    //   47: getfield gd : J
    //   50: lstore_3
    //   51: aload_0
    //   52: getfield f5 : I
    //   55: i2l
    //   56: lstore #5
    //   58: invokestatic currentTimeMillis : ()J
    //   61: lstore #7
    //   63: iload_2
    //   64: i2l
    //   65: lload_3
    //   66: lload #5
    //   68: ladd
    //   69: lload #7
    //   71: lsub
    //   72: lcmp
    //   73: ifle -> 145
    //   76: iconst_0
    //   77: istore_1
    //   78: iload_1
    //   79: ifeq -> 11
    //   82: aload_0
    //   83: iload_2
    //   84: putfield f5 : I
    //   87: aload_0
    //   88: invokestatic currentTimeMillis : ()J
    //   91: putfield gd : J
    //   94: aload_0
    //   95: aload_0
    //   96: getfield f5 : I
    //   99: i2l
    //   100: invokespecial if : (J)V
    //   103: goto -> 11
    //   106: aload_0
    //   107: getfield gf : F
    //   110: ldc 1000.0
    //   112: fcmpl
    //   113: ifle -> 122
    //   116: ldc 120000
    //   118: istore_2
    //   119: goto -> 25
    //   122: aload_0
    //   123: getfield gf : F
    //   126: ldc 500.0
    //   128: fcmpl
    //   129: ifle -> 138
    //   132: ldc 60000
    //   134: istore_2
    //   135: goto -> 25
    //   138: sipush #10000
    //   141: istore_2
    //   142: goto -> 25
    //   145: iconst_1
    //   146: istore_1
    //   147: goto -> 78
    //   150: goto -> 39
  }
  
  private boolean a2() {
    if (this.gb == null || this.gb.isEmpty())
      return false; 
    Iterator iterator = this.gb.iterator();
    boolean bool = false;
    while (true) {
      boolean bool1 = bool;
      if (iterator.hasNext()) {
        if (((BDNotifyListener)iterator.next()).Notified < 3)
          bool = true; 
        continue;
      } 
      return bool1;
    } 
  }
  
  private void if(long paramLong) {
    if (this.gh)
      this.f7.cancel(this.ga); 
    this.ga = PendingIntent.getBroadcast(this.f6, 0, new Intent("android.com.baidu.location.TIMER.NOTIFY"), 134217728);
    this.f7.set(0, System.currentTimeMillis() + paramLong, this.ga);
  }
  
  private void int(BDLocation paramBDLocation) {
    this.gh = false;
    if (paramBDLocation.getLocType() != 61 && paramBDLocation.getLocType() != 161 && paramBDLocation.getLocType() != 65) {
      if(120000L);
      return;
    } 
    if (System.currentTimeMillis() - this.gi >= 5000L && this.gb != null) {
      this.gc = paramBDLocation;
      this.gi = System.currentTimeMillis();
      float[] arrayOfFloat = new float[1];
      Iterator<BDNotifyListener> iterator = this.gb.iterator();
      float f = Float.MAX_VALUE;
      while (iterator.hasNext()) {
        BDNotifyListener bDNotifyListener = iterator.next();
        Location.distanceBetween(paramBDLocation.getLatitude(), paramBDLocation.getLongitude(), bDNotifyListener.mLatitudeC, bDNotifyListener.mLongitudeC, arrayOfFloat);
        float f1 = arrayOfFloat[0] - bDNotifyListener.mRadius - paramBDLocation.getRadius();
        if (f1 > 0.0F) {
          if (f1 < f)
            f = f1; 
          continue;
        } 
        if (bDNotifyListener.Notified < 3) {
          bDNotifyListener.Notified++;
          bDNotifyListener.onNotify(paramBDLocation, arrayOfFloat[0]);
          if (bDNotifyListener.Notified < 3)
            this.gg = true; 
        } 
      } 
      if (f < this.gf)
        this.gf = f; 
      this.f5 = 0;
      a0();
    } 
  }
  
  public void a1() {
    if (this.gh)
      this.f7.cancel(this.ga); 
    this.gc = null;
    this.gi = 0L;
    if (this.gj)
      this.f6.unregisterReceiver(this.ge); 
    this.gj = false;
  }
  
  public int do(BDNotifyListener paramBDNotifyListener) {
    if (this.gb == null)
      this.gb = new ArrayList(); 
    this.gb.add(paramBDNotifyListener);
    paramBDNotifyListener.isAdded = true;
    paramBDNotifyListener.mNotifyCache = this;
    if (!this.gj) {
      this.f6.registerReceiver(this.ge, new IntentFilter("android.com.baidu.location.TIMER.NOTIFY"));
      this.gj = true;
    } 
    if (paramBDNotifyListener.mCoorType != null) {
      if (!paramBDNotifyListener.mCoorType.equals("gcj02")) {
        double[] arrayOfDouble = Jni.if(paramBDNotifyListener.mLongitude, paramBDNotifyListener.mLatitude, paramBDNotifyListener.mCoorType + "2gcj");
        paramBDNotifyListener.mLongitudeC = arrayOfDouble[0];
        paramBDNotifyListener.mLatitudeC = arrayOfDouble[1];
      } 
      if (this.gc == null || System.currentTimeMillis() - this.gi > 30000L) {
        this.gk.requestNotifyLocation();
      } else {
        float[] arrayOfFloat = new float[1];
        Location.distanceBetween(this.gc.getLatitude(), this.gc.getLongitude(), paramBDNotifyListener.mLatitudeC, paramBDNotifyListener.mLongitudeC, arrayOfFloat);
        float f = arrayOfFloat[0] - paramBDNotifyListener.mRadius - this.gc.getRadius();
        if (f > 0.0F) {
          if (f < this.gf)
            this.gf = f; 
        } else if (paramBDNotifyListener.Notified < 3) {
          paramBDNotifyListener.Notified++;
          paramBDNotifyListener.onNotify(this.gc, arrayOfFloat[0]);
          if (paramBDNotifyListener.Notified < 3)
            this.gg = true; 
        } 
      } 
      a0();
    } 
    return 1;
  }
  
  public int for(BDNotifyListener paramBDNotifyListener) {
    if (this.gb == null)
      return 0; 
    if (this.gb.contains(paramBDNotifyListener))
      this.gb.remove(paramBDNotifyListener); 
    if (this.gb.size() == 0 && this.gh)
      this.f7.cancel(this.ga); 
    return 1;
  }
  
  public void if(BDNotifyListener paramBDNotifyListener) {
    if (paramBDNotifyListener.mCoorType != null) {
      if (!paramBDNotifyListener.mCoorType.equals("gcj02")) {
        double[] arrayOfDouble = Jni.if(paramBDNotifyListener.mLongitude, paramBDNotifyListener.mLatitude, paramBDNotifyListener.mCoorType + "2gcj");
        paramBDNotifyListener.mLongitudeC = arrayOfDouble[0];
        paramBDNotifyListener.mLatitudeC = arrayOfDouble[1];
      } 
      if (this.gc == null || System.currentTimeMillis() - this.gi > 300000L) {
        this.gk.requestNotifyLocation();
      } else {
        float[] arrayOfFloat = new float[1];
        Location.distanceBetween(this.gc.getLatitude(), this.gc.getLongitude(), paramBDNotifyListener.mLatitudeC, paramBDNotifyListener.mLongitudeC, arrayOfFloat);
        float f = arrayOfFloat[0] - paramBDNotifyListener.mRadius - this.gc.getRadius();
        if (f > 0.0F) {
          if (f < this.gf)
            this.gf = f; 
        } else if (paramBDNotifyListener.Notified < 3) {
          paramBDNotifyListener.Notified++;
          paramBDNotifyListener.onNotify(this.gc, arrayOfFloat[0]);
          if (paramBDNotifyListener.Notified < 3)
            this.gg = true; 
        } 
      } 
      a0();
    } 
  }
  
  public class a implements BDLocationListener {
    public a(x this$0) {}
    
    public void onReceiveLocation(BDLocation param1BDLocation) {
      x.if(this.a, param1BDLocation);
    }
    
    public void onReceivePoi(BDLocation param1BDLocation) {}
  }
  
  public class b extends BroadcastReceiver {
    public b(x this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      if (x.do(this.a) != null && !x.do(this.a).isEmpty())
        x.if(this.a).requestNotifyLocation(); 
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */