package com.baidu.location;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Process;
import android.util.Log;

public class f extends Service implements au, l {
  static a h0 = null;
  
  private static Context hZ = null;
  
  public static boolean isServing = false;
  
  private boolean h1 = false;
  
  Messenger h2 = null;
  
  private Looper h3;
  
  private HandlerThread hY;
  
  private void bU() {
    r.aa().af();
    ad.al().ak();
    ab.a5().a7();
    o.t();
    i.m().k();
    if (!this.h1)
      Process.killProcess(Process.myPid()); 
  }
  
  private void bV() {
    isServing = true;
    r.aa().Z();
    ao.bC().bI();
    v.aR().aH();
    p.D().G();
    ad.al().ap();
    av.bW().b1();
    w.aU().aV();
    at.do().for();
  }
  
  private void d(Message paramMessage) {
    if (paramMessage == null || paramMessage.obj != null);
  }
  
  private void e(Message paramMessage) {
    i.m().do(paramMessage);
  }
  
  public static Handler getHandler() {
    return h0;
  }
  
  public static Context getServiceContext() {
    return hZ;
  }
  
  private void h(Message paramMessage) {
    i.m().new(paramMessage);
    w.aU().aW();
  }
  
  private void i(Message paramMessage) {
    i.m().int(paramMessage);
  }
  
  public IBinder onBind(Intent paramIntent) {
    Bundle bundle = paramIntent.getExtras();
    boolean bool = false;
    if (bundle != null) {
      aw.iu = bundle.getString("key");
      aw.iA = bundle.getString("sign");
      bool = bundle.getBoolean("cache_exception");
      this.h1 = bundle.getBoolean("kill_process");
    } 
    if (!bool)
      Thread.setDefaultUncaughtExceptionHandler(new y((Context)this)); 
    return this.h2.getBinder();
  }
  
  public void onCreate() {
    hZ = (Context)this;
    this.hY = al.a();
    this.h3 = this.hY.getLooper();
    h0 = new a(this, this.h3);
    this.h2 = new Messenger(h0);
    h0.sendEmptyMessage(0);
    Log.d("baidu_location_service", "baidu location service start1 ..." + Process.myPid());
  }
  
  public void onDestroy() {
    isServing = false;
    ao.bC().bz();
    e.for().do();
    p.D().C();
    v.aR().aJ();
    at.do().if();
    h0.sendEmptyMessage(1);
    Log.d("baidu_location_service", "baidu location service stop ...");
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    return 1;
  }
  
  public class a extends Handler {
    public a(f this$0, Looper param1Looper) {
      super(param1Looper);
    }
    
    public void handleMessage(Message param1Message) {
      if (f.isServing == true) {
        switch (param1Message.what) {
          default:
            if (param1Message.what == 0)
              f.if(this.a); 
            if (param1Message.what == 1)
              f.do(this.a); 
            super.handleMessage(param1Message);
            return;
          case 11:
            f.for(this.a, param1Message);
          case 12:
            f.do(this.a, param1Message);
          case 15:
            f.if(this.a, param1Message);
          case 57:
            f.int(this.a, param1Message);
          case 22:
            ad.al().case(param1Message);
          case 28:
            av.bW().j(param1Message);
          case 25:
            s.at().long(param1Message);
          case 41:
            ad.al().aj();
          case 110:
            ab.a5().a9();
          case 111:
            ab.a5().a7();
          case 201:
            ah.a().do();
          case 202:
            ah.a().if();
          case 203:
            ah.a().a(param1Message);
          case 206:
            ax.cf().if(f.getServiceContext(), param1Message);
          case 207:
            break;
        } 
        ar.int(f.getServiceContext());
      } 
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */