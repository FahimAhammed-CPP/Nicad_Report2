package com.baidu.location;

import android.location.Location;
import android.os.Handler;
import android.os.Message;

class v$1 extends Handler {
  v$1(v paramv) {}
  
  public void handleMessage(Message paramMessage) {
    if (!f.isServing);
    switch (paramMessage.what) {
      default:
        return;
      case 1:
        v.do(this.a, (Location)paramMessage.obj);
      case 2:
        if (v.for(this.a) != null)
          v.for(this.a).a((String)paramMessage.obj); 
      case 3:
        v.if(this.a, "&og=1", (Location)paramMessage.obj);
      case 4:
        break;
    } 
    v.if(this.a, "&og=2", (Location)paramMessage.obj);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/v$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */