package com.baidu.location;

class af$2 implements Runnable {
  af$2(af paramaf) {}
  
  public void run() {
    af.if(this.a, false);
    if (af.do(this.a) && at.do().int()) {
      o.u().w();
      af.if(this.a).postDelayed(this, c.ai);
      af.if(this.a, true);
    } 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/af$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */