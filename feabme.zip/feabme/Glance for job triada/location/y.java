package com.baidu.location;

import android.content.Context;
import android.os.Environment;
import java.io.File;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.StringWriter;
import java.util.ArrayList;
import org.apache.http.HttpEntity;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

public class y implements Thread.UncaughtExceptionHandler, au, l {
  y(Context paramContext) {
    a3();
  }
  
  private String if(Throwable paramThrowable) {
    StringWriter stringWriter = new StringWriter();
    PrintWriter printWriter = new PrintWriter(stringWriter);
    paramThrowable.printStackTrace(printWriter);
    printWriter.close();
    return stringWriter.toString();
  }
  
  public void a3() {
    String str = null;
    try {
      StringBuilder stringBuilder = new StringBuilder();
      this();
      String str1 = stringBuilder.append(Environment.getExternalStorageDirectory().getPath()).append("/traces").toString();
      stringBuilder = new StringBuilder();
      this();
      str1 = stringBuilder.append(str1).append("/error_fs.dat").toString();
      File file = new File();
      this(str1);
      if (file.exists()) {
        RandomAccessFile randomAccessFile = new RandomAccessFile();
        this(file, "rw");
        randomAccessFile.seek(280L);
        if (1326 == randomAccessFile.readInt()) {
          randomAccessFile.seek(308L);
          int i = randomAccessFile.readInt();
          if (i > 0 && i < 2048) {
            byte[] arrayOfByte = new byte[i];
            randomAccessFile.read(arrayOfByte, 0, i);
            String str2 = new String();
            this(arrayOfByte, 0, i);
          } else {
            file = null;
          } 
          randomAccessFile.seek(600L);
          i = randomAccessFile.readInt();
          str1 = str;
          if (i > 0) {
            str1 = str;
            if (i < 2048) {
              byte[] arrayOfByte = new byte[i];
              randomAccessFile.read(arrayOfByte, 0, i);
              str1 = new String();
              this(arrayOfByte, 0, i);
            } 
          } 
          if (int((String)file, str1)) {
            randomAccessFile.seek(280L);
            randomAccessFile.writeInt(12346);
          } 
        } 
        randomAccessFile.close();
      } 
    } catch (Exception exception) {}
  }
  
  public void if(File paramFile, String paramString1, String paramString2) {
    try {
      RandomAccessFile randomAccessFile = new RandomAccessFile();
      this(paramFile, "rw");
      randomAccessFile.seek(280L);
      randomAccessFile.writeInt(12346);
      randomAccessFile.seek(300L);
      randomAccessFile.writeLong(System.currentTimeMillis());
      byte[] arrayOfByte = paramString1.getBytes();
      randomAccessFile.writeInt(arrayOfByte.length);
      randomAccessFile.write(arrayOfByte, 0, arrayOfByte.length);
      randomAccessFile.seek(600L);
      arrayOfByte = paramString2.getBytes();
      randomAccessFile.writeInt(arrayOfByte.length);
      randomAccessFile.write(arrayOfByte, 0, arrayOfByte.length);
      if (!int(paramString1, paramString2)) {
        randomAccessFile.seek(280L);
        randomAccessFile.writeInt(1326);
      } 
      randomAccessFile.close();
    } catch (Exception exception) {}
  }
  
  boolean int(String paramString1, String paramString2) {
    boolean bool = false;
    if (ao.bA())
      try {
        HttpPost httpPost = new HttpPost();
        this(c.X);
        ArrayList<BasicNameValuePair> arrayList = new ArrayList();
        this();
        BasicNameValuePair basicNameValuePair2 = new BasicNameValuePair();
        this("e0", paramString1);
        arrayList.add(basicNameValuePair2);
        BasicNameValuePair basicNameValuePair1 = new BasicNameValuePair();
        this("e1", paramString2);
        arrayList.add(basicNameValuePair1);
        UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity();
        this(arrayList, "utf-8");
        httpPost.setEntity((HttpEntity)urlEncodedFormEntity);
        DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
        this();
        defaultHttpClient.getParams().setParameter("http.connection.timeout", Integer.valueOf(12000));
        defaultHttpClient.getParams().setParameter("http.socket.timeout", Integer.valueOf(12000));
        int i = defaultHttpClient.execute((HttpUriRequest)httpPost).getStatusLine().getStatusCode();
        if (i == 200)
          bool = true; 
      } catch (Exception exception) {} 
    return bool;
  }
  
  public void uncaughtException(Thread paramThread, Throwable paramThrowable) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: getstatic com/baidu/location/w.fR : Z
    //   5: ifne -> 15
    //   8: invokestatic myPid : ()I
    //   11: invokestatic killProcess : (I)V
    //   14: return
    //   15: aload_0
    //   16: aload_2
    //   17: invokespecial if : (Ljava/lang/Throwable;)Ljava/lang/String;
    //   20: astore_1
    //   21: invokestatic b6 : ()Lcom/baidu/location/aw;
    //   24: iconst_0
    //   25: invokevirtual char : (Z)Ljava/lang/String;
    //   28: astore #4
    //   30: new java/lang/StringBuilder
    //   33: astore_2
    //   34: aload_2
    //   35: invokespecial <init> : ()V
    //   38: aload_2
    //   39: aload #4
    //   41: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   44: invokestatic m : ()Lcom/baidu/location/i;
    //   47: invokevirtual l : ()Ljava/lang/String;
    //   50: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   53: invokevirtual toString : ()Ljava/lang/String;
    //   56: astore_2
    //   57: aload_2
    //   58: ifnull -> 269
    //   61: aload_2
    //   62: invokestatic h : (Ljava/lang/String;)Ljava/lang/String;
    //   65: astore_2
    //   66: new java/lang/StringBuilder
    //   69: astore #4
    //   71: aload #4
    //   73: invokespecial <init> : ()V
    //   76: aload #4
    //   78: invokestatic getExternalStorageDirectory : ()Ljava/io/File;
    //   81: invokevirtual getPath : ()Ljava/lang/String;
    //   84: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   87: ldc '/traces'
    //   89: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   92: invokevirtual toString : ()Ljava/lang/String;
    //   95: astore #5
    //   97: new java/lang/StringBuilder
    //   100: astore #4
    //   102: aload #4
    //   104: invokespecial <init> : ()V
    //   107: aload #4
    //   109: aload #5
    //   111: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   114: ldc '/error_fs.dat'
    //   116: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   119: invokevirtual toString : ()Ljava/lang/String;
    //   122: astore #6
    //   124: new java/io/File
    //   127: astore #4
    //   129: aload #4
    //   131: aload #6
    //   133: invokespecial <init> : (Ljava/lang/String;)V
    //   136: aload #4
    //   138: invokevirtual exists : ()Z
    //   141: ifne -> 202
    //   144: new java/io/File
    //   147: astore #6
    //   149: aload #6
    //   151: aload #5
    //   153: invokespecial <init> : (Ljava/lang/String;)V
    //   156: aload #6
    //   158: invokevirtual exists : ()Z
    //   161: ifne -> 170
    //   164: aload #6
    //   166: invokevirtual mkdirs : ()Z
    //   169: pop
    //   170: aload #4
    //   172: invokevirtual createNewFile : ()Z
    //   175: ifne -> 263
    //   178: aload_0
    //   179: aload_3
    //   180: aload_2
    //   181: aload_1
    //   182: invokevirtual if : (Ljava/io/File;Ljava/lang/String;Ljava/lang/String;)V
    //   185: invokestatic myPid : ()I
    //   188: invokestatic killProcess : (I)V
    //   191: goto -> 14
    //   194: astore_1
    //   195: aconst_null
    //   196: astore_1
    //   197: aconst_null
    //   198: astore_2
    //   199: goto -> 66
    //   202: new java/io/RandomAccessFile
    //   205: astore_3
    //   206: aload_3
    //   207: aload #4
    //   209: ldc 'rw'
    //   211: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   214: aload_3
    //   215: ldc2_w 300
    //   218: invokevirtual seek : (J)V
    //   221: aload_3
    //   222: invokevirtual readLong : ()J
    //   225: lstore #7
    //   227: invokestatic currentTimeMillis : ()J
    //   230: lload #7
    //   232: lsub
    //   233: ldc2_w 604800000
    //   236: lcmp
    //   237: ifle -> 248
    //   240: aload_0
    //   241: aload #4
    //   243: aload_2
    //   244: aload_1
    //   245: invokevirtual if : (Ljava/io/File;Ljava/lang/String;Ljava/lang/String;)V
    //   248: aload_3
    //   249: invokevirtual close : ()V
    //   252: goto -> 185
    //   255: astore_1
    //   256: goto -> 185
    //   259: astore_2
    //   260: goto -> 197
    //   263: aload #4
    //   265: astore_3
    //   266: goto -> 178
    //   269: aconst_null
    //   270: astore_2
    //   271: goto -> 66
    // Exception table:
    //   from	to	target	type
    //   15	21	194	java/lang/Exception
    //   21	57	259	java/lang/Exception
    //   61	66	259	java/lang/Exception
    //   66	170	255	java/lang/Exception
    //   170	178	255	java/lang/Exception
    //   178	185	255	java/lang/Exception
    //   202	248	255	java/lang/Exception
    //   248	252	255	java/lang/Exception
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */