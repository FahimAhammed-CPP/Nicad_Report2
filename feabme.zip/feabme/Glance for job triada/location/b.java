package com.baidu.location;

interface b {
  public static final boolean a = false;
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */