package com.baidu.location;

import android.location.Location;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Locale;

public class u implements au, l {
  private static StringBuffer eA;
  
  private static final int eB = 5;
  
  private static File eC;
  
  private static final int eD = 3600;
  
  private static int eE = 0;
  
  private static long eF = 0L;
  
  private static long eG = 0L;
  
  private static boolean eH = false;
  
  private static final int eI = 1024;
  
  private static int eJ = 0;
  
  private static double eK = 0.0D;
  
  private static double eL = 0.0D;
  
  private static String eM;
  
  private static int eN = 0;
  
  private static int eO = 0;
  
  private static final int eP = 5;
  
  private static final int eQ = 750;
  
  private static final int eR = 1000;
  
  private static final int eT = 100;
  
  private static int eV = 0;
  
  private static u eW = null;
  
  private static long eX = 0L;
  
  private static final int ez = 12;
  
  private String eS;
  
  private boolean eU;
  
  static {
    eM = "Temp_in.dat";
    eC = new File(f.H, eM);
    eA = null;
    eH = true;
    eN = 0;
    eV = 0;
    eG = 0L;
    eF = 0L;
    eX = 0L;
    eK = 0.0D;
    eL = 0.0D;
    eE = 0;
    eJ = 0;
    eO = 0;
  }
  
  private u(String paramString) {
    String str;
    this.eS = null;
    this.eU = true;
    if (paramString != null) {
      str = paramString;
      if (paramString.length() > 100)
        str = paramString.substring(0, 100); 
    } else {
      str = "";
    } 
    this.eS = str;
  }
  
  private boolean aA() {
    if (eC.exists())
      eC.delete(); 
    aw();
    return !eC.exists();
  }
  
  private static boolean au() {
    boolean bool = false;
    if (eC.exists())
      eC.delete(); 
    if (!eC.getParentFile().exists())
      eC.getParentFile().mkdirs(); 
    try {
      eC.createNewFile();
      RandomAccessFile randomAccessFile = new RandomAccessFile();
      this(eC, "rw");
      randomAccessFile.seek(0L);
      randomAccessFile.writeInt(0);
      randomAccessFile.writeInt(0);
      randomAccessFile.writeInt(1);
      randomAccessFile.close();
      aw();
      bool = eC.exists();
    } catch (IOException iOException) {}
    return bool;
  }
  
  private void av() {
    if (eA != null && eA.length() >= 100)
      e(eA.toString()); 
    aw();
  }
  
  private static void aw() {
    eH = true;
    eA = null;
    eN = 0;
    eV = 0;
    eG = 0L;
    eF = 0L;
    eX = 0L;
    eK = 0.0D;
    eL = 0.0D;
    eE = 0;
    eJ = 0;
    eO = 0;
  }
  
  public static u ax() {
    if (eW == null)
      eW = new u(aw.b6().b2()); 
    return eW;
  }
  
  private void ay() {}
  
  public static String az() {
    if (eC == null)
      return null; 
    if (!eC.exists())
      return null; 
    try {
      RandomAccessFile randomAccessFile = new RandomAccessFile();
      this(eC, "rw");
      randomAccessFile.seek(0L);
      int i = randomAccessFile.readInt();
      int j = randomAccessFile.readInt();
      int k = randomAccessFile.readInt();
      if (!if(i, j, k)) {
        randomAccessFile.close();
        au();
        return null;
      } 
      if (j == 0 || j == k) {
        randomAccessFile.close();
        return null;
      } 
      long l1 = 0L + ((j - 1) * 1024 + 12);
      randomAccessFile.seek(l1);
      int m = randomAccessFile.readInt();
      byte[] arrayOfByte = new byte[m];
      randomAccessFile.seek(l1 + 4L);
      for (k = 0; k < m; k++)
        arrayOfByte[k] = randomAccessFile.readByte(); 
      String str = new String();
      this(arrayOfByte);
      if (i < c.ax) {
        k = j + 1;
      } else {
        k = c.ax;
        if (j == k) {
          k = 1;
        } else {
          k = j + 1;
        } 
      } 
      randomAccessFile.seek(4L);
      randomAccessFile.writeInt(k);
      randomAccessFile.close();
    } catch (IOException iOException) {
      iOException = null;
    } 
    return (String)iOException;
  }
  
  private boolean e(String paramString) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: iload_2
    //   3: istore_3
    //   4: aload_1
    //   5: ifnull -> 19
    //   8: aload_1
    //   9: ldc '&nr'
    //   11: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   14: ifne -> 21
    //   17: iload_2
    //   18: istore_3
    //   19: iload_3
    //   20: ireturn
    //   21: getstatic com/baidu/location/u.eC : Ljava/io/File;
    //   24: invokevirtual exists : ()Z
    //   27: ifne -> 38
    //   30: iload_2
    //   31: istore_3
    //   32: invokestatic au : ()Z
    //   35: ifeq -> 19
    //   38: new java/io/RandomAccessFile
    //   41: astore #4
    //   43: aload #4
    //   45: getstatic com/baidu/location/u.eC : Ljava/io/File;
    //   48: ldc 'rw'
    //   50: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   53: aload #4
    //   55: lconst_0
    //   56: invokevirtual seek : (J)V
    //   59: aload #4
    //   61: invokevirtual readInt : ()I
    //   64: istore #5
    //   66: aload #4
    //   68: invokevirtual readInt : ()I
    //   71: istore #6
    //   73: aload #4
    //   75: invokevirtual readInt : ()I
    //   78: istore #7
    //   80: iload #5
    //   82: iload #6
    //   84: iload #7
    //   86: invokestatic if : (III)Z
    //   89: ifne -> 112
    //   92: aload #4
    //   94: invokevirtual close : ()V
    //   97: invokestatic au : ()Z
    //   100: pop
    //   101: iload_2
    //   102: istore_3
    //   103: goto -> 19
    //   106: astore_1
    //   107: iload_2
    //   108: istore_3
    //   109: goto -> 19
    //   112: getstatic com/baidu/location/c.aX : Z
    //   115: ifeq -> 200
    //   118: iload #5
    //   120: getstatic com/baidu/location/c.ax : I
    //   123: if_icmpeq -> 157
    //   126: iload #7
    //   128: iconst_1
    //   129: if_icmple -> 200
    //   132: aload_1
    //   133: aload_0
    //   134: iload #7
    //   136: iconst_1
    //   137: isub
    //   138: invokespecial for : (I)Ljava/lang/String;
    //   141: invokevirtual equals : (Ljava/lang/Object;)Z
    //   144: ifeq -> 200
    //   147: aload #4
    //   149: invokevirtual close : ()V
    //   152: iload_2
    //   153: istore_3
    //   154: goto -> 19
    //   157: iload #7
    //   159: iconst_1
    //   160: if_icmpne -> 191
    //   163: getstatic com/baidu/location/c.ax : I
    //   166: istore #8
    //   168: aload_1
    //   169: aload_0
    //   170: iload #8
    //   172: invokespecial for : (I)Ljava/lang/String;
    //   175: invokevirtual equals : (Ljava/lang/Object;)Z
    //   178: ifeq -> 200
    //   181: aload #4
    //   183: invokevirtual close : ()V
    //   186: iload_2
    //   187: istore_3
    //   188: goto -> 19
    //   191: iload #7
    //   193: iconst_1
    //   194: isub
    //   195: istore #8
    //   197: goto -> 168
    //   200: aload #4
    //   202: iload #7
    //   204: iconst_1
    //   205: isub
    //   206: sipush #1024
    //   209: imul
    //   210: bipush #12
    //   212: iadd
    //   213: i2l
    //   214: lconst_0
    //   215: ladd
    //   216: invokevirtual seek : (J)V
    //   219: aload_1
    //   220: invokevirtual length : ()I
    //   223: sipush #750
    //   226: if_icmple -> 239
    //   229: aload #4
    //   231: invokevirtual close : ()V
    //   234: iload_2
    //   235: istore_3
    //   236: goto -> 19
    //   239: aload_1
    //   240: invokestatic h : (Ljava/lang/String;)Ljava/lang/String;
    //   243: astore_1
    //   244: aload_1
    //   245: invokevirtual length : ()I
    //   248: istore #8
    //   250: iload #8
    //   252: sipush #1020
    //   255: if_icmple -> 268
    //   258: aload #4
    //   260: invokevirtual close : ()V
    //   263: iload_2
    //   264: istore_3
    //   265: goto -> 19
    //   268: aload #4
    //   270: iload #8
    //   272: invokevirtual writeInt : (I)V
    //   275: aload #4
    //   277: aload_1
    //   278: invokevirtual writeBytes : (Ljava/lang/String;)V
    //   281: iload #5
    //   283: ifne -> 320
    //   286: aload #4
    //   288: lconst_0
    //   289: invokevirtual seek : (J)V
    //   292: aload #4
    //   294: iconst_1
    //   295: invokevirtual writeInt : (I)V
    //   298: aload #4
    //   300: iconst_1
    //   301: invokevirtual writeInt : (I)V
    //   304: aload #4
    //   306: iconst_2
    //   307: invokevirtual writeInt : (I)V
    //   310: aload #4
    //   312: invokevirtual close : ()V
    //   315: iconst_1
    //   316: istore_3
    //   317: goto -> 19
    //   320: iload #5
    //   322: getstatic com/baidu/location/c.ax : I
    //   325: iconst_1
    //   326: isub
    //   327: if_icmpge -> 365
    //   330: aload #4
    //   332: lconst_0
    //   333: invokevirtual seek : (J)V
    //   336: aload #4
    //   338: iload #5
    //   340: iconst_1
    //   341: iadd
    //   342: invokevirtual writeInt : (I)V
    //   345: aload #4
    //   347: ldc2_w 8
    //   350: invokevirtual seek : (J)V
    //   353: aload #4
    //   355: iload #5
    //   357: iconst_2
    //   358: iadd
    //   359: invokevirtual writeInt : (I)V
    //   362: goto -> 310
    //   365: iload #5
    //   367: getstatic com/baidu/location/c.ax : I
    //   370: iconst_1
    //   371: isub
    //   372: if_icmpne -> 423
    //   375: aload #4
    //   377: lconst_0
    //   378: invokevirtual seek : (J)V
    //   381: aload #4
    //   383: getstatic com/baidu/location/c.ax : I
    //   386: invokevirtual writeInt : (I)V
    //   389: iload #6
    //   391: ifeq -> 400
    //   394: iload #6
    //   396: iconst_1
    //   397: if_icmpne -> 406
    //   400: aload #4
    //   402: iconst_2
    //   403: invokevirtual writeInt : (I)V
    //   406: aload #4
    //   408: ldc2_w 8
    //   411: invokevirtual seek : (J)V
    //   414: aload #4
    //   416: iconst_1
    //   417: invokevirtual writeInt : (I)V
    //   420: goto -> 310
    //   423: iload #7
    //   425: iload #6
    //   427: if_icmpne -> 495
    //   430: iload #7
    //   432: getstatic com/baidu/location/c.ax : I
    //   435: if_icmpne -> 477
    //   438: iconst_1
    //   439: istore #8
    //   441: iload #8
    //   443: getstatic com/baidu/location/c.ax : I
    //   446: if_icmpne -> 486
    //   449: iconst_1
    //   450: istore #6
    //   452: aload #4
    //   454: ldc2_w 4
    //   457: invokevirtual seek : (J)V
    //   460: aload #4
    //   462: iload #6
    //   464: invokevirtual writeInt : (I)V
    //   467: aload #4
    //   469: iload #8
    //   471: invokevirtual writeInt : (I)V
    //   474: goto -> 310
    //   477: iload #7
    //   479: iconst_1
    //   480: iadd
    //   481: istore #8
    //   483: goto -> 441
    //   486: iload #8
    //   488: iconst_1
    //   489: iadd
    //   490: istore #6
    //   492: goto -> 452
    //   495: iload #7
    //   497: getstatic com/baidu/location/c.ax : I
    //   500: if_icmpne -> 557
    //   503: iconst_1
    //   504: istore #8
    //   506: iload #8
    //   508: iload #6
    //   510: if_icmpne -> 539
    //   513: iload #8
    //   515: getstatic com/baidu/location/c.ax : I
    //   518: if_icmpne -> 566
    //   521: iconst_1
    //   522: istore #6
    //   524: aload #4
    //   526: ldc2_w 4
    //   529: invokevirtual seek : (J)V
    //   532: aload #4
    //   534: iload #6
    //   536: invokevirtual writeInt : (I)V
    //   539: aload #4
    //   541: ldc2_w 8
    //   544: invokevirtual seek : (J)V
    //   547: aload #4
    //   549: iload #8
    //   551: invokevirtual writeInt : (I)V
    //   554: goto -> 310
    //   557: iload #7
    //   559: iconst_1
    //   560: iadd
    //   561: istore #8
    //   563: goto -> 506
    //   566: iload #8
    //   568: iconst_1
    //   569: iadd
    //   570: istore #6
    //   572: goto -> 524
    // Exception table:
    //   from	to	target	type
    //   38	101	106	java/io/IOException
    //   112	126	106	java/io/IOException
    //   132	152	106	java/io/IOException
    //   163	168	106	java/io/IOException
    //   168	186	106	java/io/IOException
    //   200	234	106	java/io/IOException
    //   239	250	106	java/io/IOException
    //   258	263	106	java/io/IOException
    //   268	281	106	java/io/IOException
    //   286	310	106	java/io/IOException
    //   310	315	106	java/io/IOException
    //   320	362	106	java/io/IOException
    //   365	389	106	java/io/IOException
    //   400	406	106	java/io/IOException
    //   406	420	106	java/io/IOException
    //   430	438	106	java/io/IOException
    //   441	449	106	java/io/IOException
    //   452	474	106	java/io/IOException
    //   495	503	106	java/io/IOException
    //   513	521	106	java/io/IOException
    //   524	539	106	java/io/IOException
    //   539	554	106	java/io/IOException
  }
  
  private String for(int paramInt) {
    String str = null;
    if (eC.exists()) {
      RandomAccessFile randomAccessFile;
      try {
        randomAccessFile = new RandomAccessFile();
        this(eC, "rw");
        randomAccessFile.seek(0L);
        i = randomAccessFile.readInt();
        if (!if(i, randomAccessFile.readInt(), randomAccessFile.readInt())) {
          randomAccessFile.close();
          au();
          return str;
        } 
      } catch (IOException iOException) {
        return str;
      } 
      if (paramInt == 0 || paramInt == i + 1) {
        randomAccessFile.close();
        return str;
      } 
      long l1 = 12L + 0L + ((paramInt - 1) * 1024);
      randomAccessFile.seek(l1);
      int i = randomAccessFile.readInt();
      byte[] arrayOfByte = new byte[i];
      randomAccessFile.seek(l1 + 4L);
      for (paramInt = 0; paramInt < i; paramInt++)
        arrayOfByte[paramInt] = randomAccessFile.readByte(); 
      randomAccessFile.close();
      String str1 = new String(arrayOfByte);
      str = str1;
    } 
    return str;
  }
  
  private static boolean if(int paramInt1, int paramInt2, int paramInt3) {
    boolean bool = true;
    if (paramInt1 < 0 || paramInt1 > c.ax)
      return false; 
    if (paramInt2 < 0 || paramInt2 > paramInt1 + 1)
      return false; 
    if (paramInt3 < 1 || paramInt3 > paramInt1 + 1 || paramInt3 > c.ax)
      bool = false; 
    return bool;
  }
  
  private boolean if(Location paramLocation, int paramInt1, int paramInt2) {
    if (paramLocation == null || !c.ay || !this.eU || !w.fZ)
      return false; 
    if (c.au < 5) {
      c.au = 5;
    } else if (c.au > 1000) {
      c.au = 1000;
    } 
    if (c.ar < 5) {
      c.ar = 5;
    } else if (c.ar > 3600) {
      c.ar = 3600;
    } 
    double d1 = paramLocation.getLongitude();
    double d2 = paramLocation.getLatitude();
    long l1 = paramLocation.getTime() / 1000L;
    if (eH) {
      eN = 1;
      eA = new StringBuffer("");
      eA.append(String.format(Locale.CHINA, "&nr=%s&traj=%d,%.5f,%.5f|", new Object[] { this.eS, Long.valueOf(l1), Double.valueOf(d1), Double.valueOf(d2) }));
      eV = eA.length();
      eG = l1;
      eK = d1;
      eL = d2;
      eF = (long)Math.floor(d1 * 100000.0D + 0.5D);
      eX = (long)Math.floor(d2 * 100000.0D + 0.5D);
      eH = false;
      return true;
    } 
    float[] arrayOfFloat = new float[1];
    Location.distanceBetween(d2, d1, eL, eK, arrayOfFloat);
    long l2 = eG;
    if (arrayOfFloat[0] >= c.au || l1 - l2 >= c.ar) {
      if (eA == null) {
        eN++;
        eV = 0;
        eA = new StringBuffer("");
        eA.append(String.format(Locale.CHINA, "&nr=%s&traj=%d,%.5f,%.5f|", new Object[] { this.eS, Long.valueOf(l1), Double.valueOf(d1), Double.valueOf(d2) }));
        eV = eA.length();
        eG = l1;
        eK = d1;
        eL = d2;
        eF = (long)Math.floor(d1 * 100000.0D + 0.5D);
        eX = (long)Math.floor(d2 * 100000.0D + 0.5D);
      } else {
        eK = d1;
        eL = d2;
        long l3 = (long)Math.floor(d1 * 100000.0D + 0.5D);
        l2 = (long)Math.floor(d2 * 100000.0D + 0.5D);
        eE = (int)(l1 - eG);
        eJ = (int)(l3 - eF);
        eO = (int)(l2 - eX);
        eA.append(String.format(Locale.CHINA, "%d,%d,%d|", new Object[] { Integer.valueOf(eE), Integer.valueOf(eJ), Integer.valueOf(eO) }));
        eV = eA.length();
        eG = l1;
        eF = l3;
        eX = l2;
      } 
      if (eV + 15 > 750) {
        e(eA.toString());
        eA = null;
      } 
      if (eN >= c.ax)
        this.eU = false; 
      return true;
    } 
    return false;
  }
  
  public void aB() {
    av();
  }
  
  public boolean do(Location paramLocation) {
    return if(paramLocation, c.au, c.ar);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */