package com.baidu.location;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import org.json.JSONObject;

public final class BDLocation implements l, Parcelable {
  public static final Parcelable.Creator CREATOR = new BDLocation$1();
  
  public static final int OPERATORS_TYPE_MOBILE = 1;
  
  public static final int OPERATORS_TYPE_TELECOMU = 3;
  
  public static final int OPERATORS_TYPE_UNICOM = 2;
  
  public static final int OPERATORS_TYPE_UNKONW = 0;
  
  public static final int TypeCacheLocation = 65;
  
  public static final int TypeCriteriaException = 62;
  
  public static final int TypeGpsLocation = 61;
  
  public static final int TypeNetWorkException = 63;
  
  public static final int TypeNetWorkLocation = 161;
  
  public static final int TypeNone = 0;
  
  public static final int TypeOffLineLocation = 66;
  
  public static final int TypeOffLineLocationFail = 67;
  
  public static final int TypeOffLineLocationNetworkFail = 68;
  
  public static final int TypeServerError = 167;
  
  private boolean gA = false;
  
  private int gB = 0;
  
  private double gC = Double.MIN_VALUE;
  
  private boolean gD = false;
  
  private float gE = 0.0F;
  
  private String gF = null;
  
  private String gG = null;
  
  private int gH;
  
  private String gl = null;
  
  private int gm = -1;
  
  private double gn = Double.MIN_VALUE;
  
  private String go = null;
  
  private boolean gp = false;
  
  private boolean gq = false;
  
  private float gr = -1.0F;
  
  private double gs = Double.MIN_VALUE;
  
  private boolean gt = false;
  
  private String gu = null;
  
  private a gv = new a(this);
  
  private boolean gw = false;
  
  private String gx = null;
  
  private float gy = 0.0F;
  
  private boolean gz = false;
  
  public BDLocation() {}
  
  private BDLocation(Parcel paramParcel) {
    this.gB = paramParcel.readInt();
    this.gF = paramParcel.readString();
    this.gn = paramParcel.readDouble();
    this.gC = paramParcel.readDouble();
    this.gs = paramParcel.readDouble();
    this.gE = paramParcel.readFloat();
    this.gy = paramParcel.readFloat();
    this.gm = paramParcel.readInt();
    this.gr = paramParcel.readFloat();
    this.gu = paramParcel.readString();
    this.go = paramParcel.readString();
    this.gx = paramParcel.readString();
    this.gv.if = paramParcel.readString();
    this.gv.new = paramParcel.readString();
    this.gv.int = paramParcel.readString();
    this.gv.byte = paramParcel.readString();
    this.gv.do = paramParcel.readString();
    this.gv.for = paramParcel.readString();
    this.gv.try = paramParcel.readString();
    boolean[] arrayOfBoolean = new boolean[7];
    paramParcel.readBooleanArray(arrayOfBoolean);
    this.gp = arrayOfBoolean[0];
    this.gq = arrayOfBoolean[1];
    this.gw = arrayOfBoolean[2];
    this.gD = arrayOfBoolean[3];
    this.gz = arrayOfBoolean[4];
    this.gA = arrayOfBoolean[5];
    this.gt = arrayOfBoolean[6];
    this.gH = paramParcel.readInt();
  }
  
  public BDLocation(BDLocation paramBDLocation) {
    this.gB = paramBDLocation.gB;
    this.gF = paramBDLocation.gF;
    this.gn = paramBDLocation.gn;
    this.gC = paramBDLocation.gC;
    this.gp = paramBDLocation.gp;
    paramBDLocation.gs = paramBDLocation.gs;
    this.gq = paramBDLocation.gq;
    this.gE = paramBDLocation.gE;
    this.gw = paramBDLocation.gw;
    this.gy = paramBDLocation.gy;
    this.gD = paramBDLocation.gD;
    this.gm = paramBDLocation.gm;
    this.gr = paramBDLocation.gr;
    this.gG = paramBDLocation.gG;
    this.gu = paramBDLocation.gu;
    this.gz = paramBDLocation.gz;
    this.gA = paramBDLocation.gA;
    this.gl = paramBDLocation.gl;
    this.gt = paramBDLocation.gt;
    this.gv = new a(this);
    this.gv.if = paramBDLocation.gv.if;
    this.gv.new = paramBDLocation.gv.new;
    this.gv.int = paramBDLocation.gv.int;
    this.gv.byte = paramBDLocation.gv.byte;
    this.gv.do = paramBDLocation.gv.do;
    this.gv.for = paramBDLocation.gv.for;
    this.gv.try = paramBDLocation.gv.try;
    this.go = paramBDLocation.go;
    this.gx = paramBDLocation.gx;
    this.gH = paramBDLocation.gH;
  }
  
  protected BDLocation(String paramString) {
    if (paramString != null && !paramString.equals("")) {
      JSONObject jSONObject;
      int i;
      try {
        jSONObject = new JSONObject();
        this(paramString);
        JSONObject jSONObject1 = jSONObject.getJSONObject("result");
        i = Integer.parseInt(jSONObject1.getString("error"));
        setLocType(i);
        setTime(jSONObject1.getString("time"));
        if (i == 61) {
          jSONObject1 = jSONObject.getJSONObject("content");
          jSONObject = jSONObject1.getJSONObject("point");
          setLatitude(Double.parseDouble(jSONObject.getString("y")));
          setLongitude(Double.parseDouble(jSONObject.getString("x")));
          setRadius(Float.parseFloat(jSONObject1.getString("radius")));
          setSpeed(Float.parseFloat(jSONObject1.getString("s")));
          setDerect(Float.parseFloat(jSONObject1.getString("d")));
          setSatelliteNumber(Integer.parseInt(jSONObject1.getString("n")));
          return;
        } 
      } catch (Exception exception) {
        exception.printStackTrace();
        this.gB = 0;
        this.gz = false;
        return;
      } 
      if (i == 161) {
        jSONObject = jSONObject.getJSONObject("content");
        JSONObject jSONObject1 = jSONObject.getJSONObject("point");
        setLatitude(Double.parseDouble(jSONObject1.getString("y")));
        setLongitude(Double.parseDouble(jSONObject1.getString("x")));
        setRadius(Float.parseFloat(jSONObject.getString("radius")));
        if (jSONObject.has("addr")) {
          String str2 = jSONObject.getString("addr");
          this.gv.try = str2;
          String[] arrayOfString = str2.split(",");
          this.gv.if = arrayOfString[0];
          this.gv.new = arrayOfString[1];
          this.gv.int = arrayOfString[2];
          this.gv.byte = arrayOfString[3];
          this.gv.do = arrayOfString[4];
          this.gv.for = arrayOfString[5];
          if ((this.gv.if.contains("北京") && this.gv.new.contains("北京")) || (this.gv.if.contains("上海") && this.gv.new.contains("上海")) || (this.gv.if.contains("天津") && this.gv.new.contains("天津")) || (this.gv.if.contains("重庆") && this.gv.new.contains("重庆"))) {
            str1 = this.gv.if;
          } else {
            StringBuilder stringBuilder1 = new StringBuilder();
            this();
            str1 = stringBuilder1.append(this.gv.if).append(this.gv.new).toString();
          } 
          StringBuilder stringBuilder = new StringBuilder();
          this();
          String str1 = stringBuilder.append(str1).append(this.gv.int).append(this.gv.byte).append(this.gv.do).toString();
          this.gv.try = str1;
          this.gz = true;
        } else {
          this.gz = false;
          setAddrStr(null);
        } 
        if (jSONObject.has("poi")) {
          this.gA = true;
          this.gu = jSONObject.getJSONObject("poi").toString();
        } 
        if (jSONObject.has("floor")) {
          this.go = jSONObject.getString("floor");
          if (TextUtils.isEmpty(this.go))
            this.go = null; 
        } 
        if (jSONObject.has("loctp")) {
          this.gx = jSONObject.getString("loctp");
          if (TextUtils.isEmpty(this.gx))
            this.gx = null; 
        } 
        return;
      } 
      if (i == 66 || i == 68) {
        jSONObject = jSONObject.getJSONObject("content");
        JSONObject jSONObject1 = jSONObject.getJSONObject("point");
        setLatitude(Double.parseDouble(jSONObject1.getString("y")));
        setLongitude(Double.parseDouble(jSONObject1.getString("x")));
        setRadius(Float.parseFloat(jSONObject.getString("radius")));
        if(Boolean.valueOf(Boolean.parseBoolean(jSONObject.getString("isCellChanged"))));
      } 
    } 
  }
  
  private void if(Boolean paramBoolean) {
    this.gt = paramBoolean.booleanValue();
  }
  
  protected String a4() {
    return null;
  }
  
  protected void byte(int paramInt) {
    this.gH = paramInt;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String getAddrStr() {
    return this.gv.try;
  }
  
  public double getAltitude() {
    return this.gs;
  }
  
  public String getCity() {
    return this.gv.new;
  }
  
  public String getCityCode() {
    return this.gv.for;
  }
  
  public String getCoorType() {
    return this.gG;
  }
  
  public float getDerect() {
    return this.gr;
  }
  
  public float getDirection() {
    return this.gr;
  }
  
  public String getDistrict() {
    return this.gv.int;
  }
  
  public String getFloor() {
    return this.go;
  }
  
  public double getLatitude() {
    return this.gn;
  }
  
  public int getLocType() {
    return this.gB;
  }
  
  public double getLongitude() {
    return this.gC;
  }
  
  public String getNetworkLocationType() {
    return this.gx;
  }
  
  public int getOperators() {
    return this.gH;
  }
  
  public String getPoi() {
    return this.gu;
  }
  
  public String getProvince() {
    return this.gv.if;
  }
  
  public float getRadius() {
    return this.gy;
  }
  
  public int getSatelliteNumber() {
    this.gD = true;
    return this.gm;
  }
  
  public float getSpeed() {
    return this.gE;
  }
  
  public String getStreet() {
    return this.gv.byte;
  }
  
  public String getStreetNumber() {
    return this.gv.do;
  }
  
  public String getTime() {
    return this.gF;
  }
  
  public boolean hasAddr() {
    return this.gz;
  }
  
  public boolean hasAltitude() {
    return this.gp;
  }
  
  public boolean hasPoi() {
    return this.gA;
  }
  
  public boolean hasRadius() {
    return this.gw;
  }
  
  public boolean hasSateNumber() {
    return this.gD;
  }
  
  public boolean hasSpeed() {
    return this.gq;
  }
  
  public boolean isCellChangeFlag() {
    return this.gt;
  }
  
  protected BDLocation n(String paramString) {
    return null;
  }
  
  public void setAddrStr(String paramString) {
    this.gl = paramString;
    if (paramString == null) {
      this.gz = false;
      return;
    } 
    this.gz = true;
  }
  
  public void setAltitude(double paramDouble) {
    this.gs = paramDouble;
    this.gp = true;
  }
  
  public void setCoorType(String paramString) {
    this.gG = paramString;
  }
  
  public void setDerect(float paramFloat) {
    this.gr = paramFloat;
  }
  
  public void setDirection(float paramFloat) {
    this.gr = paramFloat;
  }
  
  public void setLatitude(double paramDouble) {
    this.gn = paramDouble;
  }
  
  public void setLocType(int paramInt) {
    this.gB = paramInt;
  }
  
  public void setLongitude(double paramDouble) {
    this.gC = paramDouble;
  }
  
  public void setPoi(String paramString) {
    this.gu = paramString;
  }
  
  public void setRadius(float paramFloat) {
    this.gy = paramFloat;
    this.gw = true;
  }
  
  public void setSatelliteNumber(int paramInt) {
    this.gm = paramInt;
  }
  
  public void setSpeed(float paramFloat) {
    this.gE = paramFloat;
    this.gq = true;
  }
  
  public void setTime(String paramString) {
    this.gF = paramString;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.gB);
    paramParcel.writeString(this.gF);
    paramParcel.writeDouble(this.gn);
    paramParcel.writeDouble(this.gC);
    paramParcel.writeDouble(this.gs);
    paramParcel.writeFloat(this.gE);
    paramParcel.writeFloat(this.gy);
    paramParcel.writeInt(this.gm);
    paramParcel.writeFloat(this.gr);
    paramParcel.writeString(this.gu);
    paramParcel.writeString(this.go);
    paramParcel.writeString(this.gx);
    paramParcel.writeString(this.gv.if);
    paramParcel.writeString(this.gv.new);
    paramParcel.writeString(this.gv.int);
    paramParcel.writeString(this.gv.byte);
    paramParcel.writeString(this.gv.do);
    paramParcel.writeString(this.gv.for);
    paramParcel.writeString(this.gv.try);
    paramParcel.writeBooleanArray(new boolean[] { this.gp, this.gq, this.gw, this.gD, this.gz, this.gA, this.gt });
    paramParcel.writeInt(this.gH);
  }
  
  public class a {
    public String byte = null;
    
    public String do = null;
    
    public String for = null;
    
    public String if = null;
    
    public String int = null;
    
    public String new = null;
    
    public String try = null;
    
    public a(BDLocation this$0) {}
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/BDLocation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */