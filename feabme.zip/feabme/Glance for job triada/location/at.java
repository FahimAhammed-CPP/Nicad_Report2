package com.baidu.location;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

class at {
  private static at a = null;
  
  private a do = null;
  
  private boolean for = false;
  
  private String if = null;
  
  private at() {
    this.do = new a(this);
  }
  
  public static at do() {
    if (a == null)
      a = new at(); 
    return a;
  }
  
  public String a() {
    return this.if;
  }
  
  public void for() {
    f.getServiceContext().registerReceiver(this.do, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
  }
  
  public void if() {
    if (this.do != null)
      f.getServiceContext().unregisterReceiver(this.do); 
    this.do = null;
  }
  
  public boolean int() {
    return this.for;
  }
  
  public class a extends BroadcastReceiver {
    public a(at this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      String str = param1Intent.getAction();
      try {
        if (str.equals("android.intent.action.BATTERY_CHANGED")) {
          at.a(this.a, false);
          int i = param1Intent.getIntExtra("status", 0);
          int j = param1Intent.getIntExtra("plugged", 0);
          switch (i) {
            default:
              at.a(this.a, (String)null);
              switch (j) {
                default:
                  if (at.a(this.a)) {
                    af.bg().bf();
                    return;
                  } 
                  break;
                case 1:
                  at.a(this.a, "6");
                  at.a(this.a, true);
                case 2:
                  break;
              } 
              at.a(this.a, "5");
              at.a(this.a, true);
            case 2:
              at.a(this.a, "4");
              switch (j) {
                default:
                  if (at.a(this.a)) {
                    af.bg().bf();
                    return;
                  } 
                  break;
                case 1:
                  at.a(this.a, "6");
                  at.a(this.a, true);
                case 2:
                  break;
              } 
              at.a(this.a, "5");
              at.a(this.a, true);
            case 3:
            case 4:
              at.a(this.a, "3");
              switch (j) {
                default:
                  if (at.a(this.a)) {
                    af.bg().bf();
                    return;
                  } 
                  break;
                case 1:
                  at.a(this.a, "6");
                  at.a(this.a, true);
                case 2:
                  break;
              } 
              at.a(this.a, "5");
              at.a(this.a, true);
          } 
        } else {
          return;
        } 
      } catch (Exception exception) {
        at.a(this.a, (String)null);
        return;
      } 
      af.bg().bh();
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/at.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */