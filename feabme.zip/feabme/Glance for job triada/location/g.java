package com.baidu.location;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import java.util.Calendar;

class g {
  public static void a(Context paramContext, PendingIntent paramPendingIntent) {
    ((AlarmManager)paramContext.getSystemService("alarm")).cancel(paramPendingIntent);
  }
  
  public static void a(Context paramContext, PendingIntent paramPendingIntent, int paramInt) {
    AlarmManager alarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    alarmManager.cancel(paramPendingIntent);
    Calendar calendar = Calendar.getInstance();
    calendar.setTimeInMillis(System.currentTimeMillis());
    calendar.add(14, paramInt);
    alarmManager.set(0, calendar.getTimeInMillis(), paramPendingIntent);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */