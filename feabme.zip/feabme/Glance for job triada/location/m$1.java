package com.baidu.location;

import android.os.Handler;
import android.os.Message;

class m$1 extends Handler {
  m$1(m paramm) {}
  
  public void handleMessage(Message paramMessage) {
    if (!f.isServing);
    switch (paramMessage.what) {
      default:
        return;
      case 1:
        break;
    } 
    m.if(this.a);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/m$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */