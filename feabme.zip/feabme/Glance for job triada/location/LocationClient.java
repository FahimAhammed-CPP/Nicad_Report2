package com.baidu.location;

import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.regex.Pattern;

public final class LocationClient implements l, au {
  public static String PREF_FILE_NAME = "pref_key";
  
  public static String PREF_KEY_NAME = "access_key";
  
  private static final int i7 = 10;
  
  private static final String i9 = "baidu_location_Client";
  
  private static final int jA = 12;
  
  private static final int jC = 6;
  
  private static final int jD = 2;
  
  private static final int jG = 6000;
  
  private static final int jN = 11;
  
  private static final int jQ = 4;
  
  private static final int jc = 1;
  
  private static final int jh = 1000;
  
  private static final int jl = 3;
  
  private static final String jm = "sign";
  
  private static final int jn = 8;
  
  private static final String jp = "key";
  
  private static final int jr = 9;
  
  private static final int jt = 7;
  
  private static final int jz = 5;
  
  private boolean i6 = false;
  
  private a i8 = new a(null);
  
  private Boolean jB = Boolean.valueOf(true);
  
  private boolean jE = false;
  
  private long jF = 0L;
  
  private long jH = 0L;
  
  private ServiceConnection jI = new LocationClient$1(this);
  
  private String jJ;
  
  private boolean jK = false;
  
  private boolean jL = false;
  
  private BDLocation jM = null;
  
  private String jO = null;
  
  private String jP = null;
  
  private ArrayList jR = null;
  
  private final Object ja = new Object();
  
  private BDErrorReport jb = null;
  
  private b jd = null;
  
  private Boolean je = Boolean.valueOf(false);
  
  private long jf = 0L;
  
  private x jg = null;
  
  private long ji = 0L;
  
  private Boolean jj = Boolean.valueOf(false);
  
  private boolean jk = false;
  
  private BDLocationListener jo = null;
  
  private boolean jq = false;
  
  private boolean js = false;
  
  private final Messenger ju = new Messenger(this.i8);
  
  private Context jv = null;
  
  private Messenger jw = null;
  
  private long jx = 0L;
  
  private LocationClientOption jy = new LocationClientOption();
  
  public LocationClient(Context paramContext) {
    this.jv = paramContext;
    this.jy = new LocationClientOption();
    this.jg = new x(this.jv, this);
  }
  
  public LocationClient(Context paramContext, LocationClientOption paramLocationClientOption) {
    this.jv = paramContext;
    this.jy = paramLocationClientOption;
    this.jg = new x(this.jv, this);
  }
  
  private Bundle cg() {
    if (this.jy == null)
      return null; 
    Bundle bundle = new Bundle();
    bundle.putInt("num", this.jy.goto);
    bundle.putFloat("distance", this.jy.void);
    bundle.putBoolean("extraInfo", this.jy.c);
    return bundle;
  }
  
  private Bundle ch() {
    if (this.jy == null)
      return null; 
    Bundle bundle = new Bundle();
    bundle.putString("packName", this.jP);
    bundle.putString("prodName", this.jy.if);
    bundle.putString("coorType", this.jy.do);
    bundle.putString("addrType", this.jy.char);
    bundle.putBoolean("openGPS", this.jy.for);
    bundle.putBoolean("location_change_notify", this.jy.else);
    bundle.putInt("scanSpan", this.jy.int);
    bundle.putInt("timeOut", this.jy.b);
    bundle.putInt("priority", this.jy.f);
    bundle.putBoolean("map", this.jj.booleanValue());
    bundle.putBoolean("import", this.je.booleanValue());
    bundle.putBoolean("needDirect", this.jy.e);
    return bundle;
  }
  
  private void char(int paramInt) {
    if (paramInt == 26) {
      if (this.jK == true) {
        Iterator<BDLocationListener> iterator = this.jR.iterator();
        while (iterator.hasNext())
          ((BDLocationListener)iterator.next()).onReceivePoi(this.jM); 
        this.jK = false;
      } 
      return;
    } 
    if (this.jq == true || (this.jy.else == true && this.jM.getLocType() == 61) || this.jM.getLocType() == 66 || this.jM.getLocType() == 67 || this.jk) {
      Iterator<BDLocationListener> iterator = this.jR.iterator();
      while (iterator.hasNext())
        ((BDLocationListener)iterator.next()).onReceiveLocation(this.jM); 
      if (this.jM.getLocType() != 66 && this.jM.getLocType() != 67) {
        this.jq = false;
        this.jH = System.currentTimeMillis();
      } 
    } 
  }
  
  private void ci() {
    if (this.jw != null) {
      Message message = Message.obtain(null, 25);
      try {
        message.replyTo = this.ju;
        message.setData(cg());
        this.jw.send(message);
        this.jf = System.currentTimeMillis();
        this.jK = true;
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } 
  }
  
  private void cj() {
    if (this.jE != true) {
      c.case();
      this.jP = this.jv.getPackageName();
      this.jO = this.jP + "_bdls_v2.9";
      String str1 = t.a(this.jv);
      String str2 = str1;
      if (TextUtils.isEmpty(str1))
        str2 = this.jJ; 
      this.jJ = str2;
      if (TextUtils.isEmpty(this.jJ))
        throw new IllegalStateException("please setting key from Manifest.xml"); 
      Intent intent = new Intent(this.jv, f.class);
      try {
        intent.putExtra("key", this.jJ);
        intent.putExtra("sign", t.if(this.jv));
      } catch (Exception exception) {}
      if (this.jy == null)
        this.jy = new LocationClientOption(); 
      if (this.jy.getLocationMode() == LocationClientOption.LocationMode.Device_Sensors)
        this.jy.setIsNeedAddress(false); 
      intent.putExtra("cache_exception", this.jy.long);
      intent.putExtra("kill_process", this.jy.case);
      try {
        this.jv.bindService(intent, this.jI, 1);
      } catch (Exception exception) {
        exception.printStackTrace();
        this.jE = false;
      } 
    } 
  }
  
  private void ck() {
    if (this.jE && this.jw != null) {
      Message message = Message.obtain(null, 12);
      message.replyTo = this.ju;
      try {
        this.jw.send(message);
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
      this.jv.unbindService(this.jI);
      synchronized (this.ja) {
        if (this.js == true) {
          this.i8.removeCallbacks(this.jd);
          this.js = false;
        } 
      } 
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{android/os/Message}, name=null} */
      this.jg.a1();
      this.jw = null;
      c.byte();
      this.jk = false;
      this.jE = false;
    } 
  }
  
  private void cl() {
    if (this.jw != null) {
      Message message = Message.obtain(null, 22);
      try {
        message.replyTo = this.ju;
        this.jw.send(message);
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } 
  }
  
  private void cm() {
    Message message = Message.obtain(null, 28);
    try {
      message.replyTo = this.ju;
      this.jw.send(message);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  private void else(boolean paramBoolean) {
    if (this.jb != null)
      this.jb.onReportResult(paramBoolean); 
    this.jb = null;
    this.ji = 0L;
  }
  
  private boolean else(int paramInt) {
    boolean bool1 = false;
    boolean bool2 = bool1;
    if (this.jw != null) {
      if (!this.jE)
        return bool1; 
    } else {
      return bool2;
    } 
    try {
      Message message = Message.obtain(null, paramInt);
      this.jw.send(message);
      bool2 = true;
    } catch (Exception exception) {
      bool2 = bool1;
    } 
    return bool2;
  }
  
  private void if(Message paramMessage, int paramInt) {
    Bundle bundle = paramMessage.getData();
    bundle.setClassLoader(BDLocation.class.getClassLoader());
    this.jM = (BDLocation)bundle.getParcelable("locStr");
    if (this.jM.getLocType() == 61)
      this.jx = System.currentTimeMillis(); 
    char(paramInt);
  }
  
  private void l(Message paramMessage) {
    if (paramMessage != null && paramMessage.obj != null) {
      BDNotifyListener bDNotifyListener = (BDNotifyListener)paramMessage.obj;
      this.jg.do(bDNotifyListener);
    } 
  }
  
  private void m(Message paramMessage) {
    if (paramMessage != null && paramMessage.obj != null) {
      BDLocationListener bDLocationListener = (BDLocationListener)paramMessage.obj;
      if (this.jR != null && this.jR.contains(bDLocationListener))
        this.jR.remove(bDLocationListener); 
    } 
  }
  
  private void n(Message paramMessage) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 11
    //   4: aload_1
    //   5: getfield obj : Ljava/lang/Object;
    //   8: ifnonnull -> 12
    //   11: return
    //   12: aload_1
    //   13: getfield obj : Ljava/lang/Object;
    //   16: checkcast com/baidu/location/LocationClientOption
    //   19: astore_1
    //   20: aload_0
    //   21: getfield jy : Lcom/baidu/location/LocationClientOption;
    //   24: aload_1
    //   25: invokevirtual equals : (Lcom/baidu/location/LocationClientOption;)Z
    //   28: ifne -> 11
    //   31: aload_0
    //   32: getfield jy : Lcom/baidu/location/LocationClientOption;
    //   35: getfield int : I
    //   38: aload_1
    //   39: getfield int : I
    //   42: if_icmpeq -> 139
    //   45: aload_0
    //   46: getfield ja : Ljava/lang/Object;
    //   49: astore_2
    //   50: aload_2
    //   51: monitorenter
    //   52: aload_0
    //   53: getfield js : Z
    //   56: iconst_1
    //   57: if_icmpne -> 76
    //   60: aload_0
    //   61: getfield i8 : Lcom/baidu/location/LocationClient$a;
    //   64: aload_0
    //   65: getfield jd : Lcom/baidu/location/LocationClient$b;
    //   68: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   71: aload_0
    //   72: iconst_0
    //   73: putfield js : Z
    //   76: aload_1
    //   77: getfield int : I
    //   80: sipush #1000
    //   83: if_icmplt -> 137
    //   86: aload_0
    //   87: getfield js : Z
    //   90: ifne -> 137
    //   93: aload_0
    //   94: getfield jd : Lcom/baidu/location/LocationClient$b;
    //   97: ifnonnull -> 115
    //   100: new com/baidu/location/LocationClient$b
    //   103: astore_3
    //   104: aload_3
    //   105: aload_0
    //   106: aconst_null
    //   107: invokespecial <init> : (Lcom/baidu/location/LocationClient;Lcom/baidu/location/LocationClient$1;)V
    //   110: aload_0
    //   111: aload_3
    //   112: putfield jd : Lcom/baidu/location/LocationClient$b;
    //   115: aload_0
    //   116: getfield i8 : Lcom/baidu/location/LocationClient$a;
    //   119: aload_0
    //   120: getfield jd : Lcom/baidu/location/LocationClient$b;
    //   123: aload_1
    //   124: getfield int : I
    //   127: i2l
    //   128: invokevirtual postDelayed : (Ljava/lang/Runnable;J)Z
    //   131: pop
    //   132: aload_0
    //   133: iconst_1
    //   134: putfield js : Z
    //   137: aload_2
    //   138: monitorexit
    //   139: aload_0
    //   140: new com/baidu/location/LocationClientOption
    //   143: dup
    //   144: aload_1
    //   145: invokespecial <init> : (Lcom/baidu/location/LocationClientOption;)V
    //   148: putfield jy : Lcom/baidu/location/LocationClientOption;
    //   151: aload_0
    //   152: getfield jw : Landroid/os/Messenger;
    //   155: ifnull -> 11
    //   158: aconst_null
    //   159: bipush #15
    //   161: invokestatic obtain : (Landroid/os/Handler;I)Landroid/os/Message;
    //   164: astore_1
    //   165: aload_1
    //   166: aload_0
    //   167: getfield ju : Landroid/os/Messenger;
    //   170: putfield replyTo : Landroid/os/Messenger;
    //   173: aload_1
    //   174: aload_0
    //   175: invokespecial ch : ()Landroid/os/Bundle;
    //   178: invokevirtual setData : (Landroid/os/Bundle;)V
    //   181: aload_0
    //   182: getfield jw : Landroid/os/Messenger;
    //   185: aload_1
    //   186: invokevirtual send : (Landroid/os/Message;)V
    //   189: goto -> 11
    //   192: astore_1
    //   193: aload_1
    //   194: invokevirtual printStackTrace : ()V
    //   197: goto -> 11
    //   200: astore_3
    //   201: aload_2
    //   202: monitorexit
    //   203: aload_3
    //   204: athrow
    //   205: astore_2
    //   206: goto -> 139
    // Exception table:
    //   from	to	target	type
    //   45	52	205	java/lang/Exception
    //   52	76	200	finally
    //   76	115	200	finally
    //   115	137	200	finally
    //   137	139	200	finally
    //   158	189	192	java/lang/Exception
    //   201	203	200	finally
    //   203	205	205	java/lang/Exception
  }
  
  private void o(Message paramMessage) {
    if (this.jw != null) {
      if ((System.currentTimeMillis() - this.jx > 3000L || !this.jy.else) && (!this.jk || System.currentTimeMillis() - this.jH > 20000L)) {
        Message message = Message.obtain(null, 22);
        try {
          message.replyTo = this.ju;
          message.arg1 = paramMessage.arg1;
          this.jw.send(message);
          this.jF = System.currentTimeMillis();
          this.jq = true;
        } catch (Exception exception) {
          exception.printStackTrace();
        } 
      } 
      synchronized (this.ja) {
        if (this.jy != null && this.jy.int >= 1000 && !this.js) {
          if (this.jd == null) {
            b b1 = new b();
            this(this, null);
            this.jd = b1;
          } 
          this.i8.postDelayed(this.jd, this.jy.int);
          this.js = true;
        } 
        return;
      } 
    } 
  }
  
  private void p(Message paramMessage) {
    Bundle bundle = paramMessage.getData();
    bundle.setClassLoader(BDLocation.class.getClassLoader());
    BDLocation bDLocation = (BDLocation)bundle.getParcelable("locStr");
    if (this.jo != null && (this.jy == null || !this.jy.isDisableCache() || bDLocation.getLocType() != 65))
      this.jo.onReceiveLocation(bDLocation); 
  }
  
  private void q(Message paramMessage) {
    if (paramMessage != null && paramMessage.obj != null) {
      BDNotifyListener bDNotifyListener = (BDNotifyListener)paramMessage.obj;
      this.jg.for(bDNotifyListener);
    } 
  }
  
  private void r(Message paramMessage) {
    if (paramMessage != null && paramMessage.obj != null) {
      BDLocationListener bDLocationListener = (BDLocationListener)paramMessage.obj;
      if (this.jR == null)
        this.jR = new ArrayList(); 
      this.jR.add(bDLocationListener);
    } 
  }
  
  private void s(Message paramMessage) {
    if (paramMessage != null && paramMessage.obj != null)
      this.jo = (BDLocationListener)paramMessage.obj; 
  }
  
  public void cancleError() {
    else(202);
  }
  
  public String getAccessKey() {
    String str1 = t.a(this.jv);
    String str2 = str1;
    if (TextUtils.isEmpty(str1))
      str2 = this.jJ; 
    this.jJ = str2;
    return String.format("KEY=%s;SHA1=%s", new Object[] { this.jJ, t.if(this.jv) });
  }
  
  public BDLocation getLastKnownLocation() {
    return this.jM;
  }
  
  public LocationClientOption getLocOption() {
    return this.jy;
  }
  
  public String getVersion() {
    return "4.1.5";
  }
  
  public boolean isStarted() {
    return this.jE;
  }
  
  public boolean notifyError() {
    return else(201);
  }
  
  public void registerLocationListener(BDLocationListener paramBDLocationListener) {
    if (paramBDLocationListener == null)
      throw new IllegalStateException("please set a non-null listener"); 
    Message message = this.i8.obtainMessage(5);
    message.obj = paramBDLocationListener;
    message.sendToTarget();
  }
  
  public void registerNotify(BDNotifyListener paramBDNotifyListener) {
    Message message = this.i8.obtainMessage(9);
    message.obj = paramBDNotifyListener;
    message.sendToTarget();
  }
  
  public void registerNotifyLocationListener(BDLocationListener paramBDLocationListener) {
    Message message = this.i8.obtainMessage(8);
    message.obj = paramBDLocationListener;
    message.sendToTarget();
  }
  
  public void removeNotifyEvent(BDNotifyListener paramBDNotifyListener) {
    Message message = this.i8.obtainMessage(10);
    message.obj = paramBDNotifyListener;
    message.sendToTarget();
  }
  
  public int reportErrorWithInfo(BDErrorReport paramBDErrorReport) {
    byte b1 = 1;
    byte b2 = b1;
    if (this.jw != null) {
      if (!this.jE)
        return b1; 
    } else {
      return b2;
    } 
    if (paramBDErrorReport == null)
      return 2; 
    if (System.currentTimeMillis() - this.ji < 50000L && this.jb != null)
      return 4; 
    Bundle bundle = paramBDErrorReport.getErrorInfo();
    if (bundle == null)
      return 3; 
    try {
      Message message = Message.obtain(null, 203);
      message.replyTo = this.ju;
      message.setData(bundle);
      this.jw.send(message);
      this.jb = paramBDErrorReport;
      this.ji = System.currentTimeMillis();
      b2 = 0;
    } catch (Exception exception) {
      b2 = b1;
    } 
    return b2;
  }
  
  public int requestLocation() {
    byte b1 = 1;
    null = b1;
    if (this.jw != null) {
      if (this.ju == null)
        return b1; 
    } else {
      return null;
    } 
    if (this.jR == null || this.jR.size() < 1)
      return 2; 
    if (System.currentTimeMillis() - this.jF < 1000L)
      return 6; 
    Message message = this.i8.obtainMessage(4);
    message.arg1 = 1;
    message.sendToTarget();
    return 0;
  }
  
  public void requestNotifyLocation() {
    this.i8.obtainMessage(11).sendToTarget();
  }
  
  public int requestOfflineLocation() {
    byte b1 = 1;
    null = b1;
    if (this.jw != null) {
      if (this.ju == null)
        return b1; 
    } else {
      return null;
    } 
    if (this.jR == null || this.jR.size() < 1)
      return 2; 
    this.i8.obtainMessage(12).sendToTarget();
    return 0;
  }
  
  public int requestPoi() {
    byte b1 = 7;
    if (this.jw == null || this.ju == null)
      return 1; 
    if (this.jR == null || this.jR.size() < 1)
      return 2; 
    if (System.currentTimeMillis() - this.jf < 6000L)
      return 6; 
    if (this.jy.goto >= 1) {
      this.i8.obtainMessage(7).sendToTarget();
      b1 = 0;
    } 
    return b1;
  }
  
  public void setAccessKey(String paramString) {
    String str = paramString;
    if (!TextUtils.isEmpty(paramString))
      str = Pattern.compile("[&=]").matcher(paramString).replaceAll(""); 
    this.jJ = str;
    Context context2 = this.jv;
    paramString = PREF_FILE_NAME;
    Context context1 = this.jv;
    context2.getSharedPreferences(paramString, 0).edit().putString(PREF_KEY_NAME, this.jJ).commit();
  }
  
  public void setForBaiduMap(boolean paramBoolean) {
    this.jj = Boolean.valueOf(paramBoolean);
  }
  
  public void setLocOption(LocationClientOption paramLocationClientOption) {
    Message message2;
    if (paramLocationClientOption == null) {
      LocationClientOption locationClientOption = new LocationClientOption();
    } else {
      Message message;
      LocationClientOption locationClientOption;
      switch (paramLocationClientOption.f) {
        default:
          locationClientOption = paramLocationClientOption;
          message = this.i8.obtainMessage(3);
          message.obj = locationClientOption;
          message.sendToTarget();
          return;
        case 1:
          message2 = message;
          if (((LocationClientOption)message).int != 0) {
            message2 = message;
            if (((LocationClientOption)message).int < 1000) {
              Log.w("baidu_location_service", String.format("scanSpan time %d less than 1 second, location services may not star", new Object[] { Integer.valueOf(((LocationClientOption)message).int) }));
              ((LocationClientOption)message).int = 1000;
              message2 = message;
            } 
          } 
          message = this.i8.obtainMessage(3);
          message.obj = message2;
          message.sendToTarget();
          return;
        case 3:
          if (((LocationClientOption)message).int != 0 && ((LocationClientOption)message).int < 1000) {
            Log.w("baidu_location_service", String.format("scanSpan time %d less than 1 second, location services may not star", new Object[] { Integer.valueOf(((LocationClientOption)message).int) }));
            ((LocationClientOption)message).int = 1000;
            message2 = message;
          } else {
            message2 = message;
            if (((LocationClientOption)message).int == 0) {
              ((LocationClientOption)message).int = 1000;
              message2 = message;
            } 
          } 
          message = this.i8.obtainMessage(3);
          message.obj = message2;
          message.sendToTarget();
          return;
        case 2:
          break;
      } 
      message2 = message;
      if (((LocationClientOption)message).int != 0) {
        message2 = message;
        if (((LocationClientOption)message).int < 3000) {
          ((LocationClientOption)message).int = 3000;
          Log.w("baidu_location_service", String.format("scanSpan time %d less than 3 second, location services may not star", new Object[] { Integer.valueOf(((LocationClientOption)message).int) }));
          message2 = message;
        } 
      } 
    } 
    Message message1 = this.i8.obtainMessage(3);
    message1.obj = message2;
    message1.sendToTarget();
  }
  
  public void start() {
    this.i8.obtainMessage(1).sendToTarget();
  }
  
  public void stop() {
    ck();
  }
  
  public void unRegisterLocationListener(BDLocationListener paramBDLocationListener) {
    if (paramBDLocationListener == null)
      throw new IllegalStateException("please set a non-null listener"); 
    Message message = this.i8.obtainMessage(6);
    message.obj = paramBDLocationListener;
    message.sendToTarget();
  }
  
  public boolean updateLocation(Location paramLocation) {
    if (this.jw == null || this.ju == null || paramLocation == null)
      return false; 
    try {
      Message message = Message.obtain(null, 57);
      message.obj = paramLocation;
      this.jw.send(message);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return true;
  }
  
  private class a extends Handler {
    private a(LocationClient this$0) {}
    
    public void handleMessage(Message param1Message) {
      switch (param1Message.what) {
        default:
          super.handleMessage(param1Message);
          return;
        case 3:
          LocationClient.for(this.a, param1Message);
          return;
        case 8:
          LocationClient.do(this.a, param1Message);
          return;
        case 5:
          LocationClient.if(this.a, param1Message);
          return;
        case 6:
          LocationClient.case(this.a, param1Message);
          return;
        case 9:
          LocationClient.byte(this.a, param1Message);
          return;
        case 10:
          LocationClient.new(this.a, param1Message);
          return;
        case 1:
          LocationClient.do(this.a);
          return;
        case 2:
          LocationClient.try(this.a);
          return;
        case 11:
          LocationClient.case(this.a);
          return;
        case 4:
          LocationClient.int(this.a, param1Message);
          return;
        case 12:
          LocationClient.int(this.a);
          return;
        case 7:
          LocationClient.long(this.a);
          return;
        case 54:
          if ((LocationClient.else(this.a)).else)
            LocationClient.for(this.a, true); 
          return;
        case 55:
          if ((LocationClient.else(this.a)).else)
            LocationClient.for(this.a, false); 
          return;
        case 21:
          LocationClient.if(this.a, param1Message, 21);
          return;
        case 26:
          LocationClient.if(this.a, param1Message, 26);
          return;
        case 27:
          LocationClient.try(this.a, param1Message);
          return;
        case 205:
          LocationClient.do(this.a, true);
          return;
        case 204:
          break;
      } 
      LocationClient.do(this.a, false);
    }
  }
  
  private class b implements Runnable {
    private b(LocationClient this$0) {}
    
    public void run() {
      synchronized (LocationClient.for(this.a)) {
        LocationClient.int(this.a, false);
        if (LocationClient.char(this.a) == null || LocationClient.new(this.a) == null)
          return; 
        if (LocationClient.goto(this.a) == null || LocationClient.goto(this.a).size() < 1)
          return; 
      } 
      LocationClient.byte(this.a).obtainMessage(4).sendToTarget();
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_1} */
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/LocationClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */