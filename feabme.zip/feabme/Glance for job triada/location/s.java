package com.baidu.location;

import android.os.Message;

class s extends ae implements au, l {
  private static s eu = null;
  
  static final int ev = 3000;
  
  private long ew = 0L;
  
  private BDLocation ex = null;
  
  public ae.a ey = null;
  
  private s() {
    this.ey = new ae.a(this);
  }
  
  private void as() {
    o.u().A();
  }
  
  public static s at() {
    if (eu == null)
      eu = new s(); 
    return eu;
  }
  
  private void void(Message paramMessage) {
    if (System.currentTimeMillis() - this.ew < 3000L && this.ex != null) {
      i.m().if(this.ex, 26);
      return;
    } 
    String str = d(i.m().if(paramMessage));
    this.ey.void(str);
    this.ew = System.currentTimeMillis();
  }
  
  void ag() {
    c.if("baidu_location_service", "on network exception");
    this.ex = null;
    i.m().if(av.bW().case(false), 26);
    as();
  }
  
  void byte(Message paramMessage) {
    c.if("baidu_location_service", "on network success");
    BDLocation bDLocation = (BDLocation)paramMessage.obj;
    i.m().if(bDLocation, 26);
    if (c.if(bDLocation)) {
      this.ex = bDLocation;
    } else {
      this.ex = null;
    } 
    as();
  }
  
  public void long(Message paramMessage) {
    void(paramMessage);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */