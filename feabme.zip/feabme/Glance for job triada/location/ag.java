package com.baidu.location;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import java.util.Timer;

public class ag implements l, au {
  public static final float g0 = 0.01F;
  
  private static final int g9 = 6;
  
  private static final int hb = 20;
  
  private static final float hg = 0.8F;
  
  public static final float hh = 4.0F;
  
  private int g1 = 0;
  
  private double g2 = 1.6D;
  
  private double[] g3 = new double[6];
  
  public SensorEventListener g4 = new ag$1(this);
  
  private int g5 = 0;
  
  private long g6 = 0L;
  
  Timer g7;
  
  private int g8;
  
  private int gV;
  
  private int gW = 440;
  
  private int gX = 1;
  
  private final long gY = 30L;
  
  private float[] gZ = new float[3];
  
  private Sensor ha;
  
  private float[] hc = new float[] { 0.0F, 0.0F, 0.0F };
  
  private volatile int hd = 0;
  
  private int he = 31;
  
  private double[] hf = new double[this.he];
  
  private int hi = 0;
  
  private SensorManager hj;
  
  private boolean hk;
  
  public ag(Context paramContext) {
    this(paramContext, 0);
  }
  
  private ag(Context paramContext, int paramInt) {
    try {
      this.hj = (SensorManager)paramContext.getSystemService("sensor");
      this.g8 = paramInt;
      this.ha = this.hj.getDefaultSensor(1);
    } catch (Exception exception) {}
  }
  
  private void bm() {
    if (this.gV >= 20) {
      long l1 = System.currentTimeMillis();
      float[] arrayOfFloat = new float[3];
      System.arraycopy(this.hc, 0, arrayOfFloat, 0, 3);
      float f1 = arrayOfFloat[0];
      float f2 = arrayOfFloat[0];
      float f3 = arrayOfFloat[1];
      float f4 = arrayOfFloat[1];
      float f5 = arrayOfFloat[2];
      double d = Math.sqrt((arrayOfFloat[2] * f5 + f1 * f2 + f3 * f4));
      this.hf[this.hi] = d;
      do(d);
      this.hi++;
      if (this.hi == this.he) {
        this.hi = 0;
        d = if(this.hf);
        if (this.hd == 0 && d < 0.3D) {
          case(0);
          this.hd = 0;
        } else {
          case(1);
          this.hd = 1;
        } 
      } 
      if (l1 - this.g6 > this.gW && if(this.g2)) {
        this.g1++;
        this.g6 = l1;
      } 
    } 
  }
  
  private void case(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_0
    //   4: getfield gX : I
    //   7: iload_1
    //   8: ior
    //   9: putfield gX : I
    //   12: aload_0
    //   13: monitorexit
    //   14: return
    //   15: astore_2
    //   16: aload_0
    //   17: monitorexit
    //   18: aload_2
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	15	finally
  }
  
  private void do(double paramDouble) {
    this.g3[this.g5 % 6] = paramDouble;
    this.g5++;
    this.g5 %= 6;
  }
  
  private double if(double[] paramArrayOfdouble) {
    boolean bool = false;
    double d1 = 0.0D;
    int i = paramArrayOfdouble.length;
    byte b = 0;
    double d2 = 0.0D;
    while (b < i) {
      d2 += paramArrayOfdouble[b];
      b++;
    } 
    double d3 = d2 / i;
    d2 = d1;
    for (b = bool; b < i; b++)
      d2 += (paramArrayOfdouble[b] - d3) * (paramArrayOfdouble[b] - d3); 
    return d2 / (i - 1);
  }
  
  private boolean if(double paramDouble) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_3
    //   2: iconst_1
    //   3: istore #4
    //   5: iload #4
    //   7: iconst_5
    //   8: if_icmpgt -> 65
    //   11: aload_0
    //   12: getfield g3 : [D
    //   15: aload_0
    //   16: getfield g5 : I
    //   19: iconst_1
    //   20: isub
    //   21: iload #4
    //   23: isub
    //   24: bipush #6
    //   26: iadd
    //   27: bipush #6
    //   29: iadd
    //   30: bipush #6
    //   32: irem
    //   33: daload
    //   34: aload_0
    //   35: getfield g3 : [D
    //   38: aload_0
    //   39: getfield g5 : I
    //   42: iconst_1
    //   43: isub
    //   44: bipush #6
    //   46: iadd
    //   47: bipush #6
    //   49: irem
    //   50: daload
    //   51: dsub
    //   52: dload_1
    //   53: dcmpl
    //   54: ifle -> 59
    //   57: iload_3
    //   58: ireturn
    //   59: iinc #4, 1
    //   62: goto -> 5
    //   65: iconst_0
    //   66: istore_3
    //   67: goto -> 57
  }
  
  private float[] if(float paramFloat1, float paramFloat2, float paramFloat3) {
    this.gZ[0] = this.gZ[0] * 0.8F + 0.19999999F * paramFloat1;
    this.gZ[1] = this.gZ[1] * 0.8F + 0.19999999F * paramFloat2;
    this.gZ[2] = this.gZ[2] * 0.8F + 0.19999999F * paramFloat3;
    return new float[] { paramFloat1 - this.gZ[0], paramFloat2 - this.gZ[1], paramFloat3 - this.gZ[2] };
  }
  
  public int bj() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield gV : I
    //   6: istore_1
    //   7: iload_1
    //   8: bipush #20
    //   10: if_icmpge -> 19
    //   13: iconst_m1
    //   14: istore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: iload_1
    //   18: ireturn
    //   19: aload_0
    //   20: getfield g1 : I
    //   23: istore_1
    //   24: goto -> 15
    //   27: astore_2
    //   28: aload_0
    //   29: monitorexit
    //   30: aload_2
    //   31: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	27	finally
    //   19	24	27	finally
  }
  
  public void bk() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iconst_0
    //   4: putfield gX : I
    //   7: aload_0
    //   8: monitorexit
    //   9: return
    //   10: astore_1
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_1
    //   14: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	10	finally
  }
  
  public int bl() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield gV : I
    //   6: istore_1
    //   7: iload_1
    //   8: bipush #20
    //   10: if_icmpge -> 19
    //   13: iconst_1
    //   14: istore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: iload_1
    //   18: ireturn
    //   19: aload_0
    //   20: getfield gX : I
    //   23: istore_1
    //   24: goto -> 15
    //   27: astore_2
    //   28: aload_0
    //   29: monitorexit
    //   30: aload_2
    //   31: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	27	finally
    //   19	24	27	finally
  }
  
  public void bn() {
    if (!this.hk && this.ha != null) {
      try {
        this.hj.registerListener(this.g4, this.ha, this.g8);
      } catch (Exception exception) {}
      this.g7 = new Timer("UpdateData", false);
      ag$2 ag$2 = new ag$2(this);
      this.g7.schedule(ag$2, 500L, 30L);
      this.hk = true;
    } 
  }
  
  public void bo() {
    if (this.hk == true) {
      try {
        this.hj.unregisterListener(this.g4);
      } catch (Exception exception) {}
      this.g7.cancel();
      this.g7.purge();
      this.g7 = null;
      this.hk = false;
    } 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/ag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */