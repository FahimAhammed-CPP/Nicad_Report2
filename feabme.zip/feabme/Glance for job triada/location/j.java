package com.baidu.location;

import android.app.AlarmManager;
import android.app.KeyguardManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.os.Handler;
import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

class j implements au, l {
  private static final int b2 = 200;
  
  private static File b4;
  
  private static File bA;
  
  private static final int bH = 800;
  
  public static final String bJ = "com.baidu.locTest.LocationServer4.1.5";
  
  private static final int bT = 24;
  
  private static String bW = H + "/glb.dat";
  
  private int b0;
  
  private boolean b1;
  
  long b3;
  
  private a b5;
  
  private boolean bB;
  
  private boolean bC;
  
  private String bD;
  
  private int bE;
  
  private AlarmManager bF;
  
  private PendingIntent bG;
  
  private Context bI;
  
  private String bK;
  
  private long bL;
  
  private boolean bM;
  
  private long bN;
  
  private r.a bO;
  
  private long bP;
  
  private final int bQ;
  
  String bR;
  
  ArrayList bS;
  
  private long bU;
  
  ArrayList bV;
  
  private long bX;
  
  private final int bY;
  
  private int bZ;
  
  c bu;
  
  private final long bv;
  
  private String bw;
  
  private Handler bx;
  
  private boolean by;
  
  private long[] bz;
  
  static {
    bA = null;
    b4 = null;
  }
  
  public j(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: new java/lang/StringBuilder
    //   8: dup
    //   9: invokespecial <init> : ()V
    //   12: getstatic com/baidu/location/j.H : Ljava/lang/String;
    //   15: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   18: ldc '/vm.dat'
    //   20: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   23: invokevirtual toString : ()Ljava/lang/String;
    //   26: putfield bD : Ljava/lang/String;
    //   29: aload_0
    //   30: ldc2_w 86100000
    //   33: putfield bv : J
    //   36: aload_0
    //   37: sipush #200
    //   40: putfield bY : I
    //   43: aload_0
    //   44: aconst_null
    //   45: putfield bF : Landroid/app/AlarmManager;
    //   48: aload_0
    //   49: aconst_null
    //   50: putfield b5 : Lcom/baidu/location/j$a;
    //   53: aload_0
    //   54: aconst_null
    //   55: putfield bG : Landroid/app/PendingIntent;
    //   58: aload_0
    //   59: aconst_null
    //   60: putfield bI : Landroid/content/Context;
    //   63: aload_0
    //   64: lconst_0
    //   65: putfield bU : J
    //   68: aload_0
    //   69: bipush #20
    //   71: newarray long
    //   73: putfield bz : [J
    //   76: aload_0
    //   77: iconst_0
    //   78: putfield bE : I
    //   81: aload_0
    //   82: aconst_null
    //   83: putfield bO : Lcom/baidu/location/r$a;
    //   86: aload_0
    //   87: aconst_null
    //   88: putfield bK : Ljava/lang/String;
    //   91: aload_0
    //   92: iconst_1
    //   93: putfield b0 : I
    //   96: aload_0
    //   97: iconst_0
    //   98: putfield bC : Z
    //   101: aload_0
    //   102: iconst_0
    //   103: putfield bM : Z
    //   106: aload_0
    //   107: iconst_0
    //   108: putfield b1 : Z
    //   111: aload_0
    //   112: aconst_null
    //   113: putfield bx : Landroid/os/Handler;
    //   116: aload_0
    //   117: iconst_1
    //   118: putfield bQ : I
    //   121: aload_0
    //   122: iconst_0
    //   123: putfield bB : Z
    //   126: aload_0
    //   127: getstatic com/baidu/location/c.ac : J
    //   130: putfield bP : J
    //   133: aload_0
    //   134: iconst_0
    //   135: putfield bZ : I
    //   138: aload_0
    //   139: lconst_0
    //   140: putfield bN : J
    //   143: aload_0
    //   144: lconst_0
    //   145: putfield bL : J
    //   148: aload_0
    //   149: lconst_0
    //   150: putfield bX : J
    //   153: aload_0
    //   154: ldc ''
    //   156: putfield bw : Ljava/lang/String;
    //   159: aload_0
    //   160: iconst_0
    //   161: putfield by : Z
    //   164: aload_0
    //   165: aconst_null
    //   166: putfield bu : Lcom/baidu/location/j$c;
    //   169: aload_0
    //   170: aconst_null
    //   171: putfield bV : Ljava/util/ArrayList;
    //   174: aload_0
    //   175: aconst_null
    //   176: putfield bS : Ljava/util/ArrayList;
    //   179: aload_0
    //   180: lconst_0
    //   181: putfield b3 : J
    //   184: aload_0
    //   185: ldc 'dlcu.dat'
    //   187: putfield bR : Ljava/lang/String;
    //   190: aload_0
    //   191: aload_1
    //   192: putfield bI : Landroid/content/Context;
    //   195: aload_0
    //   196: lconst_0
    //   197: putfield b3 : J
    //   200: new com/baidu/location/j$c
    //   203: astore_2
    //   204: aload_2
    //   205: aload_0
    //   206: invokespecial <init> : (Lcom/baidu/location/j;)V
    //   209: aload_0
    //   210: aload_2
    //   211: putfield bu : Lcom/baidu/location/j$c;
    //   214: aload_0
    //   215: monitorenter
    //   216: getstatic com/baidu/location/f.isServing : Z
    //   219: ifne -> 234
    //   222: aload_0
    //   223: monitorexit
    //   224: return
    //   225: astore_2
    //   226: aload_0
    //   227: aconst_null
    //   228: putfield bu : Lcom/baidu/location/j$c;
    //   231: goto -> 214
    //   234: new com/baidu/location/j$1
    //   237: astore_2
    //   238: aload_2
    //   239: aload_0
    //   240: invokespecial <init> : (Lcom/baidu/location/j;)V
    //   243: aload_0
    //   244: aload_2
    //   245: putfield bx : Landroid/os/Handler;
    //   248: aload_0
    //   249: invokestatic currentTimeMillis : ()J
    //   252: putfield bU : J
    //   255: aload_0
    //   256: aload_1
    //   257: ldc 'alarm'
    //   259: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   262: checkcast android/app/AlarmManager
    //   265: putfield bF : Landroid/app/AlarmManager;
    //   268: new com/baidu/location/j$a
    //   271: astore_2
    //   272: aload_2
    //   273: aload_0
    //   274: invokespecial <init> : (Lcom/baidu/location/j;)V
    //   277: aload_0
    //   278: aload_2
    //   279: putfield b5 : Lcom/baidu/location/j$a;
    //   282: aload_0
    //   283: getfield b5 : Lcom/baidu/location/j$a;
    //   286: astore_2
    //   287: new android/content/IntentFilter
    //   290: astore_3
    //   291: aload_3
    //   292: ldc 'com.baidu.locTest.LocationServer4.1.5'
    //   294: invokespecial <init> : (Ljava/lang/String;)V
    //   297: aload_1
    //   298: aload_2
    //   299: aload_3
    //   300: invokevirtual registerReceiver : (Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    //   303: pop
    //   304: new android/content/Intent
    //   307: astore_2
    //   308: aload_2
    //   309: ldc 'com.baidu.locTest.LocationServer4.1.5'
    //   311: invokespecial <init> : (Ljava/lang/String;)V
    //   314: aload_0
    //   315: aload_1
    //   316: iconst_0
    //   317: aload_2
    //   318: ldc 134217728
    //   320: invokestatic getBroadcast : (Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;
    //   323: putfield bG : Landroid/app/PendingIntent;
    //   326: aload_0
    //   327: getfield bF : Landroid/app/AlarmManager;
    //   330: iconst_0
    //   331: invokestatic currentTimeMillis : ()J
    //   334: ldc2_w 1000
    //   337: ladd
    //   338: aload_0
    //   339: getfield bG : Landroid/app/PendingIntent;
    //   342: invokevirtual set : (IJLandroid/app/PendingIntent;)V
    //   345: aload_0
    //   346: getstatic com/baidu/location/c.ac : J
    //   349: putfield bP : J
    //   352: new java/util/ArrayList
    //   355: astore_1
    //   356: aload_1
    //   357: invokespecial <init> : ()V
    //   360: aload_0
    //   361: aload_1
    //   362: putfield bV : Ljava/util/ArrayList;
    //   365: new java/util/ArrayList
    //   368: astore_1
    //   369: aload_1
    //   370: invokespecial <init> : ()V
    //   373: aload_0
    //   374: aload_1
    //   375: putfield bS : Ljava/util/ArrayList;
    //   378: aload_0
    //   379: invokespecial q : ()V
    //   382: aload_0
    //   383: iconst_1
    //   384: putfield bB : Z
    //   387: aload_0
    //   388: monitorexit
    //   389: goto -> 224
    //   392: astore_1
    //   393: aload_0
    //   394: monitorexit
    //   395: aload_1
    //   396: athrow
    // Exception table:
    //   from	to	target	type
    //   200	214	225	java/lang/Exception
    //   216	224	392	finally
    //   234	389	392	finally
    //   393	395	392	finally
  }
  
  private void if(boolean paramBoolean) {
    String str = c.try();
    if (str != null) {
      String str1 = str + File.separator + "baidu/tempdata/" + this.bR;
      try {
        RandomAccessFile randomAccessFile = new RandomAccessFile();
        this(str1, "rw");
        if (paramBoolean) {
          randomAccessFile.seek(0L);
          randomAccessFile.writeLong(System.currentTimeMillis());
          randomAccessFile.writeInt(2125);
          this.bZ = 0;
          this.bN = System.currentTimeMillis();
        } else {
          randomAccessFile.seek(12L);
        } 
        randomAccessFile.writeInt(this.bZ);
        randomAccessFile.writeInt(2125);
        randomAccessFile.close();
      } catch (Exception exception) {}
    } 
  }
  
  public static void n() {
    try {
      if (bW != null) {
        File file = new File();
        this(bW);
        b4 = file;
        if (!b4.exists()) {
          file = new File();
          this(H);
          if (!file.exists())
            file.mkdirs(); 
          b4.createNewFile();
          RandomAccessFile randomAccessFile = new RandomAccessFile();
          this(b4, "rw");
          randomAccessFile.seek(0L);
          randomAccessFile.writeInt(-1);
          randomAccessFile.writeInt(-1);
          randomAccessFile.writeInt(0);
          randomAccessFile.writeLong(0L);
          randomAccessFile.writeInt(0);
          randomAccessFile.writeInt(0);
          randomAccessFile.close();
        } 
        return;
      } 
      b4 = null;
    } catch (Exception exception) {
      b4 = null;
    } 
  }
  
  public static String p() {
    return null;
  }
  
  private void q() {
    String str = c.try();
    if (str != null) {
      long l1;
      boolean bool1;
      boolean bool2;
      str = str + File.separator + "baidu/tempdata/" + this.bR;
      try {
        RandomAccessFile randomAccessFile = new RandomAccessFile();
        this(str, "r");
        randomAccessFile.seek(0L);
        l1 = randomAccessFile.readLong();
        try {
          if (randomAccessFile.readInt() == 2125) {
            bool1 = randomAccessFile.readInt();
            try {
              bool2 = randomAccessFile.readInt();
              if (bool2 == 'ࡍ') {
                bool2 = true;
              } else {
                bool2 = false;
              } 
              try {
                randomAccessFile.close();
              } catch (Exception exception) {}
            } catch (Exception exception) {
              bool2 = false;
            } 
          } else {
            bool1 = false;
            bool2 = false;
            try {
              randomAccessFile.close();
            } catch (Exception exception) {}
          } 
        } catch (Exception exception) {
          bool1 = false;
          bool2 = false;
        } 
      } catch (Exception exception) {
        l1 = 0L;
        bool1 = false;
        bool2 = false;
      } 
      if (bool2) {
        this.bZ = bool1;
        this.bN = l1;
        return;
      } 
      this.bZ = 0;
      this.bN = 0L;
    } 
  }
  
  boolean if(double paramDouble1, double paramDouble2) {
    return (-2.1971522D * paramDouble1 + -0.70587059D * paramDouble2 + 0.8428018D > 0.0D);
  }
  
  public boolean o() {
    return ((KeyguardManager)this.bI.getSystemService("keyguard")).inKeyguardRestrictedInputMode();
  }
  
  public void r() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iconst_0
    //   4: putfield bB : Z
    //   7: aload_0
    //   8: getfield b5 : Lcom/baidu/location/j$a;
    //   11: ifnull -> 25
    //   14: aload_0
    //   15: getfield bI : Landroid/content/Context;
    //   18: aload_0
    //   19: getfield b5 : Lcom/baidu/location/j$a;
    //   22: invokevirtual unregisterReceiver : (Landroid/content/BroadcastReceiver;)V
    //   25: aload_0
    //   26: aconst_null
    //   27: putfield b5 : Lcom/baidu/location/j$a;
    //   30: aload_0
    //   31: getfield bF : Landroid/app/AlarmManager;
    //   34: ifnull -> 55
    //   37: aload_0
    //   38: getfield bG : Landroid/app/PendingIntent;
    //   41: ifnull -> 55
    //   44: aload_0
    //   45: getfield bF : Landroid/app/AlarmManager;
    //   48: aload_0
    //   49: getfield bG : Landroid/app/PendingIntent;
    //   52: invokevirtual cancel : (Landroid/app/PendingIntent;)V
    //   55: aload_0
    //   56: aconst_null
    //   57: putfield bF : Landroid/app/AlarmManager;
    //   60: aload_0
    //   61: aconst_null
    //   62: putfield bG : Landroid/app/PendingIntent;
    //   65: aconst_null
    //   66: putstatic com/baidu/location/j.bA : Ljava/io/File;
    //   69: aload_0
    //   70: getfield bV : Ljava/util/ArrayList;
    //   73: invokevirtual clear : ()V
    //   76: aload_0
    //   77: getfield bS : Ljava/util/ArrayList;
    //   80: invokevirtual clear : ()V
    //   83: aload_0
    //   84: aconst_null
    //   85: putfield bV : Ljava/util/ArrayList;
    //   88: aload_0
    //   89: aconst_null
    //   90: putfield bS : Ljava/util/ArrayList;
    //   93: aload_0
    //   94: lconst_0
    //   95: putfield b3 : J
    //   98: aload_0
    //   99: lconst_0
    //   100: putfield bX : J
    //   103: aload_0
    //   104: ldc ''
    //   106: putfield bw : Ljava/lang/String;
    //   109: aload_0
    //   110: iconst_0
    //   111: putfield by : Z
    //   114: aload_0
    //   115: monitorexit
    //   116: return
    //   117: astore_1
    //   118: aload_0
    //   119: monitorexit
    //   120: aload_1
    //   121: athrow
    // Exception table:
    //   from	to	target	type
    //   2	25	117	finally
    //   25	55	117	finally
    //   55	114	117	finally
  }
  
  void s() {
    // Byte code:
    //   0: aload_0
    //   1: getfield bB : Z
    //   4: ifne -> 8
    //   7: return
    //   8: aload_0
    //   9: getfield bX : J
    //   12: lconst_0
    //   13: lcmp
    //   14: ifeq -> 1467
    //   17: invokestatic currentTimeMillis : ()J
    //   20: aload_0
    //   21: getfield bX : J
    //   24: lsub
    //   25: ldc2_w 30000
    //   28: ladd
    //   29: lstore_1
    //   30: aload_0
    //   31: invokestatic currentTimeMillis : ()J
    //   34: putfield bX : J
    //   37: invokestatic try : ()Ljava/lang/String;
    //   40: astore_3
    //   41: aload_3
    //   42: ifnonnull -> 67
    //   45: aload_0
    //   46: getfield bF : Landroid/app/AlarmManager;
    //   49: iconst_0
    //   50: invokestatic currentTimeMillis : ()J
    //   53: getstatic com/baidu/location/c.aO : J
    //   56: ladd
    //   57: aload_0
    //   58: getfield bG : Landroid/app/PendingIntent;
    //   61: invokevirtual set : (IJLandroid/app/PendingIntent;)V
    //   64: goto -> 7
    //   67: invokestatic aa : ()Lcom/baidu/location/r;
    //   70: invokevirtual X : ()Lcom/baidu/location/r$a;
    //   73: astore #4
    //   75: aload #4
    //   77: ifnonnull -> 102
    //   80: aload_0
    //   81: getfield bF : Landroid/app/AlarmManager;
    //   84: iconst_0
    //   85: invokestatic currentTimeMillis : ()J
    //   88: getstatic com/baidu/location/c.aO : J
    //   91: ladd
    //   92: aload_0
    //   93: getfield bG : Landroid/app/PendingIntent;
    //   96: invokevirtual set : (IJLandroid/app/PendingIntent;)V
    //   99: goto -> 7
    //   102: invokestatic bC : ()Lcom/baidu/location/ao;
    //   105: invokevirtual bH : ()Lcom/baidu/location/ao$b;
    //   108: astore #5
    //   110: iconst_0
    //   111: istore #6
    //   113: aload_0
    //   114: getfield b3 : J
    //   117: lconst_0
    //   118: lcmp
    //   119: ifne -> 139
    //   122: iconst_1
    //   123: istore #6
    //   125: aload_0
    //   126: getfield bV : Ljava/util/ArrayList;
    //   129: invokevirtual clear : ()V
    //   132: aload_0
    //   133: getfield bS : Ljava/util/ArrayList;
    //   136: invokevirtual clear : ()V
    //   139: iconst_0
    //   140: istore #7
    //   142: iload #7
    //   144: istore #8
    //   146: iload #6
    //   148: ifne -> 272
    //   151: aload_0
    //   152: getfield bS : Ljava/util/ArrayList;
    //   155: invokevirtual size : ()I
    //   158: istore #9
    //   160: iload #7
    //   162: istore #8
    //   164: iload #9
    //   166: ifle -> 272
    //   169: iload #7
    //   171: istore #8
    //   173: aload #4
    //   175: aload_0
    //   176: getfield bS : Ljava/util/ArrayList;
    //   179: iload #9
    //   181: iconst_1
    //   182: isub
    //   183: invokevirtual get : (I)Ljava/lang/Object;
    //   186: checkcast com/baidu/location/r$a
    //   189: invokevirtual a : (Lcom/baidu/location/r$a;)Z
    //   192: ifeq -> 272
    //   195: iload #7
    //   197: istore #8
    //   199: aload_0
    //   200: getfield bV : Ljava/util/ArrayList;
    //   203: invokevirtual size : ()I
    //   206: iload #9
    //   208: if_icmplt -> 272
    //   211: aload_0
    //   212: getfield bV : Ljava/util/ArrayList;
    //   215: iload #9
    //   217: iconst_1
    //   218: isub
    //   219: invokevirtual get : (I)Ljava/lang/Object;
    //   222: checkcast com/baidu/location/ao$b
    //   225: astore #10
    //   227: iload #7
    //   229: istore #8
    //   231: aload_0
    //   232: aload #5
    //   234: aload #10
    //   236: invokestatic if : (Lcom/baidu/location/ao$b;Lcom/baidu/location/ao$b;)D
    //   239: new com/baidu/location/j$b
    //   242: dup
    //   243: aload_0
    //   244: aload #10
    //   246: invokespecial <init> : (Lcom/baidu/location/j;Lcom/baidu/location/ao$b;)V
    //   249: new com/baidu/location/j$b
    //   252: dup
    //   253: aload_0
    //   254: aload #5
    //   256: invokespecial <init> : (Lcom/baidu/location/j;Lcom/baidu/location/ao$b;)V
    //   259: invokevirtual a : (Lcom/baidu/location/j$b;)D
    //   262: invokevirtual if : (DD)Z
    //   265: ifne -> 272
    //   268: iconst_1
    //   269: ineg
    //   270: istore #8
    //   272: iconst_0
    //   273: istore #7
    //   275: iload #8
    //   277: ifge -> 283
    //   280: iconst_1
    //   281: istore #7
    //   283: iload #7
    //   285: ifne -> 352
    //   288: invokestatic currentTimeMillis : ()J
    //   291: aload_0
    //   292: getfield bN : J
    //   295: lsub
    //   296: ldc2_w 86400000
    //   299: lcmp
    //   300: ifgt -> 316
    //   303: invokestatic currentTimeMillis : ()J
    //   306: aload_0
    //   307: getfield bN : J
    //   310: lsub
    //   311: lconst_0
    //   312: lcmp
    //   313: ifge -> 762
    //   316: aload_0
    //   317: iconst_0
    //   318: putfield bZ : I
    //   321: aload_0
    //   322: iconst_1
    //   323: invokespecial if : (Z)V
    //   326: aload_0
    //   327: getfield bZ : I
    //   330: getstatic com/baidu/location/c.a3 : I
    //   333: if_icmple -> 352
    //   336: aload_0
    //   337: aload_0
    //   338: getfield bN : J
    //   341: ldc2_w 86400000
    //   344: ladd
    //   345: invokestatic currentTimeMillis : ()J
    //   348: lsub
    //   349: putfield bL : J
    //   352: aload_0
    //   353: getfield bL : J
    //   356: ldc2_w 900000
    //   359: lcmp
    //   360: ifle -> 780
    //   363: aload_0
    //   364: aload_0
    //   365: getfield bL : J
    //   368: putfield bP : J
    //   371: aload_0
    //   372: getfield bF : Landroid/app/AlarmManager;
    //   375: iconst_0
    //   376: invokestatic currentTimeMillis : ()J
    //   379: aload_0
    //   380: getfield bP : J
    //   383: ladd
    //   384: aload_0
    //   385: getfield bG : Landroid/app/PendingIntent;
    //   388: invokevirtual set : (IJLandroid/app/PendingIntent;)V
    //   391: aload_0
    //   392: lconst_0
    //   393: putfield bL : J
    //   396: aload_0
    //   397: invokestatic currentTimeMillis : ()J
    //   400: putfield b3 : J
    //   403: iload #7
    //   405: ifne -> 7
    //   408: new java/lang/StringBuffer
    //   411: dup
    //   412: sipush #200
    //   415: invokespecial <init> : (I)V
    //   418: astore #11
    //   420: iload #6
    //   422: ifeq -> 434
    //   425: aload #11
    //   427: ldc_w 's'
    //   430: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   433: pop
    //   434: aload #11
    //   436: ldc_w 'v'
    //   439: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   442: pop
    //   443: aload #11
    //   445: iconst_3
    //   446: invokevirtual append : (I)Ljava/lang/StringBuffer;
    //   449: pop
    //   450: invokestatic currentTimeMillis : ()J
    //   453: bipush #15
    //   455: lshr
    //   456: l2i
    //   457: istore #12
    //   459: aload #11
    //   461: ldc_w 't'
    //   464: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   467: pop
    //   468: aload #11
    //   470: iload #12
    //   472: invokevirtual append : (I)Ljava/lang/StringBuffer;
    //   475: pop
    //   476: aload #4
    //   478: invokevirtual for : ()Z
    //   481: ifeq -> 555
    //   484: aload #4
    //   486: getfield do : I
    //   489: sipush #460
    //   492: if_icmpne -> 949
    //   495: aload #11
    //   497: ldc_w 'x,'
    //   500: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   503: pop
    //   504: aload #11
    //   506: aload #4
    //   508: getfield if : I
    //   511: invokevirtual append : (I)Ljava/lang/StringBuffer;
    //   514: pop
    //   515: aload #11
    //   517: ldc_w ','
    //   520: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   523: pop
    //   524: aload #11
    //   526: aload #4
    //   528: getfield for : I
    //   531: invokevirtual append : (I)Ljava/lang/StringBuffer;
    //   534: pop
    //   535: aload #11
    //   537: ldc_w ','
    //   540: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   543: pop
    //   544: aload #11
    //   546: aload #4
    //   548: getfield try : I
    //   551: invokevirtual append : (I)Ljava/lang/StringBuffer;
    //   554: pop
    //   555: invokestatic bC : ()Lcom/baidu/location/ao;
    //   558: invokevirtual bK : ()Ljava/lang/String;
    //   561: astore #13
    //   563: iconst_0
    //   564: istore #6
    //   566: iconst_0
    //   567: istore #8
    //   569: aconst_null
    //   570: astore #10
    //   572: aload #5
    //   574: ifnull -> 1160
    //   577: aload #5
    //   579: getfield for : Ljava/util/List;
    //   582: ifnull -> 1160
    //   585: iconst_0
    //   586: istore #9
    //   588: iload #9
    //   590: aload #5
    //   592: getfield for : Ljava/util/List;
    //   595: invokeinterface size : ()I
    //   600: if_icmpge -> 1460
    //   603: aload #5
    //   605: getfield for : Ljava/util/List;
    //   608: iload #9
    //   610: invokeinterface get : (I)Ljava/lang/Object;
    //   615: checkcast android/net/wifi/ScanResult
    //   618: getfield BSSID : Ljava/lang/String;
    //   621: ldc_w ':'
    //   624: ldc ''
    //   626: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   629: astore #14
    //   631: aload #5
    //   633: getfield for : Ljava/util/List;
    //   636: iload #9
    //   638: invokeinterface get : (I)Ljava/lang/Object;
    //   643: checkcast android/net/wifi/ScanResult
    //   646: getfield level : I
    //   649: istore #15
    //   651: iload #15
    //   653: ifge -> 1457
    //   656: iload #15
    //   658: ineg
    //   659: istore #15
    //   661: iload #6
    //   663: iconst_3
    //   664: if_icmpge -> 1442
    //   667: iload #9
    //   669: iconst_2
    //   670: if_icmplt -> 981
    //   673: iload #8
    //   675: ifne -> 981
    //   678: aload #13
    //   680: ifnull -> 981
    //   683: aload #13
    //   685: aload #14
    //   687: invokevirtual equals : (Ljava/lang/Object;)Z
    //   690: ifne -> 981
    //   693: aload #10
    //   695: ifnonnull -> 1427
    //   698: new java/lang/StringBuilder
    //   701: dup
    //   702: invokespecial <init> : ()V
    //   705: ldc_w ','
    //   708: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   711: aload #14
    //   713: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   716: ldc_w ';'
    //   719: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   722: iload #15
    //   724: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   727: invokevirtual toString : ()Ljava/lang/String;
    //   730: astore #10
    //   732: iload #8
    //   734: istore #7
    //   736: iload #6
    //   738: istore #8
    //   740: iload #7
    //   742: istore #6
    //   744: iinc #9, 1
    //   747: iload #8
    //   749: istore #7
    //   751: iload #6
    //   753: istore #8
    //   755: iload #7
    //   757: istore #6
    //   759: goto -> 588
    //   762: aload_0
    //   763: aload_0
    //   764: getfield bZ : I
    //   767: iconst_1
    //   768: iadd
    //   769: putfield bZ : I
    //   772: aload_0
    //   773: iconst_0
    //   774: invokespecial if : (Z)V
    //   777: goto -> 326
    //   780: iload #8
    //   782: ifge -> 890
    //   785: aload_0
    //   786: aload_0
    //   787: getfield bP : J
    //   790: getstatic com/baidu/location/c.an : J
    //   793: ladd
    //   794: putfield bP : J
    //   797: aload #5
    //   799: ifnull -> 823
    //   802: aload #5
    //   804: getfield for : Ljava/util/List;
    //   807: ifnull -> 823
    //   810: aload #5
    //   812: getfield for : Ljava/util/List;
    //   815: invokeinterface size : ()I
    //   820: ifne -> 869
    //   823: aload_0
    //   824: getfield bP : J
    //   827: getstatic com/baidu/location/c.aI : J
    //   830: lcmp
    //   831: ifle -> 841
    //   834: aload_0
    //   835: getstatic com/baidu/location/c.aI : J
    //   838: putfield bP : J
    //   841: aload_0
    //   842: getfield bF : Landroid/app/AlarmManager;
    //   845: iconst_0
    //   846: invokestatic currentTimeMillis : ()J
    //   849: aload_0
    //   850: getfield bP : J
    //   853: ladd
    //   854: aload_0
    //   855: getfield bG : Landroid/app/PendingIntent;
    //   858: invokevirtual set : (IJLandroid/app/PendingIntent;)V
    //   861: aload_0
    //   862: iconst_1
    //   863: putfield by : Z
    //   866: goto -> 396
    //   869: aload_0
    //   870: getfield bP : J
    //   873: getstatic com/baidu/location/c.aO : J
    //   876: lcmp
    //   877: ifle -> 841
    //   880: aload_0
    //   881: getstatic com/baidu/location/c.aO : J
    //   884: putfield bP : J
    //   887: goto -> 841
    //   890: aload_0
    //   891: getstatic com/baidu/location/c.ac : J
    //   894: putfield bP : J
    //   897: aload_0
    //   898: getfield bF : Landroid/app/AlarmManager;
    //   901: iconst_0
    //   902: invokestatic currentTimeMillis : ()J
    //   905: aload_0
    //   906: getfield bP : J
    //   909: ladd
    //   910: aload_0
    //   911: getfield bG : Landroid/app/PendingIntent;
    //   914: invokevirtual set : (IJLandroid/app/PendingIntent;)V
    //   917: invokestatic currentTimeMillis : ()J
    //   920: aload_0
    //   921: getfield b3 : J
    //   924: lsub
    //   925: ldc2_w 840000
    //   928: lcmp
    //   929: ifle -> 396
    //   932: aload_0
    //   933: getfield bV : Ljava/util/ArrayList;
    //   936: invokevirtual clear : ()V
    //   939: aload_0
    //   940: getfield bS : Ljava/util/ArrayList;
    //   943: invokevirtual clear : ()V
    //   946: goto -> 396
    //   949: aload #11
    //   951: ldc_w 'x'
    //   954: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   957: pop
    //   958: aload #11
    //   960: aload #4
    //   962: getfield do : I
    //   965: invokevirtual append : (I)Ljava/lang/StringBuffer;
    //   968: pop
    //   969: aload #11
    //   971: ldc_w ','
    //   974: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   977: pop
    //   978: goto -> 504
    //   981: iload #9
    //   983: ifne -> 1329
    //   986: aload #11
    //   988: ldc_w 'w'
    //   991: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   994: pop
    //   995: aload #11
    //   997: aload #14
    //   999: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1002: pop
    //   1003: iload #8
    //   1005: istore #7
    //   1007: aload #13
    //   1009: ifnull -> 1098
    //   1012: iload #8
    //   1014: istore #7
    //   1016: aload #13
    //   1018: aload #14
    //   1020: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1023: ifeq -> 1098
    //   1026: aload #5
    //   1028: getfield for : Ljava/util/List;
    //   1031: iload #9
    //   1033: invokeinterface get : (I)Ljava/lang/Object;
    //   1038: checkcast android/net/wifi/ScanResult
    //   1041: getfield capabilities : Ljava/lang/String;
    //   1044: astore #14
    //   1046: aload #14
    //   1048: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   1051: ifne -> 1353
    //   1054: aload #14
    //   1056: getstatic java/util/Locale.CHINA : Ljava/util/Locale;
    //   1059: invokevirtual toUpperCase : (Ljava/util/Locale;)Ljava/lang/String;
    //   1062: astore #14
    //   1064: aload #14
    //   1066: ldc_w 'WEP'
    //   1069: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   1072: ifne -> 1086
    //   1075: aload #14
    //   1077: ldc_w 'WPA'
    //   1080: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   1083: ifeq -> 1341
    //   1086: aload #11
    //   1088: ldc_w 'l'
    //   1091: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1094: pop
    //   1095: iconst_1
    //   1096: istore #7
    //   1098: aload #11
    //   1100: new java/lang/StringBuilder
    //   1103: dup
    //   1104: invokespecial <init> : ()V
    //   1107: ldc_w ';'
    //   1110: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1113: iload #15
    //   1115: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   1118: invokevirtual toString : ()Ljava/lang/String;
    //   1121: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1124: pop
    //   1125: iload #6
    //   1127: iconst_1
    //   1128: iadd
    //   1129: istore #8
    //   1131: iload #7
    //   1133: istore #6
    //   1135: iload #8
    //   1137: iconst_2
    //   1138: if_icmple -> 1424
    //   1141: iload #8
    //   1143: iconst_3
    //   1144: if_icmpge -> 1160
    //   1147: aload #10
    //   1149: ifnull -> 1160
    //   1152: aload #11
    //   1154: aload #10
    //   1156: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1159: pop
    //   1160: aload_0
    //   1161: invokevirtual o : ()Z
    //   1164: ifeq -> 1365
    //   1167: ldc_w 'y2'
    //   1170: astore #10
    //   1172: aload #10
    //   1174: astore #13
    //   1176: invokestatic do : ()Lcom/baidu/location/at;
    //   1179: invokevirtual a : ()Ljava/lang/String;
    //   1182: ifnull -> 1211
    //   1185: new java/lang/StringBuilder
    //   1188: dup
    //   1189: invokespecial <init> : ()V
    //   1192: aload #10
    //   1194: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1197: invokestatic do : ()Lcom/baidu/location/at;
    //   1200: invokevirtual a : ()Ljava/lang/String;
    //   1203: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1206: invokevirtual toString : ()Ljava/lang/String;
    //   1209: astore #13
    //   1211: aload #11
    //   1213: aload #13
    //   1215: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1218: pop
    //   1219: aload_0
    //   1220: getfield by : Z
    //   1223: ifeq -> 1283
    //   1226: lload_1
    //   1227: lconst_0
    //   1228: lcmp
    //   1229: ifle -> 1278
    //   1232: lload_1
    //   1233: ldc2_w 60000
    //   1236: ldiv
    //   1237: lstore_1
    //   1238: aload_0
    //   1239: new java/lang/StringBuilder
    //   1242: dup
    //   1243: invokespecial <init> : ()V
    //   1246: ldc_w 'r'
    //   1249: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1252: lload_1
    //   1253: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   1256: invokevirtual toString : ()Ljava/lang/String;
    //   1259: putfield bw : Ljava/lang/String;
    //   1262: aload #11
    //   1264: aload_0
    //   1265: getfield bw : Ljava/lang/String;
    //   1268: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1271: pop
    //   1272: aload_0
    //   1273: ldc ''
    //   1275: putfield bw : Ljava/lang/String;
    //   1278: aload_0
    //   1279: iconst_0
    //   1280: putfield by : Z
    //   1283: invokestatic currentTimeMillis : ()J
    //   1286: pop2
    //   1287: aload_3
    //   1288: aload #11
    //   1290: invokevirtual toString : ()Ljava/lang/String;
    //   1293: invokestatic for : (Ljava/lang/String;Ljava/lang/String;)V
    //   1296: aload_0
    //   1297: getfield bV : Ljava/util/ArrayList;
    //   1300: aload #5
    //   1302: invokevirtual add : (Ljava/lang/Object;)Z
    //   1305: pop
    //   1306: aload_0
    //   1307: getfield bV : Ljava/util/ArrayList;
    //   1310: invokevirtual size : ()I
    //   1313: iconst_3
    //   1314: if_icmple -> 1391
    //   1317: aload_0
    //   1318: getfield bV : Ljava/util/ArrayList;
    //   1321: iconst_0
    //   1322: invokevirtual remove : (I)Ljava/lang/Object;
    //   1325: pop
    //   1326: goto -> 1306
    //   1329: aload #11
    //   1331: ldc_w ','
    //   1334: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1337: pop
    //   1338: goto -> 995
    //   1341: aload #11
    //   1343: ldc_w 'j'
    //   1346: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1349: pop
    //   1350: goto -> 1095
    //   1353: aload #11
    //   1355: ldc_w 'j'
    //   1358: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1361: pop
    //   1362: goto -> 1095
    //   1365: ldc_w 'y1'
    //   1368: astore #10
    //   1370: invokestatic cx : ()Lcom/baidu/location/aa;
    //   1373: iload #12
    //   1375: invokevirtual goto : (I)V
    //   1378: goto -> 1172
    //   1381: astore #10
    //   1383: ldc_w 'y'
    //   1386: astore #10
    //   1388: goto -> 1172
    //   1391: aload_0
    //   1392: getfield bS : Ljava/util/ArrayList;
    //   1395: aload #4
    //   1397: invokevirtual add : (Ljava/lang/Object;)Z
    //   1400: pop
    //   1401: aload_0
    //   1402: getfield bS : Ljava/util/ArrayList;
    //   1405: invokevirtual size : ()I
    //   1408: iconst_3
    //   1409: if_icmple -> 7
    //   1412: aload_0
    //   1413: getfield bS : Ljava/util/ArrayList;
    //   1416: iconst_0
    //   1417: invokevirtual remove : (I)Ljava/lang/Object;
    //   1420: pop
    //   1421: goto -> 1401
    //   1424: goto -> 744
    //   1427: iload #6
    //   1429: istore #7
    //   1431: iload #8
    //   1433: istore #6
    //   1435: iload #7
    //   1437: istore #8
    //   1439: goto -> 744
    //   1442: iload #8
    //   1444: istore #7
    //   1446: iload #6
    //   1448: istore #8
    //   1450: iload #7
    //   1452: istore #6
    //   1454: goto -> 1135
    //   1457: goto -> 661
    //   1460: iload #6
    //   1462: istore #8
    //   1464: goto -> 1141
    //   1467: lconst_0
    //   1468: lstore_1
    //   1469: goto -> 30
    // Exception table:
    //   from	to	target	type
    //   1160	1167	1381	java/lang/Exception
    //   1370	1378	1381	java/lang/Exception
  }
  
  public class a extends BroadcastReceiver {
    public a(j this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      if (param1Intent.getAction().equals("com.baidu.locTest.LocationServer4.1.5"))
        j.if(this.a).sendEmptyMessage(1); 
    }
  }
  
  class b {
    public static final double do = 0.8D;
    
    public static final double if = 0.7D;
    
    private double for = 1.0D;
    
    private HashMap int = new HashMap<Object, Object>();
    
    public b(j this$0, ao.b param1b) {
      if (param1b.for != null) {
        Iterator<ScanResult> iterator = param1b.for.iterator();
        byte b1 = 0;
        while (iterator.hasNext()) {
          ScanResult scanResult = iterator.next();
          int i = Math.abs(scanResult.level);
          this.int.put(scanResult.BSSID, Integer.valueOf(i));
          this.for += ((100 - i) * (100 - i));
          if (++b1 > 16)
            break; 
        } 
        this.for = Math.sqrt(this.for);
      } 
    }
    
    public double a() {
      return this.for;
    }
    
    double a(b param1b) {
      Iterator<String> iterator = this.int.keySet().iterator();
      double d = 0.0D;
      while (iterator.hasNext()) {
        String str = iterator.next();
        int i = ((Integer)this.int.get(str)).intValue();
        Integer integer = (Integer)param1b.if().get(str);
        if (integer != null)
          d = ((100 - integer.intValue()) * (100 - i)) + d; 
      } 
      return d / this.for * param1b.a();
    }
    
    public HashMap if() {
      return this.int;
    }
  }
  
  class c extends BroadcastReceiver {
    boolean if = false;
    
    public c(j this$0) {
      a(f.getServiceContext());
    }
    
    public void a(Context param1Context) {
      if (!this.if) {
        this.if = true;
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.SCREEN_OFF");
        intentFilter.addAction("android.intent.action.SCREEN_ON");
        param1Context.registerReceiver(this, intentFilter);
      } 
    }
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      String str = param1Intent.getAction();
      if (!str.equals("android.intent.action.SCREEN_ON") && str.equals("android.intent.action.SCREEN_OFF"))
        aa.cx().cv(); 
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */