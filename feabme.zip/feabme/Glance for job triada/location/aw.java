package com.baidu.location;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.telephony.TelephonyManager;
import com.baidu.location.b.a.a;

class aw implements au, l, SensorEventListener {
  public static String iA;
  
  private static aw iB = null;
  
  public static String iq = null;
  
  public static String iu;
  
  public static String iw = null;
  
  int ir = -1;
  
  SensorManager is = null;
  
  int it = -1;
  
  String iv = null;
  
  String ix = null;
  
  private Sensor iy;
  
  String iz = null;
  
  static {
    iA = null;
    iu = null;
  }
  
  private aw() {
    try {
      this.iv = ((TelephonyManager)f.getServiceContext().getSystemService("phone")).getDeviceId();
    } catch (Exception exception) {
      this.iv = "NULL";
    } 
    try {
      this.iz = a.if(f.getServiceContext());
    } catch (Exception exception) {
      this.iz = null;
    } 
    try {
      iq = f.getServiceContext().getPackageName();
    } catch (Exception exception) {
      iq = null;
    } 
  }
  
  public static aw b6() {
    if (iB == null)
      iB = new aw(); 
    return iB;
  }
  
  public String b2() {
    return (iq != null) ? (b3() + "|" + iq) : b3();
  }
  
  public String b3() {
    return (this.iz != null) ? ("v4.15|" + this.iz + "|" + Build.MODEL) : ("v4.15" + this.iv + "|" + Build.MODEL);
  }
  
  public String b4() {
    return "&sdk=4.15" + b7();
  }
  
  public void b5() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic com/baidu/location/f.isServing : Z
    //   5: ifeq -> 75
    //   8: aload_0
    //   9: invokestatic getServiceContext : ()Landroid/content/Context;
    //   12: ldc 'sensor'
    //   14: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   17: checkcast android/hardware/SensorManager
    //   20: putfield is : Landroid/hardware/SensorManager;
    //   23: aload_0
    //   24: getfield is : Landroid/hardware/SensorManager;
    //   27: aload_0
    //   28: aload_0
    //   29: getfield is : Landroid/hardware/SensorManager;
    //   32: iconst_5
    //   33: invokevirtual getDefaultSensor : (I)Landroid/hardware/Sensor;
    //   36: iconst_3
    //   37: invokevirtual registerListener : (Landroid/hardware/SensorEventListener;Landroid/hardware/Sensor;I)Z
    //   40: pop
    //   41: aload_0
    //   42: aload_0
    //   43: getfield is : Landroid/hardware/SensorManager;
    //   46: bipush #8
    //   48: invokevirtual getDefaultSensor : (I)Landroid/hardware/Sensor;
    //   51: putfield iy : Landroid/hardware/Sensor;
    //   54: aload_0
    //   55: getfield iy : Landroid/hardware/Sensor;
    //   58: ifnull -> 75
    //   61: aload_0
    //   62: getfield is : Landroid/hardware/SensorManager;
    //   65: aload_0
    //   66: aload_0
    //   67: getfield iy : Landroid/hardware/Sensor;
    //   70: iconst_3
    //   71: invokevirtual registerListener : (Landroid/hardware/SensorEventListener;Landroid/hardware/Sensor;I)Z
    //   74: pop
    //   75: aload_0
    //   76: monitorexit
    //   77: return
    //   78: astore_1
    //   79: aload_0
    //   80: monitorexit
    //   81: aload_1
    //   82: athrow
    //   83: astore_1
    //   84: goto -> 75
    // Exception table:
    //   from	to	target	type
    //   2	75	83	java/lang/Exception
    //   2	75	78	finally
  }
  
  public String b7() {
    StringBuffer stringBuffer = new StringBuffer(200);
    if (this.iz != null) {
      stringBuffer.append("&cu=");
      stringBuffer.append(this.iz);
    } else {
      stringBuffer.append("&im=");
      stringBuffer.append(this.iv);
    } 
    try {
      stringBuffer.append("&mb=");
      stringBuffer.append(Build.MODEL);
    } catch (Exception exception) {}
    stringBuffer.append("&pack=");
    try {
      stringBuffer.append(iq);
    } catch (Exception exception) {}
    return stringBuffer.toString();
  }
  
  public void b8() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield is : Landroid/hardware/SensorManager;
    //   6: ifnull -> 17
    //   9: aload_0
    //   10: getfield is : Landroid/hardware/SensorManager;
    //   13: aload_0
    //   14: invokevirtual unregisterListener : (Landroid/hardware/SensorEventListener;)V
    //   17: aload_0
    //   18: aconst_null
    //   19: putfield is : Landroid/hardware/SensorManager;
    //   22: aload_0
    //   23: monitorexit
    //   24: return
    //   25: astore_1
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_1
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	25	finally
    //   17	22	25	finally
  }
  
  public String char(boolean paramBoolean) {
    return if(paramBoolean, null);
  }
  
  public String if(boolean paramBoolean, String paramString) {
    int i = -1;
    StringBuffer stringBuffer = new StringBuffer(256);
    stringBuffer.append("&sdk=");
    stringBuffer.append(4.15F);
    if (paramBoolean && c.av.equals("all"))
      stringBuffer.append("&addr=all"); 
    if (paramBoolean)
      if (paramString == null) {
        stringBuffer.append("&coor=gcj02");
      } else {
        stringBuffer.append("&coor=");
        stringBuffer.append(paramString);
      }  
    if (this.iz == null) {
      stringBuffer.append("&im=");
      stringBuffer.append(this.iv);
    } else {
      stringBuffer.append("&cu=");
      stringBuffer.append(this.iz);
    } 
    stringBuffer.append("&lt=1");
    stringBuffer.append("&mb=");
    stringBuffer.append(Build.MODEL);
    if (this.it != -1) {
      stringBuffer.append("&al=");
      if (this.ir == 0) {
        if (this.it != -1)
          i = -this.it; 
        this.it = i;
      } 
      stringBuffer.append(this.it);
    } 
    stringBuffer.append("&resid=");
    stringBuffer.append("12");
    stringBuffer.append("&os=A");
    stringBuffer.append(Build.VERSION.SDK);
    if (paramBoolean) {
      stringBuffer.append("&sv=");
      String str = Build.VERSION.RELEASE;
      paramString = str;
      if (str != null) {
        paramString = str;
        if (str.length() > 6)
          paramString = str.substring(0, 6); 
      } 
      stringBuffer.append(paramString);
    } 
    return stringBuffer.toString();
  }
  
  public void new(String paramString1, String paramString2) {
    iw = paramString1;
    iq = paramString2;
  }
  
  public void onAccuracyChanged(Sensor paramSensor, int paramInt) {}
  
  public void onSensorChanged(SensorEvent paramSensorEvent) {
    int i = paramSensorEvent.sensor.getType();
    if (i == 5) {
      this.it = (int)paramSensorEvent.values[0];
      return;
    } 
    if (i == 8)
      this.ir = (int)paramSensorEvent.values[0]; 
  }
  
  public String r(String paramString) {
    return if(true, paramString);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/aw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */