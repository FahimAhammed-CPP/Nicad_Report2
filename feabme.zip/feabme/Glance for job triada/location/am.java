package com.baidu.location;

interface am {
  void a();
  
  am do();
  
  void if();
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/am.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */