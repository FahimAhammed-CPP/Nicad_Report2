package com.baidu.location;

interface l extends b, z {
  public static final String S = "4.1.5";
  
  public static final int T = 3;
  
  public static final float U = 4.15F;
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */