package com.baidu.location;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.util.zip.GZIPOutputStream;

class aa implements au, SensorEventListener, b {
  private static aa j2;
  
  private boolean j0 = false;
  
  private Handler j1;
  
  private boolean j3 = false;
  
  private int j4 = 0;
  
  private StringBuffer j5 = null;
  
  private SensorManager j6;
  
  private StringBuffer j7 = null;
  
  private Runnable j8 = null;
  
  private final int j9 = 1;
  
  private Runnable jS = null;
  
  private Sensor jT;
  
  private final int jU = 2;
  
  private boolean jV = false;
  
  private boolean jW = false;
  
  private int jX = 0;
  
  private boolean jY = false;
  
  private Sensor jZ;
  
  private aa() {
    try {
      this.j6 = (SensorManager)f.getServiceContext().getSystemService("sensor");
      this.jT = this.j6.getDefaultSensor(1);
      this.jZ = this.j6.getDefaultSensor(2);
    } catch (Exception exception) {}
    this.j1 = new Handler();
  }
  
  private boolean cB() {
    boolean bool = false;
    String str = cC();
    if (str != null) {
      RandomAccessFile randomAccessFile;
      try {
        File file = new File();
        this(str);
        if (!file.exists()) {
          file.createNewFile();
          RandomAccessFile randomAccessFile1 = new RandomAccessFile();
          this(file, "rw");
          if(randomAccessFile1, 0);
          randomAccessFile1.close();
          return true;
        } 
        randomAccessFile = new RandomAccessFile();
        this(file, "rw");
        randomAccessFile.seek(4L);
        long l = randomAccessFile.readLong();
        int i = randomAccessFile.readInt();
        if (randomAccessFile.readInt() == 3321) {
          l = System.currentTimeMillis() - l;
          if (l < 0L || l > 86400000L) {
            randomAccessFile.seek(4L);
            randomAccessFile.writeLong(System.currentTimeMillis());
            randomAccessFile.writeInt(0);
            randomAccessFile.close();
            return true;
          } 
          if (i > 96000) {
            randomAccessFile.close();
            return bool;
          } 
          randomAccessFile.close();
          return true;
        } 
      } catch (Exception exception) {
        return bool;
      } 
      if(randomAccessFile, 0);
      randomAccessFile.close();
      bool = true;
    } 
    return bool;
  }
  
  private String cC() {
    String str1 = null;
    String str2 = void(1);
    if (str2 == null)
      return str1; 
    str2 = str2 + File.separator + "lscts.dat";
    File file = new File(str2);
    if (!file.exists()) {
      try {
        file.createNewFile();
        RandomAccessFile randomAccessFile = new RandomAccessFile();
        this(file, "rw");
        if(randomAccessFile, 0);
        randomAccessFile.close();
        str1 = str2;
      } catch (Exception exception2) {}
      return str1;
    } 
    Exception exception1 = exception2;
  }
  
  private void cn() {
    if (this.j6 != null && this.jZ != null && !this.jV)
      try {
        this.j6.registerListener(this, this.jZ, 2, this.j1);
        this.jV = true;
      } catch (Exception exception) {} 
  }
  
  private void co() {
    if (this.jV)
      try {
        this.j6.unregisterListener(this, this.jZ);
        this.jV = false;
      } catch (Exception exception) {} 
  }
  
  private void cp() {
    if (this.j6 != null && this.jT != null && !this.jW)
      try {
        this.j6.registerListener(this, this.jT, 2, this.j1);
        this.jW = true;
      } catch (Exception exception) {} 
  }
  
  private void cq() {
    if (this.jY || this.j0)
      cp(); 
    if (this.jY)
      cn(); 
  }
  
  private String cs() {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: iconst_1
    //   4: invokespecial void : (I)Ljava/lang/String;
    //   7: astore_2
    //   8: iconst_2
    //   9: anewarray java/lang/String
    //   12: astore_3
    //   13: aload_3
    //   14: iconst_0
    //   15: ldc 'lmibaca.dat'
    //   17: aastore
    //   18: aload_3
    //   19: iconst_1
    //   20: ldc 'lmibacb.dat'
    //   22: aastore
    //   23: aload_3
    //   24: arraylength
    //   25: istore #4
    //   27: iload_1
    //   28: iload #4
    //   30: if_icmpge -> 112
    //   33: aload_3
    //   34: iload_1
    //   35: aaload
    //   36: astore #5
    //   38: new java/io/File
    //   41: dup
    //   42: new java/lang/StringBuilder
    //   45: dup
    //   46: invokespecial <init> : ()V
    //   49: aload_2
    //   50: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   53: getstatic java/io/File.separator : Ljava/lang/String;
    //   56: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   59: aload #5
    //   61: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: invokevirtual toString : ()Ljava/lang/String;
    //   67: invokespecial <init> : (Ljava/lang/String;)V
    //   70: invokevirtual exists : ()Z
    //   73: ifne -> 106
    //   76: new java/lang/StringBuilder
    //   79: dup
    //   80: invokespecial <init> : ()V
    //   83: aload_2
    //   84: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   87: getstatic java/io/File.separator : Ljava/lang/String;
    //   90: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   93: aload #5
    //   95: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   98: invokevirtual toString : ()Ljava/lang/String;
    //   101: astore #5
    //   103: aload #5
    //   105: areturn
    //   106: iinc #1, 1
    //   109: goto -> 27
    //   112: aconst_null
    //   113: astore #5
    //   115: goto -> 103
  }
  
  private void ct() {
    if (this.jW)
      try {
        this.j6.unregisterListener(this, this.jT);
        this.jW = false;
      } catch (Exception exception) {} 
  }
  
  private void cu() {
    this.jY = true;
    this.j5 = new StringBuffer(8192);
    cq();
    this.j8 = new aa$3(this);
    this.j1.postDelayed(this.j8, 60000L);
  }
  
  private void cw() {
    if (!this.jY) {
      if (this.j0) {
        co();
        return;
      } 
      co();
      ct();
      this.j4 = 0;
      this.jX = 0;
    } 
  }
  
  public static aa cx() {
    if (j2 == null)
      j2 = new aa(); 
    return j2;
  }
  
  private String cy() {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: iconst_2
    //   4: invokespecial void : (I)Ljava/lang/String;
    //   7: astore_2
    //   8: iconst_4
    //   9: anewarray java/lang/String
    //   12: astore_3
    //   13: aload_3
    //   14: iconst_0
    //   15: ldc 'lbaca.dat'
    //   17: aastore
    //   18: aload_3
    //   19: iconst_1
    //   20: ldc 'lbacb.dat'
    //   22: aastore
    //   23: aload_3
    //   24: iconst_2
    //   25: ldc 'lbacc.dat'
    //   27: aastore
    //   28: aload_3
    //   29: iconst_3
    //   30: ldc 'lbacd.dat'
    //   32: aastore
    //   33: aload_3
    //   34: arraylength
    //   35: istore #4
    //   37: iload_1
    //   38: iload #4
    //   40: if_icmpge -> 122
    //   43: aload_3
    //   44: iload_1
    //   45: aaload
    //   46: astore #5
    //   48: new java/io/File
    //   51: dup
    //   52: new java/lang/StringBuilder
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: aload_2
    //   60: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   63: getstatic java/io/File.separator : Ljava/lang/String;
    //   66: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   69: aload #5
    //   71: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   74: invokevirtual toString : ()Ljava/lang/String;
    //   77: invokespecial <init> : (Ljava/lang/String;)V
    //   80: invokevirtual exists : ()Z
    //   83: ifne -> 116
    //   86: new java/lang/StringBuilder
    //   89: dup
    //   90: invokespecial <init> : ()V
    //   93: aload_2
    //   94: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   97: getstatic java/io/File.separator : Ljava/lang/String;
    //   100: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   103: aload #5
    //   105: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   108: invokevirtual toString : ()Ljava/lang/String;
    //   111: astore #5
    //   113: aload #5
    //   115: areturn
    //   116: iinc #1, 1
    //   119: goto -> 37
    //   122: aconst_null
    //   123: astore #5
    //   125: goto -> 113
  }
  
  private void d(int paramInt) {
    String str = cC();
    if (str != null)
      try {
        File file = new File();
        this(str);
        if (file.exists()) {
          RandomAccessFile randomAccessFile = new RandomAccessFile();
          this(file, "rw");
          randomAccessFile.seek(0L);
          int i = randomAccessFile.readInt();
          randomAccessFile.readLong();
          int j = randomAccessFile.readInt();
          if (randomAccessFile.readInt() == 3321 && i == 3321) {
            randomAccessFile.seek(12L);
            randomAccessFile.writeInt(j + paramInt);
          } else {
            if(randomAccessFile, 48000 + paramInt);
          } 
          randomAccessFile.close();
        } 
      } catch (Exception exception) {} 
  }
  
  private void do(StringBuffer paramStringBuffer) {
    if (this.jY && this.j5 != null)
      if(this.j5, paramStringBuffer, e(2)); 
  }
  
  private String e(int paramInt) {
    String str1 = null;
    String str2 = void(paramInt);
    if (str2 != null) {
      if (paramInt == 2)
        return str2 + File.separator + "lbacz.dat"; 
      if (paramInt == 1)
        str1 = str2 + File.separator + "lmibacz.dat"; 
    } 
    return str1;
  }
  
  private void if(RandomAccessFile paramRandomAccessFile, int paramInt) {
    try {
      paramRandomAccessFile.seek(0L);
      paramRandomAccessFile.writeInt(3321);
      paramRandomAccessFile.writeLong(System.currentTimeMillis());
      paramRandomAccessFile.writeInt(paramInt);
      paramRandomAccessFile.writeInt(3321);
    } catch (Exception exception) {}
  }
  
  private void if(StringBuffer paramStringBuffer) {
    if (this.j0 && this.j7 != null)
      if(this.j7, paramStringBuffer, e(1)); 
  }
  
  private void if(StringBuffer paramStringBuffer, File paramFile) {
    boolean bool = true;
    if (paramFile.exists())
      try {
        FileOutputStream fileOutputStream = new FileOutputStream();
        this(paramFile, true);
        GZIPOutputStream gZIPOutputStream = new GZIPOutputStream();
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream();
        this(fileOutputStream);
        this(bufferedOutputStream);
        byte b1 = 0;
        while (true) {
          if (b1 < 3) {
            try {
              gZIPOutputStream.write(paramStringBuffer.toString().getBytes());
            } catch (Exception exception) {
              bool = false;
            } 
            if (!bool) {
              b1++;
              continue;
            } 
          } 
          gZIPOutputStream.close();
          return;
        } 
      } catch (Exception exception) {} 
  }
  
  private void if(StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2, String paramString) {
    if (paramStringBuffer1.length() + paramStringBuffer2.length() < 8190) {
      paramStringBuffer1.append(paramStringBuffer2);
      return;
    } 
    File file = new File(paramString);
    d(paramStringBuffer1.length());
    if(paramStringBuffer1, file);
    this.j3 = true;
    paramStringBuffer1.delete(0, paramStringBuffer1.length());
    paramStringBuffer1.append(paramStringBuffer2);
  }
  
  private boolean if(File paramFile) {
    boolean bool;
    try {
      paramFile.createNewFile();
      StringBuffer stringBuffer = new StringBuffer();
      this(256);
      stringBuffer.append("C");
      stringBuffer.append("\t");
      stringBuffer.append(Jni.h(aw.b6().b4()));
      stringBuffer.append("\n");
      if(stringBuffer, paramFile);
      bool = true;
    } catch (Exception exception) {
      bool = false;
    } 
    return bool;
  }
  
  private boolean if(File paramFile, int paramInt) {
    String str = null;
    if (paramInt == 2) {
      str = cy();
    } else if (paramInt == 1) {
      str = cs();
    } 
    return (str == null) ? false : paramFile.renameTo(new File(str));
  }
  
  private boolean long(int paramInt) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_0
    //   3: iload_1
    //   4: invokespecial e : (I)Ljava/lang/String;
    //   7: astore_3
    //   8: aload_3
    //   9: ifnonnull -> 18
    //   12: iload_2
    //   13: istore #4
    //   15: iload #4
    //   17: ireturn
    //   18: iload_1
    //   19: iconst_2
    //   20: if_icmpne -> 101
    //   23: new java/io/File
    //   26: dup
    //   27: aload_3
    //   28: invokespecial <init> : (Ljava/lang/String;)V
    //   31: astore #5
    //   33: aload #5
    //   35: invokevirtual exists : ()Z
    //   38: ifeq -> 66
    //   41: aload #5
    //   43: invokevirtual length : ()J
    //   46: ldc2_w 30720
    //   49: lcmp
    //   50: ifle -> 95
    //   53: iload_2
    //   54: istore #4
    //   56: aload_0
    //   57: aload #5
    //   59: iload_1
    //   60: invokespecial if : (Ljava/io/File;I)Z
    //   63: ifeq -> 15
    //   66: new java/io/File
    //   69: dup
    //   70: aload_3
    //   71: invokespecial <init> : (Ljava/lang/String;)V
    //   74: astore_3
    //   75: iload_2
    //   76: istore #4
    //   78: aload_3
    //   79: invokevirtual exists : ()Z
    //   82: ifne -> 15
    //   85: aload_0
    //   86: aload_3
    //   87: invokespecial if : (Ljava/io/File;)Z
    //   90: istore #4
    //   92: goto -> 15
    //   95: iconst_1
    //   96: istore #4
    //   98: goto -> 15
    //   101: iload_2
    //   102: istore #4
    //   104: iload_1
    //   105: iconst_1
    //   106: if_icmpne -> 15
    //   109: iload_2
    //   110: istore #4
    //   112: aload_0
    //   113: invokespecial cB : ()Z
    //   116: ifeq -> 15
    //   119: new java/io/File
    //   122: dup
    //   123: aload_3
    //   124: invokespecial <init> : (Ljava/lang/String;)V
    //   127: astore #5
    //   129: aload #5
    //   131: invokevirtual exists : ()Z
    //   134: ifeq -> 162
    //   137: aload #5
    //   139: invokevirtual length : ()J
    //   142: ldc2_w 30720
    //   145: lcmp
    //   146: ifle -> 191
    //   149: iload_2
    //   150: istore #4
    //   152: aload_0
    //   153: aload #5
    //   155: iload_1
    //   156: invokespecial if : (Ljava/io/File;I)Z
    //   159: ifeq -> 15
    //   162: new java/io/File
    //   165: dup
    //   166: aload_3
    //   167: invokespecial <init> : (Ljava/lang/String;)V
    //   170: astore_3
    //   171: iload_2
    //   172: istore #4
    //   174: aload_3
    //   175: invokevirtual exists : ()Z
    //   178: ifne -> 15
    //   181: aload_0
    //   182: aload_3
    //   183: invokespecial if : (Ljava/io/File;)Z
    //   186: istore #4
    //   188: goto -> 15
    //   191: iconst_1
    //   192: istore #4
    //   194: goto -> 15
    //   197: astore_3
    //   198: iload_2
    //   199: istore #4
    //   201: goto -> 15
    //   204: astore_3
    //   205: iload_2
    //   206: istore #4
    //   208: goto -> 15
    // Exception table:
    //   from	to	target	type
    //   85	92	197	java/lang/Exception
    //   181	188	204	java/lang/Exception
  }
  
  private String void(int paramInt) {
    String str2;
    String str1 = c.char();
    if (str1 == null)
      return null; 
    if (paramInt == 1) {
      str2 = str1 + File.separator + "llmis1";
    } else if (paramInt == 2) {
      str2 = str1 + File.separator + "llmis2";
    } else {
      return null;
    } 
    File file = new File(str2);
    str1 = str2;
    if (!file.exists())
      try {
        boolean bool = file.mkdirs();
        str1 = str2;
        if (!bool)
          str1 = null; 
      } catch (Exception exception) {
        exception = null;
      }  
    return (String)exception;
  }
  
  public void cA() {
    this.jY = false;
    if (this.j5 != null && this.j5.length() > 3800) {
      File file = new File(e(2));
      if(this.j5, file);
    } 
    this.j5 = null;
    cw();
  }
  
  public String cr() {
    String str3;
    String str1 = null;
    byte b1 = 0;
    String str2 = void(1);
    String[] arrayOfString = new String[3];
    arrayOfString[0] = "lmibaca.dat";
    arrayOfString[1] = "lmibacb.dat";
    arrayOfString[2] = "lmibacz.dat";
    try {
      int i = arrayOfString.length;
      while (true) {
        str3 = str1;
        if (b1 < i) {
          str3 = arrayOfString[b1];
          File file = new File();
          StringBuilder stringBuilder = new StringBuilder();
          this();
          this(stringBuilder.append(str2).append(File.separator).append(str3).toString());
          if (file.exists())
            if (file.length() > 92160L) {
              file.delete();
            } else if (file.length() >= 4096L) {
              if (str3.equals("lmibacz.dat") && this.j0) {
                str3 = str1;
                break;
              } 
              StringBuilder stringBuilder1 = new StringBuilder();
              this();
              str3 = stringBuilder1.append(str2).append(File.separator).append(str3).toString();
              break;
            }  
          b1++;
          continue;
        } 
        break;
      } 
    } catch (Exception exception) {
      str3 = str1;
    } 
    return str3;
  }
  
  public void cv() {
    this.j1.post(new aa$2(this));
  }
  
  public void cz() {
    this.j0 = false;
    if ((this.j7 != null && this.j7.length() > 3800) || this.j3) {
      File file = new File(e(1));
      d(this.j7.length());
      if(this.j7, file);
      this.j3 = false;
    } 
    this.j7 = null;
    cw();
  }
  
  public void goto(int paramInt) {
    if (!this.j0 && long(1)) {
      StringBuffer stringBuffer = new StringBuffer(128);
      this.j0 = true;
      this.j7 = new StringBuffer(8192);
      stringBuffer.append("T1");
      stringBuffer.append("\t");
      stringBuffer.append(paramInt);
      stringBuffer.append("\n");
      if(stringBuffer);
      cq();
      this.jS = new aa$1(this);
      this.j1.postDelayed(this.jS, 8000L);
    } 
  }
  
  public void onAccuracyChanged(Sensor paramSensor, int paramInt) {}
  
  public void onSensorChanged(SensorEvent paramSensorEvent) {
    int i = paramSensorEvent.sensor.getType();
    StringBuffer stringBuffer = new StringBuffer(256);
    if (i == 1) {
      this.j4++;
      stringBuffer.append("A");
      stringBuffer.append("\t");
      stringBuffer.append(paramSensorEvent.values[0]);
      stringBuffer.append("\t");
      stringBuffer.append(paramSensorEvent.values[1]);
      stringBuffer.append("\t");
      stringBuffer.append(paramSensorEvent.values[2]);
      if (this.j4 == 1) {
        stringBuffer.append("\t");
        stringBuffer.append(paramSensorEvent.timestamp);
      } 
      if (this.j4 >= 14)
        this.j4 = 0; 
      stringBuffer.append("\n");
      do(stringBuffer);
      if(stringBuffer);
    } 
    if (i == 2) {
      this.jX++;
      stringBuffer.append("M");
      stringBuffer.append("\t");
      stringBuffer.append(paramSensorEvent.values[0]);
      stringBuffer.append("\t");
      stringBuffer.append(paramSensorEvent.values[1]);
      stringBuffer.append("\t");
      stringBuffer.append(paramSensorEvent.values[2]);
      if (this.jX == 1) {
        stringBuffer.append("\t");
        stringBuffer.append(paramSensorEvent.timestamp);
      } 
      if (this.jX > 13)
        this.jX = 0; 
      stringBuffer.append("\n");
      do(stringBuffer);
    } 
  }
  
  class a {
    StringBuffer do = null;
    
    public boolean if = false;
    
    a(aa this$0) {}
    
    public void a() {}
    
    public void do() {}
    
    public void if() {}
  }
  
  class b {
    public b(aa this$0) {}
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/aa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */