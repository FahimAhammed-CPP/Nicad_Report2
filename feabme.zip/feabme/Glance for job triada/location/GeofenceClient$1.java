package com.baidu.location;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.Messenger;

class GeofenceClient$1 implements ServiceConnection {
  GeofenceClient$1(GeofenceClient paramGeofenceClient) {}
  
  public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder) {
    GeofenceClient.if(this.a, new Messenger(paramIBinder));
    if (GeofenceClient.if(this.a) != null) {
      GeofenceClient.if(this.a, true);
      this.a.startGeofenceScann();
    } 
  }
  
  public void onServiceDisconnected(ComponentName paramComponentName) {
    GeofenceClient.if(this.a, (Messenger)null);
    GeofenceClient.if(this.a, false);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/GeofenceClient$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */