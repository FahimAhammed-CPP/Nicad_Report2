package com.baidu.location;

import android.text.TextUtils;

public class an implements BDGeofence {
  private static final String byte = "Administrative";
  
  private static final int case = 2;
  
  private static final int d = 100;
  
  private static final int e = 2;
  
  private static final int else = 1;
  
  private static final String for = "Circle";
  
  private static final int h = 3;
  
  public static final int int = 1;
  
  private static final long void = 2592000L;
  
  private final int a;
  
  private float b;
  
  private final int c;
  
  private boolean char;
  
  private final String do;
  
  private boolean f;
  
  private long g;
  
  private final double goto;
  
  private boolean if;
  
  private final long long;
  
  private final String new;
  
  private final double try;
  
  public an(int paramInt1, String paramString1, double paramDouble1, double paramDouble2, int paramInt2, long paramLong, String paramString2) {
    if(paramInt2);
    if(paramString1);
    a(paramDouble1, paramDouble2);
    a(paramString2);
    if(paramLong);
    this.c = paramInt1;
    this.do = paramString1;
    this.goto = paramDouble1;
    this.try = paramDouble2;
    this.a = paramInt2;
    this.long = paramLong;
    this.new = paramString2;
  }
  
  public an(String paramString1, double paramDouble1, double paramDouble2, int paramInt, long paramLong, String paramString2) {
    this(1, paramString1, paramDouble2, paramDouble1, paramInt, paramLong, paramString2);
  }
  
  private static String a(int paramInt) {
    switch (paramInt) {
      default:
        return null;
      case 1:
        return "Circle";
      case 2:
        break;
    } 
    return "Administrative";
  }
  
  private static void a(double paramDouble1, double paramDouble2) {}
  
  private static void a(String paramString) {
    if (!paramString.equals("bd09") && !paramString.equals("bd09ll") && !paramString.equals("gcj02"))
      throw new IllegalArgumentException("invalid coord type: " + paramString); 
  }
  
  private static void if(int paramInt) {
    if (paramInt != 1 && paramInt != 2 && paramInt != 3)
      throw new IllegalArgumentException("invalid radius type: " + paramInt); 
  }
  
  private static void if(long paramLong) {
    if (paramLong / 1000.0D > 2592000.0D)
      throw new IllegalArgumentException("invalid druationMillis :" + paramLong); 
  }
  
  private static void if(String paramString) {
    if (TextUtils.isEmpty(paramString) || paramString.length() > 100)
      throw new IllegalArgumentException("Geofence name is null or too long: " + paramString); 
  }
  
  public double a() {
    return this.try;
  }
  
  public void a(float paramFloat) {
    this.b = paramFloat;
  }
  
  public void a(long paramLong) {
    this.g = paramLong;
  }
  
  public void a(boolean paramBoolean) {
    this.if = paramBoolean;
  }
  
  public double byte() {
    return this.goto;
  }
  
  public int case() {
    return this.char ? 1 : (this.if ? 2 : 3);
  }
  
  public long char() {
    return this.g;
  }
  
  public float do() {
    return this.b;
  }
  
  public void do(boolean paramBoolean) {
    this.f = paramBoolean;
  }
  
  public long else() {
    return this.long;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = true;
    if (this != paramObject) {
      if (paramObject == null)
        return false; 
      if (!(paramObject instanceof an))
        return false; 
      paramObject = paramObject;
      if (this.a != ((an)paramObject).a)
        return false; 
      if (this.goto != ((an)paramObject).goto)
        return false; 
      if (this.try != ((an)paramObject).try)
        return false; 
      if (this.c != ((an)paramObject).c)
        return false; 
      if (this.new != ((an)paramObject).new)
        bool = false; 
    } 
    return bool;
  }
  
  public boolean for() {
    return this.char;
  }
  
  public String getGeofenceId() {
    return this.do;
  }
  
  public void if(boolean paramBoolean) {
    this.char = paramBoolean;
  }
  
  public boolean if() {
    return this.if;
  }
  
  public String int() {
    return this.new;
  }
  
  public int new() {
    return this.a;
  }
  
  public String toString() {
    return String.format("Geofence[Type:%s, Name:%s, latitude:%.6f, longitude:%.6f, radius:%.0f, expriation:%d, coordType:%s, fenceType:%d]", new Object[] { a(this.c), this.do, Double.valueOf(this.goto), Double.valueOf(this.try), Float.valueOf(this.b), Long.valueOf(this.long), this.new, Integer.valueOf(case()) });
  }
  
  public boolean try() {
    return this.f;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/an.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */