package com.baidu.location.a;

public class b {
  public static final String a = "geofence_detail";
  
  public static final String do = "ap_index";
  
  public static final String for = "ap";
  
  public static final String if = "_id";
  
  public static final String int = "ap_backup";
  
  public static final String new = "geofence_id";
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */