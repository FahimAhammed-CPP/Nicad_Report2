package com.baidu.location;

import android.text.TextUtils;

public interface BDGeofence {
  public static final String COORD_TYPE_BD09 = "bd09";
  
  public static final String COORD_TYPE_BD09LL = "bd09ll";
  
  public static final String COORD_TYPE_GCJ = "gcj02";
  
  public static final int GEOFENCE_TRANSITION_ENTER = 1;
  
  public static final int RADIUS_TYPE_LARGE = 3;
  
  public static final int RADIUS_TYPE_MIDDELE = 2;
  
  public static final int RADIUS_TYPE_SMALL = 1;
  
  String getGeofenceId();
  
  public static final class Builder {
    private int a;
    
    private String do = null;
    
    private double for;
    
    private long if = Long.MIN_VALUE;
    
    private String int;
    
    private boolean new = false;
    
    private double try;
    
    public BDGeofence build() {
      if (TextUtils.isEmpty(this.do))
        throw new IllegalArgumentException("BDGeofence name not set."); 
      if (!this.new)
        throw new IllegalArgumentException("BDGeofence region not set."); 
      if (this.if == Long.MIN_VALUE)
        throw new IllegalArgumentException("BDGeofence Expiration not set."); 
      if (TextUtils.isEmpty(this.int))
        throw new IllegalArgumentException("BDGeofence CoordType not set."); 
      return new an(this.do, this.try, this.for, this.a, this.if, this.int);
    }
    
    public Builder setCircularRegion(double param1Double1, double param1Double2, int param1Int) {
      this.new = true;
      this.try = param1Double1;
      this.for = param1Double2;
      this.a = param1Int;
      return this;
    }
    
    public Builder setCoordType(String param1String) {
      this.int = param1String;
      return this;
    }
    
    public Builder setExpirationDruation(long param1Long) {
      if (param1Long < 0L) {
        this.if = -1L;
        return this;
      } 
      this.if = param1Long;
      return this;
    }
    
    public Builder setGeofenceId(String param1String) {
      this.do = param1String;
      return this;
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/BDGeofence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */