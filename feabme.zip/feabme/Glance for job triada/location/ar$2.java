package com.baidu.location;

class ar$2 implements Runnable {
  ar$2(ar paramar) {}
  
  public void run() {
    ar.int(this.a);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/ar$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */