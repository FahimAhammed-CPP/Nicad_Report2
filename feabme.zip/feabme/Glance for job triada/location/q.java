package com.baidu.location;

import android.content.Context;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Proxy;
import android.net.Uri;
import java.util.List;
import org.apache.http.HttpEntity;

abstract class q implements au, l {
  private static int cQ = 4;
  
  private static String cT = "10.0.0.172";
  
  protected static int cU;
  
  private static int cV = 80;
  
  public String cN = null;
  
  public HttpEntity cO = null;
  
  public List cP = null;
  
  private boolean cR = false;
  
  public String cS = null;
  
  public int cW = 3;
  
  static {
    cU = 0;
  }
  
  private void H() {
    cQ = L();
  }
  
  private int L() {
    byte b;
    Context context = f.getServiceContext();
    try {
      ConnectivityManager connectivityManager = (ConnectivityManager)context.getSystemService("connectivity");
      if (connectivityManager == null)
        return 4; 
      NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
      if (networkInfo != null) {
        byte b1;
        try {
          if (!networkInfo.isAvailable())
            byte b2 = 4; 
          if (networkInfo.getType() == 1)
            return 3; 
          Uri uri = Uri.parse("content://telephony/carriers/preferapn");
          Cursor cursor = context.getContentResolver().query(uri, null, null, null, null);
          if (cursor != null && cursor.moveToFirst()) {
            String str = cursor.getString(cursor.getColumnIndex("apn"));
            if (str != null && str.toLowerCase().contains("ctwap")) {
              str = Proxy.getDefaultHost();
              if (str == null || str.equals("") || str.equals("null"))
                str = "10.0.0.200"; 
              cT = str;
              cV = 80;
              if (cursor != null)
                cursor.close(); 
              return 1;
            } 
            if (str != null && str.toLowerCase().contains("wap")) {
              str = Proxy.getDefaultHost();
              if (str == null || str.equals("") || str.equals("null"))
                str = "10.0.0.172"; 
              cT = str;
              cV = 80;
              if (cursor != null)
                cursor.close(); 
              return 1;
            } 
          } 
          if (cursor != null)
            cursor.close(); 
          b1 = 2;
        } catch (SecurityException securityException) {
          NetworkInfo networkInfo1 = networkInfo;
        } 
        return b1;
      } 
      b = 4;
    } catch (SecurityException securityException) {
      securityException = null;
      try {
        b = if(context, (NetworkInfo)securityException);
      } catch (Exception exception) {
        b = 4;
      } 
    } catch (Exception exception) {
      b = 4;
    } 
    return b;
  }
  
  private static int if(Context paramContext, NetworkInfo paramNetworkInfo) {
    // Byte code:
    //   0: iconst_2
    //   1: istore_2
    //   2: aload_1
    //   3: ifnull -> 186
    //   6: aload_1
    //   7: invokevirtual getExtraInfo : ()Ljava/lang/String;
    //   10: ifnull -> 186
    //   13: aload_1
    //   14: invokevirtual getExtraInfo : ()Ljava/lang/String;
    //   17: invokevirtual toLowerCase : ()Ljava/lang/String;
    //   20: astore_0
    //   21: aload_0
    //   22: ifnull -> 186
    //   25: aload_0
    //   26: ldc 'cmwap'
    //   28: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   31: ifne -> 52
    //   34: aload_0
    //   35: ldc 'uniwap'
    //   37: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   40: ifne -> 52
    //   43: aload_0
    //   44: ldc '3gwap'
    //   46: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   49: ifeq -> 92
    //   52: invokestatic getDefaultHost : ()Ljava/lang/String;
    //   55: astore_0
    //   56: aload_0
    //   57: ifnull -> 86
    //   60: aload_0
    //   61: ldc ''
    //   63: invokevirtual equals : (Ljava/lang/Object;)Z
    //   66: ifne -> 86
    //   69: aload_0
    //   70: ldc 'null'
    //   72: invokevirtual equals : (Ljava/lang/Object;)Z
    //   75: ifne -> 86
    //   78: aload_0
    //   79: putstatic com/baidu/location/q.cT : Ljava/lang/String;
    //   82: iconst_1
    //   83: istore_3
    //   84: iload_3
    //   85: ireturn
    //   86: ldc '10.0.0.172'
    //   88: astore_0
    //   89: goto -> 78
    //   92: aload_0
    //   93: ldc 'ctwap'
    //   95: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   98: ifeq -> 142
    //   101: invokestatic getDefaultHost : ()Ljava/lang/String;
    //   104: astore_0
    //   105: aload_0
    //   106: ifnull -> 136
    //   109: aload_0
    //   110: ldc ''
    //   112: invokevirtual equals : (Ljava/lang/Object;)Z
    //   115: ifne -> 136
    //   118: aload_0
    //   119: ldc 'null'
    //   121: invokevirtual equals : (Ljava/lang/Object;)Z
    //   124: ifne -> 136
    //   127: aload_0
    //   128: putstatic com/baidu/location/q.cT : Ljava/lang/String;
    //   131: iconst_1
    //   132: istore_3
    //   133: goto -> 84
    //   136: ldc '10.0.0.200'
    //   138: astore_0
    //   139: goto -> 127
    //   142: iload_2
    //   143: istore_3
    //   144: aload_0
    //   145: ldc 'cmnet'
    //   147: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   150: ifne -> 84
    //   153: iload_2
    //   154: istore_3
    //   155: aload_0
    //   156: ldc 'uninet'
    //   158: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   161: ifne -> 84
    //   164: iload_2
    //   165: istore_3
    //   166: aload_0
    //   167: ldc 'ctnet'
    //   169: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   172: ifne -> 84
    //   175: iload_2
    //   176: istore_3
    //   177: aload_0
    //   178: ldc '3gnet'
    //   180: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   183: ifne -> 84
    //   186: invokestatic getDefaultHost : ()Ljava/lang/String;
    //   189: astore_0
    //   190: iload_2
    //   191: istore_3
    //   192: aload_0
    //   193: ifnull -> 84
    //   196: iload_2
    //   197: istore_3
    //   198: aload_0
    //   199: invokevirtual length : ()I
    //   202: ifle -> 84
    //   205: ldc '10.0.0.172'
    //   207: aload_0
    //   208: invokevirtual trim : ()Ljava/lang/String;
    //   211: invokevirtual equals : (Ljava/lang/Object;)Z
    //   214: ifeq -> 227
    //   217: ldc '10.0.0.172'
    //   219: putstatic com/baidu/location/q.cT : Ljava/lang/String;
    //   222: iconst_1
    //   223: istore_3
    //   224: goto -> 84
    //   227: iload_2
    //   228: istore_3
    //   229: ldc '10.0.0.200'
    //   231: aload_0
    //   232: invokevirtual trim : ()Ljava/lang/String;
    //   235: invokevirtual equals : (Ljava/lang/Object;)Z
    //   238: ifeq -> 84
    //   241: ldc '10.0.0.200'
    //   243: putstatic com/baidu/location/q.cT : Ljava/lang/String;
    //   246: iconst_1
    //   247: istore_3
    //   248: goto -> 84
  }
  
  public static boolean if(Context paramContext) {
    try {
      ConnectivityManager connectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
      if (connectivityManager.getActiveNetworkInfo() != null)
        return connectivityManager.getActiveNetworkInfo().isAvailable(); 
    } catch (Exception exception) {
      return false;
    } 
    return false;
  }
  
  public void J() {
    (new q$1(this)).start();
  }
  
  public void M() {
    (new q$2(this)).start();
  }
  
  abstract void O();
  
  abstract void do(boolean paramBoolean);
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */