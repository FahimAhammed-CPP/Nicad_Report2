package com.baidu.location;

import android.os.Parcel;
import android.os.Parcelable;

final class BDLocation$1 implements Parcelable.Creator {
  public BDLocation a(Parcel paramParcel) {
    return new BDLocation(paramParcel, null);
  }
  
  public BDLocation[] a(int paramInt) {
    return new BDLocation[paramInt];
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/BDLocation$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */