package com.baidu.location;

import android.os.Bundle;
import android.os.Message;
import android.os.Messenger;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class i implements au, l {
  private static i bs = null;
  
  private boolean bq = false;
  
  private ArrayList br = null;
  
  private boolean bt = false;
  
  private i() {
    this.br = new ArrayList();
  }
  
  private void e() {
    i();
    j();
  }
  
  private void i() {
    Iterator<a> iterator = this.br.iterator();
    boolean bool = false;
    boolean bool1 = false;
    while (iterator.hasNext()) {
      a a = iterator.next();
      if (a.do.for)
        bool1 = true; 
      if (a.do.else)
        bool = true; 
    } 
    c.a1 = bool;
    if (this.bt != bool1) {
      this.bt = bool1;
      v.aR().int(this.bt);
    } 
  }
  
  private a if(Messenger paramMessenger) {
    // Byte code:
    //   0: aload_0
    //   1: getfield br : Ljava/util/ArrayList;
    //   4: ifnonnull -> 11
    //   7: aconst_null
    //   8: astore_1
    //   9: aload_1
    //   10: areturn
    //   11: aload_0
    //   12: getfield br : Ljava/util/ArrayList;
    //   15: invokevirtual iterator : ()Ljava/util/Iterator;
    //   18: astore_2
    //   19: aload_2
    //   20: invokeinterface hasNext : ()Z
    //   25: ifeq -> 54
    //   28: aload_2
    //   29: invokeinterface next : ()Ljava/lang/Object;
    //   34: checkcast com/baidu/location/i$a
    //   37: astore_3
    //   38: aload_3
    //   39: getfield for : Landroid/os/Messenger;
    //   42: aload_1
    //   43: invokevirtual equals : (Ljava/lang/Object;)Z
    //   46: ifeq -> 19
    //   49: aload_3
    //   50: astore_1
    //   51: goto -> 9
    //   54: aconst_null
    //   55: astore_1
    //   56: goto -> 9
  }
  
  private void if(a parama) {
    if (parama != null) {
      if (if(parama.for) != null) {
        a.a(parama, 14);
        return;
      } 
      this.br.add(parama);
      a.a(parama, 13);
    } 
  }
  
  public static i m() {
    if (bs == null)
      bs = new i(); 
    return bs;
  }
  
  public void d() {
    Iterator<a> iterator = this.br.iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).a(); 
  }
  
  public void do(Message paramMessage) {
    a a = if(paramMessage.replyTo);
    if (a != null)
      this.br.remove(a); 
    aw.b6().b8();
    ac.bc().bb();
    e.for().do();
    e();
  }
  
  public void do(BDLocation paramBDLocation) {
    ArrayList<a> arrayList = new ArrayList();
    for (a a : this.br) {
      a.a(paramBDLocation);
      if (a.if > 4)
        arrayList.add(a); 
    } 
    if (arrayList != null && arrayList.size() > 0)
      for (a a : arrayList)
        this.br.remove(a);  
  }
  
  public int for(Message paramMessage) {
    byte b = 1;
    int j = b;
    if (paramMessage != null) {
      if (paramMessage.replyTo == null)
        return b; 
    } else {
      return j;
    } 
    a a = if(paramMessage.replyTo);
    j = b;
    if (a != null) {
      j = b;
      if (a.do != null)
        j = a.do.f; 
    } 
    return j;
  }
  
  public boolean h() {
    return this.bt;
  }
  
  public String if(Message paramMessage) {
    String str1 = null;
    String str2 = str1;
    if (paramMessage != null) {
      if (paramMessage.replyTo == null)
        return str1; 
    } else {
      return str2;
    } 
    a a = if(paramMessage.replyTo);
    str2 = str1;
    if (a != null) {
      a.do.goto = paramMessage.getData().getInt("num", a.do.goto);
      a.do.void = paramMessage.getData().getFloat("distance", a.do.void);
      a.do.c = paramMessage.getData().getBoolean("extraInfo", a.do.c);
      a.do.new = true;
      String str = String.format(Locale.CHINA, "&poi=%.1f|%d", new Object[] { Float.valueOf(a.do.void), Integer.valueOf(a.do.goto) });
      str2 = str;
      if (a.do.c)
        str2 = str + "|1"; 
    } 
    return str2;
  }
  
  public void if(BDLocation paramBDLocation, int paramInt) {
    ArrayList<a> arrayList = new ArrayList();
    for (a a : this.br) {
      a.a(paramBDLocation, paramInt);
      if (a.if > 4)
        arrayList.add(a); 
    } 
    if (arrayList != null && arrayList.size() > 0)
      for (a a : arrayList)
        this.br.remove(a);  
  }
  
  public void if(BDLocation paramBDLocation, Message paramMessage) {
    if (paramBDLocation != null && paramMessage != null) {
      a a = if(paramMessage.replyTo);
      if (a != null) {
        a.a(paramBDLocation);
        if (a.if > 4)
          this.br.remove(a); 
      } 
    } 
  }
  
  public boolean int(Message paramMessage) {
    boolean bool1 = false;
    boolean bool2 = false;
    a a = if(paramMessage.replyTo);
    if (a != null) {
      int j = a.do.int;
      a.do.int = paramMessage.getData().getInt("scanSpan", a.do.int);
      if (a.do.int < 1000) {
        e.for().a();
        aw.b6().b8();
        ac.bc().bb();
        v.aR().aN();
      } else {
        e.for().if();
      } 
      bool2 = bool1;
      if (a.do.int > 999) {
        bool2 = bool1;
        if (j < 1000) {
          bool2 = true;
          if (a.do.e) {
            ac.bc().try(a.do.e);
            ac.bc().bd();
          } 
          aw.b6().b5();
        } 
      } 
      a.do.for = paramMessage.getData().getBoolean("openGPS", a.do.for);
      String str = paramMessage.getData().getString("coorType");
      LocationClientOption locationClientOption = a.do;
      if (str == null || str.equals(""))
        str = a.do.do; 
      locationClientOption.do = str;
      str = paramMessage.getData().getString("addrType");
      locationClientOption = a.do;
      if (str == null || str.equals(""))
        str = a.do.char; 
      locationClientOption.char = str;
      if (!c.av.equals(a.do.char))
        ad.al().am(); 
      c.av = a.do.char;
      a.do.b = paramMessage.getData().getInt("timeOut", a.do.b);
      a.do.else = paramMessage.getData().getBoolean("location_change_notify", a.do.else);
      a.do.f = paramMessage.getData().getInt("priority", a.do.f);
      e();
    } 
    return bool2;
  }
  
  public void j() {
    Iterator<a> iterator = this.br.iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).if(); 
  }
  
  public void k() {
    this.br.clear();
    e();
  }
  
  public String l() {
    StringBuffer stringBuffer = new StringBuffer(256);
    if (this.br.isEmpty())
      return "&prod=" + aw.iw + ":" + aw.iq; 
    a a = this.br.get(0);
    if (a.do.if != null)
      stringBuffer.append(a.do.if); 
    if (a.int != null) {
      stringBuffer.append(":");
      stringBuffer.append(a.int);
      stringBuffer.append("|");
    } 
    null = stringBuffer.toString();
    return (null != null && !null.equals("")) ? ("&prod=" + null) : null;
  }
  
  public void new(Message paramMessage) {
    if (paramMessage != null && paramMessage.replyTo != null) {
      if(new a(this, paramMessage));
      e();
    } 
  }
  
  public void try(String paramString) {
    BDLocation bDLocation = new BDLocation(paramString);
    (ah.a()).new = paramString;
    Iterator<a> iterator = this.br.iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).if(bDLocation); 
  }
  
  private class a {
    public LocationClientOption do = new LocationClientOption();
    
    public Messenger for = null;
    
    public int if = 0;
    
    public String int = null;
    
    public a(i this$0, Message param1Message) {
      this.for = param1Message.replyTo;
      this.int = param1Message.getData().getString("packName");
      this.do.if = param1Message.getData().getString("prodName");
      aw.b6().new(this.do.if, this.int);
      this.do.do = param1Message.getData().getString("coorType");
      this.do.char = param1Message.getData().getString("addrType");
      c.av = this.do.char;
      this.do.for = param1Message.getData().getBoolean("openGPS");
      this.do.int = param1Message.getData().getInt("scanSpan");
      this.do.b = param1Message.getData().getInt("timeOut");
      this.do.f = param1Message.getData().getInt("priority");
      this.do.else = param1Message.getData().getBoolean("location_change_notify");
      this.do.e = param1Message.getData().getBoolean("needDirect");
      if (this.do.e) {
        ac.bc().try(this.do.e);
        ac.bc().bd();
      } 
      if (this.do.int > 1000) {
        aw.b6().b5();
        e.for().int();
      } 
      if (this.do.getLocationMode() == LocationClientOption.LocationMode.Hight_Accuracy) {
        if (!ao.bC().bF())
          Log.w("baidu_location_service", "use hight accuracy mode does not use open wifi"); 
        if (!v.aR().aO())
          Log.w("baidu_location_service", "use hight accuracy mode does not use open gps"); 
      } 
    }
    
    private void a(int param1Int) {
      Message message = Message.obtain(null, param1Int);
      try {
        if (this.for != null)
          this.for.send(message); 
        this.if = 0;
      } catch (Exception exception) {}
    }
    
    private void a(int param1Int, String param1String, BDLocation param1BDLocation) {
      Bundle bundle = new Bundle();
      bundle.putParcelable(param1String, param1BDLocation);
      Message message = Message.obtain(null, param1Int);
      message.setData(bundle);
      try {
        if (this.for != null)
          this.for.send(message); 
        this.if = 0;
      } catch (Exception exception) {}
    }
    
    public void a() {
      a(23);
    }
    
    public void a(BDLocation param1BDLocation) {
      a(param1BDLocation, 21);
    }
    
    public void a(BDLocation param1BDLocation, int param1Int) {
      byte b = 0;
      param1BDLocation = new BDLocation(param1BDLocation);
      if (param1BDLocation != null) {
        if (param1Int == 21)
          a(27, "locStr", param1BDLocation); 
        if (this.do.do != null && !this.do.do.equals("gcj02")) {
          double d1 = param1BDLocation.getLongitude();
          double d2 = param1BDLocation.getLatitude();
          if (d1 != Double.MIN_VALUE && d2 != Double.MIN_VALUE) {
            double[] arrayOfDouble = Jni.if(d1, d2, this.do.do);
            param1BDLocation.setLongitude(arrayOfDouble[0]);
            param1BDLocation.setLatitude(arrayOfDouble[1]);
          } 
          if (this.do.new && param1Int == 26)
            try {
              if (param1BDLocation.getLocType() == 161 && param1BDLocation.hasPoi()) {
                JSONObject jSONObject = new JSONObject();
                this(param1BDLocation.getPoi());
                JSONArray jSONArray = jSONObject.getJSONArray("p");
                while (b < jSONArray.length()) {
                  JSONObject jSONObject1 = jSONArray.getJSONObject(b);
                  d2 = Double.parseDouble(jSONObject1.getString("x"));
                  d1 = Double.parseDouble(jSONObject1.getString("y"));
                  if (d2 != Double.MIN_VALUE && d1 != Double.MIN_VALUE) {
                    double[] arrayOfDouble = Jni.if(d2, d1, this.do.do);
                    jSONObject1.put("x", String.valueOf(arrayOfDouble[0]));
                    jSONObject1.put("y", String.valueOf(arrayOfDouble[1]));
                    jSONArray.put(b, jSONObject1);
                    b++;
                  } 
                } 
                jSONObject.put("p", jSONArray);
                param1BDLocation.setPoi(jSONObject.toString());
              } 
            } catch (JSONException jSONException) {} 
        } 
        a(param1Int, "locStr", param1BDLocation);
      } 
    }
    
    public void if() {
      if (this.do.else == true) {
        if (c.al) {
          a(54);
          return;
        } 
      } else {
        return;
      } 
      a(55);
    }
    
    public void if(BDLocation param1BDLocation) {
      if (this.do.else == true && !ab.a5().a6()) {
        a(param1BDLocation);
        ah.a().a((String)null);
        ah.a().if((ah.a()).new);
      } 
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */