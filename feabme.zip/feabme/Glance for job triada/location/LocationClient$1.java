package com.baidu.location;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.util.Log;

class LocationClient$1 implements ServiceConnection {
  LocationClient$1(LocationClient paramLocationClient) {}
  
  public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder) {
    LocationClient.if(this.a, new Messenger(paramIBinder));
    if (LocationClient.char(this.a) != null) {
      LocationClient.if(this.a, true);
      Log.d("baidu_location_client", "baidu location connected ...");
      try {
        Message message = Message.obtain(null, 11);
        message.replyTo = LocationClient.new(this.a);
        message.setData(LocationClient.void(this.a));
        LocationClient.char(this.a).send(message);
        LocationClient.if(this.a, true);
        if (LocationClient.else(this.a) != null) {
          if (LocationClient.if(this.a).booleanValue());
          LocationClient.byte(this.a).obtainMessage(4).sendToTarget();
        } 
      } catch (Exception exception) {}
    } 
  }
  
  public void onServiceDisconnected(ComponentName paramComponentName) {
    LocationClient.if(this.a, (Messenger)null);
    LocationClient.if(this.a, false);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/LocationClient$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */