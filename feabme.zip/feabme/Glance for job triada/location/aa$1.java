package com.baidu.location;

class aa$1 implements Runnable {
  aa$1(aa paramaa) {}
  
  public void run() {
    this.a.cz();
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/aa$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */