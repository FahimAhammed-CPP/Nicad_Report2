package com.baidu.location;

interface as {
  void a();
  
  void if();
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/as.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */