package com.baidu.location;

import android.net.wifi.ScanResult;
import android.os.Environment;
import android.text.TextUtils;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class aj implements l {
  private static aj hl;
  
  private static String[] hm;
  
  private static final String hn = "loc_cache.dat";
  
  private static final String ho = ";";
  
  private static final String hq = ",";
  
  private static final int hr = 5;
  
  private static final double hs = 121.314D;
  
  private String[] hp = null;
  
  private double bp() {
    double d1 = 0.0D;
    double d2 = d1;
    if (this.hp != null) {
      d2 = d1;
      if (this.hp.length > 2)
        d2 = Double.valueOf(this.hp[2]).doubleValue(); 
    } 
    return d2;
  }
  
  private double bq() {
    double d1 = 0.0D;
    double d2 = d1;
    if (this.hp != null) {
      d2 = d1;
      if (this.hp.length > 1)
        d2 = Double.valueOf(this.hp[1]).doubleValue() - 121.314D; 
    } 
    return d2;
  }
  
  private long br() {
    long l1 = 0L;
    long l2 = l1;
    if (this.hp != null) {
      l2 = l1;
      if (this.hp.length >= 3)
        l2 = Long.valueOf(this.hp[3]).longValue(); 
    } 
    return l2;
  }
  
  private boolean bs() {
    boolean bool = true;
    r.a a = r.aa().X();
    String str2 = String.format("%s|%s|%s|%s", new Object[] { Integer.valueOf(a.do), Integer.valueOf(a.if), Integer.valueOf(a.for), Integer.valueOf(a.try) });
    String str1 = hm[1];
    if (TextUtils.isEmpty(hm[1]) || !str1.equals(str2))
      bool = false; 
    return bool;
  }
  
  private void bu() {
    if (this.hp == null && hm != null) {
      String str = hm[0];
      if (!TextUtils.isEmpty(str))
        this.hp = str.split(","); 
    } 
  }
  
  private double bv() {
    double d1 = 0.0D;
    double d2 = d1;
    if (this.hp != null) {
      d2 = d1;
      if (this.hp.length > 0)
        d2 = Double.valueOf(this.hp[0]).doubleValue() - 121.314D; 
    } 
    return d2;
  }
  
  public static aj bw() {
    if (hl == null)
      hl = new aj(); 
    return hl;
  }
  
  public a bt() {
    byte[] arrayOfByte;
    FileInputStream fileInputStream1 = null;
    FileInputStream fileInputStream2 = null;
    FileInputStream fileInputStream3 = fileInputStream1;
    if ("mounted".equals(Environment.getExternalStorageState())) {
      File file = new File(f.H + File.separator + "loc_cache.dat");
      fileInputStream3 = fileInputStream1;
      if (file.exists()) {
        fileInputStream3 = fileInputStream2;
        try {
          fileInputStream1 = new FileInputStream();
          fileInputStream3 = fileInputStream2;
          this(file);
          fileInputStream3 = fileInputStream2;
          byte[] arrayOfByte1 = new byte[128];
          fileInputStream3 = fileInputStream2;
          ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
          fileInputStream3 = fileInputStream2;
          this();
          while (true) {
            fileInputStream3 = fileInputStream2;
            int i = fileInputStream1.read(arrayOfByte1);
            if (i != -1) {
              fileInputStream3 = fileInputStream2;
              byteArrayOutputStream.write(arrayOfByte1, 0, i);
              continue;
            } 
            fileInputStream3 = fileInputStream2;
            byte[] arrayOfByte2 = byteArrayOutputStream.toByteArray();
            arrayOfByte = arrayOfByte2;
            byteArrayOutputStream.close();
            arrayOfByte = arrayOfByte2;
            fileInputStream1.close();
            arrayOfByte = arrayOfByte2;
            break;
          } 
        } catch (Exception exception) {}
      } 
    } 
    hm = (new String(arrayOfByte)).split(";");
    bu();
    a a = new a(this);
    a.int = bv();
    a.try = bq();
    a.if = bp();
    a.for = bs();
    a.do = bx();
    a.new = br();
    return a;
  }
  
  public int bx() {
    Object object;
    byte b1 = 0;
    if (hm[2] != null) {
      object = hm[2].split(",");
    } else {
      object = null;
    } 
    ao.b b = ao.bC().by();
    byte b2 = b1;
    if (b != null) {
      List<ScanResult> list = b.for;
      b2 = b1;
      if (list != null) {
        b1 = 0;
        b2 = 0;
        label26: while (b1 < 5) {
          ScanResult scanResult = list.get(b1);
          if (scanResult != null) {
            String str = scanResult.BSSID.replace(":", "");
            byte b3 = 0;
            while (true) {
              if (b3 < object.length)
                if (str.equals(object[b3])) {
                  b2++;
                } else {
                  b3++;
                  continue;
                }  
              b1++;
              continue label26;
            } 
          } 
          continue;
        } 
      } 
    } 
    return b2;
  }
  
  public void new(BDLocation paramBDLocation) {
    byte b = 0;
    if (paramBDLocation.getLocType() == 161) {
      String str3;
      String str2 = String.format("%s,%s,%s,%d", new Object[] { Double.valueOf(paramBDLocation.getLongitude() + 121.314D), Double.valueOf(paramBDLocation.getLatitude() + 121.314D), Float.valueOf(paramBDLocation.getRadius()), Long.valueOf(System.currentTimeMillis()) });
      r.a a = r.aa().X();
      if (a.for()) {
        String str = String.format("%s|%s|%s|%s", new Object[] { Integer.valueOf(a.do), Integer.valueOf(a.if), Integer.valueOf(a.for), Integer.valueOf(a.try) });
      } else {
        a = null;
      } 
      ArrayList<String> arrayList1 = null;
      ao.b b1 = ao.bC().by();
      ArrayList<String> arrayList2 = arrayList1;
      if (b1 != null) {
        List<ScanResult> list = b1.for;
        arrayList2 = arrayList1;
        if (list != null) {
          arrayList2 = new ArrayList();
          while (b < 5) {
            ScanResult scanResult = list.get(b);
            if (scanResult != null)
              arrayList2.add(scanResult.BSSID.replace(":", "")); 
            b++;
          } 
          str3 = TextUtils.join(",", arrayList2);
        } 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str2).append(";").append((String)a).append(";").append(str3);
      String str1 = stringBuilder.toString();
      if ("mounted".equals(Environment.getExternalStorageState())) {
        File file2 = new File(f.H + File.separator + "loc_cache.dat");
        File file1 = file2.getParentFile();
        if (!file1.exists())
          file1.mkdirs(); 
        try {
          FileOutputStream fileOutputStream = new FileOutputStream();
          this(file2);
          fileOutputStream.write(str1.getBytes());
          fileOutputStream.close();
        } catch (Exception exception) {}
      } 
    } 
  }
  
  public class a {
    public int do;
    
    public boolean for;
    
    public double if;
    
    public double int;
    
    public long new;
    
    public double try;
    
    public a(aj this$0) {}
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/aj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */