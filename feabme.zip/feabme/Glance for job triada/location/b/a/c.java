package com.baidu.location.b.a;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public final class c {
  public static String a(byte[] paramArrayOfbyte, String paramString, boolean paramBoolean) {
    StringBuilder stringBuilder = new StringBuilder();
    int i = paramArrayOfbyte.length;
    for (byte b = 0; b < i; b++) {
      String str1 = Integer.toHexString(paramArrayOfbyte[b] & 0xFF);
      String str2 = str1;
      if (paramBoolean)
        str2 = str1.toUpperCase(); 
      if (str2.length() == 1)
        stringBuilder.append("0"); 
      stringBuilder.append(str2).append(paramString);
    } 
    return stringBuilder.toString();
  }
  
  public static String a(byte[] paramArrayOfbyte, boolean paramBoolean) {
    try {
      MessageDigest messageDigest = MessageDigest.getInstance("MD5");
      messageDigest.reset();
      messageDigest.update(paramArrayOfbyte);
      return a(messageDigest.digest(), "", paramBoolean);
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      throw new RuntimeException(noSuchAlgorithmException);
    } 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/b/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */