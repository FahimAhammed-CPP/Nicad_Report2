package com.baidu.location.b.b;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public final class a {
  private static final String a = "AES";
  
  private static final String if = "AES/CBC/PKCS5Padding";
  
  public static byte[] a(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws Exception {
    SecretKeySpec secretKeySpec = new SecretKeySpec(paramString2.getBytes(), "AES");
    Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
    cipher.init(2, secretKeySpec, new IvParameterSpec(paramString1.getBytes()));
    return cipher.doFinal(paramArrayOfbyte);
  }
  
  public static byte[] if(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws Exception {
    SecretKeySpec secretKeySpec = new SecretKeySpec(paramString2.getBytes(), "AES");
    Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
    cipher.init(1, secretKeySpec, new IvParameterSpec(paramString1.getBytes()));
    return cipher.doFinal(paramArrayOfbyte);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/b/b/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */