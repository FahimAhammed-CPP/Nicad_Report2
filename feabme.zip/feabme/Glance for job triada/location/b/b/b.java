package com.baidu.location.b.b;

import java.io.UnsupportedEncodingException;

public final class b {
  private static final byte[] a = new byte[] { 
      65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 
      75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 
      85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 
      101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 
      111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 
      121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 
      56, 57, 43, 47 };
  
  public static String a(byte[] paramArrayOfbyte, String paramString) throws UnsupportedEncodingException {
    int i = paramArrayOfbyte.length * 4 / 3;
    byte[] arrayOfByte = new byte[i + i / 76 + 3];
    int j = paramArrayOfbyte.length - paramArrayOfbyte.length % 3;
    byte b1 = 0;
    int k = 0;
    i = 0;
    while (true) {
      if (k < j) {
        int m = i + 1;
        arrayOfByte[i] = (byte)a[(paramArrayOfbyte[k] & 0xFF) >> 2];
        i = m + 1;
        arrayOfByte[m] = (byte)a[(paramArrayOfbyte[k] & 0x3) << 4 | (paramArrayOfbyte[k + 1] & 0xFF) >> 4];
        int n = i + 1;
        arrayOfByte[i] = (byte)a[(paramArrayOfbyte[k + 1] & 0xF) << 2 | (paramArrayOfbyte[k + 2] & 0xFF) >> 6];
        m = n + 1;
        arrayOfByte[n] = (byte)a[paramArrayOfbyte[k + 2] & 0x3F];
        if ((m - b1) % 76 == 0 && m != 0) {
          i = m + 1;
          arrayOfByte[m] = (byte)10;
          b1++;
        } else {
          i = m;
        } 
        k += 3;
        continue;
      } 
      switch (paramArrayOfbyte.length % 3) {
        default:
          return new String(arrayOfByte, 0, i, paramString);
        case 1:
          k = i + 1;
          arrayOfByte[i] = (byte)a[(paramArrayOfbyte[j] & 0xFF) >> 2];
          i = k + 1;
          arrayOfByte[k] = (byte)a[(paramArrayOfbyte[j] & 0x3) << 4];
          k = i + 1;
          arrayOfByte[i] = (byte)61;
          i = k + 1;
          arrayOfByte[k] = (byte)61;
        case 2:
          break;
      } 
      k = i + 1;
      arrayOfByte[i] = (byte)a[(paramArrayOfbyte[j] & 0xFF) >> 2];
      i = k + 1;
      arrayOfByte[k] = (byte)a[(paramArrayOfbyte[j] & 0x3) << 4 | (paramArrayOfbyte[j + 1] & 0xFF) >> 4];
      k = i + 1;
      arrayOfByte[i] = (byte)a[(paramArrayOfbyte[j + 1] & 0xF) << 2];
      i = k + 1;
      arrayOfByte[k] = (byte)61;
    } 
  }
  
  public static byte[] a(byte[] paramArrayOfbyte) {
    return a(paramArrayOfbyte, paramArrayOfbyte.length);
  }
  
  public static byte[] a(byte[] paramArrayOfbyte, int paramInt) {
    int i = paramInt / 4 * 3;
    if (i == 0)
      return new byte[0]; 
    byte[] arrayOfByte = new byte[i];
    int j = 0;
    int k = paramInt;
    while (true) {
      i = paramArrayOfbyte[k - 1];
      paramInt = j;
      if (i != 10) {
        paramInt = j;
        if (i != 13) {
          paramInt = j;
          if (i != 32)
            if (i == 9) {
              paramInt = j;
            } else if (i == 61) {
              paramInt = j + 1;
            } else {
              byte b1 = 0;
              int m = 0;
              int n = 0;
              paramInt = 0;
              while (true) {
                if (b1 < k) {
                  i = paramArrayOfbyte[b1];
                  if (i != 10 && i != 13 && i != 32) {
                    if (i == 9) {
                      i = paramInt;
                      paramInt = m;
                    } else {
                      if (i >= 65 && i <= 90) {
                        i -= 65;
                      } else if (i >= 97 && i <= 122) {
                        i -= 71;
                      } else if (i >= 48 && i <= 57) {
                        i += 4;
                      } else if (i == 43) {
                        i = 62;
                      } else if (i == 47) {
                        i = 63;
                      } else {
                        return null;
                      } 
                      m = m << 6 | (byte)i;
                      if (n % 4 == 3) {
                        int i1 = paramInt + 1;
                        arrayOfByte[paramInt] = (byte)(byte)((0xFF0000 & m) >> 16);
                        i = i1 + 1;
                        arrayOfByte[i1] = (byte)(byte)((0xFF00 & m) >> 8);
                        paramInt = i + 1;
                        arrayOfByte[i] = (byte)(byte)(m & 0xFF);
                      } 
                      n++;
                      i = paramInt;
                      paramInt = m;
                    } 
                  } else {
                    i = paramInt;
                    paramInt = m;
                  } 
                  b1++;
                  m = paramInt;
                  paramInt = i;
                  continue;
                } 
                i = paramInt;
                if (j > 0) {
                  n = m << j * 6;
                  i = paramInt + 1;
                  arrayOfByte[paramInt] = (byte)(byte)((0xFF0000 & n) >> 16);
                  if (j == 1) {
                    paramInt = i + 1;
                    arrayOfByte[i] = (byte)(byte)((0xFF00 & n) >> 8);
                    i = paramInt;
                  } 
                } 
                paramArrayOfbyte = new byte[i];
                System.arraycopy(arrayOfByte, 0, paramArrayOfbyte, 0, i);
                return paramArrayOfbyte;
              } 
              break;
            }  
        } 
      } 
      k--;
      j = paramInt;
    } 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/b/b/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */