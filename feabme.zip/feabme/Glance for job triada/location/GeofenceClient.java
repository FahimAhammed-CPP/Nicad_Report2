package com.baidu.location;

import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;
import java.util.List;

public class GeofenceClient implements au, l {
  public static final String BUNDLE_FOR_GEOFENCE_ID = "geofence_id";
  
  private static final int bh = 1;
  
  private Context bd;
  
  private OnGeofenceTriggerListener be;
  
  private ServiceConnection bf = new GeofenceClient$1(this);
  
  private Messenger bg = new Messenger(this.bk);
  
  private Messenger bi = null;
  
  private boolean bj = false;
  
  private a bk = new a(null);
  
  public GeofenceClient(Context paramContext) {
    this.bd = paramContext;
  }
  
  private void else() {
    if (!this.bj) {
      Intent intent = new Intent(this.bd, f.class);
      try {
        this.bd.bindService(intent, this.bf, 1);
      } catch (Exception exception) {
        this.bj = false;
      } 
    } 
  }
  
  private void for(String paramString) {
    if (this.be != null)
      this.be.onGeofenceTrigger(paramString); 
  }
  
  private void goto() {
    try {
      Message message = Message.obtain(null, 207);
      message.replyTo = this.bg;
      this.bi.send(message);
    } catch (Exception exception) {}
  }
  
  public void addBDGeofence(BDGeofence paramBDGeofence, OnAddBDGeofencesResultListener paramOnAddBDGeofencesResultListener) throws NullPointerException, IllegalArgumentException, IllegalStateException {
    ak.a(paramBDGeofence, "geofence is null");
    if (paramBDGeofence != null)
      ak.if(paramBDGeofence instanceof an, "BDGeofence must be created using BDGeofence.Builder"); 
    ar.for(this.bd).if((an)paramBDGeofence, paramOnAddBDGeofencesResultListener);
  }
  
  public boolean isStarted() {
    return this.bj;
  }
  
  public void registerGeofenceTriggerListener(OnGeofenceTriggerListener paramOnGeofenceTriggerListener) {
    if (this.be == null)
      this.be = paramOnGeofenceTriggerListener; 
  }
  
  public void removeBDGeofences(List paramList, OnRemoveBDGeofencesResultListener paramOnRemoveBDGeofencesResultListener) throws NullPointerException, IllegalArgumentException {
    ar.for(this.bd).if(paramList, paramOnRemoveBDGeofencesResultListener);
  }
  
  public void start() throws NullPointerException {
    ak.a(this.be, "OnGeofenceTriggerListener not register!");
    this.bk.obtainMessage(1).sendToTarget();
  }
  
  public void startGeofenceScann() {
    if (this.bj)
      try {
        Message message = Message.obtain(null, 206);
        message.replyTo = this.bg;
        this.bi.send(message);
      } catch (Exception exception) {} 
  }
  
  public void stop() {
    goto();
  }
  
  public static interface OnAddBDGeofencesResultListener {
    void onAddBDGeofencesResult(int param1Int, String param1String);
  }
  
  public static interface OnGeofenceTriggerListener {
    void onGeofenceTrigger(String param1String);
  }
  
  public static interface OnRemoveBDGeofencesResultListener {
    void onRemoveBDGeofencesByRequestIdsResult(int param1Int, String[] param1ArrayOfString);
  }
  
  private class a extends Handler {
    private a(GeofenceClient this$0) {}
    
    public void handleMessage(Message param1Message) {
      Bundle bundle;
      switch (param1Message.what) {
        default:
          return;
        case 208:
          bundle = param1Message.getData();
          if (bundle != null) {
            String str = bundle.getString("geofence_id");
            GeofenceClient.if(this.a, str);
          } 
        case 1:
          break;
      } 
      GeofenceClient.do(this.a);
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/GeofenceClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */