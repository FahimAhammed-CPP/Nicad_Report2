package com.baidu.location;

import android.content.Context;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.regex.Pattern;

class t {
  public static String a(Context paramContext) {
    String str1;
    String str2 = paramContext.getPackageName();
    String str3 = null;
    try {
      str2 = (paramContext.getPackageManager().getApplicationInfo(str2, 128)).metaData.getString("com.baidu.lbsapi.API_KEY");
      str1 = str2;
      str3 = str2;
      if (!TextUtils.isEmpty(str2)) {
        str3 = str2;
        str1 = Pattern.compile("[&=]").matcher(str2).replaceAll("");
      } 
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      str1 = str3;
    } 
    return str1;
  }
  
  private static String a(Context paramContext, String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   4: aload_1
    //   5: bipush #64
    //   7: invokevirtual getPackageInfo : (Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   10: getfield signatures : [Landroid/content/pm/Signature;
    //   13: astore_1
    //   14: ldc 'X.509'
    //   16: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/cert/CertificateFactory;
    //   19: astore_2
    //   20: new java/io/ByteArrayInputStream
    //   23: astore_0
    //   24: aload_0
    //   25: aload_1
    //   26: iconst_0
    //   27: aaload
    //   28: invokevirtual toByteArray : ()[B
    //   31: invokespecial <init> : ([B)V
    //   34: aload_2
    //   35: aload_0
    //   36: invokevirtual generateCertificate : (Ljava/io/InputStream;)Ljava/security/cert/Certificate;
    //   39: checkcast java/security/cert/X509Certificate
    //   42: invokestatic a : (Ljava/security/cert/X509Certificate;)Ljava/lang/String;
    //   45: astore_0
    //   46: new java/lang/StringBuffer
    //   49: dup
    //   50: invokespecial <init> : ()V
    //   53: astore_1
    //   54: iconst_0
    //   55: istore_3
    //   56: iload_3
    //   57: aload_0
    //   58: invokevirtual length : ()I
    //   61: if_icmpge -> 122
    //   64: aload_1
    //   65: aload_0
    //   66: iload_3
    //   67: invokevirtual charAt : (I)C
    //   70: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   73: pop
    //   74: iload_3
    //   75: ifle -> 102
    //   78: iload_3
    //   79: iconst_2
    //   80: irem
    //   81: iconst_1
    //   82: if_icmpne -> 102
    //   85: iload_3
    //   86: aload_0
    //   87: invokevirtual length : ()I
    //   90: iconst_1
    //   91: isub
    //   92: if_icmpge -> 102
    //   95: aload_1
    //   96: ldc ':'
    //   98: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   101: pop
    //   102: iinc #3, 1
    //   105: goto -> 56
    //   108: astore_0
    //   109: ldc ''
    //   111: astore_0
    //   112: goto -> 46
    //   115: astore_0
    //   116: ldc ''
    //   118: astore_0
    //   119: goto -> 46
    //   122: aload_1
    //   123: invokevirtual toString : ()Ljava/lang/String;
    //   126: areturn
    // Exception table:
    //   from	to	target	type
    //   0	46	108	android/content/pm/PackageManager$NameNotFoundException
    //   0	46	115	java/security/cert/CertificateException
  }
  
  static String a(X509Certificate paramX509Certificate) {
    try {
      String str = a.a(a(paramX509Certificate.getEncoded()));
    } catch (CertificateEncodingException certificateEncodingException) {
      certificateEncodingException = null;
    } 
    return (String)certificateEncodingException;
  }
  
  static byte[] a(byte[] paramArrayOfbyte) {
    try {
      paramArrayOfbyte = MessageDigest.getInstance("SHA1").digest(paramArrayOfbyte);
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      noSuchAlgorithmException = null;
    } 
    return (byte[])noSuchAlgorithmException;
  }
  
  public static String if(Context paramContext) {
    String str2 = paramContext.getPackageName();
    String str1 = a(paramContext, str2);
    return str1 + ";" + str2;
  }
  
  static class a {
    public static String a(byte[] param1ArrayOfbyte) {
      char[] arrayOfChar = new char[16];
      arrayOfChar[0] = '0';
      arrayOfChar[1] = '1';
      arrayOfChar[2] = '2';
      arrayOfChar[3] = '3';
      arrayOfChar[4] = '4';
      arrayOfChar[5] = '5';
      arrayOfChar[6] = '6';
      arrayOfChar[7] = '7';
      arrayOfChar[8] = '8';
      arrayOfChar[9] = '9';
      arrayOfChar[10] = 'A';
      arrayOfChar[11] = 'B';
      arrayOfChar[12] = 'C';
      arrayOfChar[13] = 'D';
      arrayOfChar[14] = 'E';
      arrayOfChar[15] = 'F';
      StringBuilder stringBuilder = new StringBuilder(param1ArrayOfbyte.length * 2);
      for (byte b = 0; b < param1ArrayOfbyte.length; b++) {
        stringBuilder.append(arrayOfChar[(param1ArrayOfbyte[b] & 0xF0) >> 4]);
        stringBuilder.append(arrayOfChar[param1ArrayOfbyte[b] & 0xF]);
      } 
      return stringBuilder.toString();
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */