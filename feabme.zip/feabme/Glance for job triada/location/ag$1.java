package com.baidu.location;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;

class ag$1 implements SensorEventListener {
  ag$1(ag paramag) {}
  
  public void onAccuracyChanged(Sensor paramSensor, int paramInt) {}
  
  public void onSensorChanged(SensorEvent paramSensorEvent) {
    switch (paramSensorEvent.sensor.getType()) {
      default:
        return;
      case 1:
        break;
    } 
    float[] arrayOfFloat = (float[])paramSensorEvent.values.clone();
    ag.if(this.a, (float[])arrayOfFloat.clone());
    arrayOfFloat = ag.if(this.a, arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2]);
    if (ag.do(this.a) >= 20) {
      float f1 = arrayOfFloat[0];
      float f2 = arrayOfFloat[0];
      float f3 = arrayOfFloat[1];
      float f4 = arrayOfFloat[1];
      float f5 = arrayOfFloat[2];
      double d = (arrayOfFloat[2] * f5 + f1 * f2 + f3 * f4);
      if (ag.for(this.a) == 0)
        if (d > 4.0D)
          ag.if(this.a, 1);  
      if (d < 0.009999999776482582D)
        ag.if(this.a, 0); 
    } 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/ag$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */