package com.baidu.location;

import android.os.Environment;

interface au {
  public static final int A = 55;
  
  public static final int B = 51;
  
  public static final int C = 53;
  
  public static final int D = 13;
  
  public static final int E = 12000;
  
  public static final int F = 22;
  
  public static final int G = 65;
  
  public static final String H = Environment.getExternalStorageDirectory().getPath() + "/baidu/tempdata";
  
  public static final int I = 207;
  
  public static final int J = 21;
  
  public static final int K = 1;
  
  public static final int L = 61;
  
  public static final int M = 64;
  
  public static final int N = 5120;
  
  public static final int O = 205;
  
  public static final int P = 11;
  
  public static final int b = 204;
  
  public static final int byte = 1;
  
  public static final int c = 0;
  
  public static final int case = 43;
  
  public static final int char = 26;
  
  public static final int d = 42;
  
  public static final int do = 25;
  
  public static final int e = 52;
  
  public static final int else = 12;
  
  public static final int f = 110;
  
  public static final int for = 2;
  
  public static final int g = 31;
  
  public static final int goto = 14;
  
  public static final String h = "baidu_location_service";
  
  public static final int i = 206;
  
  public static final int if = 203;
  
  public static final int int = 111;
  
  public static final int j = 3;
  
  public static final int k = 101;
  
  public static final int l = 57;
  
  public static final int long = 202;
  
  public static final int m = 28;
  
  public static final int n = 23;
  
  public static final int new = 208;
  
  public static final int o = 27;
  
  public static final int p = 15;
  
  public static final int q = 4;
  
  public static final int r = 63;
  
  public static final int s = 201;
  
  public static final int t = 62;
  
  public static final int try = 92;
  
  public static final int u = 91;
  
  public static final int v = 71;
  
  public static final int void = 24;
  
  public static final int w = 41;
  
  public static final int x = 81;
  
  public static final int y = 56;
  
  public static final int z = 54;
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/au.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */