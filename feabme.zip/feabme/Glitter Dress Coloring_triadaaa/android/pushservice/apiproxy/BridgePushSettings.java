package com.baidu.android.pushservice.apiproxy;

import android.content.Context;
import com.baidu.android.pushservice.internal.PushSettings;

public class BridgePushSettings {
  public static void enableDebugMode(Context paramContext, boolean paramBoolean) {
    PushSettings.enableDebugMode(paramContext, paramBoolean);
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/android/pushservice/apiproxy/BridgePushSettings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */