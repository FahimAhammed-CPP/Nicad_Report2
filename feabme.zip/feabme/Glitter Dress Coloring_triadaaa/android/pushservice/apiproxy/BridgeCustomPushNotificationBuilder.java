package com.baidu.android.pushservice.apiproxy;

import android.app.Notification;
import android.content.Context;
import android.net.Uri;
import com.baidu.android.pushservice.internal.CustomPushNotificationBuilder;
import com.baidu.android.pushservice.internal.PushNotificationBuilder;

public class BridgeCustomPushNotificationBuilder extends BridgePushNotificationBuilder {
  public BridgeCustomPushNotificationBuilder(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mInstance = (PushNotificationBuilder)new CustomPushNotificationBuilder(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public BridgeCustomPushNotificationBuilder(CustomPushNotificationBuilder paramCustomPushNotificationBuilder) {
    this.mInstance = (PushNotificationBuilder)paramCustomPushNotificationBuilder;
  }
  
  public Notification construct(Context paramContext) {
    return this.mInstance.construct(paramContext);
  }
  
  public CustomPushNotificationBuilder getInner() {
    return (CustomPushNotificationBuilder)this.mInstance;
  }
  
  public void setLayoutDrawable(int paramInt) {
    ((CustomPushNotificationBuilder)this.mInstance).setLayoutDrawable(paramInt);
  }
  
  public void setNotificationDefaults(int paramInt) {
    this.mInstance.setNotificationDefaults(paramInt);
  }
  
  public void setNotificationFlags(int paramInt) {
    this.mInstance.setNotificationFlags(paramInt);
  }
  
  public void setNotificationSound(Uri paramUri) {
    this.mInstance.setNotificationSound(paramUri);
  }
  
  public void setNotificationText(String paramString) {
    this.mInstance.setNotificationText(paramString);
  }
  
  public void setNotificationTitle(String paramString) {
    this.mInstance.setNotificationTitle(paramString);
  }
  
  public void setNotificationVibrate(long[] paramArrayOflong) {
    this.mInstance.setNotificationVibrate(paramArrayOflong);
  }
  
  public void setStatusbarIcon(int paramInt) {
    this.mInstance.setStatusbarIcon(paramInt);
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/android/pushservice/apiproxy/BridgeCustomPushNotificationBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */