package com.baidu.android.pushservice.apiproxy;

import android.app.Notification;
import android.content.Context;
import com.baidu.android.pushservice.internal.BasicPushNotificationBuilder;

public class BridgeBasicPushNotificationBuilder {
  private BasicPushNotificationBuilder a = new BasicPushNotificationBuilder();
  
  public BridgeBasicPushNotificationBuilder() {}
  
  public BridgeBasicPushNotificationBuilder(BasicPushNotificationBuilder paramBasicPushNotificationBuilder) {}
  
  public Notification construct(Context paramContext) {
    return this.a.construct(paramContext);
  }
  
  public BasicPushNotificationBuilder getInner() {
    return this.a;
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/android/pushservice/apiproxy/BridgeBasicPushNotificationBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */