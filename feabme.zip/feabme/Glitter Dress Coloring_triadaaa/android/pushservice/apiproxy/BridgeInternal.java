package com.baidu.android.pushservice.apiproxy;

import android.content.Context;
import com.baidu.android.pushservice.util.Internal;

public class BridgeInternal {
  public static void createBdussIntent(Context paramContext) {
    Internal.createBdussInent(paramContext);
  }
  
  public static void disablePushConnection(Context paramContext) {
    Internal.disablePushConnection(paramContext);
  }
  
  public static void disablePushService(Context paramContext) {
    Internal.disablePushService(paramContext);
  }
  
  public static void enablePushConnection(Context paramContext) {
    Internal.enablePushConnection(paramContext);
  }
  
  public static void enablePushService(Context paramContext) {
    Internal.enablePushService(paramContext);
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/android/pushservice/apiproxy/BridgeInternal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */