package com.baidu.android.pushservice.apiproxy;

import android.app.Activity;
import android.content.Context;
import com.baidu.android.pushservice.internal.PushManager;
import java.util.List;

public class BridgePushManager {
  public static void activityStarted(Activity paramActivity) {
    PushManager.activityStarted(paramActivity);
  }
  
  public static void activityStoped(Activity paramActivity) {
    PushManager.activityStoped(paramActivity);
  }
  
  public static void bind(Context paramContext, int paramInt) {
    PushManager.bind(paramContext, paramInt);
  }
  
  public static void bindGroup(Context paramContext, String paramString) {
    PushManager.bindGroup(paramContext, paramString);
  }
  
  public static void delTags(Context paramContext, List<String> paramList) {
    PushManager.delTags(paramContext, paramList);
  }
  
  public static void deleteMessages(Context paramContext, String[] paramArrayOfString) {
    PushManager.deleteMessages(paramContext, paramArrayOfString);
  }
  
  public static void disableLbs(Context paramContext) {
    PushManager.disableLbs(paramContext);
  }
  
  public static void enableLbs(Context paramContext) {
    PushManager.enableLbs(paramContext);
  }
  
  public static void fetchGroupMessages(Context paramContext, String paramString, int paramInt1, int paramInt2) {
    PushManager.fetchGroupMessages(paramContext, paramString, paramInt1, paramInt2);
  }
  
  public static void fetchMessages(Context paramContext, int paramInt1, int paramInt2) {
    PushManager.fetchMessages(paramContext, paramInt1, paramInt2);
  }
  
  public static void getGroupInfo(Context paramContext, String paramString) {
    PushManager.getGroupInfo(paramContext, paramString);
  }
  
  public static void getGroupList(Context paramContext) {
    PushManager.getGroupList(paramContext);
  }
  
  public static void getGroupMessageCounts(Context paramContext, String paramString) {
    PushManager.getGroupMessageCounts(paramContext, paramString);
  }
  
  public static void getMessageCounts(Context paramContext) {
    PushManager.getMessageCounts(paramContext);
  }
  
  public static void init(Context paramContext, String paramString) {
    PushManager.init(paramContext, paramString);
  }
  
  public static void init(Context paramContext, String paramString1, String paramString2) {
    PushManager.init(paramContext, paramString1, paramString2);
  }
  
  public static void initFromAKSK(Context paramContext, String paramString) {
    PushManager.initFromAKSK(paramContext, paramString);
  }
  
  public static boolean isConnected(Context paramContext) {
    return PushManager.isConnected(paramContext);
  }
  
  public static boolean isPushEnabled(Context paramContext) {
    return PushManager.isPushEnabled(paramContext);
  }
  
  public static void listTags(Context paramContext) {
    PushManager.listTags(paramContext);
  }
  
  public static void resumeWork(Context paramContext) {
    PushManager.resumeWork(paramContext);
  }
  
  public static void sdkBind(Context paramContext, int paramInt1, String paramString, int paramInt2) {
    PushManager.sdkBind(paramContext, paramInt1, paramString, paramInt2);
  }
  
  public static void sdkStartWork(Context paramContext, String paramString, int paramInt) {
    PushManager.sdkStartWork(paramContext, paramString, paramInt);
  }
  
  public static void sendMsgToUser(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4) {
    PushManager.sendMsgToUser(paramContext, paramString1, paramString2, paramString3, paramString4);
  }
  
  public static void setAccessToken(Context paramContext, String paramString) {
    PushManager.setAccessToken(paramContext, paramString);
  }
  
  public static void setApiKey(Context paramContext, String paramString) {
    PushManager.setApiKey(paramContext, paramString);
  }
  
  public static void setBduss(Context paramContext, String paramString) {
    PushManager.setBduss(paramContext, paramString);
  }
  
  public static void setDefaultNotificationBuilder(Context paramContext, BridgePushNotificationBuilder paramBridgePushNotificationBuilder) {
    PushManager.setDefaultNotificationBuilder(paramContext, paramBridgePushNotificationBuilder.getInner());
  }
  
  public static void setMediaNotificationBuilder(Context paramContext, BridgePushNotificationBuilder paramBridgePushNotificationBuilder) {
    PushManager.setMediaNotificationBuilder(paramContext, paramBridgePushNotificationBuilder.getInner());
  }
  
  public static void setNotificationBuilder(Context paramContext, int paramInt, BridgePushNotificationBuilder paramBridgePushNotificationBuilder) {
    try {
      PushManager.setNotificationBuilder(paramContext, paramInt, paramBridgePushNotificationBuilder.getInner());
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public static void setTags(Context paramContext, List<String> paramList) {
    PushManager.setTags(paramContext, paramList);
  }
  
  public static void startWork(Context paramContext, int paramInt, String paramString) {
    PushManager.startWork(paramContext, paramInt, paramString);
  }
  
  public static void startWork(Context paramContext, String paramString1, String paramString2) {
    PushManager.startWork(paramContext, paramString1, paramString2);
  }
  
  public static void stopWork(Context paramContext) {
    PushManager.stopWork(paramContext);
  }
  
  public static void tryConnect(Context paramContext) {
    PushManager.tryConnect(paramContext);
  }
  
  public static void unbind(Context paramContext) {
    PushManager.unbind(paramContext);
  }
  
  public static void unbindGroup(Context paramContext, String paramString) {
    PushManager.unbindGroup(paramContext, paramString);
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/android/pushservice/apiproxy/BridgePushManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */