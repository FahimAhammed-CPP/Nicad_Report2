package mono.android.view.accessibility;

import android.view.accessibility.AccessibilityManager;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class AccessibilityManager_AccessibilityStateChangeListenerImplementor implements IGCUserPeer, AccessibilityManager.AccessibilityStateChangeListener {
  static final String __md_methods = "n_onAccessibilityStateChanged:(Z)V:GetOnAccessibilityStateChanged_ZHandler:Android.Views.Accessibility.AccessibilityManager/IAccessibilityStateChangeListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Android.Views.Accessibility.AccessibilityManager/IAccessibilityStateChangeListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", AccessibilityManager_AccessibilityStateChangeListenerImplementor.class, __md_methods);
  }
  
  public AccessibilityManager_AccessibilityStateChangeListenerImplementor() throws Throwable {
    if (getClass() == AccessibilityManager_AccessibilityStateChangeListenerImplementor.class)
      TypeManager.Activate("Android.Views.Accessibility.AccessibilityManager/IAccessibilityStateChangeListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "", this, new Object[0]); 
  }
  
  private native void n_onAccessibilityStateChanged(boolean paramBoolean);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onAccessibilityStateChanged(boolean paramBoolean) {
    n_onAccessibilityStateChanged(paramBoolean);
  }
}


/* Location:              /home/fahim/Desktop/feabme2_jumperchess-dex2jar.jar!/mono/android/view/accessibility/AccessibilityManager_AccessibilityStateChangeListenerImplementor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */