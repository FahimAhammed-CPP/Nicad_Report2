package mono.android;

public interface IGCUserPeer {
  void monodroidAddReference(Object paramObject);
  
  void monodroidClearReferences();
}


/* Location:              /home/fahim/Desktop/feabme2_jumperchess-dex2jar.jar!/mono/android/IGCUserPeer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */