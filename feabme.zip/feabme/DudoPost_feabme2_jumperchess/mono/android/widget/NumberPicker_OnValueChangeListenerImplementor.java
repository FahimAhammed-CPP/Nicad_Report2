package mono.android.widget;

import android.widget.NumberPicker;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class NumberPicker_OnValueChangeListenerImplementor implements IGCUserPeer, NumberPicker.OnValueChangeListener {
  static final String __md_methods = "n_onValueChange:(Landroid/widget/NumberPicker;II)V:GetOnValueChange_Landroid_widget_NumberPicker_IIHandler:Android.Widget.NumberPicker/IOnValueChangeListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Android.Widget.NumberPicker/IOnValueChangeListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", NumberPicker_OnValueChangeListenerImplementor.class, __md_methods);
  }
  
  public NumberPicker_OnValueChangeListenerImplementor() throws Throwable {
    if (getClass() == NumberPicker_OnValueChangeListenerImplementor.class)
      TypeManager.Activate("Android.Widget.NumberPicker/IOnValueChangeListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "", this, new Object[0]); 
  }
  
  private native void n_onValueChange(NumberPicker paramNumberPicker, int paramInt1, int paramInt2);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onValueChange(NumberPicker paramNumberPicker, int paramInt1, int paramInt2) {
    n_onValueChange(paramNumberPicker, paramInt1, paramInt2);
  }
}


/* Location:              /home/fahim/Desktop/feabme2_jumperchess-dex2jar.jar!/mono/android/widget/NumberPicker_OnValueChangeListenerImplementor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */