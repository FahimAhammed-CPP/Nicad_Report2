package mono.android.animation;

import android.animation.TimeAnimator;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class TimeAnimator_TimeListenerImplementor implements IGCUserPeer, TimeAnimator.TimeListener {
  static final String __md_methods = "n_onTimeUpdate:(Landroid/animation/TimeAnimator;JJ)V:GetOnTimeUpdate_Landroid_animation_TimeAnimator_JJHandler:Android.Animation.TimeAnimator/ITimeListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Android.Animation.TimeAnimator/ITimeListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", TimeAnimator_TimeListenerImplementor.class, __md_methods);
  }
  
  public TimeAnimator_TimeListenerImplementor() throws Throwable {
    if (getClass() == TimeAnimator_TimeListenerImplementor.class)
      TypeManager.Activate("Android.Animation.TimeAnimator/ITimeListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "", this, new Object[0]); 
  }
  
  private native void n_onTimeUpdate(TimeAnimator paramTimeAnimator, long paramLong1, long paramLong2);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onTimeUpdate(TimeAnimator paramTimeAnimator, long paramLong1, long paramLong2) {
    n_onTimeUpdate(paramTimeAnimator, paramLong1, paramLong2);
  }
}


/* Location:              /home/fahim/Desktop/feabme2_jumperchess-dex2jar.jar!/mono/android/animation/TimeAnimator_TimeListenerImplementor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */