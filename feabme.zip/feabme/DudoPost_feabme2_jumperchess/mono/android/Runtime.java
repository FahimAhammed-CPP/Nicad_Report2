package mono.android;

public class Runtime {
  public static native void init(String paramString1, String[] paramArrayOfString1, String paramString2, String[] paramArrayOfString2, ClassLoader paramClassLoader, String paramString3, String[] paramArrayOfString3, String paramString4);
  
  public static native void register(String paramString1, Class paramClass, String paramString2);
}


/* Location:              /home/fahim/Desktop/feabme2_jumperchess-dex2jar.jar!/mono/android/Runtime.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */