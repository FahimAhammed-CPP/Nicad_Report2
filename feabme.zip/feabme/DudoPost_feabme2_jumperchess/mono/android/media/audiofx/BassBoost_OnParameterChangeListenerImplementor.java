package mono.android.media.audiofx;

import android.media.audiofx.BassBoost;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class BassBoost_OnParameterChangeListenerImplementor implements IGCUserPeer, BassBoost.OnParameterChangeListener {
  static final String __md_methods = "n_onParameterChange:(Landroid/media/audiofx/BassBoost;IIS)V:GetOnParameterChange_Landroid_media_audiofx_BassBoost_IISHandler:Android.Media.Audiofx.BassBoost/IOnParameterChangeListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Android.Media.Audiofx.BassBoost/IOnParameterChangeListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", BassBoost_OnParameterChangeListenerImplementor.class, __md_methods);
  }
  
  public BassBoost_OnParameterChangeListenerImplementor() throws Throwable {
    if (getClass() == BassBoost_OnParameterChangeListenerImplementor.class)
      TypeManager.Activate("Android.Media.Audiofx.BassBoost/IOnParameterChangeListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "", this, new Object[0]); 
  }
  
  private native void n_onParameterChange(BassBoost paramBassBoost, int paramInt1, int paramInt2, short paramShort);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onParameterChange(BassBoost paramBassBoost, int paramInt1, int paramInt2, short paramShort) {
    n_onParameterChange(paramBassBoost, paramInt1, paramInt2, paramShort);
  }
}


/* Location:              /home/fahim/Desktop/feabme2_jumperchess-dex2jar.jar!/mono/android/media/audiofx/BassBoost_OnParameterChangeListenerImplementor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */