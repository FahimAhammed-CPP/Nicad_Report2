package mono.android.media.audiofx;

import android.media.audiofx.Virtualizer;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class Virtualizer_OnParameterChangeListenerImplementor implements IGCUserPeer, Virtualizer.OnParameterChangeListener {
  static final String __md_methods = "n_onParameterChange:(Landroid/media/audiofx/Virtualizer;IIS)V:GetOnParameterChange_Landroid_media_audiofx_Virtualizer_IISHandler:Android.Media.Audiofx.Virtualizer/IOnParameterChangeListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Android.Media.Audiofx.Virtualizer/IOnParameterChangeListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", Virtualizer_OnParameterChangeListenerImplementor.class, __md_methods);
  }
  
  public Virtualizer_OnParameterChangeListenerImplementor() throws Throwable {
    if (getClass() == Virtualizer_OnParameterChangeListenerImplementor.class)
      TypeManager.Activate("Android.Media.Audiofx.Virtualizer/IOnParameterChangeListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "", this, new Object[0]); 
  }
  
  private native void n_onParameterChange(Virtualizer paramVirtualizer, int paramInt1, int paramInt2, short paramShort);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onParameterChange(Virtualizer paramVirtualizer, int paramInt1, int paramInt2, short paramShort) {
    n_onParameterChange(paramVirtualizer, paramInt1, paramInt2, paramShort);
  }
}


/* Location:              /home/fahim/Desktop/feabme2_jumperchess-dex2jar.jar!/mono/android/media/audiofx/Virtualizer_OnParameterChangeListenerImplementor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */