package mono.android.media;

import android.media.MediaScannerConnection;
import android.net.Uri;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class MediaScannerConnection_OnScanCompletedListenerImplementor implements IGCUserPeer, MediaScannerConnection.OnScanCompletedListener {
  static final String __md_methods = "n_onScanCompleted:(Ljava/lang/String;Landroid/net/Uri;)V:GetOnScanCompleted_Ljava_lang_String_Landroid_net_Uri_Handler:Android.Media.MediaScannerConnection/IOnScanCompletedListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Android.Media.MediaScannerConnection/IOnScanCompletedListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", MediaScannerConnection_OnScanCompletedListenerImplementor.class, __md_methods);
  }
  
  public MediaScannerConnection_OnScanCompletedListenerImplementor() throws Throwable {
    if (getClass() == MediaScannerConnection_OnScanCompletedListenerImplementor.class)
      TypeManager.Activate("Android.Media.MediaScannerConnection/IOnScanCompletedListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "", this, new Object[0]); 
  }
  
  private native void n_onScanCompleted(String paramString, Uri paramUri);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onScanCompleted(String paramString, Uri paramUri) {
    n_onScanCompleted(paramString, paramUri);
  }
}


/* Location:              /home/fahim/Desktop/feabme2_jumperchess-dex2jar.jar!/mono/android/media/MediaScannerConnection_OnScanCompletedListenerImplementor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */