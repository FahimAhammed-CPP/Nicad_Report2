package mono.android.location;

import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class LocationListenerImplementor implements IGCUserPeer, LocationListener {
  static final String __md_methods = "n_onLocationChanged:(Landroid/location/Location;)V:GetOnLocationChanged_Landroid_location_Location_Handler:Android.Locations.ILocationListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\nn_onProviderDisabled:(Ljava/lang/String;)V:GetOnProviderDisabled_Ljava_lang_String_Handler:Android.Locations.ILocationListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\nn_onProviderEnabled:(Ljava/lang/String;)V:GetOnProviderEnabled_Ljava_lang_String_Handler:Android.Locations.ILocationListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\nn_onStatusChanged:(Ljava/lang/String;ILandroid/os/Bundle;)V:GetOnStatusChanged_Ljava_lang_String_ILandroid_os_Bundle_Handler:Android.Locations.ILocationListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Android.Locations.ILocationListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", LocationListenerImplementor.class, __md_methods);
  }
  
  public LocationListenerImplementor() throws Throwable {
    if (getClass() == LocationListenerImplementor.class)
      TypeManager.Activate("Android.Locations.ILocationListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "", this, new Object[0]); 
  }
  
  private native void n_onLocationChanged(Location paramLocation);
  
  private native void n_onProviderDisabled(String paramString);
  
  private native void n_onProviderEnabled(String paramString);
  
  private native void n_onStatusChanged(String paramString, int paramInt, Bundle paramBundle);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onLocationChanged(Location paramLocation) {
    n_onLocationChanged(paramLocation);
  }
  
  public void onProviderDisabled(String paramString) {
    n_onProviderDisabled(paramString);
  }
  
  public void onProviderEnabled(String paramString) {
    n_onProviderEnabled(paramString);
  }
  
  public void onStatusChanged(String paramString, int paramInt, Bundle paramBundle) {
    n_onStatusChanged(paramString, paramInt, paramBundle);
  }
}


/* Location:              /home/fahim/Desktop/feabme2_jumperchess-dex2jar.jar!/mono/android/location/LocationListenerImplementor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */