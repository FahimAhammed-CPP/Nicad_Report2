package mono;

class MonoPackageManager_Resources {
  public static final String ApiPackageName;
  
  public static final String[] Assemblies = new String[] { "CheckersGameAndroid.dll", "SharedAll.dll", "TinkerAccountLibrary.dll", "Newtonsoft.Json.dll", "HtmlAgilityPack-PCL.dll" };
  
  public static final String[] Dependencies = new String[0];
  
  static {
    ApiPackageName = null;
  }
}


/* Location:              /home/fahim/Desktop/feabme2_jumperchess-dex2jar.jar!/mono/MonoPackageManager_Resources.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */