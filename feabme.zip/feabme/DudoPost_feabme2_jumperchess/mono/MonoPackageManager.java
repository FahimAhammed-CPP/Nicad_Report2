package mono;

import android.content.Context;
import android.os.Environment;
import java.io.File;
import java.util.Locale;
import mono.android.Runtime;

public class MonoPackageManager {
  static boolean initialized;
  
  static Object lock = new Object();
  
  public static void LoadApplication(Context paramContext, String paramString, String[] paramArrayOfString) {
    synchronized (lock) {
      if (!initialized) {
        System.loadLibrary("monodroid");
        Locale locale = Locale.getDefault();
        StringBuilder stringBuilder1 = new StringBuilder();
        this();
        String str2 = stringBuilder1.append(locale.getLanguage()).append("-").append(locale.getCountry()).toString();
        String str4 = paramContext.getFilesDir().getAbsolutePath();
        String str3 = paramContext.getCacheDir().getAbsolutePath();
        StringBuilder stringBuilder2 = new StringBuilder();
        this();
        String str5 = stringBuilder2.append((paramContext.getApplicationInfo()).dataDir).append("/lib").toString();
        ClassLoader classLoader = paramContext.getClassLoader();
        File file1 = new File();
        File file2 = Environment.getExternalStorageDirectory();
        StringBuilder stringBuilder3 = new StringBuilder();
        this();
        this(file2, stringBuilder3.append("Android/data/").append(paramContext.getPackageName()).append("/files/.__override__").toString());
        String str6 = file1.getAbsolutePath();
        String[] arrayOfString = MonoPackageManager_Resources.Assemblies;
        String str1 = paramContext.getPackageName();
        Runtime.init(str2, paramArrayOfString, paramString, new String[] { str4, str3, str5 }, classLoader, str6, arrayOfString, str1);
        initialized = true;
      } 
      return;
    } 
  }
  
  public static String getApiPackageName() {
    return MonoPackageManager_Resources.ApiPackageName;
  }
  
  public static String[] getAssemblies() {
    return MonoPackageManager_Resources.Assemblies;
  }
  
  public static String[] getDependencies() {
    return MonoPackageManager_Resources.Dependencies;
  }
}


/* Location:              /home/fahim/Desktop/feabme2_jumperchess-dex2jar.jar!/mono/MonoPackageManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */