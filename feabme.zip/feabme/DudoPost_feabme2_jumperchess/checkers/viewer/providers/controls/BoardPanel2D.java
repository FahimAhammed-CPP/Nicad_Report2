package checkers.viewer.providers.controls;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class BoardPanel2D extends View implements IGCUserPeer {
  static final String __md_methods = "n_onDraw:(Landroid/graphics/Canvas;)V:GetOnDraw_Landroid_graphics_Canvas_Handler\nn_onTouchEvent:(Landroid/view/MotionEvent;)Z:GetOnTouchEvent_Landroid_view_MotionEvent_Handler\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Checkers.Viewer.Providers.Controls.BoardPanel2D, CheckersGameAndroid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null", BoardPanel2D.class, __md_methods);
  }
  
  public BoardPanel2D(Context paramContext, AttributeSet paramAttributeSet) throws Throwable {
    super(paramContext, paramAttributeSet);
    if (getClass() == BoardPanel2D.class)
      TypeManager.Activate("Checkers.Viewer.Providers.Controls.BoardPanel2D, CheckersGameAndroid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null", "Android.Content.Context, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065:Android.Util.IAttributeSet, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", this, new Object[] { paramContext, paramAttributeSet }); 
  }
  
  public BoardPanel2D(Context paramContext, AttributeSet paramAttributeSet, int paramInt) throws Throwable {
    super(paramContext, paramAttributeSet, paramInt);
    if (getClass() == BoardPanel2D.class)
      TypeManager.Activate("Checkers.Viewer.Providers.Controls.BoardPanel2D, CheckersGameAndroid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null", "Android.Content.Context, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065:Android.Util.IAttributeSet, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065:System.Int32, mscorlib, Version=2.0.5.0, Culture=neutral, PublicKeyToken=7cec85d7bea7798e", this, new Object[] { paramContext, paramAttributeSet, Integer.valueOf(paramInt) }); 
  }
  
  private native void n_onDraw(Canvas paramCanvas);
  
  private native boolean n_onTouchEvent(MotionEvent paramMotionEvent);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onDraw(Canvas paramCanvas) {
    n_onDraw(paramCanvas);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    return n_onTouchEvent(paramMotionEvent);
  }
}


/* Location:              /home/fahim/Desktop/feabme2_jumperchess-dex2jar.jar!/checkers/viewer/providers/controls/BoardPanel2D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */