package checkers.multipeer.connection;

import android.app.Activity;
import android.os.Bundle;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class DeviceListActivity extends Activity implements IGCUserPeer {
  static final String __md_methods = "n_onCreate:(Landroid/os/Bundle;)V:GetOnCreate_Landroid_os_Bundle_Handler\nn_onDestroy:()V:GetOnDestroyHandler\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Checkers.Multipeer.Connection.DeviceListActivity, CheckersGameAndroid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null", DeviceListActivity.class, __md_methods);
  }
  
  public DeviceListActivity() throws Throwable {
    if (getClass() == DeviceListActivity.class)
      TypeManager.Activate("Checkers.Multipeer.Connection.DeviceListActivity, CheckersGameAndroid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null", "", this, new Object[0]); 
  }
  
  private native void n_onCreate(Bundle paramBundle);
  
  private native void n_onDestroy();
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onCreate(Bundle paramBundle) {
    n_onCreate(paramBundle);
  }
  
  public void onDestroy() {
    n_onDestroy();
  }
}


/* Location:              /home/fahim/Desktop/feabme2_jumperchess-dex2jar.jar!/checkers/multipeer/connection/DeviceListActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */