package checkers.multipeer.connection;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class DeviceListActivity_Receiver extends BroadcastReceiver implements IGCUserPeer {
  static final String __md_methods = "n_onReceive:(Landroid/content/Context;Landroid/content/Intent;)V:GetOnReceive_Landroid_content_Context_Landroid_content_Intent_Handler\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Checkers.Multipeer.Connection.DeviceListActivity/Receiver, CheckersGameAndroid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null", DeviceListActivity_Receiver.class, __md_methods);
  }
  
  public DeviceListActivity_Receiver() throws Throwable {
    if (getClass() == DeviceListActivity_Receiver.class)
      TypeManager.Activate("Checkers.Multipeer.Connection.DeviceListActivity/Receiver, CheckersGameAndroid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null", "", this, new Object[0]); 
  }
  
  public DeviceListActivity_Receiver(Activity paramActivity) throws Throwable {
    if (getClass() == DeviceListActivity_Receiver.class)
      TypeManager.Activate("Checkers.Multipeer.Connection.DeviceListActivity/Receiver, CheckersGameAndroid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null", "Android.App.Activity, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", this, new Object[] { paramActivity }); 
  }
  
  private native void n_onReceive(Context paramContext, Intent paramIntent);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    n_onReceive(paramContext, paramIntent);
  }
}


/* Location:              /home/fahim/Desktop/feabme2_jumperchess-dex2jar.jar!/checkers/multipeer/connection/DeviceListActivity_Receiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */