package com.tinker.jumperchess;

public final class R {
  public static final class attr {}
  
  public static final class drawable {
    public static final int back_button_normal = 2130837504;
    
    public static final int back_button_press = 2130837505;
    
    public static final int background = 2130837506;
    
    public static final int bg_back_btn = 2130837507;
    
    public static final int bg_connect_btn = 2130837508;
    
    public static final int bg_create_btn = 2130837509;
    
    public static final int bg_info_btn = 2130837510;
    
    public static final int bg_menu_btn = 2130837511;
    
    public static final int bg_multiple_btn = 2130837512;
    
    public static final int bg_options_btn = 2130837513;
    
    public static final int bg_single_btn = 2130837514;
    
    public static final int black = 2130837515;
    
    public static final int black_btn = 2130837516;
    
    public static final int blackking = 2130837517;
    
    public static final int color_done_tv = 2130837518;
    
    public static final int connect_button_normal = 2130837519;
    
    public static final int connect_button_press = 2130837520;
    
    public static final int create_button_normal = 2130837521;
    
    public static final int create_button_press = 2130837522;
    
    public static final int demo_btn = 2130837523;
    
    public static final int empty_screen = 2130837524;
    
    public static final int emptybackground = 2130837525;
    
    public static final int exit_btn = 2130837526;
    
    public static final int hiresico2n = 2130837527;
    
    public static final int icon = 2130837528;
    
    public static final int images = 2130837529;
    
    public static final int info_button_normal = 2130837530;
    
    public static final int info_button_press = 2130837531;
    
    public static final int loading = 2130837532;
    
    public static final int mainboard = 2130837533;
    
    public static final int menu_button_normal = 2130837534;
    
    public static final int menu_button_press = 2130837535;
    
    public static final int multiple_button_normal = 2130837536;
    
    public static final int multiple_button_press = 2130837537;
    
    public static final int options_button_normal = 2130837538;
    
    public static final int options_button_press = 2130837539;
    
    public static final int single_button_normal = 2130837540;
    
    public static final int single_button_press = 2130837541;
    
    public static final int single_screen = 2130837542;
    
    public static final int splash = 2130837543;
    
    public static final int start_btn = 2130837544;
    
    public static final int tunka = 2130837545;
    
    public static final int undo_btn = 2130837546;
    
    public static final int white = 2130837547;
    
    public static final int white_btn = 2130837548;
    
    public static final int whiteking = 2130837549;
  }
  
  public static final class id {
    public static final int btnInfo = 2131230733;
    
    public static final int btnMenu = 2131230741;
    
    public static final int btnMultiple = 2131230731;
    
    public static final int btnOptions = 2131230732;
    
    public static final int btnSingle = 2131230730;
    
    public static final int button_scan = 2131230724;
    
    public static final int container = 2131230740;
    
    public static final int linearLayout1 = 2131230725;
    
    public static final int linearLayout2 = 2131230734;
    
    public static final int login = 2131230745;
    
    public static final int logo = 2131230742;
    
    public static final int new_devices = 2131230723;
    
    public static final int paired_devices = 2131230721;
    
    public static final int password = 2131230744;
    
    public static final int relativeLayout1 = 2131230726;
    
    public static final int sbLevel = 2131230738;
    
    public static final int scan = 2131230746;
    
    public static final int swFirst = 2131230736;
    
    public static final int textView1 = 2131230735;
    
    public static final int textView2 = 2131230737;
    
    public static final int textView5 = 2131230727;
    
    public static final int textView6 = 2131230729;
    
    public static final int title_new_devices = 2131230722;
    
    public static final int title_paired_devices = 2131230720;
    
    public static final int tvDone = 2131230728;
    
    public static final int tvLevel = 2131230739;
    
    public static final int userName = 2131230743;
  }
  
  public static final class layout {
    public static final int device_list = 2130903040;
    
    public static final int device_name = 2130903041;
    
    public static final int info = 2130903042;
    
    public static final int main = 2130903043;
    
    public static final int options = 2130903044;
    
    public static final int single = 2130903045;
    
    public static final int tinkerlogin = 2130903046;
  }
  
  public static final class menu {
    public static final int option_menu = 2131165184;
  }
  
  public static final class raw {
    public static final int gamewin = 2130968576;
    
    public static final int piece_drop1 = 2130968577;
    
    public static final int piece_drop2 = 2130968578;
  }
  
  public static final class string {
    public static final int ApplicationName = 2131034113;
    
    public static final int Hello = 2131034112;
    
    public static final int app_name = 2131034114;
    
    public static final int bt_not_enabled_leaving = 2131034117;
    
    public static final int button_scan = 2131034127;
    
    public static final int connect = 2131034128;
    
    public static final int discoverable = 2131034129;
    
    public static final int none_found = 2131034124;
    
    public static final int none_paired = 2131034123;
    
    public static final int not_connected = 2131034116;
    
    public static final int scanning = 2131034121;
    
    public static final int select_device = 2131034122;
    
    public static final int send = 2131034115;
    
    public static final int title_connected_to = 2131034119;
    
    public static final int title_connecting = 2131034118;
    
    public static final int title_not_connected = 2131034120;
    
    public static final int title_other_devices = 2131034126;
    
    public static final int title_paired_devices = 2131034125;
  }
  
  public static final class style {
    public static final int Theme_Splash = 2131099648;
  }
}


/* Location:              /home/fahim/Desktop/feabme2_jumperchess-dex2jar.jar!/com/tinker/jumperchess/R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */