package checkersgameandroid;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class SplashActivity_MyHandler extends Handler implements IGCUserPeer {
  static final String __md_methods = "n_handleMessage:(Landroid/os/Message;)V:GetHandleMessage_Landroid_os_Message_Handler\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("CheckersGameAndroid.SplashActivity/MyHandler, CheckersGameAndroid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null", SplashActivity_MyHandler.class, __md_methods);
  }
  
  public SplashActivity_MyHandler() throws Throwable {
    if (getClass() == SplashActivity_MyHandler.class)
      TypeManager.Activate("CheckersGameAndroid.SplashActivity/MyHandler, CheckersGameAndroid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null", "", this, new Object[0]); 
  }
  
  public SplashActivity_MyHandler(Looper paramLooper) throws Throwable {
    super(paramLooper);
    if (getClass() == SplashActivity_MyHandler.class)
      TypeManager.Activate("CheckersGameAndroid.SplashActivity/MyHandler, CheckersGameAndroid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null", "Android.OS.Looper, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", this, new Object[] { paramLooper }); 
  }
  
  public SplashActivity_MyHandler(SplashActivity paramSplashActivity) throws Throwable {
    if (getClass() == SplashActivity_MyHandler.class)
      TypeManager.Activate("CheckersGameAndroid.SplashActivity/MyHandler, CheckersGameAndroid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null", "CheckersGameAndroid.SplashActivity, CheckersGameAndroid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null", this, new Object[] { paramSplashActivity }); 
  }
  
  private native void n_handleMessage(Message paramMessage);
  
  public void handleMessage(Message paramMessage) {
    n_handleMessage(paramMessage);
  }
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
}


/* Location:              /home/fahim/Desktop/feabme2_jumperchess-dex2jar.jar!/checkersgameandroid/SplashActivity_MyHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */