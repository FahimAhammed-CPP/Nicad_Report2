package checkersgameandroid;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class MultiActivity extends Activity implements IGCUserPeer {
  static final String __md_methods = "n_onCreate:(Landroid/os/Bundle;)V:GetOnCreate_Landroid_os_Bundle_Handler\nn_onStart:()V:GetOnStartHandler\nn_onResume:()V:GetOnResumeHandler\nn_onPause:()V:GetOnPauseHandler\nn_onStop:()V:GetOnStopHandler\nn_onDestroy:()V:GetOnDestroyHandler\nn_onActivityResult:(IILandroid/content/Intent;)V:GetOnActivityResult_IILandroid_content_Intent_Handler\nn_onCreateOptionsMenu:(Landroid/view/Menu;)Z:GetOnCreateOptionsMenu_Landroid_view_Menu_Handler\nn_onOptionsItemSelected:(Landroid/view/MenuItem;)Z:GetOnOptionsItemSelected_Landroid_view_MenuItem_Handler\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("CheckersGameAndroid.MultiActivity, CheckersGameAndroid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null", MultiActivity.class, __md_methods);
  }
  
  public MultiActivity() throws Throwable {
    if (getClass() == MultiActivity.class)
      TypeManager.Activate("CheckersGameAndroid.MultiActivity, CheckersGameAndroid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null", "", this, new Object[0]); 
  }
  
  private native void n_onActivityResult(int paramInt1, int paramInt2, Intent paramIntent);
  
  private native void n_onCreate(Bundle paramBundle);
  
  private native boolean n_onCreateOptionsMenu(Menu paramMenu);
  
  private native void n_onDestroy();
  
  private native boolean n_onOptionsItemSelected(MenuItem paramMenuItem);
  
  private native void n_onPause();
  
  private native void n_onResume();
  
  private native void n_onStart();
  
  private native void n_onStop();
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    n_onActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  public void onCreate(Bundle paramBundle) {
    n_onCreate(paramBundle);
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    return n_onCreateOptionsMenu(paramMenu);
  }
  
  public void onDestroy() {
    n_onDestroy();
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    return n_onOptionsItemSelected(paramMenuItem);
  }
  
  public void onPause() {
    n_onPause();
  }
  
  public void onResume() {
    n_onResume();
  }
  
  public void onStart() {
    n_onStart();
  }
  
  public void onStop() {
    n_onStop();
  }
}


/* Location:              /home/fahim/Desktop/feabme2_jumperchess-dex2jar.jar!/checkersgameandroid/MultiActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */