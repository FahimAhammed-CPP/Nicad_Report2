package mono;

class MonoPackageManager_Resources {
  public static final String ApiPackageName;
  
  public static final String[] Assemblies = new String[] { 
      "CowboyAdventure.dll", "HtmlAgilityPack-PCL.dll", "MonoGame.Framework.dll", "Newtonsoft.Json.dll", "TinkerAccountLibrary.dll", "System.Diagnostics.Tracing.dll", "System.Reflection.Emit.dll", "System.Reflection.Emit.ILGeneration.dll", "System.Reflection.Emit.Lightweight.dll", "System.ServiceModel.Security.dll", 
      "System.Threading.Timer.dll" };
  
  public static final String[] Dependencies = new String[0];
  
  static {
    ApiPackageName = null;
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/mono/MonoPackageManager_Resources.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */