package mono.android.app;

import android.app.Application;
import android.content.Context;

public class Application extends Application {
  static Context Context;
  
  public Application() {
    Context = (Context)this;
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/mono/android/app/Application.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */