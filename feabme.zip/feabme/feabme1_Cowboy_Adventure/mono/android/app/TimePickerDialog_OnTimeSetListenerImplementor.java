package mono.android.app;

import android.app.TimePickerDialog;
import android.widget.TimePicker;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class TimePickerDialog_OnTimeSetListenerImplementor implements IGCUserPeer, TimePickerDialog.OnTimeSetListener {
  static final String __md_methods = "n_onTimeSet:(Landroid/widget/TimePicker;II)V:GetOnTimeSet_Landroid_widget_TimePicker_IIHandler:Android.App.TimePickerDialog/IOnTimeSetListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Android.App.TimePickerDialog/IOnTimeSetListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", TimePickerDialog_OnTimeSetListenerImplementor.class, __md_methods);
  }
  
  public TimePickerDialog_OnTimeSetListenerImplementor() throws Throwable {
    if (getClass() == TimePickerDialog_OnTimeSetListenerImplementor.class)
      TypeManager.Activate("Android.App.TimePickerDialog/IOnTimeSetListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "", this, new Object[0]); 
  }
  
  private native void n_onTimeSet(TimePicker paramTimePicker, int paramInt1, int paramInt2);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onTimeSet(TimePicker paramTimePicker, int paramInt1, int paramInt2) {
    n_onTimeSet(paramTimePicker, paramInt1, paramInt2);
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/mono/android/app/TimePickerDialog_OnTimeSetListenerImplementor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */