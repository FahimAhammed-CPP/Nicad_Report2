package mono.android.drm;

import android.drm.DrmErrorEvent;
import android.drm.DrmManagerClient;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class DrmManagerClient_OnErrorListenerImplementor implements IGCUserPeer, DrmManagerClient.OnErrorListener {
  static final String __md_methods = "n_onError:(Landroid/drm/DrmManagerClient;Landroid/drm/DrmErrorEvent;)V:GetOnError_Landroid_drm_DrmManagerClient_Landroid_drm_DrmErrorEvent_Handler:Android.Drm.DrmManagerClient/IOnErrorListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Android.Drm.DrmManagerClient/IOnErrorListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", DrmManagerClient_OnErrorListenerImplementor.class, __md_methods);
  }
  
  public DrmManagerClient_OnErrorListenerImplementor() throws Throwable {
    if (getClass() == DrmManagerClient_OnErrorListenerImplementor.class)
      TypeManager.Activate("Android.Drm.DrmManagerClient/IOnErrorListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "", this, new Object[0]); 
  }
  
  private native void n_onError(DrmManagerClient paramDrmManagerClient, DrmErrorEvent paramDrmErrorEvent);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onError(DrmManagerClient paramDrmManagerClient, DrmErrorEvent paramDrmErrorEvent) {
    n_onError(paramDrmManagerClient, paramDrmErrorEvent);
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/mono/android/drm/DrmManagerClient_OnErrorListenerImplementor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */