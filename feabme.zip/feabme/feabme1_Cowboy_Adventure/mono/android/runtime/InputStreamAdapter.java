package mono.android.runtime;

import java.io.InputStream;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class InputStreamAdapter extends InputStream implements IGCUserPeer {
  static final String __md_methods = "n_close:()V:GetCloseHandler\nn_read:()I:GetReadHandler\nn_read:([B)I:GetRead_arrayBHandler\nn_read:([BII)I:GetRead_arrayBIIHandler\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Android.Runtime.InputStreamAdapter, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", InputStreamAdapter.class, __md_methods);
  }
  
  public InputStreamAdapter() throws Throwable {
    if (getClass() == InputStreamAdapter.class)
      TypeManager.Activate("Android.Runtime.InputStreamAdapter, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "", this, new Object[0]); 
  }
  
  private native void n_close();
  
  private native int n_read();
  
  private native int n_read(byte[] paramArrayOfbyte);
  
  private native int n_read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
  
  public void close() {
    n_close();
  }
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public int read() {
    return n_read();
  }
  
  public int read(byte[] paramArrayOfbyte) {
    return n_read(paramArrayOfbyte);
  }
  
  public int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    return n_read(paramArrayOfbyte, paramInt1, paramInt2);
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/mono/android/runtime/InputStreamAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */