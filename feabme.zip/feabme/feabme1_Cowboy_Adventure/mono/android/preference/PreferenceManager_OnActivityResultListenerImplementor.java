package mono.android.preference;

import android.content.Intent;
import android.preference.PreferenceManager;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class PreferenceManager_OnActivityResultListenerImplementor implements IGCUserPeer, PreferenceManager.OnActivityResultListener {
  static final String __md_methods = "n_onActivityResult:(IILandroid/content/Intent;)Z:GetOnActivityResult_IILandroid_content_Intent_Handler:Android.Preferences.PreferenceManager/IOnActivityResultListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Android.Preferences.PreferenceManager/IOnActivityResultListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", PreferenceManager_OnActivityResultListenerImplementor.class, __md_methods);
  }
  
  public PreferenceManager_OnActivityResultListenerImplementor() throws Throwable {
    if (getClass() == PreferenceManager_OnActivityResultListenerImplementor.class)
      TypeManager.Activate("Android.Preferences.PreferenceManager/IOnActivityResultListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "", this, new Object[0]); 
  }
  
  private native boolean n_onActivityResult(int paramInt1, int paramInt2, Intent paramIntent);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public boolean onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    return n_onActivityResult(paramInt1, paramInt2, paramIntent);
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/mono/android/preference/PreferenceManager_OnActivityResultListenerImplementor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */