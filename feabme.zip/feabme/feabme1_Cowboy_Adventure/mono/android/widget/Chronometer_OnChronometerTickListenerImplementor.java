package mono.android.widget;

import android.widget.Chronometer;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class Chronometer_OnChronometerTickListenerImplementor implements IGCUserPeer, Chronometer.OnChronometerTickListener {
  static final String __md_methods = "n_onChronometerTick:(Landroid/widget/Chronometer;)V:GetOnChronometerTick_Landroid_widget_Chronometer_Handler:Android.Widget.Chronometer/IOnChronometerTickListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Android.Widget.Chronometer/IOnChronometerTickListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", Chronometer_OnChronometerTickListenerImplementor.class, __md_methods);
  }
  
  public Chronometer_OnChronometerTickListenerImplementor() throws Throwable {
    if (getClass() == Chronometer_OnChronometerTickListenerImplementor.class)
      TypeManager.Activate("Android.Widget.Chronometer/IOnChronometerTickListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "", this, new Object[0]); 
  }
  
  private native void n_onChronometerTick(Chronometer paramChronometer);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onChronometerTick(Chronometer paramChronometer) {
    n_onChronometerTick(paramChronometer);
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/mono/android/widget/Chronometer_OnChronometerTickListenerImplementor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */