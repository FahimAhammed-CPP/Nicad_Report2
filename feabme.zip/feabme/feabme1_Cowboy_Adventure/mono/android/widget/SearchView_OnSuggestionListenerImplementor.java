package mono.android.widget;

import android.widget.SearchView;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class SearchView_OnSuggestionListenerImplementor implements IGCUserPeer, SearchView.OnSuggestionListener {
  static final String __md_methods = "n_onSuggestionClick:(I)Z:GetOnSuggestionClick_IHandler:Android.Widget.SearchView/IOnSuggestionListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\nn_onSuggestionSelect:(I)Z:GetOnSuggestionSelect_IHandler:Android.Widget.SearchView/IOnSuggestionListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Android.Widget.SearchView/IOnSuggestionListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", SearchView_OnSuggestionListenerImplementor.class, __md_methods);
  }
  
  public SearchView_OnSuggestionListenerImplementor() throws Throwable {
    if (getClass() == SearchView_OnSuggestionListenerImplementor.class)
      TypeManager.Activate("Android.Widget.SearchView/IOnSuggestionListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "", this, new Object[0]); 
  }
  
  private native boolean n_onSuggestionClick(int paramInt);
  
  private native boolean n_onSuggestionSelect(int paramInt);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public boolean onSuggestionClick(int paramInt) {
    return n_onSuggestionClick(paramInt);
  }
  
  public boolean onSuggestionSelect(int paramInt) {
    return n_onSuggestionSelect(paramInt);
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/mono/android/widget/SearchView_OnSuggestionListenerImplementor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */