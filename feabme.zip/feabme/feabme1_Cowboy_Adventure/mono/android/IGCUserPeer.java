package mono.android;

public interface IGCUserPeer {
  void monodroidAddReference(Object paramObject);
  
  void monodroidClearReferences();
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/mono/android/IGCUserPeer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */