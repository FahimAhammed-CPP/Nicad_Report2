package mono.android.media;

import android.media.MediaPlayer;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class MediaPlayer_OnPreparedListenerImplementor implements IGCUserPeer, MediaPlayer.OnPreparedListener {
  static final String __md_methods = "n_onPrepared:(Landroid/media/MediaPlayer;)V:GetOnPrepared_Landroid_media_MediaPlayer_Handler:Android.Media.MediaPlayer/IOnPreparedListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Android.Media.MediaPlayer/IOnPreparedListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", MediaPlayer_OnPreparedListenerImplementor.class, __md_methods);
  }
  
  public MediaPlayer_OnPreparedListenerImplementor() throws Throwable {
    if (getClass() == MediaPlayer_OnPreparedListenerImplementor.class)
      TypeManager.Activate("Android.Media.MediaPlayer/IOnPreparedListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "", this, new Object[0]); 
  }
  
  private native void n_onPrepared(MediaPlayer paramMediaPlayer);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onPrepared(MediaPlayer paramMediaPlayer) {
    n_onPrepared(paramMediaPlayer);
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/mono/android/media/MediaPlayer_OnPreparedListenerImplementor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */