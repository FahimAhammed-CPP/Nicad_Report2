package mono.android.content;

import android.content.Loader;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class Loader_OnLoadCompleteListenerImplementor implements IGCUserPeer, Loader.OnLoadCompleteListener {
  static final String __md_methods = "n_onLoadComplete:(Landroid/content/Loader;Ljava/lang/Object;)V:GetOnLoadComplete_Landroid_content_Loader_Ljava_lang_Object_Handler:Android.Content.Loader/IOnLoadCompleteListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Android.Content.Loader/IOnLoadCompleteListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", Loader_OnLoadCompleteListenerImplementor.class, __md_methods);
  }
  
  public Loader_OnLoadCompleteListenerImplementor() throws Throwable {
    if (getClass() == Loader_OnLoadCompleteListenerImplementor.class)
      TypeManager.Activate("Android.Content.Loader/IOnLoadCompleteListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "", this, new Object[0]); 
  }
  
  private native void n_onLoadComplete(Loader paramLoader, Object paramObject);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onLoadComplete(Loader paramLoader, Object paramObject) {
    n_onLoadComplete(paramLoader, paramObject);
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/mono/android/content/Loader_OnLoadCompleteListenerImplementor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */