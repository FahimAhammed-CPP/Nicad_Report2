package mono.android.view;

import android.view.ViewTreeObserver;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class ViewTreeObserver_OnGlobalLayoutListenerImplementor implements IGCUserPeer, ViewTreeObserver.OnGlobalLayoutListener {
  static final String __md_methods = "n_onGlobalLayout:()V:GetOnGlobalLayoutHandler:Android.Views.ViewTreeObserver/IOnGlobalLayoutListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Android.Views.ViewTreeObserver/IOnGlobalLayoutListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", ViewTreeObserver_OnGlobalLayoutListenerImplementor.class, __md_methods);
  }
  
  public ViewTreeObserver_OnGlobalLayoutListenerImplementor() throws Throwable {
    if (getClass() == ViewTreeObserver_OnGlobalLayoutListenerImplementor.class)
      TypeManager.Activate("Android.Views.ViewTreeObserver/IOnGlobalLayoutListenerImplementor, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "", this, new Object[0]); 
  }
  
  private native void n_onGlobalLayout();
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onGlobalLayout() {
    n_onGlobalLayout();
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/mono/android/view/ViewTreeObserver_OnGlobalLayoutListenerImplementor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */