package mono;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.net.Uri;

public class MonoRuntimeProvider extends ContentProvider {
  public void attachInfo(Context paramContext, ProviderInfo paramProviderInfo) {
    MonoPackageManager.LoadApplication(paramContext, (paramContext.getApplicationInfo()).dataDir, new String[] { (paramContext.getApplicationInfo()).sourceDir });
    super.attachInfo(paramContext, paramProviderInfo);
  }
  
  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    throw new RuntimeException("This operation is not supported.");
  }
  
  public String getType(Uri paramUri) {
    throw new RuntimeException("This operation is not supported.");
  }
  
  public Uri insert(Uri paramUri, ContentValues paramContentValues) {
    throw new RuntimeException("This operation is not supported.");
  }
  
  public boolean onCreate() {
    return true;
  }
  
  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    throw new RuntimeException("This operation is not supported.");
  }
  
  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    throw new RuntimeException("This operation is not supported.");
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/mono/MonoRuntimeProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */