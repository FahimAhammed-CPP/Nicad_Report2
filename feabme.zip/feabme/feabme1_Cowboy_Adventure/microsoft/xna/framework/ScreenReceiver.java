package microsoft.xna.framework;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class ScreenReceiver extends BroadcastReceiver implements IGCUserPeer {
  static final String __md_methods = "n_onReceive:(Landroid/content/Context;Landroid/content/Intent;)V:GetOnReceive_Landroid_content_Context_Landroid_content_Intent_Handler\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Microsoft.Xna.Framework.ScreenReceiver, MonoGame.Framework, Version=3.3.0.2238, Culture=neutral, PublicKeyToken=null", ScreenReceiver.class, __md_methods);
  }
  
  public ScreenReceiver() throws Throwable {
    if (getClass() == ScreenReceiver.class)
      TypeManager.Activate("Microsoft.Xna.Framework.ScreenReceiver, MonoGame.Framework, Version=3.3.0.2238, Culture=neutral, PublicKeyToken=null", "", this, new Object[0]); 
  }
  
  private native void n_onReceive(Context paramContext, Intent paramIntent);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    n_onReceive(paramContext, paramIntent);
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/microsoft/xna/framework/ScreenReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */