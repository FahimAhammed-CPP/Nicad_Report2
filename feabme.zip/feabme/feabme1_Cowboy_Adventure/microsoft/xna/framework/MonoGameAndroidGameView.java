package microsoft.xna.framework;

import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.View;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;
import opentk_1_0.platform.android.AndroidGameView;

public class MonoGameAndroidGameView extends AndroidGameView implements IGCUserPeer, View.OnTouchListener, SurfaceHolder.Callback {
  static final String __md_methods = "n_onKeyDown:(ILandroid/view/KeyEvent;)Z:GetOnKeyDown_ILandroid_view_KeyEvent_Handler\nn_onKeyUp:(ILandroid/view/KeyEvent;)Z:GetOnKeyUp_ILandroid_view_KeyEvent_Handler\nn_onTouch:(Landroid/view/View;Landroid/view/MotionEvent;)Z:GetOnTouch_Landroid_view_View_Landroid_view_MotionEvent_Handler:Android.Views.View/IOnTouchListenerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\nn_surfaceChanged:(Landroid/view/SurfaceHolder;III)V:GetSurfaceChanged_Landroid_view_SurfaceHolder_IIIHandler:Android.Views.ISurfaceHolderCallbackInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\nn_surfaceCreated:(Landroid/view/SurfaceHolder;)V:GetSurfaceCreated_Landroid_view_SurfaceHolder_Handler:Android.Views.ISurfaceHolderCallbackInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\nn_surfaceDestroyed:(Landroid/view/SurfaceHolder;)V:GetSurfaceDestroyed_Landroid_view_SurfaceHolder_Handler:Android.Views.ISurfaceHolderCallbackInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Microsoft.Xna.Framework.MonoGameAndroidGameView, MonoGame.Framework, Version=3.3.0.2238, Culture=neutral, PublicKeyToken=null", MonoGameAndroidGameView.class, __md_methods);
  }
  
  public MonoGameAndroidGameView(Context paramContext) throws Throwable {
    super(paramContext);
    if (getClass() == MonoGameAndroidGameView.class)
      TypeManager.Activate("Microsoft.Xna.Framework.MonoGameAndroidGameView, MonoGame.Framework, Version=3.3.0.2238, Culture=neutral, PublicKeyToken=null", "Android.Content.Context, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", this, new Object[] { paramContext }); 
  }
  
  public MonoGameAndroidGameView(Context paramContext, AttributeSet paramAttributeSet) throws Throwable {
    super(paramContext, paramAttributeSet);
    if (getClass() == MonoGameAndroidGameView.class)
      TypeManager.Activate("Microsoft.Xna.Framework.MonoGameAndroidGameView, MonoGame.Framework, Version=3.3.0.2238, Culture=neutral, PublicKeyToken=null", "Android.Content.Context, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065:Android.Util.IAttributeSet, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", this, new Object[] { paramContext, paramAttributeSet }); 
  }
  
  public MonoGameAndroidGameView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) throws Throwable {
    super(paramContext, paramAttributeSet, paramInt);
    if (getClass() == MonoGameAndroidGameView.class)
      TypeManager.Activate("Microsoft.Xna.Framework.MonoGameAndroidGameView, MonoGame.Framework, Version=3.3.0.2238, Culture=neutral, PublicKeyToken=null", "Android.Content.Context, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065:Android.Util.IAttributeSet, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065:System.Int32, mscorlib, Version=2.0.5.0, Culture=neutral, PublicKeyToken=7cec85d7bea7798e", this, new Object[] { paramContext, paramAttributeSet, Integer.valueOf(paramInt) }); 
  }
  
  private native boolean n_onKeyDown(int paramInt, KeyEvent paramKeyEvent);
  
  private native boolean n_onKeyUp(int paramInt, KeyEvent paramKeyEvent);
  
  private native boolean n_onTouch(View paramView, MotionEvent paramMotionEvent);
  
  private native void n_surfaceChanged(SurfaceHolder paramSurfaceHolder, int paramInt1, int paramInt2, int paramInt3);
  
  private native void n_surfaceCreated(SurfaceHolder paramSurfaceHolder);
  
  private native void n_surfaceDestroyed(SurfaceHolder paramSurfaceHolder);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return n_onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    return n_onKeyUp(paramInt, paramKeyEvent);
  }
  
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent) {
    return n_onTouch(paramView, paramMotionEvent);
  }
  
  public void surfaceChanged(SurfaceHolder paramSurfaceHolder, int paramInt1, int paramInt2, int paramInt3) {
    n_surfaceChanged(paramSurfaceHolder, paramInt1, paramInt2, paramInt3);
  }
  
  public void surfaceCreated(SurfaceHolder paramSurfaceHolder) {
    n_surfaceCreated(paramSurfaceHolder);
  }
  
  public void surfaceDestroyed(SurfaceHolder paramSurfaceHolder) {
    n_surfaceDestroyed(paramSurfaceHolder);
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/microsoft/xna/framework/MonoGameAndroidGameView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */