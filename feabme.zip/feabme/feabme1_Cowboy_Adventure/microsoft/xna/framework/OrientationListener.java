package microsoft.xna.framework;

import android.content.Context;
import android.view.OrientationEventListener;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class OrientationListener extends OrientationEventListener implements IGCUserPeer {
  static final String __md_methods = "n_onOrientationChanged:(I)V:GetOnOrientationChanged_IHandler\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Microsoft.Xna.Framework.OrientationListener, MonoGame.Framework, Version=3.3.0.2238, Culture=neutral, PublicKeyToken=null", OrientationListener.class, __md_methods);
  }
  
  public OrientationListener(Context paramContext, int paramInt) throws Throwable {
    super(paramContext, paramInt);
    if (getClass() == OrientationListener.class)
      TypeManager.Activate("Microsoft.Xna.Framework.OrientationListener, MonoGame.Framework, Version=3.3.0.2238, Culture=neutral, PublicKeyToken=null", "Android.Content.Context, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065:Android.Hardware.SensorDelay, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", this, new Object[] { paramContext, Integer.valueOf(paramInt) }); 
  }
  
  private native void n_onOrientationChanged(int paramInt);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onOrientationChanged(int paramInt) {
    n_onOrientationChanged(paramInt);
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/microsoft/xna/framework/OrientationListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */