package cowboyadventure;

import android.app.Activity;
import android.os.Bundle;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class HomeActivity extends Activity implements IGCUserPeer {
  static final String __md_methods = "n_onCreate:(Landroid/os/Bundle;)V:GetOnCreate_Landroid_os_Bundle_Handler\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("CowboyAdventure.HomeActivity, CowboyAdventure, Version=3.3.0.2238, Culture=neutral, PublicKeyToken=null", HomeActivity.class, __md_methods);
  }
  
  public HomeActivity() throws Throwable {
    if (getClass() == HomeActivity.class)
      TypeManager.Activate("CowboyAdventure.HomeActivity, CowboyAdventure, Version=3.3.0.2238, Culture=neutral, PublicKeyToken=null", "", this, new Object[0]); 
  }
  
  private native void n_onCreate(Bundle paramBundle);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void onCreate(Bundle paramBundle) {
    n_onCreate(paramBundle);
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/cowboyadventure/HomeActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */