package android.runtime;

import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class JavaProxyThrowable extends Throwable implements IGCUserPeer {
  static final String __md_methods = "";
  
  ArrayList refList;
  
  static {
    Runtime.register("Android.Runtime.JavaProxyThrowable, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", JavaProxyThrowable.class, __md_methods);
  }
  
  public JavaProxyThrowable() throws Throwable {
    if (getClass() == JavaProxyThrowable.class)
      TypeManager.Activate("Android.Runtime.JavaProxyThrowable, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "", this, new Object[0]); 
  }
  
  public JavaProxyThrowable(String paramString) throws Throwable {
    super(paramString);
    if (getClass() == JavaProxyThrowable.class)
      TypeManager.Activate("Android.Runtime.JavaProxyThrowable, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "System.String, mscorlib, Version=2.0.5.0, Culture=neutral, PublicKeyToken=7cec85d7bea7798e", this, new Object[] { paramString }); 
  }
  
  public JavaProxyThrowable(String paramString, Throwable paramThrowable) throws Throwable {
    super(paramString, paramThrowable);
    if (getClass() == JavaProxyThrowable.class)
      TypeManager.Activate("Android.Runtime.JavaProxyThrowable, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "System.String, mscorlib, Version=2.0.5.0, Culture=neutral, PublicKeyToken=7cec85d7bea7798e:Java.Lang.Throwable, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", this, new Object[] { paramString, paramThrowable }); 
  }
  
  public JavaProxyThrowable(Throwable paramThrowable) throws Throwable {
    super(paramThrowable);
    if (getClass() == JavaProxyThrowable.class)
      TypeManager.Activate("Android.Runtime.JavaProxyThrowable, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "Java.Lang.Throwable, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", this, new Object[] { paramThrowable }); 
  }
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/android/runtime/JavaProxyThrowable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */