package android.runtime;

import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public class UncaughtExceptionHandler implements IGCUserPeer, Thread.UncaughtExceptionHandler {
  static final String __md_methods = "n_uncaughtException:(Ljava/lang/Thread;Ljava/lang/Throwable;)V:GetUncaughtException_Ljava_lang_Thread_Ljava_lang_Throwable_Handler:Java.Lang.Thread/IUncaughtExceptionHandlerInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("Android.Runtime.UncaughtExceptionHandler, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", UncaughtExceptionHandler.class, __md_methods);
  }
  
  public UncaughtExceptionHandler() throws Throwable {
    if (getClass() == UncaughtExceptionHandler.class)
      TypeManager.Activate("Android.Runtime.UncaughtExceptionHandler, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "", this, new Object[0]); 
  }
  
  public UncaughtExceptionHandler(Thread.UncaughtExceptionHandler paramUncaughtExceptionHandler) throws Throwable {
    if (getClass() == UncaughtExceptionHandler.class)
      TypeManager.Activate("Android.Runtime.UncaughtExceptionHandler, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "Java.Lang.Thread/IUncaughtExceptionHandler, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", this, new Object[] { paramUncaughtExceptionHandler }); 
  }
  
  private native void n_uncaughtException(Thread paramThread, Throwable paramThrowable);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void uncaughtException(Thread paramThread, Throwable paramThrowable) {
    n_uncaughtException(paramThread, paramThrowable);
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/android/runtime/UncaughtExceptionHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */