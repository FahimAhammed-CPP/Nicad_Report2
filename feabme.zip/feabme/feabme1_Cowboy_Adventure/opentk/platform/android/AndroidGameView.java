package opentk.platform.android;

import android.content.Context;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;
import opentk.GameViewBase;

public class AndroidGameView extends GameViewBase implements IGCUserPeer, SurfaceHolder.Callback {
  static final String __md_methods = "n_surfaceChanged:(Landroid/view/SurfaceHolder;III)V:GetSurfaceChanged_Landroid_view_SurfaceHolder_IIIHandler:Android.Views.ISurfaceHolderCallbackInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\nn_surfaceCreated:(Landroid/view/SurfaceHolder;)V:GetSurfaceCreated_Landroid_view_SurfaceHolder_Handler:Android.Views.ISurfaceHolderCallbackInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\nn_surfaceDestroyed:(Landroid/view/SurfaceHolder;)V:GetSurfaceDestroyed_Landroid_view_SurfaceHolder_Handler:Android.Views.ISurfaceHolderCallbackInvoker, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null\n";
  
  ArrayList refList;
  
  static {
    Runtime.register("OpenTK.Platform.Android.AndroidGameView, OpenTK, Version=0.9.9.3, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", AndroidGameView.class, __md_methods);
  }
  
  public AndroidGameView(Context paramContext) throws Throwable {
    super(paramContext);
    if (getClass() == AndroidGameView.class)
      TypeManager.Activate("OpenTK.Platform.Android.AndroidGameView, OpenTK, Version=0.9.9.3, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "Android.Content.Context, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", this, new Object[] { paramContext }); 
  }
  
  public AndroidGameView(Context paramContext, AttributeSet paramAttributeSet) throws Throwable {
    super(paramContext, paramAttributeSet);
    if (getClass() == AndroidGameView.class)
      TypeManager.Activate("OpenTK.Platform.Android.AndroidGameView, OpenTK, Version=0.9.9.3, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "Android.Content.Context, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065:Android.Util.IAttributeSet, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", this, new Object[] { paramContext, paramAttributeSet }); 
  }
  
  public AndroidGameView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) throws Throwable {
    super(paramContext, paramAttributeSet, paramInt);
    if (getClass() == AndroidGameView.class)
      TypeManager.Activate("OpenTK.Platform.Android.AndroidGameView, OpenTK, Version=0.9.9.3, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "Android.Content.Context, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065:Android.Util.IAttributeSet, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065:System.Int32, mscorlib, Version=2.0.5.0, Culture=neutral, PublicKeyToken=7cec85d7bea7798e", this, new Object[] { paramContext, paramAttributeSet, Integer.valueOf(paramInt) }); 
  }
  
  private native void n_surfaceChanged(SurfaceHolder paramSurfaceHolder, int paramInt1, int paramInt2, int paramInt3);
  
  private native void n_surfaceCreated(SurfaceHolder paramSurfaceHolder);
  
  private native void n_surfaceDestroyed(SurfaceHolder paramSurfaceHolder);
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
  
  public void surfaceChanged(SurfaceHolder paramSurfaceHolder, int paramInt1, int paramInt2, int paramInt3) {
    n_surfaceChanged(paramSurfaceHolder, paramInt1, paramInt2, paramInt3);
  }
  
  public void surfaceCreated(SurfaceHolder paramSurfaceHolder) {
    n_surfaceCreated(paramSurfaceHolder);
  }
  
  public void surfaceDestroyed(SurfaceHolder paramSurfaceHolder) {
    n_surfaceDestroyed(paramSurfaceHolder);
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/opentk/platform/android/AndroidGameView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */