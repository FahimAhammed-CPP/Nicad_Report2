package opentk;

import android.content.Context;
import android.util.AttributeSet;
import android.view.SurfaceView;
import java.util.ArrayList;
import mono.android.IGCUserPeer;
import mono.android.Runtime;
import mono.android.TypeManager;

public abstract class GameViewBase extends SurfaceView implements IGCUserPeer {
  static final String __md_methods = "";
  
  ArrayList refList;
  
  static {
    Runtime.register("OpenTK.GameViewBase, OpenTK, Version=0.9.9.3, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", GameViewBase.class, __md_methods);
  }
  
  public GameViewBase(Context paramContext) throws Throwable {
    super(paramContext);
    if (getClass() == GameViewBase.class)
      TypeManager.Activate("OpenTK.GameViewBase, OpenTK, Version=0.9.9.3, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "Android.Content.Context, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", this, new Object[] { paramContext }); 
  }
  
  public GameViewBase(Context paramContext, AttributeSet paramAttributeSet) throws Throwable {
    super(paramContext, paramAttributeSet);
    if (getClass() == GameViewBase.class)
      TypeManager.Activate("OpenTK.GameViewBase, OpenTK, Version=0.9.9.3, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "Android.Content.Context, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065:Android.Util.IAttributeSet, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", this, new Object[] { paramContext, paramAttributeSet }); 
  }
  
  public GameViewBase(Context paramContext, AttributeSet paramAttributeSet, int paramInt) throws Throwable {
    super(paramContext, paramAttributeSet, paramInt);
    if (getClass() == GameViewBase.class)
      TypeManager.Activate("OpenTK.GameViewBase, OpenTK, Version=0.9.9.3, Culture=neutral, PublicKeyToken=84e04ff9cfb79065", "Android.Content.Context, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065:Android.Util.IAttributeSet, Mono.Android, Version=0.0.0.0, Culture=neutral, PublicKeyToken=84e04ff9cfb79065:System.Int32, mscorlib, Version=2.0.5.0, Culture=neutral, PublicKeyToken=7cec85d7bea7798e", this, new Object[] { paramContext, paramAttributeSet, Integer.valueOf(paramInt) }); 
  }
  
  public void monodroidAddReference(Object paramObject) {
    if (this.refList == null)
      this.refList = new ArrayList(); 
    this.refList.add(paramObject);
  }
  
  public void monodroidClearReferences() {
    if (this.refList != null)
      this.refList.clear(); 
  }
}


/* Location:              /home/fahim/Desktop/feabme1_Cowboy_Adventure-dex2jar.jar!/opentk/GameViewBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */